﻿Imports System.Windows.Forms
Imports Microsoft.Reporting.WinForms
Imports System.IO

Public Class FrmCuadre
    Dim mstrStringConection As String
    Dim mstrUsuario As String
    Dim mEfectivo As Integer
    Dim mDiferencia As Integer
    Dim mintIdCaja As Integer

    Sub New(ByVal strStringConection As String, ByVal intIdCaja As Integer, ByVal strUsuario As String, ByVal efectivo As Integer, ByVal diferencia As Integer)

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        mstrStringConection = strStringConection
        mstrUsuario = strUsuario
        mEfectivo = efectivo
        mDiferencia = diferencia
        mintIdCaja = intIdCaja

    End Sub

    Private Sub FrmCuadre_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim mResultado = dc.usp_ConsultarPagos(CType(mstrUsuario, Int32), mintIdCaja, 0)
            Dim mRes As New List(Of Object)

            For Each mR In mResultado
                mRes.Add(mR)
            Next

            If mRes.Count = 0 Then
                mResultado = dc.usp_ConsultarPagos(CType(mstrUsuario, Int32), mintIdCaja, 1)
                For Each mR In mResultado
                    mRes.Add(mR)
                Next

            End If

            BindingSource.DataSource = mRes

            Dim paramList As New Generic.List(Of ReportParameter)
            paramList.Add(New ReportParameter("Efectivo", mEfectivo))
            paramList.Add(New ReportParameter("Diferencia", mDiferencia))

            Me.ReportViewerCuadreCaja.LocalReport.SetParameters(paramList)
            Me.Dock = DockStyle.Fill
            Me.ReportViewerCuadreCaja.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Me.ReportViewerCuadreCaja.ZoomMode = ZoomMode.Percent
            Me.ReportViewerCuadreCaja.ZoomPercent = 100
            Me.ReportViewerCuadreCaja.RefreshReport()



        Catch ex As Exception

        End Try


        Me.ReportViewerCuadreCaja.RefreshReport()
    End Sub

    Private Sub EviarCorreoToolStripMenuItem_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub EnviarToolStripMenuItem_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Try

            'Me.ReportViewerCuadreCaja.LocalReport
            Dim exePath As String = System.IO.Path.GetDirectoryName(Application.ExecutablePath)
            Dim dir As New DirectoryInfo(System.IO.Path.Combine(exePath, "tmpDir"))
            Dim file As New FileInfo(System.IO.Path.Combine( _
                dir.FullName, String.Format("rptCuadreCaja_{0:yyyyMMdd_hhmmss}.pdf", DateTime.Now)))

            If Not dir.Exists Then
                dir.Create()
            End If

            Dim bytes As Byte() = Me.ReportViewerCuadreCaja.LocalReport.Render("PDF")

            Using fs As New System.IO.FileStream(file.FullName, System.IO.FileMode.Create)
                fs.Write(bytes, 0, bytes.Length)
                fs.Close()
            End Using

            Dim clsCorreo As ClsUtilidades.clsEnviarCorreo = New ClsUtilidades.clsEnviarCorreo()
            clsCorreo.EnvioMail("carlosalean@gmail.com", "carlosalean@gmail.com", "Cuadre de Caja", "Adjunto encontrará el cuadre de caja correspondiente", file.FullName)
        Catch ex As Exception

        End Try

    End Sub
End Class