﻿Imports Microsoft.Reporting.WinForms
Imports System.Windows.Forms
Imports System.IO

Public Class FrmItemsHCImprimir

  Dim mClsCreatePDF As ClsCreatePDF

  Public Sub New(ByVal pstrStringConection As String, ByVal arrCodigosCitasHC As Integer(,))

    ' Llamada necesaria para el Diseñador de Windows Forms.
    InitializeComponent()
    mClsCreatePDF = New ClsReportes.ClsCreatePDF(pstrStringConection, 0, 0, 0, String.Empty, Now, Now)

    Try
      Dim sNombreArchivo As String = String.Empty

      mClsCreatePDF.GenerarPDF(arrCodigosCitasHC, sNombreArchivo)
      If System.IO.File.Exists(sNombreArchivo) Then
        wbItemsSeleccionadoHC.Url = New System.Uri(sNombreArchivo)
      Else
        MsgBox("El archivo no fue generado, por favor intentelo de nuevo más tarde")
        'Hide()
      End If
    Catch ex As Exception
      MsgBox(String.Format("Error al crear la instacia de la clase, Exeption: {0}, Inner exeption: {1}.", ex.Message, ex.InnerException.ToString))
      'Hide()
    End Try
  End Sub
End Class