﻿Imports System.Windows.Forms

Public Class DialogProcedimientosEPS
    Public mFechaIncial As Date
    Public mFechaFinal As Date
    Public mEstadoCita As Integer

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        mFechaIncial = ClsDateTimePickerFechaI.Value
        mFechaFinal = ClsDateTimePickerFechaF.Value
        mEstadoCita = ClsComboBoxEstadoCita.SelectedIndex
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DialogProcedimientosEPS_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ClsComboBoxEstadoCita.SelectedIndex = 0
    End Sub
End Class
