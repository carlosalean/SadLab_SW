﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DialogGenerarRIPS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.OK_Button = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.ClsTextBoxRuta = New ClsUtilidades.ClsTextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.ButtonBuscarRuta = New System.Windows.Forms.Button
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog
        Me.ClsDateTimePickerFechaI = New ClsUtilidades.ClsDateTimePicker
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.ClsDateTimePickerFechaF = New ClsUtilidades.ClsDateTimePicker
        Me.CheckBoxArchivo81 = New System.Windows.Forms.CheckBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.rbOtro = New System.Windows.Forms.RadioButton
        Me.rbMP = New System.Windows.Forms.RadioButton
        Me.rbPos = New System.Windows.Forms.RadioButton
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(308, 121)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "Aceptar"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancelar"
        '
        'ClsTextBoxRuta
        '
        Me.ClsTextBoxRuta.DataSource = Nothing
        Me.ClsTextBoxRuta.Location = New System.Drawing.Point(135, 38)
        Me.ClsTextBoxRuta.Name = "ClsTextBoxRuta"
        Me.ClsTextBoxRuta.NombreCodigoF2 = Nothing
        Me.ClsTextBoxRuta.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxRuta.Size = New System.Drawing.Size(287, 20)
        Me.ClsTextBoxRuta.TabIndex = 3
        Me.ClsTextBoxRuta.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(14, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Ruta:"
        '
        'ButtonBuscarRuta
        '
        Me.ButtonBuscarRuta.Location = New System.Drawing.Point(429, 38)
        Me.ButtonBuscarRuta.Name = "ButtonBuscarRuta"
        Me.ButtonBuscarRuta.Size = New System.Drawing.Size(27, 23)
        Me.ButtonBuscarRuta.TabIndex = 4
        Me.ButtonBuscarRuta.Text = "..."
        Me.ButtonBuscarRuta.UseVisualStyleBackColor = True
        '
        'ClsDateTimePickerFechaI
        '
        Me.ClsDateTimePickerFechaI.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.ClsDateTimePickerFechaI.Location = New System.Drawing.Point(135, 12)
        Me.ClsDateTimePickerFechaI.Name = "ClsDateTimePickerFechaI"
        Me.ClsDateTimePickerFechaI.Size = New System.Drawing.Size(99, 20)
        Me.ClsDateTimePickerFechaI.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Fecha Inicio"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(276, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Fecha Final:"
        '
        'ClsDateTimePickerFechaF
        '
        Me.ClsDateTimePickerFechaF.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.ClsDateTimePickerFechaF.Location = New System.Drawing.Point(357, 12)
        Me.ClsDateTimePickerFechaF.Name = "ClsDateTimePickerFechaF"
        Me.ClsDateTimePickerFechaF.Size = New System.Drawing.Size(96, 20)
        Me.ClsDateTimePickerFechaF.TabIndex = 2
        '
        'CheckBoxArchivo81
        '
        Me.CheckBoxArchivo81.AutoSize = True
        Me.CheckBoxArchivo81.Location = New System.Drawing.Point(135, 64)
        Me.CheckBoxArchivo81.Name = "CheckBoxArchivo81"
        Me.CheckBoxArchivo81.Size = New System.Drawing.Size(15, 14)
        Me.CheckBoxArchivo81.TabIndex = 4
        Me.CheckBoxArchivo81.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(108, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Generar Archivo (81):"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbOtro)
        Me.GroupBox1.Controls.Add(Me.rbMP)
        Me.GroupBox1.Controls.Add(Me.rbPos)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 86)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(276, 64)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tipo Prestación"
        '
        'rbOtro
        '
        Me.rbOtro.AutoSize = True
        Me.rbOtro.Location = New System.Drawing.Point(26, 41)
        Me.rbOtro.Name = "rbOtro"
        Me.rbOtro.Size = New System.Drawing.Size(45, 17)
        Me.rbOtro.TabIndex = 18
        Me.rbOtro.Text = "Otro"
        Me.rbOtro.UseVisualStyleBackColor = True
        '
        'rbMP
        '
        Me.rbMP.AutoSize = True
        Me.rbMP.Location = New System.Drawing.Point(91, 19)
        Me.rbMP.Name = "rbMP"
        Me.rbMP.Size = New System.Drawing.Size(123, 17)
        Me.rbMP.TabIndex = 17
        Me.rbMP.Text = "Medicina Prepagada"
        Me.rbMP.UseVisualStyleBackColor = True
        '
        'rbPos
        '
        Me.rbPos.AutoSize = True
        Me.rbPos.Checked = True
        Me.rbPos.Location = New System.Drawing.Point(26, 19)
        Me.rbPos.Name = "rbPos"
        Me.rbPos.Size = New System.Drawing.Size(47, 17)
        Me.rbPos.TabIndex = 16
        Me.rbPos.TabStop = True
        Me.rbPos.Text = "POS"
        Me.rbPos.UseVisualStyleBackColor = True
        '
        'DialogGenerarRIPS
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(466, 157)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.CheckBoxArchivo81)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ClsDateTimePickerFechaF)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ClsDateTimePickerFechaI)
        Me.Controls.Add(Me.ButtonBuscarRuta)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ClsTextBoxRuta)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DialogGenerarRIPS"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Generar RIPS"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents ClsTextBoxRuta As ClsUtilidades.ClsTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ButtonBuscarRuta As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents ClsDateTimePickerFechaI As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ClsDateTimePickerFechaF As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents CheckBoxArchivo81 As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbOtro As System.Windows.Forms.RadioButton
    Friend WithEvents rbMP As System.Windows.Forms.RadioButton
    Friend WithEvents rbPos As System.Windows.Forms.RadioButton

End Class
