﻿Imports System.Windows.Forms
Imports Microsoft.Reporting.WinForms

Public Class FrmServiciosPrestados
    Dim mstrStringConection As String
    Dim mdtmFechaInicial As Date
    Dim mdtmFechaFinal As Date
    Dim mIdPrestador As Object
    Dim mDatos As String
    Dim mstrUsuario As String


    Public Sub New(ByVal strStringConection As String, ByVal dtmFechaInicial As Date, ByVal dtmFechaFinal As Date, ByVal strUsuario As String, ByVal IdPrestador As Object, ByVal strDatos As String)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        mstrStringConection = strStringConection
        mdtmFechaInicial = dtmFechaInicial
        mdtmFechaFinal = dtmFechaFinal
        mstrUsuario = strUsuario
        mIdPrestador = IdPrestador
        mDatos = strDatos

    End Sub

    Private Sub FrmServiciosPrestados_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            'variable de tipo conexion
            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            dc.CommandTimeout = 600
            'Obtengo los resultados del procedimiento almacenado
            Dim mResultado = dc.usp_rptServiciosPrestados(mIdPrestador, mdtmFechaInicial, mdtmFechaFinal, mDatos)

            'Creo una lista de tipo objetos
            Dim mRes As New List(Of Object)

            'Recorrer la variable donde estan almacenados los datos y agregarlos a lista de tipo object
            For Each mR In mResultado
                mRes.Add(mR)
            Next

            BindingSource.DataSource = mRes

            Dim paramList As New Generic.List(Of ReportParameter)
            paramList.Add(New ReportParameter("FechaInicial", mdtmFechaInicial))
            paramList.Add(New ReportParameter("FechaFinal", mdtmFechaFinal))
            paramList.Add(New ReportParameter("strUsuario", mstrUsuario))

            Me.ReportViewer1.LocalReport.SetParameters(paramList)
            Me.Dock = DockStyle.Fill
            Me.ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Me.ReportViewer1.ZoomMode = ZoomMode.Percent
            Me.ReportViewer1.ZoomPercent = 100
            Me.ReportViewer1.RefreshReport()

        Catch ex As Exception
            'MsgBox(ex.ToString)
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class