﻿Imports System.Windows.Forms

Public Class DialogGenerarFacturacion
    Dim mstrStringConection As String

    Public mFechaIncial As Date
    Public mFechaFinal As Date
    Public mIdPrestador As Integer
    Public mIdEPS As Integer

    Sub New(ByVal strStringConection As String)
        Try
            ' Llamada necesaria para el Diseñador de Windows Forms.
            InitializeComponent()
            mstrStringConection = strStringConection

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub DialogGenerarFacturacion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ClsDateTimePickerFechaI.Value = Now.Date
            ClsDateTimePickerFechaF.Value = Now.Date

            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            TblDatosPrestadoresBindingSource.DataSource = dc.tblDatosPrestadores
            TblEPsBindingSource.DataSource = dc.tblEPs
        Catch ex As Exception

        End Try
    End Sub

    Private Sub OK_Button_Click(sender As Object, e As EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        mFechaIncial = ClsDateTimePickerFechaI.Value
        mFechaFinal = ClsDateTimePickerFechaF.Value
        mIdPrestador = TblDatosPrestadoresBindingSource.Item(TblDatosPrestadoresBindingSource.Position).intIdPrestadores
        mIdEPS = TblEPsBindingSource.Item(TblEPsBindingSource.Position).intIdEPS

        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(sender As Object, e As EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

End Class