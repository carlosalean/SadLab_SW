﻿Imports System.Windows.Forms

Public Class DialogPrestacionServicios
    Dim mstrStringConection As String
    Public mintIdCaja As Object
    Public mintIdPrestador As Object
    Public mFechaIncial As Date
    Public mFechaFinal As Date
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Sub New(ByVal strStringConection As String, ByVal IdCaja As String)

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()
        mstrStringConection = strStringConection
        mintIdCaja = IdCaja

    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        mFechaIncial = ClsDateTimePickerFechaInicial.Value
        mFechaFinal = ClsDateTimePickerFechaFinal.Value
        mintIdCaja = IIf(ClsCheckBox1.Checked, Nothing, ClsComboBoxCaja.SelectedValue)
        mintIdPrestador = ClsComboBoxPrestador.SelectedValue
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DialogPrestacionServicios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

            ClsComboBoxPrestador.DataSource = dc.tblDatosPrestadores
            ClsComboBoxCaja.DataSource = dc.tblCajas
            ClsDateTimePickerFechaInicial.Value = Now
            ClsDateTimePickerFechaFinal.Value = Now

            If mintIdCaja = Nothing Then
                ClsComboBoxCaja.SelectedIndex = 0
            Else
                ClsComboBoxCaja.SelectedValue = mintIdCaja
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try


    End Sub

    Private Sub ClsCheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClsCheckBox1.CheckedChanged
        ClsComboBoxCaja.Enabled = (Not ClsCheckBox1.Checked)
    End Sub
End Class
