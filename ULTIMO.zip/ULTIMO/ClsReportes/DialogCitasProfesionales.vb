﻿Imports System.Windows.Forms

Public Class DialogCitasProfesionales
    Dim mstrStringConection As String

    Public mFechaIncial As Date
    Public mFechaFinal As Date
    Public mEstadoCita As Integer
    Public mIdProfesional As Integer
    Public mSede As Integer

    Sub New(ByVal strStringConection As String)
        Try
            ' Llamada necesaria para el Diseñador de Windows Forms.
            InitializeComponent()
            mstrStringConection = strStringConection

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        mFechaIncial = ClsDateTimePickerFechaI.Value
        mFechaFinal = ClsDateTimePickerFechaF.Value
        mEstadoCita = ClsComboBoxEstadoCita.SelectedIndex
        mIdProfesional = TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).intIdCodigoEmpleado

        If Not CheckBoxSedes.Checked Then
            mSede = ClsComboBoxSedes.SelectedValue
        End If

        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DialogCitasProfesionales_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ClsComboBoxEstadoCita.SelectedIndex = 0

        ClsDateTimePickerFechaI.Value = Now.Date
        ClsDateTimePickerFechaF.Value = Now.Date

        Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
        TblEmpeadoBindingSource.DataSource = dc.tblEmpeados

        ClsComboBoxSedes.DataSource = dc.tblSedes
        ClsComboBoxSedes.DisplayMember = "strNombreSede"
        ClsComboBoxSedes.ValueMember = "intIdSede"
        ClsComboBoxSedes.SelectedIndex = 0
    End Sub

    Private Sub CheckBoxSedes_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxSedes.CheckedChanged
        If CheckBoxSedes.Checked = True Then
            ClsComboBoxSedes.Enabled = False
        Else
            ClsComboBoxSedes.Enabled = True
        End If
    End Sub

End Class
