﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGenerarRIPS
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbPrestadores = New System.Windows.Forms.ComboBox()
        Me.lblPrestadores = New System.Windows.Forms.Label()
        Me.lblFechaFinal = New System.Windows.Forms.Label()
        Me.dpFechaFinal = New ClsUtilidades.ClsDateTimePicker()
        Me.lblFechaInicio = New System.Windows.Forms.Label()
        Me.dpFechaInicio = New ClsUtilidades.ClsDateTimePicker()
        Me.btnAceptar = New System.Windows.Forms.Button()
        Me.btnCancelar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cmbPrestadores
        '
        Me.cmbPrestadores.DisplayMember = "strRazonSocial"
        Me.cmbPrestadores.FormattingEnabled = True
        Me.cmbPrestadores.Location = New System.Drawing.Point(97, 17)
        Me.cmbPrestadores.Name = "cmbPrestadores"
        Me.cmbPrestadores.Size = New System.Drawing.Size(270, 21)
        Me.cmbPrestadores.TabIndex = 41
        Me.cmbPrestadores.ValueMember = "intIdPrestadores"
        '
        'lblPrestadores
        '
        Me.lblPrestadores.AutoSize = True
        Me.lblPrestadores.Location = New System.Drawing.Point(30, 20)
        Me.lblPrestadores.Name = "lblPrestadores"
        Me.lblPrestadores.Size = New System.Drawing.Size(63, 13)
        Me.lblPrestadores.TabIndex = 40
        Me.lblPrestadores.Text = "Prestadores"
        '
        'lblFechaFinal
        '
        Me.lblFechaFinal.AutoSize = True
        Me.lblFechaFinal.Location = New System.Drawing.Point(205, 50)
        Me.lblFechaFinal.Name = "lblFechaFinal"
        Me.lblFechaFinal.Size = New System.Drawing.Size(62, 13)
        Me.lblFechaFinal.TabIndex = 39
        Me.lblFechaFinal.Text = "Fecha Final"
        '
        'dpFechaFinal
        '
        Me.dpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dpFechaFinal.Location = New System.Drawing.Point(271, 46)
        Me.dpFechaFinal.Name = "dpFechaFinal"
        Me.dpFechaFinal.Size = New System.Drawing.Size(96, 20)
        Me.dpFechaFinal.TabIndex = 37
        '
        'lblFechaInicio
        '
        Me.lblFechaInicio.AutoSize = True
        Me.lblFechaInicio.Location = New System.Drawing.Point(30, 48)
        Me.lblFechaInicio.Name = "lblFechaInicio"
        Me.lblFechaInicio.Size = New System.Drawing.Size(65, 13)
        Me.lblFechaInicio.TabIndex = 38
        Me.lblFechaInicio.Text = "Fecha Inicio"
        '
        'dpFechaInicio
        '
        Me.dpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dpFechaInicio.Location = New System.Drawing.Point(97, 46)
        Me.dpFechaInicio.Name = "dpFechaInicio"
        Me.dpFechaInicio.Size = New System.Drawing.Size(97, 20)
        Me.dpFechaInicio.TabIndex = 36
        '
        'btnAceptar
        '
        Me.btnAceptar.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnAceptar.Location = New System.Drawing.Point(116, 84)
        Me.btnAceptar.Name = "btnAceptar"
        Me.btnAceptar.Size = New System.Drawing.Size(67, 23)
        Me.btnAceptar.TabIndex = 34
        Me.btnAceptar.Text = "Aceptar"
        '
        'btnCancelar
        '
        Me.btnCancelar.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancelar.Location = New System.Drawing.Point(202, 84)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(67, 23)
        Me.btnCancelar.TabIndex = 35
        Me.btnCancelar.Text = "Cancelar"
        '
        'frmGenerarRIPS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(394, 123)
        Me.Controls.Add(Me.cmbPrestadores)
        Me.Controls.Add(Me.lblPrestadores)
        Me.Controls.Add(Me.lblFechaFinal)
        Me.Controls.Add(Me.dpFechaFinal)
        Me.Controls.Add(Me.lblFechaInicio)
        Me.Controls.Add(Me.dpFechaInicio)
        Me.Controls.Add(Me.btnAceptar)
        Me.Controls.Add(Me.btnCancelar)
        Me.Name = "frmGenerarRIPS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Generar archivo RIPS"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbPrestadores As System.Windows.Forms.ComboBox
  Friend WithEvents lblPrestadores As System.Windows.Forms.Label
  Friend WithEvents lblFechaFinal As System.Windows.Forms.Label
  Friend WithEvents dpFechaFinal As ClsUtilidades.ClsDateTimePicker
  Friend WithEvents lblFechaInicio As System.Windows.Forms.Label
  Friend WithEvents dpFechaInicio As ClsUtilidades.ClsDateTimePicker
  Friend WithEvents btnAceptar As System.Windows.Forms.Button
  Friend WithEvents btnCancelar As System.Windows.Forms.Button
End Class
