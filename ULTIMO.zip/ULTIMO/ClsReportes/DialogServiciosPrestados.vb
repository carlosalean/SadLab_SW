﻿Imports System.Windows.Forms
Imports System.IO

Public Class DialogServiciosPrestacion
    Dim mstrStringConection As String
    Public mintIdPrestador As Object
    Public mFechaIncial As Date
    Public mFechaFinal As Date
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mstrIntIdUsuario As String
    Public mDatosDescuento As String = ""

    Sub New(ByVal strStringConection As String, ByVal IdCaja As String, ByVal strIntIdUsuario As String)

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()
        mstrStringConection = strStringConection
        mstrIntIdUsuario = strIntIdUsuario
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        mFechaIncial = ClsDateTimePickerFechaInicial.Value
        mFechaFinal = ClsDateTimePickerFechaFinal.Value
        mintIdPrestador = ClsComboBoxPrestador.SelectedValue
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DialogPrestacionServicios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

            ClsComboBoxPrestador.DataSource = dc.tblDatosPrestadores
            ClsDateTimePickerFechaInicial.Value = Now
            ClsDateTimePickerFechaFinal.Value = Now


        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try


    End Sub

    Private Sub DialogServiciosPrestacion_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
        If e.Alt Then
            If e.KeyCode = Keys.F10 Then
                Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
                Dim mClaveIngreso
                If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then
                    Dim mstrClave = dc.usp_ClaveSuperUsuario(mValidaHuella.mstrIntIdUsuario)
                    Dim mDlgClaveSuperUsuario As New DlgClaveSuperUsuario()
                    If mDlgClaveSuperUsuario.ShowDialog = Windows.Forms.DialogResult.OK Then
                        mClaveIngreso = mDlgClaveSuperUsuario.strClave
                        If mstrClave(0).strClaveSuperUsuario = mClaveIngreso Then
                            If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                                Dim objStreamReader As StreamReader
                                Dim mclsCodificar As New clsCodificaciones
                                Dim mLinea As String

                                objStreamReader = New StreamReader(OpenFileDialog1.SafeFileName)
                                mLinea = objStreamReader.ReadLine
                                mDatosDescuento = mclsCodificar.FnDecodifica(mLinea)
                                Do While (Not mLinea Is Nothing)
                                    mLinea = objStreamReader.ReadLine
                                    If Not (mLinea Is Nothing) Then
                                        mDatosDescuento = mDatosDescuento & "|" & mclsCodificar.FnDecodifica(mLinea)
                                    End If
                                Loop
                                'mDatosDescuento = mLinea
                                objStreamReader.Close()

                            End If
                            'NumValorAdminClsTextBox.Visible = True
                        Else
                            MsgBox("La clave es incorrecta..")
                        End If
                    End If
                End If
            End If
        End If
    End Sub
End Class
