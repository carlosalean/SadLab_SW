﻿Imports System.IO

Public Class ClsExportacionRIPS
    Dim mstrStringConection As String
    Public mNroFactura As String
    Dim CountUS As Integer = 0
    Dim CountAC As Integer = 0
    Dim CountAP As Integer = 0
    Dim mValorDescuento As Integer
    Dim strEsPOS As String

    Public Sub New(ByVal strStringConection As String, ByVal pNroFactura As String, ByVal pstrEsPOS As String)
        ' Add any initialization after the InitializeComponent() call.
        mstrStringConection = strStringConection
        mNroFactura = pNroFactura
        strEsPOS = pstrEsPOS
    End Sub

    Public Sub PrExportarArchivosRIPS(ByVal intIDPrestador As Integer, ByVal strRuta As String, ByVal mFechaI As Date, ByVal mFechaF As Date, ByVal bitArchivo81 As Boolean)
        Try
            PrGenerarArchivoAF(intIDPrestador, strRuta, mFechaI, mFechaF)
            PrGenerarArchivoUS(intIDPrestador, strRuta)
            PrGenerarArchivoAC(intIDPrestador, strRuta)
            PrGenerarArchivoAP(intIDPrestador, strRuta)
            PrGenerarArchivoAD(intIDPrestador, strRuta)
            If bitArchivo81 = True Then
                PrGenerarArchivo81(intIDPrestador, strRuta)
            End If
            PrGenerarArchivoCT(intIDPrestador, strRuta)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Public Sub PrGenerarArchivo81(ByVal intIDPrestador As Integer, ByVal strRuta As String)
        Try

            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim tblPrestadores = (From p In dc.tblDatosPrestadores Where p.intIdPrestadores = intIDPrestador Select p).Single
            'Dim tmpFacturas = (From f In dc.tblFacturacions Where f.strNroFactura.Trim() = mNroFactura.Trim() And f.intIdPrestador = intIDPrestador Select f)
            'Dim tblFacturas As New List(Of Object)
            'For Each tblFac In tmpFacturas
            '    tblFacturas.Add(tblFac)
            'Next
            FileOpen(1, strRuta & "\" & tblPrestadores.strNroDeID & ".txt", OpenMode.Output)
            Dim mLines As String
            Dim mRegisrtrosErrados As String
            mRegisrtrosErrados = ""
            'Dim mValorCooPago As Integer
            'Dim mValorDescuento As Integer
            'Dim mValorNeto As Integer

            'mValorCooPago = dc.usp_ValorCoopagoFactura(mNroFactura, intIDPrestador)
            'mValorDescuento = dc.usp_ValorDescuentoFactura(mNroFactura, intIDPrestador)
            'mValorNeto = dc.usp_ValorFactura(mNroFactura, intIDPrestador)
            'If CountAP > 0 Then
            '    mLines = "0" & CountAP.ToString().PadLeft(2, "0") & "000001" & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "001" & tblPrestadores.strTipoDeID & tblPrestadores.strNroDeID.PadLeft(15, "0") & tblPrestadores.intCodigoVerificacion
            '    PrintLine(1, mLines)
            '    mLines = "1" & "0" & "000001" & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "      " & mNroFactura.PadLeft(10, "0") & mValorNeto.ToString().PadLeft(12, "0") & "0000000000" & "0000000000" & mValorCooPago.ToString().PadLeft(10, "0") & "0000000000" & mValorDescuento.ToString().PadLeft(10, "0") & "1"
            '    PrintLine(1, mLines)

            '    Dim tblProcedimientos = dc.usp_ProcedimientosRIPS(mNroFactura, intIDPrestador)
            '    Dim mConteo As Integer = 0
            '    For Each tblProcedimiento In tblProcedimientos
            '        mConteo = mConteo + 1
            '        If mConteo = 75 Then
            '            mLines = "2" & tblProcedimiento.strNroFactura.ToString().PadLeft(10, "0") & tblProcedimiento.strNroOrden.PadLeft(8, "0") & tblProcedimiento.TipoDocumento & tblProcedimiento.strNroIdentificacion.PadLeft(12, "0") & tblProcedimiento.dtmFecha.ToString("dd/MM/yyyy") & "01" & tblProcedimiento.strCodigoProcedimiento.PadLeft(7, "0") & "001" & "0000000" & "000" & tblProcedimiento.numValorUnitario.ToString().PadLeft(12, "0") & "0000000"
            '        End If
            '        mLines = "2" & tblProcedimiento.strNroFactura.ToString().PadLeft(10, "0") & tblProcedimiento.strNroOrden.PadLeft(8, "0") & tblProcedimiento.TipoDocumento & tblProcedimiento.strNroIdentificacion.PadLeft(12, "0") & tblProcedimiento.dtmFecha.ToString("dd/MM/yyyy") & "01" & tblProcedimiento.strCodigoProcedimiento.PadLeft(7, "0") & "001" & "0000000" & "000" & tblProcedimiento.numValorUnitario.ToString().PadLeft(12, "0") & "0000000"
            '        PrintLine(1, mLines)
            '    Next
            'Else
            'mLines = "0" & CountAC.ToString().PadLeft(2, "0") & "000001" & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "001" & tblPrestadores.strTipoDeID & tblPrestadores.strNroDeID.PadLeft(15, "0") & tblPrestadores.intCodigoVerificacion
            '    PrintLine(1, mLines)
            '    mLines = "1" & "0" & "000001" & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "      " & mNroFactura.PadLeft(10, "0") & mValorNeto.ToString().PadLeft(12, "0") & "0000000000" & "0000000000" & mValorCooPago.ToString().PadLeft(10, "0") & "0000000000" & mValorDescuento.ToString().PadLeft(10, "0") & "2"
            '    PrintLine(1, mLines)
            Dim tblConsultas = dc.z_uspGenerarInformacionRIPS(mNroFactura)
            For Each tblConsulta In tblConsultas
                mLines = tblConsulta.linea.ToString() '"2" & tblConsulta.strNroFactura.ToString().PadLeft(10, "0") & tblConsulta.strNroOrden.PadLeft(8, "0") & tblConsulta.TipoDocumento & tblConsulta.strNroIdentificacion.PadLeft(12, "0") & tblConsulta.dtmFecha.ToString("dd/MM/yyyy") & "01" & tblConsulta.COdigoConsulta.PadLeft(7, "0") & "001" & "0000000" & "000" & tblConsulta.numValorUnitario.ToString().PadLeft(12, "0") & "0000000"
                PrintLine(1, mLines)
                If mLines.Contains("NULL") Or mLines.Contains("Null") Or mLines.Contains("null") Then
                    mRegisrtrosErrados = mRegisrtrosErrados + Integer.Parse(mLines.Substring(29, 11)).ToString() + ", "
                End If
            Next
            'End If
            If mRegisrtrosErrados.Length > 0 Then
                Windows.Forms.MessageBox.Show("Existen registros inconsistentes: " + mRegisrtrosErrados)
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        Finally
            FileClose(1)
        End Try
    End Sub

    Private Sub PrGenerarArchivoCT(ByVal intIDPrestador As Integer, ByVal strRuta As String)
        Try

            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim tblPrestadores = (From p In dc.tblDatosPrestadores Where p.intIdPrestadores = intIDPrestador Select p).Single
            Dim tmpFacturas = (From f In dc.tblFacturacions Where f.strNroFactura.Trim() = mNroFactura.Trim() And f.intIdPrestador = intIDPrestador Select f)
            Dim tblFacturas As New List(Of Object)
            For Each tblFac In tmpFacturas
                tblFacturas.Add(tblFac)
            Next
            FileOpen(1, strRuta & "\CT" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & ".txt", OpenMode.Output)
            Dim mLines As String


            mLines = tblPrestadores.strCodigoPrestadorServicio & "," & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "," & "AF" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & ",1"
            PrintLine(1, mLines)

            mLines = tblPrestadores.strCodigoPrestadorServicio & "," & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "," & "US" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & "," & CountUS.ToString()
            PrintLine(1, mLines)

            If CountAC > 0 Then
                mLines = tblPrestadores.strCodigoPrestadorServicio & "," & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "," & "AC" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & "," & CountAC.ToString
                PrintLine(1, mLines)
            End If

            If CountAP > 0 Then
                mLines = tblPrestadores.strCodigoPrestadorServicio & "," & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "," & "AP" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & "," & CountAP.ToString
                PrintLine(1, mLines)
            End If

            mLines = tblPrestadores.strCodigoPrestadorServicio & "," & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "," & "AD" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & ",1"
            PrintLine(1, mLines)

            tblPrestadores.intIDConsecutivo = tblPrestadores.intIDConsecutivo + 1
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        Finally
            FileClose(1)
        End Try
    End Sub

    Private Sub PrGenerarArchivoAD(ByVal intIDPrestador As Integer, ByVal strRuta As String)
        Try

            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim tblPrestadores = (From p In dc.tblDatosPrestadores Where p.intIdPrestadores = intIDPrestador Select p).Single
            If tblPrestadores.bitRealizaConsultas = True Then
                Dim tblConsultas = dc.usp_ConsultasRIPS(mNroFactura, intIDPrestador)
                FileOpen(1, strRuta & "\AD" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & ".txt", OpenMode.Output)
                Dim mLines As String
                Dim mCantidad As Integer = 0
                Dim mValorUnitario As Double = 0
                Dim mValorTotal As Double = 0

                For Each tblConsulta In tblConsultas
                    mCantidad = mCantidad + 1
                    mValorTotal = mValorTotal + tblConsulta.numValorUnitario
                Next
                mLines = mNroFactura & "," & tblPrestadores.strCodigoPrestadorServicio & "," & "01" & "," & mCantidad.ToString & "," & Math.Round((mValorTotal / mCantidad)).ToString() & "," & mValorTotal.ToString()
                PrintLine(1, mLines)
                FileClose(1)
            Else
                Dim tblProcedimientos = dc.usp_ProcedimientosRIPS(mNroFactura, intIDPrestador)

                FileOpen(1, strRuta & "\AD" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & ".txt", OpenMode.Output)

                Dim mLines As String
                Dim mCantidad As Integer = 0
                Dim mValorUnitario As Double = 0
                Dim mValorTotal As Double = 0

                For Each tblProcedimiento In tblProcedimientos
                    mCantidad = mCantidad + 1
                    mValorTotal = mValorTotal + tblProcedimiento.numValorUnitario
                Next
                mLines = mNroFactura & "," & tblPrestadores.strCodigoPrestadorServicio & "," & "02" & "," & mCantidad.ToString & "," & (mValorTotal / mCantidad).ToString() & "," & mValorTotal.ToString()
                PrintLine(1, mLines)
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        Finally
            FileClose(1)
        End Try
    End Sub

    Public Sub PrGenerarArchivoAC(ByVal intIDPrestador As Integer, ByVal strRuta As String)
        Try

            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim tblPrestadores = (From p In dc.tblDatosPrestadores Where p.intIdPrestadores = intIDPrestador Select p).Single
            'If tblPrestadores.bitRealizaConsultas = True Then
            Dim tblConsultas = dc.usp_ConsultasRIPS(mNroFactura, intIDPrestador)


            Dim mLines As String
            Dim i As Integer = 0

            For Each tblConsulta In tblConsultas
                If tblConsulta.strTipoProcedimiento = "Consulta" Then
                    If i = 0 Then
                        FileOpen(1, strRuta & "\AC" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & ".txt", OpenMode.Output)
                    End If
                    mLines = tblConsulta.strNroFactura & "," & tblPrestadores.strCodigoPrestadorServicio & "," & tblConsulta.TipoDocumento & "," & tblConsulta.strNroIdentificacion & "," & tblConsulta.dtmFecha.ToString("dd/MM/yyyy") & "," & tblConsulta.strNroOrden & "," & tblConsulta.COdigoConsulta & "," & tblConsulta.Finalidad & ",15," & tblConsulta.DiagNosticoPrincipal & "," & tblConsulta.DiagnosticoRelacionadoN1 & "," & tblConsulta.DiagnosticoRelacionadoN2 & "," & tblConsulta.DiagnosticoRelacionadoN3 & "," & tblConsulta.TipoDiag & "," & tblConsulta.numValorUnitario & "," & tblConsulta.numValorCoopago & "," & tblConsulta.ValorNeto
                    PrintLine(1, mLines)
                    CountAC = CountAC + 1
                    i = i + 1
                End If
            Next
            'End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        Finally
            FileClose(1)
        End Try
    End Sub

    Public Sub PrGenerarArchivoAP(ByVal intIDPrestador As Integer, ByVal strRuta As String)
        Try

            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim tblPrestadores = (From p In dc.tblDatosPrestadores Where p.intIdPrestadores = intIDPrestador Select p).Single
            'If tblPrestadores.bitRealizaConsultas = False Or tblPrestadores.bitRealizaConsultas = Nothing Then
            Dim tblProcedimientos = dc.usp_ProcedimientosRIPS(mNroFactura, intIDPrestador)


            Dim mLines As String
            Dim i As Integer = 0

            For Each tblProcedimiento In tblProcedimientos
                If tblProcedimiento.strTipoProcedimiento = "Terapia" Or tblProcedimiento.strTipoProcedimiento = "Examen" Then
                    If i = 0 Then
                        FileOpen(1, strRuta & "\AP" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & ".txt", OpenMode.Output)
                    End If
                    mLines = tblProcedimiento.strNroFactura & "," & tblPrestadores.strCodigoPrestadorServicio & "," & tblProcedimiento.TipoDocumento & "," & tblProcedimiento.strNroIdentificacion & "," & tblProcedimiento.dtmFecha.ToString("dd/MM/yyyy") & "," & tblProcedimiento.strNroOrden & "," & tblProcedimiento.strCodigoProcedimiento & "," & tblProcedimiento.Ambito & "," & tblProcedimiento.Finalidad & "," & tblProcedimiento.PersonalAtiende & "," & tblProcedimiento.DiagNosticoPrincipal & "," & tblProcedimiento.DiagnosticoPos & "," & tblProcedimiento.Complicacion & "," & tblProcedimiento.Forma & "," & tblProcedimiento.numValorUnitario
                    PrintLine(1, mLines)
                    CountAP = CountAP + 1
                    i = i + 1
                End If
            Next
            'End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        Finally
            FileClose(1)
        End Try
    End Sub

    Public Sub PrGenerarArchivoUS(ByVal intIDPrestador As Integer, ByVal strRuta As String)
        Try

            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim tblPrestadores = (From p In dc.tblDatosPrestadores Where p.intIdPrestadores = intIDPrestador Select p).Single
            FileOpen(1, strRuta & "\US" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & ".txt", OpenMode.Output)
            Dim tblPacientes = dc.usp_PacientesFactura(mNroFactura, intIDPrestador)

            Dim mLines As String
            For Each tblPaciente In tblPacientes
                mLines = tblPaciente.TipoDocumento & "," & tblPaciente.strNroIdentificacion & "," & tblPaciente.strCodigoEPS & "," & tblPaciente.TipoUsuario & "," & tblPaciente.strPrimerApellido & "," & tblPaciente.strSegundoApellido & "," & tblPaciente.strPrimerNombre & "," & tblPaciente.strSegundoNombre & "," & tblPaciente.intEdad & "," & tblPaciente.MedidaEdad & "," & tblPaciente.Sexo & "," & tblPaciente.strDepartamento & "," & tblPaciente.Municipio & "," & tblPaciente.ZonaResidencial
                PrintLine(1, mLines)
                CountUS = CountUS + 1
            Next
            If CountUS = 0 Then
                MsgBox("Al paciente le faltan datos, por favor verifique..")
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        Finally
            FileClose(1)
        End Try
    End Sub


    Public Sub PrGenerarArchivoAF(ByVal intIDPrestador As Integer, ByVal strRuta As String, ByVal mFechaI As Date, ByVal mFechaF As Date)
        Try

            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim tblPrestadores = (From p In dc.tblDatosPrestadores Where p.intIdPrestadores = intIDPrestador Select p).Single
            Dim tmpFacturas = (From f In dc.tblFacturacions Where f.strNroFactura.Trim() = mNroFactura.Trim() And f.intIdPrestador = intIDPrestador Select f)
            Dim tblFacturas As New List(Of Object)
            For Each tblFac In tmpFacturas
                tblFacturas.Add(tblFac)
            Next
            FileOpen(1, strRuta & "\AF" & tblPrestadores.intIDConsecutivo.ToString().PadLeft(6, "0") & ".txt", OpenMode.Output)
            Dim mLines As String
            Dim mValorCooPago As Integer
            Dim mValorDescuento As Integer
            Dim mValorNeto As Integer

            mValorCooPago = dc.usp_ValorCoopagoFactura(mNroFactura, intIDPrestador)
            mValorDescuento = dc.usp_ValorDescuentoFactura(mNroFactura, intIDPrestador)
            mValorNeto = dc.usp_ValorFactura(mNroFactura, intIDPrestador)

            mLines = tblPrestadores.strCodigoPrestadorServicio & "," & tblPrestadores.strRazonSocial & "," & tblPrestadores.strTipoDeID & "," & tblPrestadores.strNroDeID & "," & mNroFactura & "," & CType(tblFacturas(0).dtmFechaFactura, Date).ToString("dd/MM/yyyy") & "," & mFechaI.ToString("dd/MM/yyyy") & "," & mFechaF.ToString("dd/MM/yyyy") & "," & tblFacturas(0).strCodigoEPS & "," & tblFacturas(0).strNombreEPS & ",," & strEsPOS & ",," & IIf(mValorCooPago.ToString() = "0", "", mValorCooPago.ToString()) & ",," & IIf(mValorDescuento.ToString() = "0", "", mValorDescuento.ToString()) & "," & mValorNeto.ToString()
            PrintLine(1, mLines)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        Finally
            FileClose(1)
        End Try
    End Sub

End Class
