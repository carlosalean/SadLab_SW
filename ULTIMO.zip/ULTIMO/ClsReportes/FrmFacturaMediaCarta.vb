﻿Imports Microsoft.Reporting.WinForms
Imports System.Windows.Forms

Public Class FrmFacturaMediaCarta
    Dim mstrStringConection As String
    Dim mintIdCita As Integer
    Dim numLetras As String
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mbitAnulada As Boolean

    Public Sub New(ByVal strStringConection As String, ByVal intIdCita As Integer, Optional ByRef mAnulada As Boolean = False)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()
        Try
            mstrStringConection = strStringConection
            mintIdCita = intIdCita
            mbitAnulada = mAnulada

            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
        Catch ex As Exception
            MsgBox("No existe pago registrado para generar la factura", MsgBoxStyle.Information, "Generar Factura")
            Me.Close()
        End Try
    End Sub


    Private Sub FrmReciboCaja_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim mEsCompia As Boolean = False
            Try
                Dim mCopia = (From C In dc.tblPagos Where C.intIdCita = mintIdCita And C.intNroFactura IsNot Nothing Select C)
                If mCopia.Count > 0 Then
                    mEsCompia = True
                End If
            Catch ex As Exception
                mEsCompia = False
            End Try

            If mbitAnulada = True Then
                mEsCompia = mbitAnulada
            Else
                Try
                    Dim mCopia = (From C In dc.tblPagos Where C.intIdCita = mintIdCita And C.bitAnulado = True Select C)
                    If mCopia.Count > 0 Then
                        mbitAnulada = True
                        mEsCompia = mbitAnulada
                    End If
                Catch ex As Exception
                    'No hace nada
                End Try
            End If

            Dim mResultado = dc.usp_rptFacturaMediaCarta(mintIdCita, mEsCompia, mbitAnulada)
            Dim mRes As New List(Of Object)

            For Each mR In mResultado
                mRes.Add(mR)
            Next

            BindingSource.DataSource = mRes
            Dim mUtilidades As New ClsUtilidades.ClsConvertirLetras()
            numLetras = BindingSource.Item(0).numValorPagado().ToString

            Dim paramList As New Generic.List(Of ReportParameter)
            paramList.Add(New ReportParameter("ValorLetras", mUtilidades.Letras(numLetras.ToString).ToUpper() & " PESOS M.L."))
            paramList.Add(New ReportParameter("EsCopia", mEsCompia))
            paramList.Add(New ReportParameter("Anulada", mbitAnulada))

            Me.ReportViewer.LocalReport.SetParameters(paramList)
            Me.Dock = DockStyle.Fill
            Me.ReportViewer.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Me.ReportViewer.ZoomMode = ZoomMode.Percent
            Me.ReportViewer.ZoomPercent = 100
            Me.ReportViewer.RefreshReport()

        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
            MsgBox("No existe pago registrado para generar la factura", MsgBoxStyle.Information, "Generar Factura")
            Me.Close()
        End Try
    End Sub

    Private Sub ReportViewer_ReportRefresh(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ReportViewer.ReportRefresh
        Try
            ReportViewer.ShowPrintButton = True
            Dim mEsCompia As Boolean = False
            Try
                Dim mCopia = (From C In dc.tblPagos Where C.intIdCita = mintIdCita And C.intNroFactura IsNot Nothing Select C)
                If mCopia.Count > 0 Then
                    mEsCompia = True
                End If
            Catch ex As Exception
                mEsCompia = False
            End Try
            Dim mResultado = dc.usp_rptFacturaMediaCarta(mintIdCita, mEsCompia, mbitAnulada)
            Dim mRes As New List(Of Object)

            For Each mR In mResultado
                mRes.Add(mR)
            Next

            BindingSource.DataSource = mRes
            Dim mUtilidades As New ClsUtilidades.ClsConvertirLetras()
            numLetras = BindingSource.Item(0).numValorPagado().ToString

            Dim paramList As New Generic.List(Of ReportParameter)
            paramList.Add(New ReportParameter("ValorLetras", mUtilidades.Letras(numLetras.ToString).ToUpper() & " PESOS M.L."))
            paramList.Add(New ReportParameter("EsCopia", mEsCompia))


            Me.ReportViewer.LocalReport.SetParameters(paramList)
            Me.Dock = DockStyle.Fill
            Me.ReportViewer.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Me.ReportViewer.ZoomMode = ZoomMode.Percent
            Me.ReportViewer.ZoomPercent = 100
            Me.ReportViewer.RefreshReport()
            Me.ReportViewer.Refresh()

        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
            MsgBox("No existe pago registrado para generar la factura", MsgBoxStyle.Information, "Generar Factura")
            Me.Close()
        End Try
    End Sub

    Private Sub ReportViewer_Print(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles ReportViewer.Print
        Try
            ReportViewer.ShowPrintButton = False
            ReportViewer.Refresh()
        Catch ex As Exception

        End Try
    End Sub
End Class