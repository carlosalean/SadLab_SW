﻿Imports System.Xml
Imports Microsoft.Reporting.WinForms

Public Class FrmVerHistoriaClinica
    Dim mstrStringConection As String
    Dim mCedula As String
    Dim mNombre As String
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    'Dim mListaIDTexto As New List(Of Integer)
    'Dim mListaID As New List(Of Integer)
    Dim mParametrosHC As String
    Dim mParametrosHCtexto As String
    Dim tblRevisionsistemas As List(Of Object)
    Dim tblAntecedentesPersonales As List(Of Object)
    Dim tblAntecedentesFamiliares As List(Of Object)
    Dim tblAntecedentesGineco As List(Of Object)
    Dim tblAntecedentesSocioEconomicos As List(Of Object)
    Dim tblHabitos As List(Of Object)
    Dim tblExamenFisico As List(Of Object)
    Dim tblExamenes As List(Of Object)
    Dim tblDiagnosticoConducta As List(Of Object)
    Dim tblTratamiento As List(Of Object)
    Dim tblEvolucion As List(Of Object)
    Dim tblRevisionsistemasTexto As List(Of Object)
    Dim tblMotivoConsultaVarios As List(Of Object)
    Dim tblAntecedentesPersonalesTexto As List(Of Object)
    Dim tblAntecedentesFamiliaresTexto As List(Of Object)
    Dim PrimerVez As Boolean

    Sub New(ByVal strStringConection As String, ByVal mCedulaPaciente As String, ByVal mNombrePaciente As String)
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            mstrStringConection = strStringConection
            mCedula = mCedulaPaciente
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
    Private Sub FrmVerHistoriaClinica_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim consultarCasos = dc.usp_ConsultarCasosDelPaciente(mCedula)

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class