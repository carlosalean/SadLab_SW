﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DialogPrestacionServicios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.OK_Button = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.ClsComboBoxCaja = New ClsUtilidades.ClsComboBox
        Me.TblCajasBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ClsDateTimePickerFechaInicial = New ClsUtilidades.ClsDateTimePicker
        Me.ClsDateTimePickerFechaFinal = New ClsUtilidades.ClsDateTimePicker
        Me.ClsComboBoxPrestador = New ClsUtilidades.ClsComboBox
        Me.TblDatosPrestadoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.ClsCheckBox1 = New ClsUtilidades.ClsCheckBox
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.TblCajasBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(248, 118)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "Aceptar"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancelar"
        '
        'ClsComboBoxCaja
        '
        Me.ClsComboBoxCaja.DataSource = Me.TblCajasBindingSource
        Me.ClsComboBoxCaja.DisplayMember = "strNombreCaja"
        Me.ClsComboBoxCaja.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ClsComboBoxCaja.FormattingEnabled = True
        Me.ClsComboBoxCaja.Location = New System.Drawing.Point(69, 46)
        Me.ClsComboBoxCaja.Name = "ClsComboBoxCaja"
        Me.ClsComboBoxCaja.Size = New System.Drawing.Size(252, 21)
        Me.ClsComboBoxCaja.TabIndex = 2
        Me.ClsComboBoxCaja.ValueMember = "intIdCajas"
        '
        'TblCajasBindingSource
        '
        Me.TblCajasBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCajas)
        '
        'ClsDateTimePickerFechaInicial
        '
        Me.ClsDateTimePickerFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.ClsDateTimePickerFechaInicial.Location = New System.Drawing.Point(69, 73)
        Me.ClsDateTimePickerFechaInicial.Name = "ClsDateTimePickerFechaInicial"
        Me.ClsDateTimePickerFechaInicial.Size = New System.Drawing.Size(84, 20)
        Me.ClsDateTimePickerFechaInicial.TabIndex = 3
        '
        'ClsDateTimePickerFechaFinal
        '
        Me.ClsDateTimePickerFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.ClsDateTimePickerFechaFinal.Location = New System.Drawing.Point(236, 73)
        Me.ClsDateTimePickerFechaFinal.Name = "ClsDateTimePickerFechaFinal"
        Me.ClsDateTimePickerFechaFinal.Size = New System.Drawing.Size(85, 20)
        Me.ClsDateTimePickerFechaFinal.TabIndex = 6
        '
        'ClsComboBoxPrestador
        '
        Me.ClsComboBoxPrestador.DataSource = Me.TblDatosPrestadoresBindingSource
        Me.ClsComboBoxPrestador.DisplayMember = "strRazonSocial"
        Me.ClsComboBoxPrestador.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ClsComboBoxPrestador.FormattingEnabled = True
        Me.ClsComboBoxPrestador.Location = New System.Drawing.Point(69, 19)
        Me.ClsComboBoxPrestador.Name = "ClsComboBoxPrestador"
        Me.ClsComboBoxPrestador.Size = New System.Drawing.Size(252, 21)
        Me.ClsComboBoxPrestador.TabIndex = 0
        Me.ClsComboBoxPrestador.ValueMember = "intIdPrestadores"
        '
        'TblDatosPrestadoresBindingSource
        '
        Me.TblDatosPrestadoresBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDatosPrestadores)
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(1, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Prestador:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(1, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Caja:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(1, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Fecha Incial:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(171, 77)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Fecha Final:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ClsCheckBox1)
        Me.GroupBox1.Controls.Add(Me.ClsComboBoxPrestador)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.ClsComboBoxCaja)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.ClsDateTimePickerFechaInicial)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.ClsDateTimePickerFechaFinal)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(10, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(389, 107)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        '
        'ClsCheckBox1
        '
        Me.ClsCheckBox1.AutoSize = True
        Me.ClsCheckBox1.Location = New System.Drawing.Point(327, 48)
        Me.ClsCheckBox1.Name = "ClsCheckBox1"
        Me.ClsCheckBox1.Size = New System.Drawing.Size(56, 17)
        Me.ClsCheckBox1.TabIndex = 1
        Me.ClsCheckBox1.Text = "Todas"
        Me.ClsCheckBox1.UseVisualStyleBackColor = True
        '
        'DialogPrestacionServicios
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(406, 159)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DialogPrestacionServicios"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Liquidación prestadores de servicios"
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.TblCajasBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents ClsComboBoxCaja As ClsUtilidades.ClsComboBox
    Friend WithEvents ClsDateTimePickerFechaInicial As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents ClsDateTimePickerFechaFinal As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents ClsComboBoxPrestador As ClsUtilidades.ClsComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TblCajasBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDatosPrestadoresBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ClsCheckBox1 As ClsUtilidades.ClsCheckBox

End Class
