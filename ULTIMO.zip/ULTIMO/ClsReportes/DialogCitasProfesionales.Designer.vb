﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DialogCitasProfesionales
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.OK_Button = New System.Windows.Forms.Button
        Me.Cancel_Button = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.ClsDateTimePickerFechaF = New ClsUtilidades.ClsDateTimePicker
        Me.Label3 = New System.Windows.Forms.Label
        Me.ClsDateTimePickerFechaI = New ClsUtilidades.ClsDateTimePicker
        Me.ComboBoxProfesional = New System.Windows.Forms.ComboBox
        Me.TblEmpeadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.ClsComboBoxEstadoCita = New ClsUtilidades.ClsComboBox
        Me.CheckBoxSedes = New System.Windows.Forms.CheckBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.ClsComboBoxSedes = New ClsUtilidades.ClsComboBox
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(239, 99)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "Aceptar"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancelar"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(198, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 13)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Fecha Final:"
        '
        'ClsDateTimePickerFechaF
        '
        Me.ClsDateTimePickerFechaF.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.ClsDateTimePickerFechaF.Location = New System.Drawing.Point(294, 68)
        Me.ClsDateTimePickerFechaF.Name = "ClsDateTimePickerFechaF"
        Me.ClsDateTimePickerFechaF.Size = New System.Drawing.Size(96, 20)
        Me.ClsDateTimePickerFechaF.TabIndex = 17
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 70)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Fecha Inicio"
        '
        'ClsDateTimePickerFechaI
        '
        Me.ClsDateTimePickerFechaI.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.ClsDateTimePickerFechaI.Location = New System.Drawing.Point(75, 68)
        Me.ClsDateTimePickerFechaI.Name = "ClsDateTimePickerFechaI"
        Me.ClsDateTimePickerFechaI.Size = New System.Drawing.Size(97, 20)
        Me.ClsDateTimePickerFechaI.TabIndex = 16
        '
        'ComboBoxProfesional
        '
        Me.ComboBoxProfesional.DataSource = Me.TblEmpeadoBindingSource
        Me.ComboBoxProfesional.DisplayMember = "strNombreEmpleado"
        Me.ComboBoxProfesional.FormattingEnabled = True
        Me.ComboBoxProfesional.Location = New System.Drawing.Point(75, 14)
        Me.ComboBoxProfesional.Name = "ComboBoxProfesional"
        Me.ComboBoxProfesional.Size = New System.Drawing.Size(315, 21)
        Me.ComboBoxProfesional.TabIndex = 21
        Me.ComboBoxProfesional.ValueMember = "intIdCodigoEmpleado"
        '
        'TblEmpeadoBindingSource
        '
        Me.TblEmpeadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEmpeados)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Profesional"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 13)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Estado Cita:"
        '
        'ClsComboBoxEstadoCita
        '
        Me.ClsComboBoxEstadoCita.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ClsComboBoxEstadoCita.FormattingEnabled = True
        Me.ClsComboBoxEstadoCita.Items.AddRange(New Object() {"Pendientes", "Cumplidas", "Canceladas"})
        Me.ClsComboBoxEstadoCita.Location = New System.Drawing.Point(75, 41)
        Me.ClsComboBoxEstadoCita.Name = "ClsComboBoxEstadoCita"
        Me.ClsComboBoxEstadoCita.Size = New System.Drawing.Size(97, 21)
        Me.ClsComboBoxEstadoCita.TabIndex = 22
        '
        'CheckBoxSedes
        '
        Me.CheckBoxSedes.AutoSize = True
        Me.CheckBoxSedes.Location = New System.Drawing.Point(236, 44)
        Me.CheckBoxSedes.Name = "CheckBoxSedes"
        Me.CheckBoxSedes.Size = New System.Drawing.Size(56, 17)
        Me.CheckBoxSedes.TabIndex = 29
        Me.CheckBoxSedes.Text = "Todas"
        Me.CheckBoxSedes.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(198, 45)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "Sede:"
        '
        'ClsComboBoxSedes
        '
        Me.ClsComboBoxSedes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ClsComboBoxSedes.FormattingEnabled = True
        Me.ClsComboBoxSedes.Location = New System.Drawing.Point(294, 41)
        Me.ClsComboBoxSedes.Name = "ClsComboBoxSedes"
        Me.ClsComboBoxSedes.Size = New System.Drawing.Size(96, 21)
        Me.ClsComboBoxSedes.TabIndex = 27
        '
        'DialogCitasProfesionales
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(400, 140)
        Me.Controls.Add(Me.CheckBoxSedes)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ClsComboBoxSedes)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ClsComboBoxEstadoCita)
        Me.Controls.Add(Me.ComboBoxProfesional)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ClsDateTimePickerFechaF)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ClsDateTimePickerFechaI)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DialogCitasProfesionales"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Citas Profesionales"
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ClsDateTimePickerFechaF As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ClsDateTimePickerFechaI As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents ComboBoxProfesional As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TblEmpeadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ClsComboBoxEstadoCita As ClsUtilidades.ClsComboBox
    Friend WithEvents CheckBoxSedes As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ClsComboBoxSedes As ClsUtilidades.ClsComboBox

End Class
