﻿Imports System.Windows.Forms
Imports Microsoft.Reporting.WinForms

Public Class FrmAnexoRips
    Dim mstrStringConection As String
    Dim intNroFactura As Integer
    Dim intPrestador As Integer

    Public Sub New(ByVal strStringConection As String, ByVal pNroFactura As String, ByVal pintPrestador As Integer)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        mstrStringConection = strStringConection
        If IsNumeric(pNroFactura) Then
            intNroFactura = Convert.ToInt32(pNroFactura)
        End If
        intPrestador = pintPrestador
    End Sub
    Private Sub FrmAnexoRips_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            'ReportViewer1
            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

            dc.CommandTimeout = 1200
            Dim mResultado = dc.usp_RptAnexoRips(intNroFactura.ToString(), intPrestador)
            Dim mRes As New List(Of Object)

            For Each mR In mResultado
                mRes.Add(mR)
            Next
            UspRptAnexoRipsResultBindingSource.DataSource = mRes

            Me.Dock = DockStyle.Fill
            Me.ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Me.ReportViewer1.ZoomMode = ZoomMode.Percent
            Me.ReportViewer1.ZoomPercent = 100
            Me.ReportViewer1.RefreshReport()
            Me.ReportViewer1.RefreshReport()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class