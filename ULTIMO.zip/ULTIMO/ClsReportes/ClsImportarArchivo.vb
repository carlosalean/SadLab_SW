﻿Imports System.IO

Public Class ClsImportarArchivo

    Public Function FnImportarArchivo(mstrNombreArchivo As String) As DataTable
        Dim dt As DataTable = New DataTable()
        Dim row As DataRow
        Try
            Dim SR As StreamReader = New StreamReader(mstrNombreArchivo)
            Dim line As String = SR.ReadLine()
            Dim strArray As String() = line.Split(","c)

            For Each s As String In strArray
                dt.Columns.Add(New DataColumn())
            Next

            Do
                line = SR.ReadLine
                If Not line = String.Empty Then
                    row = dt.NewRow()
                    row.ItemArray = line.Split(","c)
                    dt.Rows.Add(row)
                Else
                    Exit Do
                End If
            Loop
        Catch ex As Exception

        End Try
        Return dt
    End Function

End Class
