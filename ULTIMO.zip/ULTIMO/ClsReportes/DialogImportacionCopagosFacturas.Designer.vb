﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DialogImportacionCopagosFacturas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ClsDateTimePickerFechaF = New ClsUtilidades.ClsDateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ClsDateTimePickerFechaI = New ClsUtilidades.ClsDateTimePicker()
        Me.CheckBoxAnulado = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBoxPrestador = New System.Windows.Forms.ComboBox()
        Me.TblDatosPrestadoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblEmpeadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(200, 99)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 1
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "Aceptar"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancelar"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(184, 48)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Fecha Final"
        '
        'ClsDateTimePickerFechaF
        '
        Me.ClsDateTimePickerFechaF.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.ClsDateTimePickerFechaF.Location = New System.Drawing.Point(250, 44)
        Me.ClsDateTimePickerFechaF.Name = "ClsDateTimePickerFechaF"
        Me.ClsDateTimePickerFechaF.Size = New System.Drawing.Size(96, 20)
        Me.ClsDateTimePickerFechaF.TabIndex = 21
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 46)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Fecha Inicio"
        '
        'ClsDateTimePickerFechaI
        '
        Me.ClsDateTimePickerFechaI.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.ClsDateTimePickerFechaI.Location = New System.Drawing.Point(76, 44)
        Me.ClsDateTimePickerFechaI.Name = "ClsDateTimePickerFechaI"
        Me.ClsDateTimePickerFechaI.Size = New System.Drawing.Size(97, 20)
        Me.ClsDateTimePickerFechaI.TabIndex = 20
        '
        'CheckBoxAnulado
        '
        Me.CheckBoxAnulado.AutoSize = True
        Me.CheckBoxAnulado.Location = New System.Drawing.Point(76, 71)
        Me.CheckBoxAnulado.Name = "CheckBoxAnulado"
        Me.CheckBoxAnulado.Size = New System.Drawing.Size(15, 14)
        Me.CheckBoxAnulado.TabIndex = 31
        Me.CheckBoxAnulado.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(9, 71)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "Anulada"
        '
        'ComboBoxPrestador
        '
        Me.ComboBoxPrestador.DataSource = Me.TblDatosPrestadoresBindingSource
        Me.ComboBoxPrestador.DisplayMember = "strRazonSocial"
        Me.ComboBoxPrestador.FormattingEnabled = True
        Me.ComboBoxPrestador.Location = New System.Drawing.Point(76, 18)
        Me.ComboBoxPrestador.Name = "ComboBoxPrestador"
        Me.ComboBoxPrestador.Size = New System.Drawing.Size(270, 21)
        Me.ComboBoxPrestador.TabIndex = 33
        Me.ComboBoxPrestador.ValueMember = "intIdPrestadores"
        '
        'TblDatosPrestadoresBindingSource
        '
        Me.TblDatosPrestadoresBindingSource.DataMember = "tblDatosPrestadores"
        Me.TblDatosPrestadoresBindingSource.DataSource = Me.TblEmpeadoBindingSource
        '
        'TblEmpeadoBindingSource
        '
        Me.TblEmpeadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEmpeados)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 21)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Prestadores"
        '
        'DialogImportacionCopagosFacturas
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(353, 140)
        Me.Controls.Add(Me.ComboBoxPrestador)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.ClsDateTimePickerFechaF)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ClsDateTimePickerFechaI)
        Me.Controls.Add(Me.CheckBoxAnulado)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DialogImportacionCopagosFacturas"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Importación Copagos Facturas"
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ClsDateTimePickerFechaF As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ClsDateTimePickerFechaI As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents CheckBoxAnulado As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ComboBoxPrestador As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TblEmpeadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDatosPrestadoresBindingSource As System.Windows.Forms.BindingSource
End Class
