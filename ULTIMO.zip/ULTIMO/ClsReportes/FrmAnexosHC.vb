﻿Public Class FrmAnexosHC
    Dim strArchivo As String
    Dim tmpNumeroAnexo As Integer
    Dim mClsCreatePDF As ClsAnexosHistoriaClinicaPDF
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim tmpstrVAlor As String

    Public Sub New(ByVal pstrStringConection As String, ByVal pintIdCita As Integer, ByVal pintIdHC As Integer, mNumeroAnexo As Integer, Optional strVAlor As String = "")

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        tmpNumeroAnexo = mNumeroAnexo
        tmpstrVAlor = strVAlor
        mClsCreatePDF = New ClsReportes.ClsAnexosHistoriaClinicaPDF(pstrStringConection, pintIdCita, pintIdHC)
        'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(pstrStringConection)

    End Sub

    Private Sub FrmAnexosHC_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try


            strArchivo = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\AnexoHistoriaClinica_" & Now.ToString("ddMMyyyyhhmmss") & ".pdf"
            mClsCreatePDF.GenerarAnexoPDF(strArchivo, tmpNumeroAnexo, tmpstrVAlor)
            WebBrowser1.Url = New System.Uri(strArchivo)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
End Class