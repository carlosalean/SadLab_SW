﻿Imports Microsoft.Reporting.WinForms
Imports System.Windows.Forms
Imports System.IO

Public Class FrmResumenHC
  Dim strArchivo As String
  Dim tmpHCCompleta As Boolean
  Dim mClsCreatePDF As ClsCreatePDF
  Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

  Public Sub New(ByVal pstrStringConection As String, ByVal pintIdCita As Integer, ByVal pintIdHC As Integer, ByVal mIdUsuario As String, ByVal mcedula As String, ByVal HoraInicioAtencion As DateTime, ByVal HoraFinalAtencion As DateTime, Optional mHCCompleta As Boolean = False)

    ' Llamada necesaria para el Diseñador de Windows Forms.
    InitializeComponent()

    tmpHCCompleta = mHCCompleta
    mClsCreatePDF = New ClsReportes.ClsCreatePDF(pstrStringConection, pintIdCita, pintIdHC, mIdUsuario, mcedula, HoraInicioAtencion, HoraFinalAtencion)
    'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(pstrStringConection)

  End Sub

  Private Sub FrmResumenHC_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Try
      strArchivo = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\HistoriaClinica_" & Now.ToString("ddMMyyyyhhmmss") & ".pdf"
      'Show()
      mClsCreatePDF.GenerarPDF(strArchivo, tmpHCCompleta)
      If System.IO.File.Exists(strArchivo) Then
        WebBrowser1.Url = New System.Uri(strArchivo)
      Else
        MsgBox("El archivo no fue generado, por favor intentelo de nuevo más tarde")
        'Hide()
      End If
    Catch ex As Exception
      MsgBox(ex.ToString)
      'Hide()
    End Try

  End Sub

  Private Sub FrmResumenHC_Leave(sender As Object, e As EventArgs) Handles MyBase.Leave
  End Sub

  Private Sub FrmResumenHC_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
    Try
      'If My.Computer.FileSystem.FileExists(strArchivo) Then
      '    Dim sPath = WebBrowser1.Url.LocalPath
      '    WebBrowser1.Navigate("about:blank")
      '    File.Move(sPath, sPath.Replace(RECORDS_PATH, RECORDS_DELETE_PATH))
      '    My.Computer.FileSystem.DeleteFile(strArchivo)
      'End If
    Catch ex As Exception

    End Try
  End Sub
End Class