﻿Imports Microsoft.Reporting.WinForms
Imports System.Windows.Forms

Public Class FrmFacturacion
    Dim mstrStringConection As String
    Dim intNroFactura As Integer
    Dim mBPaciente As Boolean
    Dim intIdPrestadores As Integer
    Dim mEsDuplicado As Boolean

    Public Sub New(ByVal strStringConection As String, ByVal pNroFactura As String, ByVal mPaciente As Boolean, ByVal pintIdPrestadores As Integer, ByVal pEsDuplicado As Boolean)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        mstrStringConection = strStringConection
        If IsNumeric(pNroFactura) Then
            intNroFactura = Convert.ToInt32(pNroFactura)
        End If
        'Esta variable boolena indica si se debe imprimir en la factura el nombre y la cedula del paciente
        mBPaciente = mPaciente
        intIdPrestadores = pintIdPrestadores
        mEsDuplicado = pEsDuplicado
    End Sub
    Private Sub FrmFacturacion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            'ReportViewer1
            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim tmpTblFactura = (From f In dc.tblFacturacions Where f.strNroFactura = intNroFactura _
                            Select f)
            tblFacturacionBindingSource.DataSource = tmpTblFactura

            Dim dblValorFactura As Double
            dblValorFactura = dc.usp_ValorFactura(intNroFactura.ToString, intIdPrestadores)

            Dim dblValorCoopago As Double
            dblValorCoopago = dc.usp_ValorCoopagoFactura(intNroFactura.ToString, intIdPrestadores)

            Dim dblValorDescuento As Double
            dblValorDescuento = dc.usp_ValorDescuentoFactura(intNroFactura.ToString, intIdPrestadores)

            Dim paramList As New Generic.List(Of ReportParameter)
            Dim mUtilidades As New ClsUtilidades.ClsConvertirLetras()
            Dim strPaciente As String = ""
            If mBPaciente = True Then
                If (From c In dc.tblCita Where c.strNroFactura = intNroFactura.ToString Select c).Count = 1 Then
                    Dim strDatosPaciente = (From c In dc.tblCita _
                                            Join p In dc.tblPacientes On c.strNroIdPaciente _
                                            Equals p.strNroIdentificacion _
                                            Where c.strNroFactura = intNroFactura.ToString _
                                            Select c.strNroIdPaciente, _
                                            strNombrePaciente = p.strPrimerNombre & " " & IIf(p.strSegundoNombre Is Nothing, "", p.strSegundoNombre) & " " & p.strPrimerApellido & " " & IIf(p.strSegundoApellido Is Nothing, "", p.strSegundoApellido)).Single
                    strPaciente = strDatosPaciente.strNroIdPaciente & " " & strDatosPaciente.strNombrePaciente
                End If
            End If

            paramList.Add(New ReportParameter("ValorEnLetras", mUtilidades.Letras(dblValorFactura.ToString).ToUpper() & " PESOS M.L."))
            paramList.Add(New ReportParameter("Valor", dblValorFactura))
            paramList.Add(New ReportParameter("ValorCoopago", dblValorCoopago * -1))
            paramList.Add(New ReportParameter("ValorDescuento", dblValorDescuento * -1))
            paramList.Add(New ReportParameter("DatosPaciente", strPaciente))

            Me.ReportViewer1.LocalReport.SetParameters(paramList)

            Me.Dock = DockStyle.Fill
            Me.ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Me.ReportViewer1.ZoomMode = ZoomMode.Percent
            Me.ReportViewer1.ZoomPercent = 100
            Me.ReportViewer1.RefreshReport()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub GenerarToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GenerarToolStripButton.Click
        Try
            Dim mDialogGenerarRIPS As New DialogGenerarRIPS(mstrStringConection, intNroFactura.ToString(), intIdPrestadores)
            If mDialogGenerarRIPS.ShowDialog = Windows.Forms.DialogResult.OK Then
                MsgBox("Los Archivos se generaron correctamente..")
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class