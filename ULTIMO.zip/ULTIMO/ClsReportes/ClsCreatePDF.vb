﻿Imports System.IO
Imports iTextSharp.text.pdf
Imports iTextSharp.text

Public Class ClsCreatePDF
  Dim fuenteNormal As New Font(Font.FontFamily.HELVETICA, 8, Font.NORMAL)
  Dim fuenteBold As New Font(Font.FontFamily.HELVETICA, 8, Font.BOLD)
  Dim mHoraInicioAtencion As DateTime
  Dim mHoraFinalAtencion As DateTime

  Dim mstrStringConection As String
  Dim mintIdCita As Integer
  Dim mintIdHC As Integer
  Dim mUsuario As String
  Dim mIdentificacion As String

  Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

  Dim mConsulta
  Dim Docxml As XDocument
  Dim nDistanciaEntreContenidoFirma As Integer = 50

  Public Sub New(ByVal pstrStringConection As String, ByVal pintIdCita As Integer, ByVal pintIdHC As Integer, ByVal mIdUsuario As String, ByVal mcedula As String, ByVal HoraInicioAtencion As DateTime, ByVal HoraFinalAtencion As DateTime)
    ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    mstrStringConection = pstrStringConection
    mintIdCita = pintIdCita
    mintIdHC = pintIdHC
    mUsuario = mIdUsuario
    mIdentificacion = mcedula
    mHoraInicioAtencion = HoraInicioAtencion
    mHoraFinalAtencion = HoraFinalAtencion

    dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
  End Sub

  Public Sub GenerarPDF(strNombreArchivo As String, Optional mHCCompleta As Boolean = False)
    Dim oDoc As New iTextSharp.text.Document(PageSize.LETTER, 36, 36, 36, 36)
    Dim pdfw As iTextSharp.text.pdf.PdfWriter
    Dim cb As PdfContentByte

    Dim NombreArchivo As String = strNombreArchivo '"D:\ejemplo.pdf"

    Dim oImagen As Image 'iTextSharp.text.Image
    Dim coordenadaX As Single = 5
    Dim coordenadaY As Single = 5

    Try

      pdfw = PdfWriter.GetInstance(oDoc, New FileStream(NombreArchivo,
      FileMode.Create, FileAccess.Write, FileShare.None))
      'Apertura del documento.
      oDoc.Open()
      cb = pdfw.DirectContent
      'Agregamos una pagina.
      oDoc.NewPage()

      '-- Modificación -------------------
      '--Autor: Alejandro Torres Monsalve
      '--Fecha: 2016/05/01
      'Descripcion: Se crea variable para leer parametros del appconfig, se valida contra el parametro en el app.config EsDesarrollo para validar de donde se va a cargar el logo
      Docxml = XDocument.Load(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")

      If Docxml.Descendants("setting")(3).Value.Equals("0") Then
        If Not My.Computer.FileSystem.FileExists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\LogoVasculab.bmp") Then
          My.Computer.FileSystem.CopyFile(My.Application.Info.DirectoryPath & "\LogoVasculab.bmp",
                                         My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")
        End If
        oImagen = Image.GetInstance(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\LogoVasculab.bmp")
      Else
        oImagen = Image.GetInstance(String.Format("{0}\{1}\{2}", My.Computer.FileSystem.SpecialDirectories.MyDocuments, My.Application.Info.CompanyName, Docxml.Descendants("setting")(7).Value))
      End If

      oImagen.SetAbsolutePosition(50, oDoc.PageSize.Height - 100)

      cb.AddImage(oImagen)

      Dim Lineas As Integer = 20
      Dim mTipo As Integer
      Dim mTblCitas 'As ClsBaseDatos_SadLab.tblCita
      If mHCCompleta Then

        mTipo = dc.usp_SeleccionarTipo("ESTADO_CITA", "Cumplida").ReturnValue
        mTblCitas = (From c In dc.tblCita
                     Where ((c.strNroIdPaciente = mIdentificacion) _
                                And (c.intIdEstadoCita = mTipo))
                     Order By c.intIdCita Descending
                     Select c)
        For Each tCitas In mTblCitas

          mintIdCita = tCitas.intIdCita
          Try
            Dim mTblHC = (From h In dc.tblHistoriasClinicas
                          Where h.intIdCita = mintIdCita
                          Select h.intIdHC).Single

            mintIdHC = CInt(mTblHC.ToString)
            Exit For
          Catch ex As Exception

          End Try
        Next
      End If


      'Encabezado
      Dim mResultado = dc.usp_rptResumenHistoriaClinicaEncabezado(mintIdCita, mHoraInicioAtencion, mHoraFinalAtencion)
      Dim mRes As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)
      For Each mR In mResultado
        mRes.Add(mR)
      Next

      Dim tblEncabezado As PdfPTable = FnEncabezado(mRes)
            tblEncabezado.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 330, oDoc.PageSize.Height - Lineas, cb)

            Dim tblPiePagina As PdfPTable = FnPiePagina(mRes)

            'titulo
            Lineas = Lineas + 110
            Dim tblTitulo As PdfPTable = FnTitulo()
      tblTitulo.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)

            'Fecha
            Lineas = Lineas + 30
            Dim tblFechas As PdfPTable = FnFechas(mRes)
      tblFechas.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
      Lineas = Lineas + tblFechas.TotalHeight

      mConsulta = dc.usp_rptResumenHistoriaClinicaMotivosConsulta(mintIdCita)
      If Not mConsulta Is Nothing Then
        Dim tblMotivosConsulta = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaMotivosConsultaResult)
        For Each mR In mConsulta
          tblMotivosConsulta.Add(mR)
        Next
        'Motivo Consulta
        If tblMotivosConsulta.Count > 0 Then
          Lineas = Lineas + 5
          Dim tblMotivoColsulta As PdfPTable = FnMotivoColsulta(tblMotivosConsulta(0))
          tblMotivoColsulta.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
          Lineas = Lineas + tblMotivoColsulta.TotalHeight
        End If
      End If
      'Antecedentes Personales
      Lineas = Lineas + 5
      mConsulta = dc.usp_rptResumenHistoriaClinicaAntecedentesPersonalesTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblAntecedentesPersonales As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesPersonalesTextoResult)
        For Each mR In mConsulta
          tblAntecedentesPersonales.Add(mR)
        Next
        If tblAntecedentesPersonales.Count > 0 Then
          Dim tblAntecedentesP As PdfPTable = FnAntecedentesP(tblAntecedentesPersonales.ElementAt(0))
          tblAntecedentesP.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
          Lineas = Lineas + tblAntecedentesP.TotalHeight
        End If
      End If

      'Antecedentes Familiares
      mConsulta = dc.usp_rptResumenHistoriaClinicaAntecedentesFamiliaresTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblAntecedentesFamiliaresTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesFamiliaresTextoResult)
        For Each mR In mConsulta
          tblAntecedentesFamiliaresTexto.Add(mR)
        Next
        If tblAntecedentesFamiliaresTexto.Count > 0 Then
          Lineas = Lineas + 5
          Dim tblAntecedentesF As PdfPTable = FnAntecedentesF(tblAntecedentesFamiliaresTexto.ElementAt(0))
          tblAntecedentesF.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
          Lineas = Lineas + tblAntecedentesF.TotalHeight
        End If
      End If

      If Lineas + 100 >= oDoc.PageSize.Height Then
        Lineas = 30
        oDoc.NewPage()
        'Pie de Pagina
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
      End If

      'Habitos
      mConsulta = dc.usp_rptResumenHistoriaClinicaHabitosTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblHabitosTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaHabitosTextoResult)
        For Each mR In mConsulta
          tblHabitosTexto.Add(mR)
        Next
        If tblHabitosTexto.Count > 0 Then
          Lineas = Lineas + 5
          Dim tblHabitos As PdfPTable = FnHabitos(tblHabitosTexto.ElementAt(0))
          tblHabitos.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
          Lineas = Lineas + tblHabitos.TotalHeight
        End If
      End If


      If Lineas + 10 >= oDoc.PageSize.Height Then
        Lineas = 30
        oDoc.NewPage()
        'Pie de Pagina
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
      End If

      'Antecedeltes Socieconomicos
      mConsulta = dc.usp_rptResumenHistoriaClinicaAntecedentesSocioEconomicosTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblAntecedentesSocioEconomicos As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesSocioEconomicosTextoResult)
        For Each mR In mConsulta
          tblAntecedentesSocioEconomicos.Add(mR)
        Next
        If tblAntecedentesSocioEconomicos.Count > 0 Then
          Lineas = Lineas + 5
          Dim tAntecedentesSocieconomicos As PdfPTable = FnAntecedentesSocieconomicos(tblAntecedentesSocioEconomicos.ElementAt(0))
          tAntecedentesSocieconomicos.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
          Lineas = Lineas + tAntecedentesSocieconomicos.TotalHeight
        End If
      End If


      If Lineas + 100 >= oDoc.PageSize.Height Then
        Lineas = 30
        oDoc.NewPage()
        'Pie de Pagina
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
      End If

      'Antecedeltes GinecoObstetricos
      mConsulta = dc.usp_rptResumenHistoriaClinicaAntecedentesGinecoObstetricosTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblGinecoTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesGinecoObstetricosTextoResult)
        For Each mR In mConsulta
          tblGinecoTexto.Add(mR)
        Next
        If tblGinecoTexto.Count > 0 Then
          Lineas = Lineas + 5
          Dim tblAntecedentesGine As PdfPTable = FnAntecedentesGine(tblGinecoTexto.ElementAt(0))
          tblAntecedentesGine.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
          Lineas = Lineas + tblAntecedentesGine.TotalHeight
        End If
      End If


      If Lineas + 100 >= oDoc.PageSize.Height Then
        Lineas = 30
        oDoc.NewPage()
        'Pie de Pagina
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
      End If

      'Revision de Sistemas
      mConsulta = dc.usp_rptResumenHistoriaClinicaRevisionSistemasTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblRevisionsistemasTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaRevisionSistemasTextoResult)
        For Each mR In mConsulta
          tblRevisionsistemasTexto.Add(mR)
        Next
        If (tblRevisionsistemasTexto.Count > 0) Then
          If (tblRevisionsistemasTexto.ElementAt(0).strValorTexto.Trim.Count > 0) Then
            Lineas = Lineas + 5
            Dim tblRevisionSistemas As PdfPTable = FnRevisionSistemas(tblRevisionsistemasTexto.ElementAt(0))
            tblRevisionSistemas.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
            Lineas = Lineas + tblRevisionSistemas.TotalHeight
          End If
        End If
      End If

      If Lineas + 100 >= oDoc.PageSize.Height Then
        Lineas = 30
        oDoc.NewPage()
        'Pie de Pagina
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
      End If

      'Examen Fisico
      mConsulta = dc.usp_rptResumenHistoriaClinicaExamenFisicoTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblRevisionExamenesFisicosTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenFisicoTextoResult)
        For Each mR In mConsulta
          tblRevisionExamenesFisicosTexto.Add(mR)
        Next
        If tblRevisionExamenesFisicosTexto.Count > 0 Then
          Lineas = Lineas + 5
          Dim tblExamenFisico As PdfPTable = FnExamenFisico(tblRevisionExamenesFisicosTexto.ElementAt(0))
          tblExamenFisico.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
          Lineas = Lineas + tblExamenFisico.TotalHeight
        End If
      End If

      If Lineas + 100 >= oDoc.PageSize.Height Then
        Lineas = 30
        oDoc.NewPage()
        'Pie de Pagina
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
      End If

      'Examenes Paraciclicos
      mConsulta = dc.usp_rptResumenHistoriaClinicaExamenesParaciclicosTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblRevisionExamenesTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenesParaciclicosTextoResult)
        For Each mR In mConsulta
          tblRevisionExamenesTexto.Add(mR)
        Next
        If tblRevisionExamenesTexto.Count > 0 Then
          If tblRevisionExamenesTexto.ElementAt(0).strValorTexto.Count > 0 Then
            Lineas = Lineas + 5
            Dim tblExamenesParaciclicos As PdfPTable = FnExamenesParaciclicos(tblRevisionExamenesTexto)
            tblExamenesParaciclicos.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
            Lineas = Lineas + tblExamenesParaciclicos.TotalHeight
          End If
        End If
      End If

      If Lineas + 100 >= oDoc.PageSize.Height Then
        Lineas = 30
        oDoc.NewPage()
        'Pie de Pagina
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
      End If

      'Diagnostico y Conducta
      mConsulta = dc.usp_rptResumenHistoriaClinicaDiagnosticoConductaTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblDiagnosticoTexto = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaDiagnosticoConductaTextoResult)
        For Each mR In mConsulta
          tblDiagnosticoTexto.Add(mR)
        Next
        If tblDiagnosticoTexto.Count > 0 Then
          Lineas = Lineas + 5
          Dim tblDiagnosticoConducta As PdfPTable = FnDiagnosticoConducta(tblDiagnosticoTexto.ElementAt(0))
          tblDiagnosticoConducta.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
          Lineas = Lineas + tblDiagnosticoConducta.TotalHeight
        End If
      End If


      If Lineas + 100 >= oDoc.PageSize.Height Then
        Lineas = 30
        oDoc.NewPage()
        'Pie de Pagina
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
      End If

      'Tratamiento

      mConsulta = dc.usp_rptResumenHistoriaClinicaTratamientoTexto(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblTratamientoTexto = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaTratamientoTextoResult)
        For Each mR In mConsulta
          tblTratamientoTexto.Add(mR)
        Next
        If tblTratamientoTexto.Count > 0 Then
          Lineas = Lineas + 5
          Dim tblTratamiento As PdfPTable = FnTratamiento(tblTratamientoTexto.ElementAt(0))
          tblTratamiento.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
          Lineas = Lineas + tblTratamiento.TotalHeight
        End If
      End If

      If Lineas + 100 >= oDoc.PageSize.Height Then
        Lineas = 30
        oDoc.NewPage()
        'Pie de Pagina
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
      End If

      'Evolucion
      mConsulta = dc.usp_rptResumenHistoriaClinicaEvolucion(mintIdHC)
      If Not mConsulta Is Nothing Then
        Dim tblEvolucion As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEvolucionResult)
        For Each mR In mConsulta
          tblEvolucion.Add(mR)
        Next
        If tblEvolucion.Count > 0 Then
          If tblEvolucion.ElementAt(0).Strdescripcion.Count > 0 Then
            Lineas = Lineas + 5
            Dim tEvolucion As PdfPTable = FnEvolucion(tblEvolucion.ElementAt(0))
            tEvolucion.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
            Lineas = Lineas + tEvolucion.TotalHeight
          End If
        End If
      End If


      If Not mHCCompleta Then
        'Firma
        Lineas = Lineas + 15
        'Dim tblFirma As PdfPTable = FnFirma(mRes)
        'tblFirma.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)

        pdfw.Flush()
        'Cerramos el documento.
        oDoc.Close()
      Else
        'Dim mTipo As Integer

        mTipo = dc.usp_SeleccionarTipo("ESTADO_CITA", "Cumplida").ReturnValue
        'Dim mTblCitas = From c In dc.tblCita _
        '                Where ((c.strNroIdPaciente = mIdentificacion) _
        '                And (c.intIdCita <> mintIdCita) _
        '                And (c.intIdEstadoCita = mTipo)) _
        '                    Select c



        Dim mIdcitaAnt = mintIdCita

        For Each tcitas In mTblCitas
          If mIdcitaAnt <> tcitas.intIdCita Then
            mintIdCita = tcitas.intIdCita
            Dim mTblHC = Nothing
            Try
              mTblHC = (From h In dc.tblHistoriasClinicas
                        Where h.intIdCita = mintIdCita
                        Select h.intIdHC).Single
            Catch ex As Exception
              mTblHC = Nothing
            End Try

            If Not (mTblHC Is Nothing) Then
              mintIdHC = CInt(mTblHC.ToString)
              If mintIdHC.ToString.Length > 0 Then

                mintIdCita = tcitas.intIdCita

                If Lineas + 10 >= oDoc.PageSize.Height Then
                  Lineas = 30
                  oDoc.NewPage()
                  'Pie de Pagina
                  'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
                End If
                'Encabezado
                Dim mResult = dc.usp_rptResumenHistoriaClinicaEncabezado(tcitas.intIdCita, mHoraInicioAtencion, mHoraFinalAtencion)
                Dim mRest As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)
                For Each mR In mResult
                  mRest.Add(mR)
                Next

                mRes = mRest
                'Fecha
                Lineas = Lineas + 10
                Dim tlFechas As PdfPTable = FnFechas(mRest)
                tlFechas.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
                Lineas = Lineas + tlFechas.TotalHeight

                If Lineas + 100 >= oDoc.PageSize.Height Then
                  Lineas = 30
                  oDoc.NewPage()
                  'Pie de Pagina
                  'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
                End If

                mConsulta = dc.usp_rptResumenHistoriaClinicaMotivosConsulta(mintIdCita)
                If Not mConsulta Is Nothing Then
                  Dim tblMotivosConsulta = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaMotivosConsultaResult)
                  For Each mR In mConsulta
                    tblMotivosConsulta.Add(mR)
                  Next
                  'Motivo Consulta
                  If tblMotivosConsulta.Count > 0 Then
                    Lineas = Lineas + 5
                    Dim tblMotivoColsulta As PdfPTable = FnMotivoColsulta(tblMotivosConsulta(0))
                    tblMotivoColsulta.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
                    Lineas = Lineas + tblMotivoColsulta.TotalHeight
                  End If
                End If

                If Lineas + 100 >= oDoc.PageSize.Height Then
                  Lineas = 30
                  oDoc.NewPage()
                  'Pie de Pagina
                  'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
                End If

                'Revision de Sistemas
                mConsulta = dc.usp_rptResumenHistoriaClinicaRevisionSistemasTexto(mintIdHC)
                If Not mConsulta Is Nothing Then
                  Dim tblRevisionsistemasTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaRevisionSistemasTextoResult)
                  For Each mR In mConsulta
                    tblRevisionsistemasTexto.Add(mR)
                  Next
                  If (tblRevisionsistemasTexto.Count > 0) Then
                    If (tblRevisionsistemasTexto.ElementAt(0).strValorTexto.Trim.Count > 0) Then

                      'If (tblRevisionsistemasTexto.Count > 0) And (tblRevisionsistemasTexto.ElementAt(0).strValorTexto.Trim.Count > 0) Then
                      Lineas = Lineas + 5
                      Dim tblRevisionSistemas As PdfPTable = FnRevisionSistemas(tblRevisionsistemasTexto.ElementAt(0))
                      tblRevisionSistemas.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
                      Lineas = Lineas + tblRevisionSistemas.TotalHeight
                    End If
                  End If
                End If

                If Lineas + 100 >= oDoc.PageSize.Height Then
                  Lineas = 30
                  oDoc.NewPage()
                  'Pie de Pagina
                  'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
                End If


                'Examen Fisico
                mConsulta = dc.usp_rptResumenHistoriaClinicaExamenFisicoTexto(mintIdHC)
                If Not mConsulta Is Nothing Then
                  Dim tblRevisionExamenesFisicosTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenFisicoTextoResult)
                  For Each mR In mConsulta
                    tblRevisionExamenesFisicosTexto.Add(mR)
                  Next
                  If tblRevisionExamenesFisicosTexto.Count > 0 Then
                    Lineas = Lineas + 5
                    Dim tblExamenFisico As PdfPTable = FnExamenFisico(tblRevisionExamenesFisicosTexto.ElementAt(0))
                    tblExamenFisico.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
                    Lineas = Lineas + tblExamenFisico.TotalHeight
                  End If
                End If


                If Lineas + 100 >= oDoc.PageSize.Height Then
                  Lineas = 30
                  oDoc.NewPage()
                  'Pie de Pagina
                  'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
                End If

                'Examenes Paraciclicos
                mConsulta = dc.usp_rptResumenHistoriaClinicaExamenesParaciclicosTexto(mintIdHC)
                If Not mConsulta Is Nothing Then
                  Dim tblRevisionExamenesTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenesParaciclicosTextoResult)
                  For Each mR In mConsulta
                    tblRevisionExamenesTexto.Add(mR)
                  Next
                  If tblRevisionExamenesTexto.Count > 0 Then
                    If tblRevisionExamenesTexto.ElementAt(0).strValorTexto.Count > 0 Then
                      Lineas = Lineas + 5
                      Dim tblExamenesParaciclicos As PdfPTable = FnExamenesParaciclicos(tblRevisionExamenesTexto)
                      tblExamenesParaciclicos.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
                      Lineas = Lineas + tblExamenesParaciclicos.TotalHeight
                    End If
                  End If
                End If

                If Lineas + 100 >= oDoc.PageSize.Height Then
                  Lineas = 30
                  oDoc.NewPage()
                  'Pie de Pagina
                  'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
                End If

                'Diagnostico y Conducta
                mConsulta = dc.usp_rptResumenHistoriaClinicaDiagnosticoConductaTexto(mintIdHC)
                If Not mConsulta Is Nothing Then
                  Dim tblDiagnosticoTexto = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaDiagnosticoConductaTextoResult)
                  For Each mR In mConsulta
                    tblDiagnosticoTexto.Add(mR)
                  Next
                  If tblDiagnosticoTexto.Count > 0 Then
                    Lineas = Lineas + 5
                    Dim tblDiagnosticoConducta As PdfPTable = FnDiagnosticoConducta(tblDiagnosticoTexto.ElementAt(0))
                    tblDiagnosticoConducta.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
                    Lineas = Lineas + tblDiagnosticoConducta.TotalHeight
                  End If
                End If


                If Lineas + 100 >= oDoc.PageSize.Height Then
                  Lineas = 30
                  oDoc.NewPage()
                  'Pie de Pagina
                  'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
                End If

                'Tratamiento

                mConsulta = dc.usp_rptResumenHistoriaClinicaTratamientoTexto(mintIdHC)
                If Not mConsulta Is Nothing Then
                  Dim tblTratamientoTexto = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaTratamientoTextoResult)
                  For Each mR In mConsulta
                    tblTratamientoTexto.Add(mR)
                  Next
                  If tblTratamientoTexto.Count > 0 Then
                    Lineas = Lineas + 5
                    Dim tblTratamiento As PdfPTable = FnTratamiento(tblTratamientoTexto.ElementAt(0))
                    tblTratamiento.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
                    Lineas = Lineas + tblTratamiento.TotalHeight
                  End If
                End If

                If Lineas + 100 >= oDoc.PageSize.Height Then
                  Lineas = 30
                  oDoc.NewPage()
                  'Pie de Pagina
                  'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
                End If

                'Evolucion
                mConsulta = dc.usp_rptResumenHistoriaClinicaEvolucion(mintIdHC)
                If Not mConsulta Is Nothing Then
                  Dim tblEvolucion As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEvolucionResult)
                  For Each mR In mConsulta
                    tblEvolucion.Add(mR)
                  Next
                  If tblEvolucion.Count > 0 Then
                    If tblEvolucion.ElementAt(0).Strdescripcion.Count > 0 Then
                      Lineas = Lineas + 5
                      Dim tEvolucion As PdfPTable = FnEvolucion(tblEvolucion.ElementAt(0))
                      tEvolucion.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
                      Lineas = Lineas + tEvolucion.TotalHeight
                    End If
                  End If
                End If

              End If

              If Lineas + 100 >= oDoc.PageSize.Height Then
                Lineas = 30
                oDoc.NewPage()
                'Pie de Pagina
                'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)

              End If
            End If
          End If
        Next
        Lineas = Lineas + nDistanciaEntreContenidoFirma
        'Pie de Pagina
        tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
        'tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - Lineas, oDoc.PageSize.Height - 680, cb)
        pdfw.Flush()
        'Cerramos el documento.
        oDoc.Close()
      End If
    Catch ex As Exception
      'Si hubo una excepcion y el archivo existe ...
      If File.Exists(NombreArchivo) Then
        'Cerramos el documento si esta abierto.
        'Y asi desbloqueamos el archivo para su eliminacion.
        If oDoc.IsOpen Then oDoc.Close()
        '... lo eliminamos de disco.
        File.Delete(NombreArchivo)
      End If
      MsgBox("No se pudo genrar la Historia Clínica")  'Throw New Exception("Error al generar archivo PDF (" & ex.Message & ")")
    Finally
      cb = Nothing
      pdfw = Nothing
      oDoc = Nothing
    End Try
  End Sub

  Public Sub GenerarPDF(arrCodigosCitasHC(,) As Integer, ByRef sNombreArchivo As String)
    Dim oDocumento As New iTextSharp.text.Document(PageSize.LETTER, 36, 36, 36, 36)
    Dim pdfwWirter As iTextSharp.text.pdf.PdfWriter
    Dim cbContenido As PdfContentByte
    Dim oImgLogo As Image 'iTextSharp.text.Image
    Dim nPosX As Single = 5
    Dim nPosY As Single = 5
    sNombreArchivo = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\HistoriaClinica_" & Now.ToString("ddMMyyyyhhmmss") & ".pdf" '"D:/ejemplo.pdf"

    Try
      pdfwWirter = PdfWriter.GetInstance(oDocumento, New FileStream(sNombreArchivo,
      FileMode.Create, FileAccess.Write, FileShare.None))
      'Apertura del documento.
      oDocumento.Open()
      cbContenido = pdfwWirter.DirectContent
      'Agregamos una pagina.
      oDocumento.NewPage()
      Docxml = XDocument.Load(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")

      If Docxml.Descendants("setting")(3).Value.Equals("0") Then
        If Not My.Computer.FileSystem.FileExists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\LogoVasculab.bmp") Then
          My.Computer.FileSystem.CopyFile(My.Application.Info.DirectoryPath & "\LogoVasculab.bmp",
                                         My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")
        End If
        oImgLogo = Image.GetInstance(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\LogoVasculab.bmp")
      Else
        oImgLogo = Image.GetInstance(String.Format("{0}\{1}\{2}", My.Computer.FileSystem.SpecialDirectories.MyDocuments, My.Application.Info.CompanyName, Docxml.Descendants("setting")(7).Value))
      End If

      oImgLogo.SetAbsolutePosition(50, oDocumento.PageSize.Height - 100)

      cbContenido.AddImage(oImgLogo)
      Dim Lineas As Integer = 20
      If arrCodigosCitasHC.Length > 0 Then
        Dim oDatosPaciente
        Dim ltDatosPaciente As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)
        Dim tblPiePagina As PdfPTable = Nothing
        Dim bPrimerRegistro As Boolean = True
        For i = 0 To (arrCodigosCitasHC.Length / 2) - 1
          If arrCodigosCitasHC(i, 0) > -1 And arrCodigosCitasHC(i, 1) > -1 Then
            ltDatosPaciente = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)
            oDatosPaciente = dc.usp_rptResumenHistoriaClinicaEncabezado(arrCodigosCitasHC(i, 0), Now, Now)
            For Each dPaciente In oDatosPaciente
              ltDatosPaciente.Add(dPaciente)
            Next
            If bPrimerRegistro Then 'Se buscan los datos del paciente segun los datos de la paciente
              Dim tblEncabezado As PdfPTable = FnEncabezado(ltDatosPaciente)
              tblEncabezado.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 230, oDocumento.PageSize.Height - Lineas, cbContenido)

              tblPiePagina = FnPiePagina(ltDatosPaciente)

              'titulo
              Lineas = Lineas + 100
              Dim tblTitulo As PdfPTable = FnTitulo()
              tblTitulo.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)

              'Fecha
              Lineas = Lineas + 15
              Dim tblFechas As PdfPTable = FnFechas(ltDatosPaciente)
              tblFechas.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
              Lineas = Lineas + tblFechas.TotalHeight

              bPrimerRegistro = False
            Else
              'Fecha
              If Lineas + 100 >= oDocumento.PageSize.Height Then
                Lineas = 30
                oDocumento.NewPage()
                ''Pie de Pagina
                'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
              Else
                Lineas = Lineas + 15
              End If

              Dim tblFechas As PdfPTable = FnFechas(ltDatosPaciente)
              tblFechas.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
              Lineas = Lineas + tblFechas.TotalHeight
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan los motivos de consulta del paciente, se consultan a partir del idCita que viene en el parametro arrCodigosCitaHC
            mConsulta = dc.usp_rptResumenHistoriaClinicaMotivosConsulta(arrCodigosCitasHC(i, 0))
            If Not mConsulta Is Nothing Then
              Dim tblMotivosConsulta = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaMotivosConsultaResult)
              For Each mR In mConsulta
                tblMotivosConsulta.Add(mR)
              Next
              If tblMotivosConsulta.Count > 0 Then
                Lineas = Lineas + 5
                Dim tblMotivoColsulta As PdfPTable = FnMotivoColsulta(tblMotivosConsulta.ElementAt(0))
                tblMotivoColsulta.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                Lineas = Lineas + tblMotivoColsulta.TotalHeight
              End If
            End If

            If Lineas + 150 >= oDocumento.PageSize.Height Then
              Lineas = 60
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan los antencedentes personales del paciente, se consultan a partir del idHC que viene en el parametro arrCodigosCitaHC
            Lineas = Lineas + 10
            mConsulta = dc.usp_rptResumenHistoriaClinicaAntecedentesPersonalesTexto(arrCodigosCitasHC(i, 1))
            If Not mConsulta Is Nothing Then
              Dim tblAntecedentesPersonales As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesPersonalesTextoResult)
              For Each mR In mConsulta
                tblAntecedentesPersonales.Add(mR)
              Next
              If tblAntecedentesPersonales.Count > 0 Then
                Dim tblAntecedentesP As PdfPTable = FnAntecedentesP(tblAntecedentesPersonales.ElementAt(0))
                tblAntecedentesP.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                Lineas = Lineas + tblAntecedentesP.TotalHeight
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan los antencedentes familiares del paciente, se consultan a partir del idHC que viene en el parametro arrCodigosCitaHC
            mConsulta = dc.usp_rptResumenHistoriaClinicaAntecedentesFamiliaresTexto(arrCodigosCitasHC(i, 1))
            If Not mConsulta Is Nothing Then
              Dim tblAntecedentesFamiliaresTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesFamiliaresTextoResult)
              For Each mR In mConsulta
                tblAntecedentesFamiliaresTexto.Add(mR)
              Next
              If tblAntecedentesFamiliaresTexto.Count > 0 Then
                Lineas = Lineas + 5
                Dim tblAntecedentesF As PdfPTable = FnAntecedentesF(tblAntecedentesFamiliaresTexto.ElementAt(0))
                tblAntecedentesF.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                Lineas = Lineas + tblAntecedentesF.TotalHeight
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan los habitos del paciente, se consultan a partir del idHC que viene en el parametro arrCodigosCitaHC
            mConsulta = dc.usp_rptResumenHistoriaClinicaHabitosTexto(arrCodigosCitasHC(i, 1))
            If Not mConsulta Is Nothing Then
              Dim tblHabitosTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaHabitosTextoResult)
              For Each mR In mConsulta
                tblHabitosTexto.Add(mR)
              Next
              If tblHabitosTexto.Count > 0 Then
                Lineas = Lineas + 5
                Dim tblHabitos As PdfPTable = FnHabitos(tblHabitosTexto.ElementAt(0))
                tblHabitos.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                Lineas = Lineas + tblHabitos.TotalHeight
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan los antecedentes socieconomicos del paciente, se consultan a partir del idHC que viene en el parametro arrCodigosCitaHC
            mConsulta = dc.usp_rptResumenHistoriaClinicaAntecedentesSocioEconomicosTexto(arrCodigosCitasHC(i, 1))
            If Not mConsulta Is Nothing Then
              Dim tblAntecedentesSocioEconomicos As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesSocioEconomicosTextoResult)
              For Each mR In mConsulta
                tblAntecedentesSocioEconomicos.Add(mR)
              Next
              If tblAntecedentesSocioEconomicos.Count > 0 Then
                Lineas = Lineas + 5
                Dim tAntecedentesSocieconomicos As PdfPTable = FnAntecedentesSocieconomicos(tblAntecedentesSocioEconomicos.ElementAt(0))
                tAntecedentesSocieconomicos.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                Lineas = Lineas + tAntecedentesSocieconomicos.TotalHeight
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan los antecedeltes ginecoObstetricos del paciente, se consultan a partir del idHC que viene en el parametro arrCodigosCitaHC
            mConsulta = dc.usp_rptResumenHistoriaClinicaAntecedentesGinecoObstetricosTexto(arrCodigosCitasHC(i, 1))
            If Not mConsulta Is Nothing Then
              Dim tblGinecoTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesGinecoObstetricosTextoResult)
              For Each mR In mConsulta
                tblGinecoTexto.Add(mR)
              Next
              If tblGinecoTexto.Count > 0 Then
                Lineas = Lineas + 5
                Dim tblAntecedentesGine As PdfPTable = FnAntecedentesGine(tblGinecoTexto.ElementAt(0))
                tblAntecedentesGine.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                Lineas = Lineas + tblAntecedentesGine.TotalHeight
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan la revisión de sistemas del paciente, se consultan a partir del idHC que viene en el parametro arrCodigosCitaHC 
            mConsulta = dc.usp_rptResumenHistoriaClinicaRevisionSistemasTexto(arrCodigosCitasHC(i, 1))
            If Not mConsulta Is Nothing Then
              Dim tblRevisionsistemasTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaRevisionSistemasTextoResult)
              For Each mR In mConsulta
                tblRevisionsistemasTexto.Add(mR)
              Next
              If (tblRevisionsistemasTexto.Count > 0) Then
                If (tblRevisionsistemasTexto.ElementAt(0).strValorTexto.Trim.Count > 0) Then
                  Lineas = Lineas + 5
                  Dim tblRevisionSistemas As PdfPTable = FnRevisionSistemas(tblRevisionsistemasTexto.ElementAt(0))
                  tblRevisionSistemas.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                  Lineas = Lineas + tblRevisionSistemas.TotalHeight
                End If
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan el examen físico del paciente, se consultan a partir del idHC que viene en el parametro arrCodigosCitaHC
            mConsulta = dc.usp_rptResumenHistoriaClinicaExamenFisicoTexto(arrCodigosCitasHC(i, 1))
            If Not mConsulta Is Nothing Then
              Dim tblRevisionExamenesFisicosTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenFisicoTextoResult)
              For Each mR In mConsulta
                tblRevisionExamenesFisicosTexto.Add(mR)
              Next
              If tblRevisionExamenesFisicosTexto.Count > 0 Then
                Lineas = Lineas + 5
                Dim tblExamenFisico As PdfPTable = FnExamenFisico(tblRevisionExamenesFisicosTexto.ElementAt(0))
                tblExamenFisico.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                Lineas = Lineas + tblExamenFisico.TotalHeight
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan los examenes paraciclicos del paciente, se consultan a partir del idHC que viene en el parametro arrCodigosCitaHC
            mConsulta = dc.usp_rptResumenHistoriaClinicaExamenesParaciclicosTexto(arrCodigosCitasHC(i, 1))
            If Not mConsulta Is Nothing Then
              Dim tblRevisionExamenesTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenesParaciclicosTextoResult)
              For Each mR In mConsulta
                tblRevisionExamenesTexto.Add(mR)
              Next
              If tblRevisionExamenesTexto.Count > 0 Then
                If tblRevisionExamenesTexto.ElementAt(0).strValorTexto.Count > 0 Then
                  Lineas = Lineas + 5
                  Dim tblExamenesParaciclicos As PdfPTable = FnExamenesParaciclicos(tblRevisionExamenesTexto)
                  tblExamenesParaciclicos.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                  Lineas = Lineas + tblExamenesParaciclicos.TotalHeight
                End If
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Se consultan el diagnostico y conducta del paciente, se consultan a partir del idHC que viene en el parametro arrCodigosCitaHC
            mConsulta = dc.usp_rptResumenHistoriaClinicaDiagnosticoConductaTexto(arrCodigosCitasHC(i, 1))
            If Not mConsulta Is Nothing Then
              Dim tblDiagnosticoTexto = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaDiagnosticoConductaTextoResult)
              For Each mR In mConsulta
                tblDiagnosticoTexto.Add(mR)
              Next
              If tblDiagnosticoTexto.Count > 0 Then
                Lineas = Lineas + 5
                Dim tblDiagnosticoConducta As PdfPTable = FnDiagnosticoConducta(tblDiagnosticoTexto.ElementAt(0))
                tblDiagnosticoConducta.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                Lineas = Lineas + tblDiagnosticoConducta.TotalHeight
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Tratamiento
            mConsulta = dc.usp_rptResumenHistoriaClinicaTratamientoTexto(mintIdHC)
            If Not mConsulta Is Nothing Then
              Dim tblTratamientoTexto = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaTratamientoTextoResult)
              For Each mR In mConsulta
                tblTratamientoTexto.Add(mR)
              Next
              If tblTratamientoTexto.Count > 0 Then
                Lineas = Lineas + 5
                Dim tblTratamiento As PdfPTable = FnTratamiento(tblTratamientoTexto.ElementAt(0))
                tblTratamiento.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                Lineas = Lineas + tblTratamiento.TotalHeight
              End If
            End If

            If Lineas + 100 >= oDocumento.PageSize.Height Then
              Lineas = 30
              oDocumento.NewPage()
              ''Pie de Pagina
              'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDoc.PageSize.Height - 720, cb)
            End If
            'Evolucion
            mConsulta = dc.usp_rptResumenHistoriaClinicaEvolucion(mintIdHC)
            If Not mConsulta Is Nothing Then
              Dim tblEvolucion As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEvolucionResult)
              For Each mR In mConsulta
                tblEvolucion.Add(mR)
              Next
              If tblEvolucion.Count > 0 Then
                If tblEvolucion.ElementAt(0).Strdescripcion.Count > 0 Then
                  Lineas = Lineas + 5
                  Dim tEvolucion As PdfPTable = FnEvolucion(tblEvolucion.ElementAt(0))
                  tEvolucion.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
                  Lineas = Lineas + tEvolucion.TotalHeight
                End If
              End If
            End If
          End If
        Next
        'MsgBox("Se inserta el pie de pagina")
        Lineas = Lineas + nDistanciaEntreContenidoFirma
        'Pie de Pagina
        If Not tblPiePagina Is Nothing Then
          tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - Lineas, cbContenido)
          'tblPiePagina.WriteSelectedRows(0, -1, oDocumento.PageSize.Width - 550, oDocumento.PageSize.Height - 675, cbContenido)
        End If
        'MsgBox("Se va a cerrar el docuemto")
        pdfwWirter.Flush()
        'Cerramos el documento.
        oDocumento.Close()
        ' MsgBox("Se cierra el docuemto")
      End If
    Catch ex As Exception
      'Si hubo una excepcion y el archivo existe ...
      If File.Exists(sNombreArchivo) Then
        'Cerramos el documento si esta abierto.
        'Y asi desbloqueamos el archivo para su eliminacion.
        If oDocumento.IsOpen Then oDocumento.Close()
        '... lo eliminamos de disco.
        File.Delete(sNombreArchivo)
      End If
      MsgBox("No se pudo genrar la Historia Clínica")  '
      'Throw New Exception("Error al generar archivo PDF (" & ex.Message & ")")
    Finally
      cbContenido = Nothing
      pdfwWirter = Nothing
      oDocumento = Nothing
    End Try
  End Sub

  Private Function FnEncabezado(mRes As List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)) As PdfPTable
    Dim table As New PdfPTable(2)
    Try
            'Modificiación
            'Realizada por: Alejandro Torres Monsalve
            'Fecha: 2016/05/07
            'Descripción: Se hacen los ajustes del tamaño solicitados
            Dim aWidthsCells(1) As Single
            aWidthsCells(0) = 100
            aWidthsCells(1) = 210

            table.SetWidths(aWidthsCells)

            table.TotalWidth = 310.0F
            Dim cell As New PdfPCell(New Phrase("PACIENTE", fuenteBold))
      cell.Colspan = 2
      cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
      cell.BackgroundColor = BaseColor.LIGHT_GRAY

            table.AddCell(cell)
            table.AddCell(New Phrase("Apellidos:", fuenteNormal))
            table.AddCell(New Phrase(mRes.ElementAt(0).Apellidos, fuenteNormal))
            table.AddCell(New Phrase("Nombres: ", fuenteNormal))
            table.AddCell(New Phrase(mRes.ElementAt(0).Nombres, fuenteNormal))
            table.AddCell(New Phrase("Número de Identificación: ", fuenteNormal))
            table.AddCell(New Phrase(mRes.ElementAt(0).strNroIdentificacion, fuenteNormal))
            table.AddCell(New Phrase("Sexo: ", fuenteNormal))
            table.AddCell(New Phrase(mRes.ElementAt(0).Sexo, fuenteNormal))
            table.AddCell(New Phrase("Edad: ", fuenteNormal))
            table.AddCell(New Phrase(mRes.ElementAt(0).Edad, fuenteNormal))
            table.AddCell(New Phrase("Dirección: ", fuenteNormal))
            table.AddCell(New Phrase(mRes.ElementAt(0).strDireccion, fuenteNormal))
            table.AddCell(New Phrase("Aseguradora: ", fuenteNormal))
            table.AddCell(New Phrase(mRes.ElementAt(0).strEPS, fuenteNormal))

        Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnTitulo() As PdfPTable
    Dim table As New PdfPTable(1)

    Try
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER
            Dim fontH1 As New Font(vbCurrency, 16, Font.BOLD)

            table.TotalWidth = 500.0F
            Dim cell As New PdfPCell(New Phrase("HISTORIA CLINICA", fontH1))
            cell.Colspan = 1
      cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

            table.AddCell(cell)
    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnFechas(mRes As List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)) As PdfPTable
    Dim table As New PdfPTable(4)

    Try
      '-- Modificación ---------------------------------------------------------------------------------------------------------------
      '--Autor: Alejandro Torres Monsalve
      '--Fecha: 2016/05/08
      'Descripcion: Se le asignan tamaños a las celdas para evitar que se vea mucho espacio desperdiciado al momento de imprimir
      Dim aWidthsCells(3) As Single
      aWidthsCells(0) = 30
      aWidthsCells(1) = 80
      aWidthsCells(2) = 80
      aWidthsCells(3) = 150

      table.SetWidths(aWidthsCells)
      '-- Fin modificación ----------------------------------------------------------------------------------------------------------
      table.DefaultCell.BorderColor = BaseColor.WHITE
      table.DefaultCell.Border = Rectangle.NO_BORDER
      table.TotalWidth = 340.0F
      table.AddCell(New Phrase("Fecha:", fuenteNormal))
      table.AddCell(New Phrase(mRes.ElementAt(0).dtmFecha, fuenteNormal))
      table.AddCell(New Phrase("Medico Tratante: ", fuenteNormal))
      table.AddCell(New Phrase(mRes.ElementAt(0).strNombreEmpleado, fuenteNormal))
      table.AddCell(New Phrase(" ", fuenteNormal))
    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnMotivoColsulta(mResumen As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaMotivosConsultaResult) As PdfPTable
    Dim table As New PdfPTable(2)
    Try

            table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER
            table.DefaultCell.Border = Rectangle.NO_BORDER

            table.TotalWidth = 200.0F
            table.AddCell(New Phrase("Motivo de Consulta:", fuenteBold))

            'Dim cell5 As New PdfPCell(New Phrase("Motivo de Consulta:", fuenteBold))
            'cell5.Colspan = 2
            'cell5.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
            'cell5.Border = Rectangle.NO_BORDER
            'cell5.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

            'table.AddCell(cell5)

            'table.AddCell(New Phrase(mResumen.strDescripcion, fuenteBold))

            Dim cell3 As New PdfPCell(New Phrase(mResumen.strDescripcion, fuenteBold))
            cell3.Colspan = 2
            cell3.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
            cell3.Border = Rectangle.NO_BORDER
            cell3.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

            table.AddCell(cell3)


            If mResumen.strDescripcionMotivo.Length > 0 Then
                'Dim cell As New PdfPCell(New Phrase("Descripción del Motivo y la Enfermedad", fuenteBold))
                'cell.Colspan = 2
                ''cell.BackgroundColor = BaseColor.LIGHT_GRAY
                'cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
                'cell.Border = Rectangle.NO_BORDER
                'cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

                'table.AddCell(cell)

                Dim cell2 As New PdfPCell(New Phrase(mResumen.strDescripcionMotivo, fuenteNormal))
                cell2.Colspan = 2
                cell2.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
                cell2.Border = Rectangle.NO_BORDER
                cell2.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

                table.AddCell(cell2)
      End If

      If mResumen.strDescripcionEnfermedad.Length > 0 Then
        'Dim cell3 As New PdfPCell(New Phrase("Descripción Enfermedad", fuenteBold))
        'cell3.Colspan = 2
        'cell3.BackgroundColor = BaseColor.LIGHT_GRAY
        'cell3.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
        'table.AddCell(cell3)

        Dim cell4 As New PdfPCell(New Phrase(mResumen.strDescripcionEnfermedad, fuenteNormal))
        cell4.Colspan = 2
        cell4.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
        cell4.Border = Rectangle.NO_BORDER
        cell4.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

        table.AddCell(cell4)
      End If

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnAntecedentesP(mAntecedentes As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesPersonalesTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER


      Dim cell As New PdfPCell(New Phrase("Antecedentes Personales", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
      table.AddCell(cell)
      table.AddCell(New Phrase(mAntecedentes.strHCtexto, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnAntecedentesF(mAntecedente As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesFamiliaresTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Antecedentes Familiares", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
      table.AddCell(cell)

      table.AddCell(New Phrase(mAntecedente.strHCtexto, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnHabitos(mHabitos As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaHabitosTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Hábitos", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      table.AddCell(New Phrase(mHabitos.strHcTextoHabitos, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnAntecedentesSocieconomicos(mAntecedentes As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesSocioEconomicosTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Antecedentes Socieconómicos", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      table.AddCell(New Phrase(mAntecedentes.strHcAntEconomicos, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnAntecedentesGine(mGineco As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaAntecedentesGinecoObstetricosTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Antecedentes Gineco-Obstétricos", fuenteBold))
      cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      table.AddCell(New Phrase(mGineco.strHcTextoGinecoObst, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnRevisionSistemas(mRevision As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaRevisionSistemasTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try
      If mRevision.strValorTexto.Trim.Count > 0 Then
        table.TotalWidth = 500.0F
        table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

        Dim cell As New PdfPCell(New Phrase("Revisión de Sistemas", fuenteBold))
        'cell.BackgroundColor = BaseColor.LIGHT_GRAY
        cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
        cell.Border = Rectangle.NO_BORDER
        cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

        table.AddCell(cell)

        table.AddCell(New Phrase(mRevision.strValorTexto, fuenteNormal))
      End If
    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnExamenFisico(mExamenFisico As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenFisicoTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Examen Físico", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      table.AddCell(New Phrase(mExamenFisico.strValorTexto, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnExamenesParaciclicos(mExamenes As List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenesParaciclicosTextoResult)) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Exámenes Paracíclicos", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      For Each mR In mExamenes
        If mR.strValorTexto.Trim.Length > 0 Then
          table.AddCell(New Phrase(mR.strValorTexto, fuenteNormal))
        End If
        'tblRevisionExamenesTexto.Add(mR)
      Next


    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnDiagnosticoConducta(mDiagnostico As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaDiagnosticoConductaTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try
            table.TotalWidth = 500.0F
            table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

            Dim cell As New PdfPCell(New Phrase("Diagnóstico", fuenteBold))
            'cell.BackgroundColor = BaseColor.LIGHT_GRAY
            cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
            cell.Border = Rectangle.NO_BORDER
            cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

            table.AddCell(cell)

            Dim mIndex As Integer = mDiagnostico.strDiagnosticoConductaTextoHC.IndexOf(vbNewLine + vbNewLine)

            'mIndex = mIndex + mDiagnostico.strDiagnosticoConductaTextoHC.Substring(mIndex + 1).IndexOf(vbNewLine)
            Dim Diagnostico As String = mDiagnostico.strDiagnosticoConductaTextoHC.Substring(0, mIndex + 1)
            table.AddCell(New Phrase(Diagnostico, fuenteNormal))

            cell = New PdfPCell(New Phrase("Conducta", fuenteBold))
            'cell.BackgroundColor = BaseColor.LIGHT_GRAY
            cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
            cell.Border = Rectangle.NO_BORDER
            cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

            table.AddCell(cell)

            Dim Conducta As String = mDiagnostico.strDiagnosticoConductaTextoHC.Substring(mIndex + 1).TrimStart()

            table.AddCell(New Phrase(Conducta, fuenteNormal))

        Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnTratamiento(mTratamiento As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaTratamientoTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Tratamiento", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      table.AddCell(New Phrase(mTratamiento.strTratamientoTexto, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnEvolucion(mEvolucion As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEvolucionResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Evolución", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      table.AddCell(New Phrase(mEvolucion.Strdescripcion, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnPiePagina(mRes As List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)) As PdfPTable
    Dim table As New PdfPTable(1)
        Try
            Dim cell As PdfPCell
            table.TotalWidth = 500.0F
            table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER
            table.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right

            '-- Modificación '-- Fin modificación ------------------------------------------------------------------------------------------------------------------------------
            '--Autor: Alejandro Torres Monsalve
            '--Fecha: 2016/05/01
            'Descripcion: Se crea variable para leer parametros del appconfig, se agregan los datos del medico y los datos con la informacion del laboratorio
            'en una misma tabla para que siempre vayan juntos y evitar que la información no se vea en el documento que se desea imprimir
            'Se modifica para que solo se haga una declaracion de variable de tipo PdfCell, esto para que no se desperdicie memoria creando varias variables del mismo tipo
            Docxml = XDocument.Load(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")
            Try

                Dim oImagen As Image 'iTextSharp.text.Image
                Dim stream As System.IO.MemoryStream
                Dim Img As System.Drawing.Image
                If mRes.ElementAt(0).Firma IsNot Nothing Then
                    Dim imageConverter As New System.Drawing.ImageConverter()
                    Dim ImgByte As Byte() = CType(mRes.ElementAt(0).Firma.ToArray, Byte())
                    oImagen = Image.GetInstance(ImgByte) 'EmpImg.Image = Img
                End If

                oImagen.ScalePercent(50, 50)
                oImagen.Left = 0
                cell = New PdfPCell(oImagen)
                cell.BackgroundColor = BaseColor.LIGHT_GRAY
                cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
                cell.Border = Rectangle.NO_BORDER 'NO_BORDER
                cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
                table.AddCell(cell)

            Catch ex As Exception
                'No hace nada
            End Try

            cell = New PdfPCell(New Phrase("______________________________________", fuenteBold))
            cell.BackgroundColor = BaseColor.LIGHT_GRAY
            cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
            cell.Border = Rectangle.NO_BORDER
            cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
            table.AddCell(cell)
            table.AddCell(New Phrase(mRes.ElementAt(0).strNombreEmpleado, fuenteNormal))
            table.AddCell(New Phrase(mRes.ElementAt(0).strEspecializacion, fuenteNormal))
            table.AddCell(New Phrase(mRes.ElementAt(0).strRegistroMedico, fuenteNormal))


            'Espacio entre la firma del profesional y los datos del laboratorio
            cell = New PdfPCell(New Phrase(" ", fuenteNormal))
            cell.BackgroundColor = BaseColor.LIGHT_GRAY
            cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
            cell.Border = Rectangle.NO_BORDER 'NO_BORDER
            cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
            table.AddCell(cell)

            cell = New PdfPCell(New Phrase(" ", fuenteNormal))
            cell.BackgroundColor = BaseColor.LIGHT_GRAY
            cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
            cell.Border = Rectangle.NO_BORDER 'NO_BORDER
            cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
            table.AddCell(cell)

            cell = New PdfPCell(New Phrase(" ", fuenteNormal))
            cell.BackgroundColor = BaseColor.LIGHT_GRAY
            cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
            cell.Border = Rectangle.NO_BORDER 'NO_BORDER
            cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
            table.AddCell(cell)
            'Fin de espacio entre la firma del profesional y los datos del laboratorio
            '-------------------------------------------------------------------------------------------------------------------------------------------------------------------

            cell = New PdfPCell(New Phrase(Docxml.Descendants("setting")(4).Value, fuenteBold))
            cell.BackgroundColor = BaseColor.LIGHT_GRAY
            cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
            cell.Border = Rectangle.TOP_BORDER 'NO_BORDER
            cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
            table.AddCell(cell)

            cell = New PdfPCell(New Phrase(Docxml.Descendants("setting")(5).Value, fuenteBold))
            cell.BackgroundColor = BaseColor.LIGHT_GRAY
            cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
            cell.Border = Rectangle.NO_BORDER
            cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
            table.AddCell(cell)

            cell = New PdfPCell(New Phrase(Docxml.Descendants("setting")(6).Value, fuenteBold))
            cell.BackgroundColor = BaseColor.LIGHT_GRAY
            cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
            cell.Border = Rectangle.NO_BORDER
            cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
            table.AddCell(cell)
            '-- Fin modificación -----------------------------------------------------------------------------------------------------------------------------------------------

        Catch ex As Exception

        End Try
    Return table
  End Function

End Class
