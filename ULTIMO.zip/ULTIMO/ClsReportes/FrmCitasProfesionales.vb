﻿Imports Microsoft.Reporting.WinForms
Imports System.Windows.Forms

Public Class FrmCitasProfesionales
    Dim mstrStringConection As String
    Dim mdtmFechaInicial As Date
    Dim mdtmFechaFinal As Date
    Dim mintIdProfesional As String
    Dim mintEstadoCita As Integer
    Dim mstrUsuario As String
    Dim mintSede As Integer
    Public Sub New(ByVal strStringConection As String, ByVal dtmFechaInicial As Date, ByVal dtmFechaFinal As Date, ByVal intIdProfesional As Integer, ByVal strUsuario As String, ByVal intEstadoCita As Integer, ByVal intSede As Integer)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        mstrStringConection = strStringConection
        mdtmFechaInicial = dtmFechaInicial
        mdtmFechaFinal = dtmFechaFinal
        mintIdProfesional = intIdProfesional
        mstrUsuario = strUsuario
        mintEstadoCita = intEstadoCita
        mintSede = intSede
    End Sub

    Private Sub FrmCitasProfesionales_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim mResultado = dc.usp_RptCitasProfesionales(mintIdProfesional, mdtmFechaInicial, mdtmFechaFinal, mintEstadoCita, IIf(mintSede = 0, Nothing, mintSede))

            Dim mRes As New List(Of Object)

            For Each mR In mResultado
                mRes.Add(mR)
            Next

            BindingSource.DataSource = mRes

            Dim paramList As New Generic.List(Of ReportParameter)
            paramList.Add(New ReportParameter("FechaInicial", mdtmFechaInicial))
            paramList.Add(New ReportParameter("FechaFinal", mdtmFechaFinal))
            paramList.Add(New ReportParameter("strUsuario", mstrUsuario))

            Me.ReportViewer1.LocalReport.SetParameters(paramList)
            Me.Dock = DockStyle.Fill
            Me.ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
            Me.ReportViewer1.ZoomMode = ZoomMode.Percent
            Me.ReportViewer1.ZoomPercent = 100
            Me.ReportViewer1.RefreshReport()

        Catch ex As Exception

        End Try




    End Sub
End Class