﻿Imports System.Windows.Forms

Public Class frmGenerarRIPS
  Dim sConection As String

  Public dFechaIncial As Date
  Public dFechaFinal As Date
  Public nIdPrestador As Integer
  Public sMensaje As String
  ''' <summary>
  ''' Constructor del formulario
  ''' </summary>
  ''' <param name="sConectionDB">Cadena de conecxión a la base de datos que se manda desde el formulario donde se invoca</param>
  ''' <remarks></remarks>
  Sub New(ByVal sConectionDB As String)
    Try
      ' Llamada necesaria para el Diseñador de Windows Forms.
      InitializeComponent()
      sConection = sConectionDB
    Catch ex As Exception
      MsgBox(ex.Message)
    End Try

  End Sub
  ''' <summary>
  ''' Se carga los datos iniciales en el formaulario al abrirlo
  ''' </summary>
  ''' <param name="sender"></param>
  ''' <param name="e"></param>
  ''' <remarks></remarks>
  Private Sub frmGenerarRIPS_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    'Se inicializan las variables y se llenan los combos con los datos respectivos para realizar los filtros de los informes
    dpFechaInicio.Value = DateTime.Now.AddMonths(-1)
    dpFechaFinal.Value = DateTime.Now
    'Se llenan los combos
    Try
      CargarCombos()
    Catch ex As Exception
      MsgBox(String.Format("Error al inicializar el formulario, {0}", ex.Message))
    End Try
  End Sub

  Private Sub CargarCombos()
    'Se buscan los datos en la base de datos
    Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(sConection)
    cmbPrestadores.DataSource = dc.tblDatosPrestadores
    cmbPrestadores.DisplayMember = "strRazonSocial"
    cmbPrestadores.ValueMember = "intIdPrestadores"
  End Sub

  Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnAceptar_Click(sender As Object, e As EventArgs) Handles btnAceptar.Click
    'Se validan los datos
    Dim sErrores As String = String.Empty
    If cmbPrestadores.SelectedValue <= 0 Then
      sErrores = "Debe seleccionar un prestador."
    End If
    If dpFechaInicio.Value = Nothing Or dpFechaInicio.Value = DateTime.MinValue Then
      If Not String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If
      sErrores += "Debe seleccionar una fecha inicio valida"
    End If
    If dpFechaFinal.Value = Nothing Or dpFechaFinal.Value = DateTime.MinValue Then
      If Not String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If
      sErrores += "Debe seleccionar una fecha final valida"
    End If

    If String.IsNullOrWhiteSpace(sErrores) Then
      Dim RIPSBl As ReglasNegocio.RIPS = New ReglasNegocio.RIPS()
      Me.Enabled = False

      sMensaje = RIPSBl.GenerarAchivoRIPS(dpFechaInicio.Value, dpFechaFinal.Value, cmbPrestadores.SelectedValue)
      Me.Enabled = True

      Me.DialogResult = System.Windows.Forms.DialogResult.OK
      Me.Close()
    Else
      MsgBox(sErrores, MsgBoxStyle.Information, "Validaciones")
    End If
  End Sub
End Class