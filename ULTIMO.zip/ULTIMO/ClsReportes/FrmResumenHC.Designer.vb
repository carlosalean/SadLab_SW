﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmResumenHC
  Inherits System.Windows.Forms.Form

  'Form reemplaza a Dispose para limpiar la lista de componentes.
  <System.Diagnostics.DebuggerNonUserCode()>
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Requerido por el Diseñador de Windows Forms
  Private components As System.ComponentModel.IContainer

  'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
  'Se puede modificar usando el Diseñador de Windows Forms.  
  'No lo modifique con el editor de código.
  <System.Diagnostics.DebuggerStepThrough()>
  Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmResumenHC))
    Me.ReportViewer = New Microsoft.Reporting.WinForms.ReportViewer()
    Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
    Me.BindingSource = New System.Windows.Forms.BindingSource(Me.components)
    CType(Me.BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'ReportViewer
    '
    Me.ReportViewer.Dock = System.Windows.Forms.DockStyle.Fill
    ReportDataSource1.Name = "usp_rptResumenHistoriaClinicaEncabezadoResult"
    ReportDataSource1.Value = Me.BindingSource
    Me.ReportViewer.LocalReport.DataSources.Add(ReportDataSource1)
    Me.ReportViewer.LocalReport.ReportEmbeddedResource = "ClsReportes.rptResumenHistoriaClinica.rdlc"
    Me.ReportViewer.Location = New System.Drawing.Point(0, 0)
    Me.ReportViewer.Name = "ReportViewer"
    Me.ReportViewer.Size = New System.Drawing.Size(820, 539)
    Me.ReportViewer.TabIndex = 0
    Me.ReportViewer.Visible = False
    '
    'WebBrowser1
    '
    Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.WebBrowser1.Location = New System.Drawing.Point(0, 0)
    Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
    Me.WebBrowser1.Name = "WebBrowser1"
    Me.WebBrowser1.Size = New System.Drawing.Size(820, 539)
    Me.WebBrowser1.TabIndex = 1
    '
    'BindingSource
    '
    Me.BindingSource.DataSource = GetType(ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)
    '
    'FrmResumenHC
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(820, 539)
    Me.Controls.Add(Me.WebBrowser1)
    Me.Controls.Add(Me.ReportViewer)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Name = "FrmResumenHC"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Resumen Historia Clínica"
    Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
    CType(Me.BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)

  End Sub
  Friend WithEvents ReportViewer As Microsoft.Reporting.WinForms.ReportViewer
  Friend WithEvents BindingSource As System.Windows.Forms.BindingSource
  Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
End Class
