﻿Imports System.Windows.Forms

Public Class DialogFacturacion

    Dim mstrStringConection As String
    Dim mstrIntIdUsuario As String
    Public mNroFactura As String
    Public MPaciente As Boolean
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Public intIdPrestadores As Integer
    Public mCerrarFactura As Boolean
    Public FUsuarioCierra As Integer

    Public Sub New(ByVal strStringConection As String, ByVal pstrIntIdUsuario As String)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Try
            mstrStringConection = strStringConection
            mstrIntIdUsuario = pstrIntIdUsuario
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Try
            Dim mImpresa As Boolean = False
            intIdPrestadores = ClsComboBox1.SelectedValue
            Dim mstrnroFactura As String = ClsTextBoxNroFact.Text

            Try

                Dim mTblFacturas = (From f In dc.tblFacturacions Where f.strNroFactura = mstrnroFactura And f.intIdPrestador = intIdPrestadores Select f)
                Dim mCuenta As Integer = 1
                For Each mTblFactura In mTblFacturas
                    If mCuenta > 1 Then Exit For
                    If mTblFactura.bitImpresa = True And ClsCheckBoxCerrarFactura.Checked Then
                        MsgBox("Esta Factura ya se encuentra cerrada..", MsgBoxStyle.Information, "Imprimir Factura")
                        Exit Sub
                    End If
                    mImpresa = mTblFactura.bitImpresa
                    If mTblFactura.bitAnulada = True Then
                        MsgBox("Esta Factura se encuentra anulada..", MsgBoxStyle.Information, "Imprimir Factura")
                        Exit Sub
                    End If
                    mCuenta = mCuenta + 1
                Next mTblFactura
            Catch ex As Exception
                'No hace nada
            End Try

            Me.DialogResult = System.Windows.Forms.DialogResult.OK

            If Not mImpresa Then
                dc.CommandTimeout = 12000
                dc.usp_Facturacion(ClsTextBoxNroFact.Text, ClsDateTimePickerFechaFact.Value, intIdPrestadores)
            End If

            mNroFactura = ClsTextBoxNroFact.Text
            MPaciente = ClsCheckBoxPaciente.Checked
            mCerrarFactura = ClsCheckBoxCerrarFactura.Checked
            If mCerrarFactura Then
ValidarHuella:
                Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario, False)
                If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then
                    FUsuarioCierra = mValidaHuella.mstrIntIdUsuario
                    Me.Close()
                Else
                    MsgBox("Debe Validar su identidad si desea cerrar la factura..", MsgBoxStyle.Information, "Imprimir Factura")
                    GoTo ValidarHuella
                    'Return
                    'Exit Sub
                End If
            Else
                Me.Close()
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DialogFacturacion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TblDatosPrestadoresBindingSource.DataSource = dc.tblDatosPrestadores
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class
