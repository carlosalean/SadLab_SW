﻿Imports System.IO
Imports iTextSharp.text.pdf
Imports iTextSharp.text

Public Class ClsAnexosHistoriaClinicaPDF
  Dim fuenteNormal As New Font(Font.FontFamily.HELVETICA, 8, Font.NORMAL)
  Dim fuenteBold As New Font(Font.FontFamily.HELVETICA, 8, Font.BOLD)

  Dim mstrStringConection As String
  Dim mintIdCita As Integer
  Dim mintIdHC As Integer

  Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

  Dim mConsulta
  Dim Docxml As XDocument

  Public Sub New(ByVal pstrStringConection As String, ByVal pintIdCita As Integer, ByVal pintIdHC As Integer)

    ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    mstrStringConection = pstrStringConection
    mintIdCita = pintIdCita
    mintIdHC = pintIdHC

    dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
  End Sub

  Public Sub GenerarAnexoPDF(strNombreArchivo As String, mNumeroAnexo As Integer, Optional strValor As String = "")
    Dim oDoc As New iTextSharp.text.Document(PageSize.A4, 0, 0, 0, 0)
    Dim pdfw As iTextSharp.text.pdf.PdfWriter
    Dim cb As PdfContentByte

    Dim NombreArchivo As String = strNombreArchivo

    Dim oImagen As Image 'iTextSharp.text.Image
    Dim coordenadaX As Single = 5
    Dim coordenadaY As Single = 5

    Try
      pdfw = PdfWriter.GetInstance(oDoc, New FileStream(NombreArchivo,
      FileMode.Create, FileAccess.Write, FileShare.None))
      'Apertura del documento.
      oDoc.Open()
      cb = pdfw.DirectContent
      'Agregamos una pagina.
      oDoc.NewPage()
      '-- Modificación -------------------
      '--Autor: Alejandro Torres Monsalve
      '--Fecha: 2016/05/01
      'Descripcion: Se crea variable para leer parametros del appconfig, se valida contra el parametro en el app.config EsDesarrollo para validar de donde se va a cargar el logo
      Docxml = XDocument.Load(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")

      If Docxml.Descendants("setting")(3).Value.Equals("0") Then
        If Not My.Computer.FileSystem.FileExists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\LogoVasculab.bmp") Then
          My.Computer.FileSystem.CopyFile(My.Application.Info.DirectoryPath & "\LogoVasculab.bmp",
                                         My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")
        End If
        oImagen = Image.GetInstance(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\LogoVasculab.bmp")
      Else
        oImagen = Image.GetInstance(String.Format("{0}\{1}\{2}", My.Computer.FileSystem.SpecialDirectories.MyDocuments, My.Application.Info.CompanyName, Docxml.Descendants("setting")(7).Value))
      End If


      oImagen.SetAbsolutePosition(50, oDoc.PageSize.Height - 100)

      cb.AddImage(oImagen)

      Dim Lineas As Integer = 20
      'Encabezado
      Dim mResultado = dc.usp_rptResumenHistoriaClinicaEncabezado(mintIdCita, Now, Now)
      Dim mRes As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)
      For Each mR In mResultado
        mRes.Add(mR)
      Next

      Dim tblPiePagina As PdfPTable = FnPiePagina(mRes)

      Dim tblEncabezado As PdfPTable = FnEncabezado(mRes)
      tblEncabezado.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 230, oDoc.PageSize.Height - Lineas, cb)

      'Fecha
      Lineas = Lineas + 80
      Dim tblFechas As PdfPTable = FnFechas(mRes)
      tblFechas.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
      Lineas = Lineas + tblFechas.TotalHeight

      If mNumeroAnexo = 1 Then
        'Diagnostico y Conducta
        mConsulta = dc.usp_rptResumenHistoriaClinicaDiagnosticoConductaTexto(mintIdHC)
        If Not mConsulta Is Nothing Then
          Dim tblDiagnosticoTexto = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaDiagnosticoConductaTextoResult)
          For Each mR In mConsulta
            tblDiagnosticoTexto.Add(mR)
          Next
          If tblDiagnosticoTexto.Count > 0 Then
            Lineas = Lineas + 10
            Dim tblDiagnosticoConducta As PdfPTable = FnDiagnosticoConducta(tblDiagnosticoTexto.ElementAt(0))
            tblDiagnosticoConducta.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
            Lineas = Lineas + tblDiagnosticoConducta.TotalHeight
          End If
        End If
      End If


      'Tratamiento
      If mNumeroAnexo = 2 Then

        mConsulta = dc.usp_rptResumenHistoriaClinicaTratamientoTexto(mintIdHC)
        If Not mConsulta Is Nothing Then
          Dim tblTratamientoTexto = New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaTratamientoTextoResult)
          For Each mR In mConsulta
            tblTratamientoTexto.Add(mR)
          Next
          If tblTratamientoTexto.Count > 0 Then
            Lineas = Lineas + 10
            Dim tblTratamiento As PdfPTable = FnTratamiento(tblTratamientoTexto.ElementAt(0))
            tblTratamiento.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
            Lineas = Lineas + tblTratamiento.TotalHeight
          End If
        End If
      End If

      If mNumeroAnexo = 3 Then

        'Evolucion
        mConsulta = dc.usp_rptResumenHistoriaClinicaEvolucion(mintIdHC)
        If Not mConsulta Is Nothing Then
          Dim tblEvolucion As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEvolucionResult)
          For Each mR In mConsulta
            tblEvolucion.Add(mR)
          Next
          If tblEvolucion.Count > 0 Then
            If tblEvolucion.ElementAt(0).Strdescripcion.Count > 0 Then
              Lineas = Lineas + 10
              Dim tEvolucion As PdfPTable = FnEvolucion(tblEvolucion.ElementAt(0))
              tEvolucion.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
              Lineas = Lineas + tEvolucion.TotalHeight
            End If
          End If
        End If
      End If

      If mNumeroAnexo = 4 Then

        'Examenes Paraciclicos
        mConsulta = dc.usp_rptResumenHistoriaClinicaExamenesParaciclicosTexto(mintIdHC)
        If Not mConsulta Is Nothing Then
          Dim tblRevisionExamenesTexto As New List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenesParaciclicosTextoResult)
          For Each mR In mConsulta
            tblRevisionExamenesTexto.Add(mR)
          Next
          If tblRevisionExamenesTexto.Count > 0 Then
            If tblRevisionExamenesTexto.ElementAt(0).strValorTexto.Count > 0 Then
              Lineas = Lineas + 10
              Dim tblExamenesParaciclicos As PdfPTable = FnExamenesParaciclicos(tblRevisionExamenesTexto.ElementAt(0), strValor)
              tblExamenesParaciclicos.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - Lineas, cb)
              Lineas = Lineas + tblExamenesParaciclicos.TotalHeight
            End If
          End If
        End If
      End If
      '--Modificación:
      '--Fecha: 
      Lineas = Lineas + 50

      If Lineas + 100 >= oDoc.PageSize.Height Then
        Lineas = 280
      End If

      'Pie de Pagina
      tblPiePagina.WriteSelectedRows(0, -1, oDoc.PageSize.Width - 550, oDoc.PageSize.Height - 275, cb)

      pdfw.Flush()
      'Cerramos el documento.
      oDoc.Close()

    Catch ex As Exception
      'Si hubo una excepcion y el archivo existe ...
      If File.Exists(NombreArchivo) Then
        'Cerramos el documento si esta abierto.
        'Y asi desbloqueamos el archivo para su eliminacion.
        If oDoc.IsOpen Then oDoc.Close()
        '... lo eliminamos de disco.
        File.Delete(NombreArchivo)
      End If
      MsgBox("No se pudo genrar la Historia Clínica")  'Throw New Exception("Error al generar archivo PDF (" & ex.Message & ")")
    Finally
      cb = Nothing
      pdfw = Nothing
      oDoc = Nothing
    End Try
  End Sub

  Private Function FnEncabezado(mRes As List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)) As PdfPTable
    Dim table As New PdfPTable(2)
    Try
      '--Modificación ---------------------------------------------------------------------------------------------------------------
      '--Autor: Alejandro Torres Monsalve
      '--Fecha: 2016/05/08
      'Descripcion: Se le asignan tamaños a las celdas para evitar que se vea mucho espacio desperdiciado al momento de imprimir
      Dim aWidthsCells(1) As Single
      aWidthsCells(0) = 100
      aWidthsCells(1) = 110

      table.SetWidths(aWidthsCells)
      '-- Fin modificación ----------------------------------------------------------------------------------------------------------
      table.TotalWidth = 210.0F
      Dim cell As New PdfPCell(New Phrase("PACIENTE", fuenteBold))
      cell.Colspan = 2
      cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
      cell.BackgroundColor = BaseColor.LIGHT_GRAY

      table.AddCell(cell)
      table.AddCell(New Phrase("Apellidos:", fuenteNormal))
      table.AddCell(New Phrase(mRes.ElementAt(0).Apellidos, fuenteNormal))
      table.AddCell(New Phrase("Nombres: ", fuenteNormal))
      table.AddCell(New Phrase(mRes.ElementAt(0).Nombres, fuenteNormal))
      table.AddCell(New Phrase("Número de Identificación: ", fuenteNormal))
      table.AddCell(New Phrase(mRes.ElementAt(0).strNroIdentificacion, fuenteNormal))
      table.AddCell(New Phrase("Profesional: ", fuenteNormal))
      table.AddCell(New Phrase(mRes.ElementAt(0).strNombreEmpleado, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnFechas(mRes As List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)) As PdfPTable
    Dim table As New PdfPTable(4)

    Try
      '-- Modificación ---------------------------------------------------------------------------------------------------------------
      '--Autor: Alejandro Torres Monsalve
      '--Fecha: 2016/05/08
      'Descripcion: Se le asignan tamaños a las celdas para evitar que se vea mucho espacio desperdiciado al momento de imprimir
      Dim aWidthsCells(3) As Single
      aWidthsCells(0) = 30
      aWidthsCells(1) = 130
      aWidthsCells(2) = 130
      aWidthsCells(3) = 210

      table.SetWidths(aWidthsCells)
      '-- Fin modificación ----------------------------------------------------------------------------------------------------------
      table.DefaultCell.BorderColor = BaseColor.WHITE
      table.DefaultCell.Border = Rectangle.NO_BORDER
      table.TotalWidth = 500.0F

      table.AddCell(New Phrase("Fecha:", fuenteNormal))
      table.AddCell(New Phrase(mRes.ElementAt(0).dtmFecha, fuenteNormal))
      table.AddCell(New Phrase(" ", fuenteNormal))
      table.AddCell(New Phrase(" ", fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnExamenesParaciclicos(mExamenes As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaExamenesParaciclicosTextoResult, Optional strValor As String = "") As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Exámenes ", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)
      If strValor.Trim.Length > 0 Then
        table.AddCell(New Phrase(strValor, fuenteNormal))
      Else
        table.AddCell(New Phrase(mExamenes.strValorTexto, fuenteNormal))
      End If

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnDiagnosticoConducta(mDiagnostico As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaDiagnosticoConductaTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Diagnóstico y Conducta", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      table.AddCell(New Phrase(mDiagnostico.strDiagnosticoConductaTextoHC, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnTratamiento(mTratamiento As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaTratamientoTextoResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Tratamiento", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      table.AddCell(New Phrase(mTratamiento.strTratamientoTexto, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnEvolucion(mEvolucion As ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEvolucionResult) As PdfPTable
    Dim table As New PdfPTable(1)
    Try

      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER

      Dim cell As New PdfPCell(New Phrase("Evolución", fuenteBold))
      'cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)

      table.AddCell(cell)

      table.AddCell(New Phrase(mEvolucion.Strdescripcion, fuenteNormal))

    Catch ex As Exception

    End Try
    Return table
  End Function

  Private Function FnPiePagina(mRes As List(Of ClsBaseDatos_SadLab.usp_rptResumenHistoriaClinicaEncabezadoResult)) As PdfPTable
    Dim table As New PdfPTable(1)
    Try
      table.TotalWidth = 500.0F
      table.DefaultCell.BorderColor = BaseColor.WHITE ' Rectangle. NO_BORDER
      table.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right

      '-- Modificación ---------------------------------------------------------------------------------------------------------------------------------------------------
      '--Autor: Alejandro Torres Monsalve
      '--Fecha: 2016/05/07
      'Descripcion: Se crea variable para leer parametros del appconfig, se agregan los datos del medico y los datos con la informacion del laboratorio
      'en una misma tabla para que siempre vayan juntos y evitar que la información no se vea en el documento que se desea imprimir
      'Se modifica para que solo se haga una declaracion de variable de tipo PdfCell, esto para que no se desperdicie memoria creando varias variables del mismo tipo
      Docxml = XDocument.Load(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")

      Dim cell As New PdfPCell(New Phrase("______________________________________", fuenteBold))
      cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 0 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
      table.AddCell(cell)
      table.AddCell(New Phrase(mRes.ElementAt(0).strNombreEmpleado, fuenteNormal))
      table.AddCell(New Phrase(mRes.ElementAt(0).strEspecializacion, fuenteNormal))

      'Espacio entre la firma del profesional y los datos del laboratorio
      cell = New PdfPCell(New Phrase(" ", fuenteNormal))
      cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER 'NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
      table.AddCell(cell)

      cell = New PdfPCell(New Phrase(" ", fuenteNormal))
      cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER 'NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
      table.AddCell(cell)

      cell = New PdfPCell(New Phrase(" ", fuenteNormal))
      cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER 'NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
      table.AddCell(cell)
      'Fin de espacio entre la firma del profesional y los datos del laboratorio
      '-------------------------------------------------------------------------------------------------------------------------------------------------------------------
      cell = New PdfPCell(New Phrase(Docxml.Descendants("setting")(4).Value, fuenteBold))
      cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.TOP_BORDER 'NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
      table.AddCell(cell)

      cell = New PdfPCell(New Phrase(Docxml.Descendants("setting")(5).Value, fuenteBold))
      cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
      table.AddCell(cell)

      cell = New PdfPCell(New Phrase(Docxml.Descendants("setting")(6).Value, fuenteBold))
      cell.BackgroundColor = BaseColor.LIGHT_GRAY
      cell.HorizontalAlignment = 1 '0=Left, 1=Centre, 2=Right
      cell.Border = Rectangle.NO_BORDER
      cell.BackgroundColor = BaseColor.WHITE  'New Color(255, 255, 45)
      table.AddCell(cell)
      '-- Fin modificación -----------------------------------------------------------------------------------------------------------------------------------------------
    Catch ex As Exception

    End Try
    Return table
  End Function

End Class
