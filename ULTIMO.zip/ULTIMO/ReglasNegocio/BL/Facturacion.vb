﻿Imports System.Data

Public Class Facturacion

#Region "Variables globales"

  Dim FacturacionDao As ClsBaseDatos_SadLab.SadLab.AccesoDatos.Fachadas.Facturacion

#End Region

#Region "Constructor"

  Public Sub New()
    FacturacionDao = New ClsBaseDatos_SadLab.SadLab.AccesoDatos.Fachadas.Facturacion()
  End Sub

#End Region


#Region "Metodos"

  Function ConsultarDatosFacturacionPaciente(ByVal nIdSede As Integer, Optional ByVal sNroIdPaciente As String = "") As DataTable
    Try

      Return FacturacionDao.ConsultarDatosFacturacionPaciente(nIdSede, sNroIdPaciente)

    Catch exsql As SqlClient.SqlException
      Throw New Exception(String.Format("Error al consultar los datos de la facturación, {0}", exsql.Message))
    Catch ex As Exception
      Throw New Exception(String.Format("Error al consultar los datos de la facturación, {0}", ex.Message))
    End Try
  End Function

  Function ActualizarCita(ByVal nIdCita As Integer, ByVal sNroPacienteId As String, nEstadoCita As Integer, ByVal sNroFactura As String, ByVal nValorUnitario As Decimal _
                          , ByVal nCantidadServicios As Integer, ByVal sNroOrden As String, ByVal nIdServicio As Integer, ByVal nIdDiagnosticoPrevio As Integer, ByVal nIdDiagnosticoPosterior As Integer _
                          , ByVal nIdComplicacion As Integer, ByVal nIdClaseProcedimiento As Integer, ByVal nIdFormaRealizaActoQ As Integer, ByVal nIdPersonalAtiende As Integer _
                          , ByVal nIdTipoProcedimiento As Integer, ByVal sCondicionPaciente As String, ByVal sCodigoAtencio As String, ByVal dFechaAutorizacion As Date _
                          , ByVal nIdDiagnosticoPrincipal As Integer, ByVal nIdDiagnosticoRelacionadoN1 As Integer, ByVal nIdDiagnosticoRelacionadoN2 As Integer _
                          , ByVal nIdDiagnosticoRelacionadoN3 As Integer, ByVal nIdPrestador As Integer) As Boolean
    Try
      Return FacturacionDao.ActualizarCita(nIdCita, sNroPacienteId, nEstadoCita, sNroFactura, nValorUnitario, nCantidadServicios, sNroOrden, nIdServicio, nIdDiagnosticoPrevio, nIdDiagnosticoPosterior _
                                           , nIdComplicacion, nIdClaseProcedimiento, nIdFormaRealizaActoQ, nIdPersonalAtiende, nIdTipoProcedimiento, sCondicionPaciente, sCodigoAtencio _
                                           , dFechaAutorizacion, nIdDiagnosticoPrincipal, nIdDiagnosticoRelacionadoN1, nIdDiagnosticoRelacionadoN2, nIdDiagnosticoRelacionadoN3, nIdPrestador)
    Catch exsql As SqlClient.SqlException
      Throw New Exception(String.Format("Error al actualizar los datos de la cita, {0}", exsql.Message))
    Catch ex As Exception
      Throw New Exception(String.Format("Error al actualizar los datos de la cita, {0}", ex.Message))
    End Try
  End Function

  Public Function ReadUpdateConsecutivoFactPrestador(nIdPrestador As Integer) As Integer
    Return FacturacionDao.ReadUpdateConsecutivoFactPrestador(nIdPrestador)
  End Function

  Public Function ListarCriteriosAnulacionFacturas() As DataTable
    Return FacturacionDao.ListarCriteriosAnulacionFacturas()
  End Function

#End Region

End Class
