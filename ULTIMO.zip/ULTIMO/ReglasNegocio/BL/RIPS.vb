﻿Imports System.Data

Public Class RIPS
#Region "Variables globales"

  Dim RIPSDao As ClsBaseDatos_SadLab.SadLab.AccesoDatos.Fachadas.FRIPS

#End Region

#Region "Constructor"

  Public Sub New()
    RIPSDao = New ClsBaseDatos_SadLab.SadLab.AccesoDatos.Fachadas.FRIPS()
  End Sub

#End Region

#Region "Metodos"
  Function ListarDatosArchivosRIPS() As System.Data.DataTable
    Return RIPSDao.ListarDatosArchivosRIPS
  End Function

  Function ActualizarConsecutivoGeneracionArhvios(ByVal nIdArchivoRIPS As Integer) As Boolean
    Return RIPSDao.ActualizarConsecutivoGeneracionArhvios(nIdArchivoRIPS)
  End Function

  Function CrearTrazabilidadGeneracion(ByVal nIdArchivoRIPS As Integer, ByVal nCantidadDatos As Integer) As Boolean
    Return RIPSDao.CrearTrazabilidadGeneracion(nIdArchivoRIPS, nCantidadDatos)
  End Function

  Function ListarInformacionRIPS(ByVal dFechaInicio As DateTime, ByVal dFechaFinal As DateTime, ByVal nIdPrestador As Integer, ByVal nIdArchivoRIPS As Integer) As System.Data.DataTable
    Return RIPSDao.ListarInformacionRIPS(dFechaInicio, dFechaFinal, nIdPrestador, nIdArchivoRIPS)
  End Function

  Function GenerarAchivoRIPS(ByVal dFechaInicio As DateTime, ByVal dFechaFinal As DateTime, ByVal nIdPrestador As Integer) As String
    Dim sRetorno As String = String.Empty
    Try
      'Se listan los datos de los informes RIPS activos
      Dim dtArchivosRIPS As System.Data.DataTable = ListarDatosArchivosRIPS()

      'Se valida que la lista no este vacia para poder empezar a procesarla
      If dtArchivosRIPS.Rows.Count > 0 Then
        Dim dtDatosInforme As System.Data.DataTable
        Dim sNombreArchivo As String
        Dim nCantidadDatos As Integer
        Dim sDatosArchivo(0) As String
        Dim nIdArchivoRIPS As Integer
        Dim sExtension As String = ".txt"
        Dim sCodigoPrestador As String = String.Empty
        Dim sRutaGeneracion As String = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & Convert.ToString(DateTime.Now.Year) & Convert.ToString(DateTime.Now.Month) & Convert.ToString(DateTime.Now.Day)
        Dim dtDatosAC As New DataTable()
        VerificarRuta(sRutaGeneracion)

        dtDatosAC.Columns.Add("CodigoPrestador", GetType(String))
        dtDatosAC.Columns.Add("FechaRemision", GetType(String))
        dtDatosAC.Columns.Add("CodigoArchivo", GetType(String))
        dtDatosAC.Columns.Add("TotalRegistros", GetType(String))
        For i = 0 To dtArchivosRIPS.Rows.Count - 1
          'Se extrae el valor del id del archivo RIPS
          nIdArchivoRIPS = Convert.ToInt32(dtArchivosRIPS.Rows(i)(0))

          'Se listan los datos del informe RIPS mandandole los parametros necesarios
          If nIdArchivoRIPS <> 1 Then
            dtDatosInforme = ListarInformacionRIPS(dFechaInicio, dFechaFinal, nIdPrestador, nIdArchivoRIPS)
          Else
            dtDatosInforme = dtDatosAC
          End If
          'Si la lista tiene valores se procesa la informacion de lo contrario no por que no habria informacion que procesar
          If dtDatosInforme.Rows.Count > 0 Then
            nCantidadDatos = dtDatosInforme.Rows.Count
            sNombreArchivo = Convert.ToString(dtArchivosRIPS.Rows(i)(5))
            If String.IsNullOrWhiteSpace(sCodigoPrestador) Then
              sCodigoPrestador = Convert.ToString(dtDatosInforme.Rows(0)(1))
            End If
            ReDim sDatosArchivo(nCantidadDatos - 1)
            sDatosArchivo = ProcesarDatosInforme(dtDatosInforme, nIdArchivoRIPS)
            If nIdArchivoRIPS <> 1 Then
              Dim dFilaAC As DataRow = dtDatosAC.NewRow()
              dFilaAC(0) = sCodigoPrestador
              dFilaAC(1) = DateTime.Now.ToString("dd/mm/yyyy")
              dFilaAC(2) = sNombreArchivo
              dFilaAC(3) = Convert.ToString(nCantidadDatos)

              dtDatosAC.Rows.Add(dFilaAC)
            End If
            'Se crea el archivo en la ruta
            If System.IO.File.Exists(System.IO.Path.Combine(sRutaGeneracion, String.Format("{0}{1}", sNombreArchivo, sExtension))) Then
              System.IO.File.Delete(System.IO.Path.Combine(sRutaGeneracion, String.Format("{0}{1}", sNombreArchivo, sExtension)))
            End If

            System.IO.File.WriteAllLines(System.IO.Path.Combine(sRutaGeneracion, String.Format("{0}{1}", sNombreArchivo, sExtension)), sDatosArchivo, System.Text.Encoding.ASCII)

            'Se crea la trazabilidad de la generación de RIPS
            CrearTrazabilidadGeneracion(nIdArchivoRIPS, nCantidadDatos)
            'Se actualiza el consecutivo de generacion
            ActualizarConsecutivoGeneracionArhvios(nIdArchivoRIPS)
          End If
          dtDatosInforme = New DataTable
          nCantidadDatos = 0
          sNombreArchivo = String.Empty

        Next
        sRetorno = String.Format("Los archivos RIPS se crearon en la siguiente ruta: {0}", sRutaGeneracion)
      End If
    Catch ex As Exception
      sRetorno = String.Format("Se ha presentado un error generando los archivo RIPS, {0}", ex.Message)
    End Try
    Return sRetorno
  End Function

  Private Sub VerificarRuta(ByVal sRuta As String)
    If Not System.IO.Directory.Exists(sRuta) Then
      System.IO.Directory.CreateDirectory(sRuta)
    End If
  End Sub

  Private Function ProcesarDatosInforme(ByVal dtDatos As System.Data.DataTable, ByVal nIdArchivoRips As Integer) As String()
    Dim sRetorno(dtDatos.Rows.Count - 1) As String
    For i = 0 To dtDatos.Rows.Count - 1

      Select Case nIdArchivoRips
        Case 1
          sRetorno(i) = String.Format("{0},{1},{2},{3}", Convert.ToString(dtDatos.Rows(i)(0)), Convert.ToString(dtDatos.Rows(i)(1)), Convert.ToString(dtDatos.Rows(i)(2)) _
                                      , Convert.ToString(dtDatos.Rows(i)(3)))
        Case 2
          sRetorno(i) = String.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15}" _
                                      , Convert.ToString(dtDatos.Rows(i)(0)), Convert.ToString(dtDatos.Rows(i)(1)), Convert.ToString(dtDatos.Rows(i)(2)) _
                                      , Convert.ToString(dtDatos.Rows(i)(3)), Convert.ToString(dtDatos.Rows(i)(4)), Convert.ToString(dtDatos.Rows(i)(5)) _
                                      , Convert.ToString(dtDatos.Rows(i)(6)), Convert.ToString(dtDatos.Rows(i)(7)), Convert.ToString(dtDatos.Rows(i)(8)) _
                                      , Convert.ToString(dtDatos.Rows(i)(9)), Convert.ToString(dtDatos.Rows(i)(10)), Convert.ToString(dtDatos.Rows(i)(11)) _
                                      , Convert.ToString(dtDatos.Rows(i)(12)), Convert.ToString(dtDatos.Rows(i)(13)), Convert.ToString(dtDatos.Rows(i)(14)) _
                                      , Convert.ToString(dtDatos.Rows(i)(15)))
        Case 3
          sRetorno(i) = String.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13}" _
                                      , Convert.ToString(dtDatos.Rows(i)(0)), Convert.ToString(dtDatos.Rows(i)(1)), Convert.ToString(dtDatos.Rows(i)(2)) _
                                      , Convert.ToString(dtDatos.Rows(i)(3)), Convert.ToString(dtDatos.Rows(i)(4)), Convert.ToString(dtDatos.Rows(i)(5)) _
                                      , Convert.ToString(dtDatos.Rows(i)(6)), Convert.ToString(dtDatos.Rows(i)(7)), Convert.ToString(dtDatos.Rows(i)(8)) _
                                      , Convert.ToString(dtDatos.Rows(i)(9)), Convert.ToString(dtDatos.Rows(i)(10)), Convert.ToString(dtDatos.Rows(i)(11)) _
                                      , Convert.ToString(dtDatos.Rows(i)(12)), Convert.ToString(dtDatos.Rows(i)(13)))
        Case 5
          sRetorno(i) = String.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}" _
                                      , Convert.ToString(dtDatos.Rows(i)(0)), Convert.ToString(dtDatos.Rows(i)(1)), Convert.ToString(dtDatos.Rows(i)(2)) _
                                      , Convert.ToString(dtDatos.Rows(i)(3)), Convert.ToString(dtDatos.Rows(i)(4)), Convert.ToString(dtDatos.Rows(i)(5)) _
                                      , Convert.ToString(dtDatos.Rows(i)(6)), Convert.ToString(dtDatos.Rows(i)(7)), Convert.ToString(dtDatos.Rows(i)(8)) _
                                      , Convert.ToString(dtDatos.Rows(i)(9)), Convert.ToString(dtDatos.Rows(i)(10)), Convert.ToString(dtDatos.Rows(i)(11)) _
                                      , Convert.ToString(dtDatos.Rows(i)(12)), Convert.ToString(dtDatos.Rows(i)(13)), Convert.ToString(dtDatos.Rows(i)(14)))
      End Select





    Next

    Return sRetorno
  End Function

#End Region

End Class
