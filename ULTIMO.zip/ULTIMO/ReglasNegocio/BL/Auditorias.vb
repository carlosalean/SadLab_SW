﻿Imports ClsUtilidades.Utilidades

Public Class Auditorias

#Region "Variables globales"

  Dim AuditoriaDao As ClsBaseDatos_SadLab.SadLab.AccesoDatos.Fachadas.Auditorias

#End Region

#Region "Constructor"

  Public Sub New()
    AuditoriaDao = New ClsBaseDatos_SadLab.SadLab.AccesoDatos.Fachadas.Auditorias()
  End Sub

#End Region

#Region "Metodos"

  Function CrearAuditoria(ByVal oAuditoria As Objetos.Auditorias) As Integer
    Return AuditoriaDao.CrearAuditoria(oAuditoria)
  End Function

  Function Listar() As DataTable
    Return AuditoriaDao.Listar()
  End Function

#End Region

End Class
