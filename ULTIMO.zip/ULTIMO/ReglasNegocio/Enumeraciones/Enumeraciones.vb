﻿
Namespace Enumeraciones
  Public Class Enumeraciones

    Public Enum Procesos
      AperturaCaja = 1
      CierreCaja = 2
      AsignacionCitas = 3
      CancelacionCitas = 4
      ConfirmacionCitas = 5
      RegistroLlegadaPacientes = 6
      RegistroSalidaPacientes = 7
      Facturacion = 8
      AsignacionConsecutivoFactuacion = 9
      AsignacionConsecutivoFactuacionDespuesAanularFactura = 10
      AnulacionFacturas = 11
      ConsultaFacturas = 12
      CierreFacturas = 13
      ReporteFacturacion = 14
      ReporteCopagos = 15
    End Enum

  End Class
End Namespace

