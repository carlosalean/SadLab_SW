﻿Imports System.Net.Mail
Public Class clsEnviarCorreo
    Public Sub EnvioMail(strCorreo1 As String, strCorreo2 As String, strAsunto As String, strBody As String, strFile As String)
        Try
            Dim correo As New MailMessage
            Dim smtp As New SmtpClient()

            correo.From = New MailAddress("sadlabvasculab@gmail.com", "SADLAB - VASCULAB", System.Text.Encoding.UTF8)
            correo.To.Add(strCorreo1)
            correo.To.Add(strCorreo2)
            correo.SubjectEncoding = System.Text.Encoding.UTF8
            correo.Subject = strAsunto
            correo.Body = strBody
            correo.BodyEncoding = System.Text.Encoding.UTF8
            correo.IsBodyHtml = True '"False (formato tipo web o normal: true = web)"
            correo.Priority = MailPriority.High ' prioridad
            If strFile.Count > 0 Then
                correo.Attachments.Add(New Attachment(strFile))
            End If

            smtp.Credentials = New System.Net.NetworkCredential("sadlabvasculab@gmail.com", "vasculab12345+-")
            smtp.Port = 465
            smtp.Host = "smtp.gmail.com"
            smtp.EnableSsl = False

            smtp.Send(correo)

        Catch ex As SmtpException


        End Try

    End Sub
End Class
