﻿Imports System.Windows.Forms

Public Class ClsComboBox
    Inherits ComboBox
    Protected Overrides Sub OnCreateControl()
        MyBase.OnCreateControl()
        '     Me.AutoCompleteMode = Windows.Forms.AutoCompleteMode.Suggest
        '    Me.AutoCompleteSource = Windows.Forms.AutoCompleteSource.ListItems
    End Sub

    Protected Overrides Sub OnKeyDown(ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.F2 Then
            If Not IsNothing(Me.DataSource) Then
                Dim mDlgbuscar As New DlgBuscar(Me.DataSource, Me.DisplayMember, Me.ValueMember)
                mDlgbuscar.ShowDialog()
            End If
        End If
        MyBase.OnKeyDown(e)
    End Sub

    Protected Overrides Sub OnKeyUp(ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.Enter Then
            If Me.SelectedIndex >= 0 Then
                e.Handled = True
                SendKeys.Send("{TAB}")
            End If
        End If
        ' Seguimos ejecutando el evento en el control base
        MyBase.OnKeyUp(e)
    End Sub

End Class
