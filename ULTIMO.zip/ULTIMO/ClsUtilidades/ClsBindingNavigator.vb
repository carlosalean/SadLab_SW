﻿Imports System.Windows.Forms

Public Class ClsBindingNavigator
    Inherits BindingNavigator

    Public Sub New(ByVal mcomponent As System.Windows.Forms.BindingSource)
        MyBase.New(mcomponent)
    End Sub

    Protected Overrides Sub OnCreateControl()
        MyBase.OnCreateControl()
        '     Me.AutoCompleteMode = Windows.Forms.AutoCompleteMode.Suggest
        '    Me.AutoCompleteSource = Windows.Forms.AutoCompleteSource.ListItems
    End Sub

End Class
