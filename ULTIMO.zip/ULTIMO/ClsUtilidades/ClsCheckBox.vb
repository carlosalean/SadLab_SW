﻿Imports System.Windows.Forms

Public Class ClsCheckBox
    Inherits CheckBox

    Protected Overrides Sub OnKeyUp(ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
        ' Seguimos ejecutando el evento en el control base
        MyBase.OnKeyUp(e)
    End Sub

End Class
