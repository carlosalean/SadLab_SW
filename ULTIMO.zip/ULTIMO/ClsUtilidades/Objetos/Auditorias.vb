﻿Namespace Utilidades.Objetos
  Public Class Auditorias

#Region "Propiedades"

    Private nIdTrazabilidad As Integer
    Public Property CodigoAuditoria() As Integer
      Get
        Return nIdTrazabilidad
      End Get
      Set(ByVal value As Integer)
        nIdTrazabilidad = value
      End Set
    End Property

    Private dFechaRegistro As DateTime
    Public Property FechaRegistro() As DateTime
      Get
        Return dFechaRegistro
      End Get
      Set(ByVal value As DateTime)
        dFechaRegistro = value
      End Set
    End Property

    Private nIdProceso As Integer
    Public Property CodigoProceso() As Integer
      Get
        Return nIdProceso
      End Get
      Set(ByVal value As Integer)
        nIdProceso = value
      End Set
    End Property

    Private nIdUsuario As Integer
    Public Property UsuarioEjecuta() As Integer
      Get
        Return nIdUsuario
      End Get
      Set(ByVal value As Integer)
        nIdUsuario = value
      End Set
    End Property

    Private sNombreMaquina As String
    Public Property NombreMaquina() As String
      Get
        Return sNombreMaquina
      End Get
      Set(ByVal value As String)
        sNombreMaquina = value
      End Set
    End Property

    Private sLog As String
    Public Property Log() As String
      Get
        Return sLog
      End Get
      Set(ByVal value As String)
        sLog = value
      End Set
    End Property

#End Region

  End Class
End Namespace


