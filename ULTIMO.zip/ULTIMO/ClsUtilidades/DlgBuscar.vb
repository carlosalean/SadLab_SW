﻿Imports System.Windows.Forms

Public Class DlgBuscar

    Private FDataSource As Object
    Private FDisplayMember As String
    Private FValueMember As String

    Public FValor As String

    Public Sub New(ByVal mDataSource As Object, ByVal mDisplayMember As String, ByVal mValueMember As String)
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        FDataSource = mDataSource
        FDisplayMember = mDisplayMember
        FValueMember = mValueMember

        BuscarDataGridView.DataSource = FDataSource
        RadioButton1.Text = "Por " & FValueMember.Replace("str", "")
        RadioButton2.Text = "Por " & FDisplayMember.Replace("str", "")
    End Sub


    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DlgBuscar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For Each mColum As DataGridViewColumn In BuscarDataGridView.Columns
            If mColum.Name = FDisplayMember Or mColum.Name = FValueMember Then
                mColum.HeaderText = mColum.HeaderText.Replace("str", "")
                If mColum.Name = FDisplayMember Then
                    mColum.Width = 300
                End If
            Else
                mColum.Visible = False
                'BuscarDataGridView.Columns.Remove(mColum)
            End If
        Next
    End Sub

    Private Sub PrBuscar()
        For Each mRows As DataGridViewRow In BuscarDataGridView.Rows
            If RadioButton1.Checked Then
                If mRows.Cells(FValueMember).Value.ToString.ToUpper.Contains(BuscarTextBox.Text.ToUpper) Then
                    BuscarDataGridView.CurrentCell = mRows.Cells(FValueMember)
                End If
            End If
            If RadioButton2.Checked Then
                If mRows.Cells(FDisplayMember).Value.ToString.Contains(BuscarTextBox.Text) Then
                    BuscarDataGridView.CurrentCell = mRows.Cells(FValueMember)
                End If
            End If

        Next

    End Sub

    Private Sub BuscarTextBox_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles BuscarTextBox.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        End If
    End Sub

    Private Sub BuscarTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BuscarTextBox.TextChanged
        PrBuscar()
    End Sub

    Private Sub DlgBuscar_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Try
            FValor = BuscarDataGridView.CurrentCell.Value.ToString
        Catch ex As Exception
            '
        End Try
    End Sub

    Private Sub DlgBuscar_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.Escape Then
            Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
            Me.Close()
        End If
    End Sub

    Private Sub BuscarDataGridView_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles BuscarDataGridView.CellDoubleClick
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub
End Class
