﻿Imports System.Windows.Forms

Public Class clsTabs
    Inherits List(Of UserControl)
    Private _Item As Integer

    Public ReadOnly Property SelectItem() As Integer
        Get
            Return _Item
        End Get
    End Property

    Public ReadOnly Property Items(ByVal index As Integer) As System.Windows.Forms.Control
        Get
            _Item = index
            Return Me.Item(index)
        End Get
    End Property

End Class
