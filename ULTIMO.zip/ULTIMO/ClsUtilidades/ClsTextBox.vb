﻿Imports System.Windows.Forms

Public Class ClsTextBox
    Inherits TextBox

    ' Array para los dígitos válidos
    Protected digitos() As Char

    '
    Private _tipoDato As TipoDatos
    Private _DataSource As System.Windows.Forms.BindingSource
    Private _NombreDescripcionF2 As String
    Private _NombreCodigoF2 As String
    Private _EnterEntreCampos As Boolean = True

    'Private _ComboBox As ComboBox

    'En el constructor asignamos el tipo predeterminado
    Public Sub New()
        MyBase.New()
        Me.TipoDato = TipoDatos.Texto
    End Sub

    '
    ' El tipo de datos que admite el control
    Public Overridable Property TipoDato() As TipoDatos
        Get
            Return _tipoDato
        End Get
        Set(ByVal value As TipoDatos)
            ' cambiar el array para que solo acepte los valores indicados
            Dim s As String
            _tipoDato = value
            Select Case _tipoDato
                Case TipoDatos.Binario
                    s = "01"
                Case TipoDatos.Entero
                    s = "0123456789-+"
                Case TipoDatos.Hexadecimal
                    s = "0123456789ABCDEFabcdef"
                Case TipoDatos.Moneda
                    s = "0123456789-+,"
                Case TipoDatos.Octal
                    s = "01234567"
                Case Else
                    s = "0123456789-+,Ee"
            End Select
            digitos = (s & ChrW(8)).ToCharArray
        End Set
    End Property

    'Public Overridable Property ComboBuscar() As ComboBox
    '    Get
    '        Return _ComboBox
    '    End Get
    '    Set(ByVal value As ComboBox)
    '        _ComboBox = value
    '    End Set
    'End Property

    Public Overridable Property EnterEntreCampos() As Boolean
        Get
            Return _EnterEntreCampos
        End Get
        Set(ByVal value As Boolean)
            _EnterEntreCampos = value
        End Set
    End Property

    Public Overridable Property DataSource() As System.Windows.Forms.BindingSource
        Get
            Return _DataSource
        End Get
        Set(ByVal value As System.Windows.Forms.BindingSource)
            _DataSource = value
        End Set
    End Property

    Public Overridable Property NombreCodigoF2() As String
        Get
            Return _NombreCodigoF2
        End Get
        Set(ByVal value As String)
            _NombreCodigoF2 = value
        End Set
    End Property

    Public Overridable Property NombreDescripcionF2() As String
        Get
            Return _NombreDescripcionF2
        End Get
        Set(ByVal value As String)
            _NombreDescripcionF2 = value
        End Set
    End Property

    ' Los tipos de datos válidos para el control
    Public Enum TipoDatos
        Doble ' Números decimales con notación científica
        Moneda ' Números decimales
        Entero ' Números enteros
        Hexadecimal ' Números hexadecimales
        Octal ' Números octales
        Binario ' Números binarios
        Texto
    End Enum

    Protected Overrides Sub OnKeyDown(ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.F2 Then
            If Not IsNothing(Me.DataSource) Then
                Dim mDlgbuscar As New DlgBuscar(Me.DataSource, Me.NombreDescripcionF2, Me.NombreCodigoF2)
                mDlgbuscar.ShowDialog()
                If Not String.IsNullOrEmpty(mDlgbuscar.FValor) Then
                    Me.Text = mDlgbuscar.FValor
                End If
            End If
        End If
        MyBase.OnKeyDown(e)
    End Sub

    Protected Overrides Sub OnKeyPress(ByVal e As KeyPressEventArgs)
        If TeclaValida(e.KeyChar) = False Then
            e.Handled = True
            'Else
            '    If Not IsNothing(Me.ComboBuscar) Then
            '        PrBuscarCombo()
            '    End If
        End If
        ' Seguimos ejecutando el evento en el control base
        MyBase.OnKeyPress(e)
    End Sub

    Protected Overrides Sub OnKeyUp(ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.Enter And Me.EnterEntreCampos Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
        ' Seguimos ejecutando el evento en el control base
        MyBase.OnKeyUp(e)
    End Sub

    'Private Sub PrBuscarCombo()
    '    'Me.ComboBuscar.Items
    '    'For Each mItem As Object In Me.ComboBuscar.Items
    '    '    'Me.ComboBuscar.Items.Item(0).strNit()
    '    '    If mItem.Item(0).ToString.Contains(Me.Text) Then
    '    '        Me.ComboBuscar.SelectedItem = mItem
    '    '    End If
    '    'Next
    'End Sub

    ' Comprueba si el caracter indicado es uno de los valores aceptados
    Protected Overridable Function TeclaValida(ByVal c As Char) As Boolean
        If Not Me.TipoDato = TipoDatos.Texto Then
            Return (Array.IndexOf(digitos, c) > -1)
        Else
            Return True
        End If
    End Function

    ' Al asignar una cadena comprobamos cada uno de los caracteres
    Public Overrides Property Text() As String
        Get
            Return MyBase.Text
        End Get
        Set(ByVal value As String)
            'Para que la primera vez se muestre el nombre del control
            If Me.DesignMode AndAlso Me.Text = "" Then
                MyBase.Text = value
            Else
                ' Para que la primera vez se muestre el nombre del control
                If Not (value Is Nothing) Then
                    Dim s As New System.Text.StringBuilder
                    For Each c As Char In value
                        If TeclaValida(c) Then
                            s.Append(c)
                        End If
                    Next
                    MyBase.Text = s.ToString
                End If
            End If
        End Set
    End Property

End Class

