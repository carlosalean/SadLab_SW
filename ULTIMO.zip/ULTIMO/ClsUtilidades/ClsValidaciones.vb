﻿Imports System.Windows.Forms

Public Class ClsValidaciones

    Public Function ValidarVacio(ByVal sender As System.Object, ByVal FErrorProvider As ErrorProvider)
        Dim mTxtValue As Control
        mTxtValue = sender
        If String.IsNullOrEmpty(mTxtValue.Text) Then
            If mTxtValue.Text.Trim.Length = 0 Then
                FErrorProvider.SetError(sender, "El Campo no puede estar vacío..")
                Return False
            Else
                FErrorProvider.SetError(sender, "")
                Return True
            End If
        Else
            FErrorProvider.SetError(sender, "")
            Return True
        End If
    End Function


End Class
