﻿Public Class ClsPermisos
    Public Class ClsHistoriasClinicas
        Private _Ver As Boolean
        Private _Modificar As Boolean
        Private _Crear As Boolean

        Public Property Ver() As Boolean
            Get
                Return _Ver
            End Get
            Set(ByVal value As Boolean)
                _Ver = value
            End Set
        End Property

        Public Property Modificar() As Boolean
            Get
                Return _Modificar
            End Get
            Set(ByVal value As Boolean)
                _Modificar = value
            End Set
        End Property

        Public Property Crear()
            Get
                Return _Crear
            End Get
            Set(ByVal value)
                _Crear = value
            End Set
        End Property
    End Class
End Class
