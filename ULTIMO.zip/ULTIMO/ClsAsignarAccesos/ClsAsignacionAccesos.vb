Imports System.Windows.Forms
Imports System.Data

Public Class ClsAsignacionAccesos
    Public Sub PrAsignarAccesos(ByVal mMenu As System.Windows.Forms.MenuStrip, ByVal mDataTable As DataTable)
        For Each mRow As System.Data.DataRow In mDataTable.Rows
            For Each MenuItem As System.Windows.Forms.ToolStripItem In mMenu.Items
                If MenuItem.Tag = mRow(0) Then
                    MenuItem.Enabled = mRow(1)
                    Exit For
                End If
                PrChequearSubItem(mRow(0), mRow(1), MenuItem)
            Next MenuItem
        Next mRow

    End Sub
    Private Sub PrChequearSubItem(ByVal mTagRow As Int32, ByVal mHabilitar As Boolean, ByVal mMenuItem As System.Windows.Forms.ToolStripItem)
        For Each MenuItem As System.Windows.Forms.ToolStripItem In CType(mMenuItem, System.Windows.Forms.ToolStripMenuItem).DropDownItems
            If MenuItem.Tag = mTagRow Then
                MenuItem.Enabled = mHabilitar
                Exit For
            End If
            PrChequearSubItem(mTagRow, mHabilitar, MenuItem)
        Next MenuItem
    End Sub


    Private Sub PrAsignarSubItem(ByVal mMenuItem As System.Windows.Forms.ToolStripItem, ByVal intNivelAcceso As Int16)
        Select Case intNivelAcceso
            Case 0
                If (mMenuItem.Tag <> 0 And mMenuItem.Tag <> 1 And mMenuItem.Tag <> 4 And mMenuItem.Tag <> 8) Then
                    mMenuItem.Enabled = False
                End If
            Case 1
                mMenuItem.Enabled = True
            Case 2
                If (mMenuItem.Tag = 54) Then
                    mMenuItem.Enabled = False
                End If
            Case 3
                If (mMenuItem.Tag <> 0 And mMenuItem.Tag <> 1 And mMenuItem.Tag <> 4 And mMenuItem.Tag <> 8 And mMenuItem.Tag <> 2) Then
                    mMenuItem.Enabled = False
                End If
            Case Else
                If (mMenuItem.Tag <> 0 And mMenuItem.Tag <> 1 And mMenuItem.Tag <> 4 And mMenuItem.Tag <> 8 And mMenuItem.Tag <> 5 And mMenuItem.Tag <> 51 And mMenuItem.Tag <> 52 And mMenuItem.Tag <> 53) Then
                    mMenuItem.Enabled = False
                End If
        End Select

        For Each MenuItem As System.Windows.Forms.ToolStripItem In CType(mMenuItem, System.Windows.Forms.ToolStripMenuItem).DropDownItems
            PrAsignarSubItem(MenuItem, intNivelAcceso)
        Next MenuItem
    End Sub


    Private Sub PrAgregarSubItem(ByVal mMenuItem As System.Windows.Forms.ToolStripItem, ByVal mTreeView As System.Windows.Forms.TreeNode)
        For Each MenuItem As System.Windows.Forms.ToolStripItem In CType(mMenuItem, System.Windows.Forms.ToolStripMenuItem).DropDownItems
            Dim mNode As New System.Windows.Forms.TreeNode()
            mNode.Tag = MenuItem.Tag
            mNode.Text = MenuItem.Text
            PrAgregarSubItem(MenuItem, mNode)
            mTreeView.Nodes.Add(mNode)
        Next MenuItem
    End Sub
    Public Sub PrLlenarTreeViewAccesos(ByVal mMenu As System.Windows.Forms.MenuStrip, ByVal mTreeView As System.Windows.Forms.TreeView)
        For Each MenuItem As System.Windows.Forms.ToolStripItem In mMenu.Items
            If MenuItem.Visible = True Then
                Dim mNode As New System.Windows.Forms.TreeNode()
                mNode.Tag = MenuItem.Tag
                mNode.Text = MenuItem.Text
                PrAgregarSubItem(MenuItem, mNode)
                mTreeView.Nodes.Add(mNode)
            end if
        Next MenuItem
    End Sub
End Class
