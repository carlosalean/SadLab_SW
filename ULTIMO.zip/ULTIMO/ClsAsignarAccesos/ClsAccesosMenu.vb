Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class ClsAccesosMenu

    Public Sub PrBorrarAccesosMenu(ByVal intNivelAcceso As Int16, ByVal mSqlConection As System.Data.SqlClient.SqlConnection)
        'Definir un SQLCommand, El nombre del Store Procedure en CommandText
        'El CommandType = StoreProcedure y la conexion
        Dim coDetalle As New SqlCommand()
        Dim arParms As SqlParameter
        Try
            arParms = New SqlParameter("@intNivelAcceso", SqlDbType.SmallInt)
            arParms.Value = intNivelAcceso
            coDetalle.Parameters.Add(arParms)

            coDetalle.CommandText = "dbo.spBorrarAccesosMenu"
            coDetalle.CommandType = CommandType.StoredProcedure
            coDetalle.Connection = mSqlConection
            coDetalle.ExecuteNonQuery()
        Catch ex As Exception
            Throw New Exception("PrBorrarAccesosMenu " & ex.Message, ex)
        End Try
    End Sub

    Public Sub PrGrabarAccesosMenu(ByVal intNivelAcceso As Int16, ByVal intTagMenu As Int32, ByVal bitHabilitado As Boolean, ByVal intTagPadre As Int32, ByVal mSqlConection As System.Data.SqlClient.SqlConnection)
        'Definir un SQLCommand, El nombre del Store Procedure en CommandText
        'El CommandType = StoreProcedure y la conexion
        Dim coDetalle As New SqlCommand()
        Dim arParms(4) As SqlParameter
        Try

            arParms(0) = New SqlParameter("@intTagMenu", SqlDbType.Int)
            arParms(0).Value = intTagMenu
            coDetalle.Parameters.Add(arParms(0))

            arParms(1) = New SqlParameter("@bitHabilitado", SqlDbType.Bit)
            arParms(1).Value = bitHabilitado
            coDetalle.Parameters.Add(arParms(1))

            arParms(2) = New SqlParameter("@intTagPadre", SqlDbType.Int)
            arParms(2).Value = intTagPadre
            coDetalle.Parameters.Add(arParms(2))

            arParms(3) = New SqlParameter("@intNivelAcceso", SqlDbType.SmallInt)
            arParms(3).Value = intNivelAcceso
            coDetalle.Parameters.Add(arParms(3))

            coDetalle.CommandText = "dbo.spGrabarAccesosMenu"
            coDetalle.CommandType = CommandType.StoredProcedure
            coDetalle.Connection = mSqlConection
            coDetalle.ExecuteNonQuery()

        Catch ex As Exception
            Throw New Exception("PrGrabarAccesosMenu " & ex.Message, ex)
        End Try
    End Sub

    Public Sub PrAsignarMenu(ByVal mTreeview As TreeView, ByVal mIdAcceso As Int16, ByVal mSqlConection As System.Data.SqlClient.SqlConnection)
        'Definir un SQLCommand, El nombre del Store Procedure en CommandText
        'El CommandType = StoreProcedure y la conexion
        Dim coDetalle As New SqlCommand()
        Dim arParms As SqlParameter
        Try

            arParms = New SqlParameter("@IdAcceso", SqlDbType.Int)
            arParms.Value = mIdAcceso
            coDetalle.Parameters.Add(arParms)

            coDetalle.CommandText = "dbo.spAccesosMenu_Select"
            coDetalle.CommandType = CommandType.StoredProcedure
            coDetalle.Connection = mSqlConection

            'El Adaptador y su SelectCommand
            Dim daDetalle As New SqlDataAdapter()
            daDetalle.SelectCommand = coDetalle
            'Llenar el DataSet
            'Al llenar el DataSet se ejecuta el Store Procedure
            'el SQLCommand del SQLDataAdapter se especific�
            'del tipo StoreProcedure
            Dim _mDataSet As New DataSet
            daDetalle.Fill(_mDataSet, "dbo.spAccesosMenu_Select")
            'ClsDataBase._dsDataBase.Tables("dbo.spAccesosMenu_Select")
            For Each mRow As System.Data.DataRow In _mDataSet.Tables("dbo.spAccesosMenu_Select").Rows
                For Each mNode As System.Windows.Forms.TreeNode In mTreeview.Nodes
                    If mNode.Tag = mRow(0) Then
                        mNode.Checked = mRow(1)
                        Exit For
                    End If
                    PrChequearNodos(mRow(0), mRow(1), mNode)
                Next mNode
            Next mRow
            If _mDataSet.Tables("dbo.spAccesosMenu_Select").Rows.Count = 0 Then
                For Each mNode As System.Windows.Forms.TreeNode In mTreeview.Nodes
                    mNode.Checked = False
                    PrChequearNodos(Nothing, False, mNode)
                Next mNode
            End If
        Catch ex As Exception
            'Throw New Exception("PrGrabarAccesosMenu " & ex.Message, ex)
        End Try
    End Sub

    Public Function PrAccesosMenu(ByVal mIdAcceso As Int16, ByVal mSqlConection As System.Data.SqlClient.SqlConnection) As DataTable
        'Definir un SQLCommand, El nombre del Store Procedure en CommandText
        'El CommandType = StoreProcedure y la conexion
        Dim coDetalle As New SqlCommand()
        Dim arParms As SqlParameter
        Try

            arParms = New SqlParameter("@IdAcceso", SqlDbType.Int)
            arParms.Value = mIdAcceso
            coDetalle.Parameters.Add(arParms)

            coDetalle.CommandText = "dbo.spAccesosMenu_Select"
            coDetalle.CommandType = CommandType.StoredProcedure
            coDetalle.Connection = mSqlConection

            'El Adaptador y su SelectCommand
            Dim daDetalle As New SqlDataAdapter()
            daDetalle.SelectCommand = coDetalle
            'Llenar el DataSet
            'Al llenar el DataSet se ejecuta el Store Procedure
            'el SQLCommand del SQLDataAdapter se especific�
            'del tipo StoreProcedure
            Dim _mDataSet As New DataSet
            daDetalle.Fill(_mDataSet, "dbo.spAccesosMenu_Select")
            'ClsDataBase._dsDataBase.Tables("dbo.spAccesosMenu_Select")
            Return _mDataSet.Tables("dbo.spAccesosMenu_Select")
        Catch ex As Exception
            Throw New Exception("PrAccesosMenu " & ex.Message, ex)
        End Try
    End Function

    Private Sub PrChequearNodos(ByVal mTagRow As Int32, ByVal mHabilitar As Boolean, ByVal mNodo As TreeNode)
        For Each mNode As System.Windows.Forms.TreeNode In mNodo.Nodes
            If IsNothing(mTagRow) Then
                mNode.Checked = False
            Else
                If mNode.Tag = mTagRow Then
                    mNode.Checked = mHabilitar
                    Exit For
                End If
            End If
            PrChequearNodos(mTagRow, mHabilitar, mNode)
        Next mNode
    End Sub
End Class
