﻿Imports System.Data
Imports System.Data.SqlClient

Public Class ClsNivelesAcceso

    Public Function FnNivelAcceso(ByVal strCodigoCliente As Int16, ByVal mSQLConection As System.Data.SqlClient.SqlConnection) As Int16
        'Definir un SQLCommand, El nombre del Store Procedure en CommandText
        'El CommandType = StoreProcedure y la conexion
        Dim coDetalle As New SqlCommand()
        Dim arParms As SqlParameter
        Try
            arParms = New SqlParameter("@strCodigoUsuario", SqlDbType.SmallInt)
            arParms.Value = strCodigoCliente
            coDetalle.Parameters.Add(arParms)
            coDetalle.CommandText = "dbo.spNivelAcceso_Usuario"
            coDetalle.CommandType = CommandType.StoredProcedure
            coDetalle.Connection = mSQLConection
            Return coDetalle.ExecuteScalar()
        Catch ex As Exception
            'Throw New Exception("FnNivelAcceso " & ex.Message, ex)
            Return 0
        End Try
    End Function

End Class
