﻿
Public Class ClsError
    Public Shared Sub PrMostrarError(ByVal ex As Exception)
        MsgBox("Ocurrió el Siguiente Error: " & ex.Message)
    End Sub
End Class
