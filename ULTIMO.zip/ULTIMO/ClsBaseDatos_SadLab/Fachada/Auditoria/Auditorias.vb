﻿Imports System.Data
Imports ClsUtilidades.Utilidades
Imports ClsBaseDatos_SadLab.SadLab.AccesoDatos.Interfaz

Namespace SadLab.AccesoDatos.Fachadas
  Public Class Auditorias
    Implements IAuditoria

    Dim AuditoriasDao As AccesoDatos.Dao.Auditorias = New Dao.Auditorias()

    Public Function CrearAuditoria(oAuditoria As Objetos.Auditorias) As Integer Implements SadLab.AccesoDatos.Interfaz.IAuditoria.CrearAuditoria
      Return AuditoriasDao.CrearAuditoria(oAuditoria)
    End Function

    Public Function Listar() As DataTable Implements SadLab.AccesoDatos.Interfaz.IAuditoria.Listar
      Return AuditoriasDao.Listar()
    End Function

  End Class
End Namespace
