﻿Imports ClsBaseDatos_SadLab.SadLab.AccesoDatos.Interfaz

Namespace SadLab.AccesoDatos.Fachadas
  Public Class Facturacion
    Implements IFacturacion



    Dim FacturacionDao As Dao.Facturacion = New Dao.Facturacion()

    Function ConsultarDatosFacturacionPaciente(ByVal nIdSede As Integer, Optional ByVal sNroIdPaciente As String = "") As DataTable Implements IFacturacion.ConsultarDatosFacturacionPaciente
      Return FacturacionDao.ConsultarDatosFacturacionPaciente(nIdSede, sNroIdPaciente)
    End Function

    Public Function ActualizarCita(nIdCita As String, sNroPacienteId As String, nEstadoCita As Integer, ByVal sNroFactura As String, ByVal nValorUnitario As Decimal _
                                   , ByVal nCantidadServicios As Integer, ByVal sNroOrden As String, ByVal nIdServicio As Integer, ByVal nIdDiagnosticoPrevio As Integer, ByVal nIdDiagnosticoPosterior As Integer _
                          , ByVal nIdComplicacion As Integer, ByVal nIdClaseProcedimiento As Integer, ByVal nIdFormaRealizaActoQ As Integer, ByVal nIdPersonalAtiende As Integer _
                          , ByVal nIdTipoProcedimiento As Integer, ByVal sCondicionPaciente As String, ByVal sCodigoAtencio As String, ByVal dFechaAutorizacion As Date _
                          , ByVal nIdDiagnosticoPrincipal As Integer, ByVal nIdDiagnosticoRelacionadoN1 As Integer, ByVal nIdDiagnosticoRelacionadoN2 As Integer _
                          , ByVal nIdDiagnosticoRelacionadoN3 As Integer, ByVal nIdPrestador As Integer) As Boolean Implements IFacturacion.ActualizarCita
      Return FacturacionDao.ActualizarCita(nIdCita, sNroPacienteId, nEstadoCita, sNroFactura, nValorUnitario, nCantidadServicios, sNroOrden, nIdServicio, nIdDiagnosticoPrevio, nIdDiagnosticoPosterior _
                                           , nIdComplicacion, nIdClaseProcedimiento, nIdFormaRealizaActoQ, nIdPersonalAtiende, nIdTipoProcedimiento, sCondicionPaciente, sCodigoAtencio _
                                           , dFechaAutorizacion, nIdDiagnosticoPrincipal, nIdDiagnosticoRelacionadoN1, nIdDiagnosticoRelacionadoN2, nIdDiagnosticoRelacionadoN3, nIdPrestador)
    End Function

    Public Function ReadUpdateConsecutivoFactPrestador(nIdPrestador As Integer) As Integer Implements IFacturacion.ReadUpdateConsecutivoFactPrestador
      Return FacturacionDao.ReadUpdateConsecutivoFactPrestador(nIdPrestador)
    End Function

    Public Function ListarCriteriosAnulacionFacturas() As DataTable Implements IFacturacion.ListarCriteriosAnulacionFacturas
      Return FacturacionDao.ListarCriteriosAnulacionFacturas()
    End Function
  End Class
End Namespace

