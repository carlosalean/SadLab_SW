﻿Imports ClsBaseDatos_SadLab.SadLab.AccesoDatos.Interfaz

Namespace SadLab.AccesoDatos.Fachadas
  Public Class FRIPS
    Implements IRIPS

    Dim RIPSDao As Dao.RIPS = New Dao.RIPS()

    Public Function ActualizarConsecutivoGeneracionArhvios(nIdArchivoRIPS As Integer) As Boolean Implements IRIPS.ActualizarConsecutivoGeneracionArhvios
      Return RIPSDao.ActualizarConsecutivoGeneracionArhvios(nIdArchivoRIPS)
    End Function

    Public Function CrearTrazabilidadGeneracion(nIdArchivoRIPS As Integer, nCantidadDatos As Integer) As Boolean Implements IRIPS.CrearTrazabilidadGeneracion
      Return RIPSDao.CrearTrazabilidadGeneracion(nIdArchivoRIPS, nCantidadDatos)
    End Function

    Public Function ListarDatosArchivosRIPS() As DataTable Implements IRIPS.ListarDatosArchivosRIPS
      Return RIPSDao.ListarDatosArchivosRIPS()
    End Function

    Public Function ListarInformacionRIPS(dFechaInicio As Date, dFechaFinal As Date, nIdPrestador As Integer, nIdArchivoRIPS As Integer) As DataTable Implements IRIPS.ListarInformacionRIPS
      Return RIPSDao.ListarInformacionRIPS(dFechaInicio, dFechaFinal, nIdPrestador, nIdArchivoRIPS)
    End Function
  End Class
End Namespace

