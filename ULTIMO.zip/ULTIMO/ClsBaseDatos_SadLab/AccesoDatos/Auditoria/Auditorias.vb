﻿Imports System.Data
Imports System.Data.SqlClient
Imports ClsBaseDatos_SadLab.SadLab.AccesoDatos.Interfaz

Namespace SadLab.AccesoDatos.Dao
  Public Class Auditorias
    Implements IAuditoria

#Region "Variables globales"

    Dim con As New Conexion()
    Dim dtDatos As New DataTable()
    Dim parameters() As SqlParameter
    Dim sNombreSp As String = "Usp_TrazabilidadMovimientosAdmin"

#End Region

#Region "Metodos"

    Public Function CrearAuditoria(oAuditoria As ClsUtilidades.Utilidades.Objetos.Auditorias) As Integer Implements Interfaz.IAuditoria.CrearAuditoria
      Dim nRetorno As Integer = 0
      Try
        parameters = New SqlParameter() { _
          New SqlParameter("@nOperacion", SqlDbType.Int) With {.Value = 1} _
        , New SqlParameter("@dFechaRegistro", SqlDbType.DateTime) With {.Value = oAuditoria.FechaRegistro} _
        , New SqlParameter("@nIdProceso", SqlDbType.Int) With {.Value = oAuditoria.CodigoProceso} _
        , New SqlParameter("@Log", SqlDbType.NVarChar, 10000) With {.Value = oAuditoria.Log} _
        , New SqlParameter("@sNombreMaquina", SqlDbType.NVarChar, 200) With {.Value = oAuditoria.NombreMaquina} _
        , New SqlParameter("@nIdUsuario", SqlDbType.Int) With {.Value = oAuditoria.UsuarioEjecuta} _
        }

        dtDatos = con.EjecutarProcedure(sNombreSp, parameters, Conexion.TipoProcesamiento.DataTable)

        If dtDatos.Rows.Count > 0 Then
          nRetorno = Convert.ToInt32(dtDatos.Rows(0)(0))
        End If
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      Finally
        con.Desconectar()
      End Try
      Return nRetorno
    End Function

    Public Function Listar() As DataTable Implements Interfaz.IAuditoria.Listar
      Try
        parameters = New SqlParameter() {New SqlParameter("@nOpcion", SqlDbType.Int).Value = 2}

        dtDatos = con.EjecutarProcedure(sNombreSp, parameters, Conexion.TipoProcesamiento.DataTable)
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      End Try
      Return dtDatos
    End Function

#End Region

  End Class
End Namespace

