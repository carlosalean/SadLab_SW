﻿Imports System.Data
Imports System.Data.SqlClient
Imports ClsBaseDatos_SadLab.SadLab.AccesoDatos.Interfaz

Namespace SadLab.AccesoDatos.Dao
  Public Class RIPS
    Implements IRIPS


#Region "Variables globales"

    Dim con As New Conexion()
    Dim dtDatos As New DataTable()
    Dim parameters() As SqlParameter
    Dim sNombreSp As String = "Usp_AdminRIPS"
    Dim sNombreSpInforme As String = "Usp_ListarInformacionRIPS"
#End Region

#Region "Metodos"
    Public Function ActualizarConsecutivoGeneracionArhvios(nIdArchivoRIPS As Integer) As Boolean Implements IRIPS.ActualizarConsecutivoGeneracionArhvios
      Try
        parameters = New SqlParameter() {New SqlParameter("@nOperacion", SqlDbType.Int) With {.Value = 2} _
                                        , New SqlParameter("@nIdArchivoRIPS", SqlDbType.Int) With {.Value = nIdArchivoRIPS}}


        Return con.EjecutarProcedure(sNombreSp, parameters, Conexion.TipoProcesamiento.NonQuery)
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      End Try
    End Function

    Public Function CrearTrazabilidadGeneracion(nIdArchivoRIPS As Integer, nCantidadDatos As Integer) As Boolean Implements IRIPS.CrearTrazabilidadGeneracion
      Try
        parameters = New SqlParameter() {New SqlParameter("@nOperacion", SqlDbType.Int) With {.Value = 3} _
                                        , New SqlParameter("@nIdArchivoRIPS", SqlDbType.Int) With {.Value = nIdArchivoRIPS} _
                                        , New SqlParameter("@nCantidadDatos", SqlDbType.Int) With {.Value = nCantidadDatos}}

        Return con.EjecutarProcedure(sNombreSp, parameters, Conexion.TipoProcesamiento.NonQuery)
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      End Try
    End Function

    Public Function ListarDatosArchivosRIPS() As DataTable Implements IRIPS.ListarDatosArchivosRIPS
      Try
        parameters = New SqlParameter() {New SqlParameter("@nOperacion", SqlDbType.Int) With {.Value = 1}}

        dtDatos = con.EjecutarProcedure(sNombreSp, parameters, Conexion.TipoProcesamiento.DataTable)
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      End Try
      Return dtDatos
    End Function

    Public Function ListarInformacionRIPS(dFechaInicio As Date, dFechaFinal As Date, nIdPrestador As Integer, nIdArchivoRIPS As Integer) As DataTable Implements IRIPS.ListarInformacionRIPS
      Try
        parameters = New SqlParameter() {New SqlParameter("@nIdArchivoRIPS", SqlDbType.Int) With {.Value = nIdArchivoRIPS} _
                                        , New SqlParameter("@FechaInicio", SqlDbType.DateTime) With {.Value = dFechaInicio} _
                                        , New SqlParameter("@FechaFin", SqlDbType.DateTime) With {.Value = dFechaFinal} _
                                        , New SqlParameter("@nIdPrestador", SqlDbType.Int) With {.Value = nIdPrestador}}

        dtDatos = con.EjecutarProcedure(sNombreSpInforme, parameters, Conexion.TipoProcesamiento.DataTable)
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      End Try
      Return dtDatos
    End Function
#End Region
    
  End Class
End Namespace

