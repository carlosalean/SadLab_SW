﻿Imports System.Data
Imports System.Data.SqlClient
Imports ClsBaseDatos_SadLab.SadLab.AccesoDatos.Interfaz

Namespace SadLab.AccesoDatos.Dao

  Public Class Facturacion
    Implements IFacturacion

#Region "Variables globales"

    Dim con As New Conexion()
    Dim dtDatos As New DataTable()
    Dim parameters() As SqlParameter
    Dim sNombreSp As String = "Usp_FacturacionDatosTarifas"

#End Region

#Region "Metodos"

    Public Function ConsultarDatosFacturacionPaciente(ByVal nIdSede As Integer, Optional ByVal sNroIdPaciente As String = "") As DataTable Implements IFacturacion.ConsultarDatosFacturacionPaciente
      Try
        parameters = New SqlParameter() {New SqlParameter("@nOperacion", SqlDbType.Int) With {.Value = 1} _
                                        , New SqlParameter("@nIdSede", SqlDbType.Int) With {.Value = nIdSede} _
                                        , New SqlParameter("@sNumeroPacienteId", SqlDbType.NVarChar, 30) With {.Value = IIf(String.IsNullOrWhiteSpace(sNroIdPaciente), DBNull.Value, sNroIdPaciente)}}

        dtDatos = con.EjecutarProcedure(sNombreSp, parameters, Conexion.TipoProcesamiento.DataTable)
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      End Try
      Return dtDatos
    End Function

    Public Function ActualizarCita(nIdCita As String, sNroPacienteId As String, nEstadoCita As Integer, ByVal sNroFactura As String, ByVal nValorUnitario As Decimal _
                                   , ByVal nCantidadServicios As Integer, ByVal sNroOrden As String, ByVal nIdServicio As Integer, ByVal nIdDiagnosticoPrevio As Integer _
                                   , ByVal nIdDiagnosticoPosterior As Integer _
                          , ByVal nIdComplicacion As Integer, ByVal nIdClaseProcedimiento As Integer, ByVal nIdFormaRealizaActoQ As Integer, ByVal nIdPersonalAtiende As Integer _
                          , ByVal nIdTipoProcedimiento As Integer, ByVal sCondicionPaciente As String, ByVal sCodigoAtencio As String, ByVal dFechaAutorizacion As Date _
                          , ByVal nIdDiagnosticoPrincipal As Integer, ByVal nIdDiagnosticoRelacionadoN1 As Integer, ByVal nIdDiagnosticoRelacionadoN2 As Integer _
                          , ByVal nIdDiagnosticoRelacionadoN3 As Integer, ByVal nIdPrestador As Integer) As Boolean Implements IFacturacion.ActualizarCita
      Try
        parameters = New SqlParameter() {New SqlParameter("@nOperacion", SqlDbType.Int) With {.Value = 2} _
                                        , New SqlParameter("@nIdCita", SqlDbType.Int) With {.Value = nIdCita} _
                                        , New SqlParameter("@sNumeroPacienteId", SqlDbType.NVarChar, 30) With {.Value = sNroPacienteId} _
                                        , New SqlParameter("@nEstadoCita", SqlDbType.Int) With {.Value = nEstadoCita} _
                                        , New SqlParameter("@sNroFactura", SqlDbType.NVarChar, 50) With {.Value = sNroFactura} _
                                        , New SqlParameter("@nValorUnitario", SqlDbType.Decimal) With {.Value = nValorUnitario} _
                                        , New SqlParameter("@nNroServicios", SqlDbType.Int) With {.Value = nCantidadServicios} _
                                        , New SqlParameter("@sNroOrden", SqlDbType.NVarChar, 50) With {.Value = sNroOrden} _
                                        , New SqlParameter("@intIdServicio", SqlDbType.Int) With {.Value = nIdServicio} _
                                        , New SqlParameter("@intIdDiagnosticoPrevio", SqlDbType.Int) With {.Value = nIdDiagnosticoPrevio} _
                                        , New SqlParameter("@intIdDiagnosticoPosterior", SqlDbType.Int) With {.Value = nIdDiagnosticoPosterior} _
                                        , New SqlParameter("@intIdComplicacion", SqlDbType.Int) With {.Value = nIdComplicacion} _
                                        , New SqlParameter("@intIdClaseProcedimiento", SqlDbType.Int) With {.Value = nIdClaseProcedimiento} _
                                        , New SqlParameter("@intFormaRealizaActoQ", SqlDbType.Int) With {.Value = nIdFormaRealizaActoQ} _
                                        , New SqlParameter("@intIdPersonalAtiende", SqlDbType.Int) With {.Value = nIdPersonalAtiende} _
                                        , New SqlParameter("@intTipoProcedimiento", SqlDbType.Int) With {.Value = nIdTipoProcedimiento} _
                                        , New SqlParameter("@strCondicionPaciente", SqlDbType.NVarChar, 2000) With {.Value = sCondicionPaciente} _
                                        , New SqlParameter("@strCodAtencion", SqlDbType.NVarChar, 2000) With {.Value = sCodigoAtencio} _
                                        , New SqlParameter("@dtmFechaAutorizacion", SqlDbType.Date) With {.Value = dFechaAutorizacion} _
                                        , New SqlParameter("@intIdDiagnosticoPrincipal", SqlDbType.Int) With {.Value = nIdDiagnosticoPrincipal} _
                                        , New SqlParameter("@intIdDiagnosticoRelacionadoN1", SqlDbType.Int) With {.Value = nIdDiagnosticoRelacionadoN1} _
                                        , New SqlParameter("@intIdDiagnosticoRelacionadoN2", SqlDbType.Int) With {.Value = nIdDiagnosticoRelacionadoN2} _
                                        , New SqlParameter("@intIdDiagnosticoRelacionadoN3", SqlDbType.Int) With {.Value = nIdDiagnosticoRelacionadoN3} _
                                        , New SqlParameter("@intIdPrestador", SqlDbType.Int) With {.Value = nIdPrestador}}


        Return con.EjecutarProcedure(sNombreSp, parameters, Conexion.TipoProcesamiento.NonQuery)
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      End Try
    End Function

    Public Function ReadUpdateConsecutivoFactPrestador(nIdPrestador As Integer) As Integer Implements IFacturacion.ReadUpdateConsecutivoFactPrestador
      Try
        Dim nRetorno As Integer = 0
        parameters = New SqlParameter() {New SqlParameter("@intIdPrestador", SqlDbType.Int) With {.Value = nIdPrestador}}

        dtDatos = con.EjecutarProcedure("usp_AsignarConsecutivoFacturacionPrestadores", parameters, Conexion.TipoProcesamiento.DataTable)

        If dtDatos.Rows.Count > 0 Then
          nRetorno = dtDatos.Rows(0)(0)
        End If

        Return nRetorno
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      End Try
    End Function

    Public Function ListarCriteriosAnulacionFacturas() As DataTable Implements IFacturacion.ListarCriteriosAnulacionFacturas
      Try
        parameters = New SqlParameter() {New SqlParameter("@nOperacion", SqlDbType.Int) With {.Value = 3}}

        dtDatos = con.EjecutarProcedure(sNombreSp, parameters, Conexion.TipoProcesamiento.DataTable)
      Catch exsql As SqlClient.SqlException
        Throw New Exception(exsql.Message)
      Catch ex As Exception
        Throw New Exception(ex.Message)
      End Try
      Return dtDatos
    End Function
#End Region

  End Class
End Namespace

