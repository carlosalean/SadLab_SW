Partial Class IPS

End Class

Partial Class tblPaciente

  Private Sub OnValidate(ByVal action As System.Data.Linq.ChangeAction)
    'If action = Data.Linq.ChangeAction.Insert Then
    '    intEstadoCivil = 13
    'End If
  End Sub


  Private Sub OnintEstadoCivilChanged()

    'If intIdPaciente > 0 Then
    '    'no hace nada
    'End If
    'If intEstadoCivil = 0 Then
    '    'no hace nada
    'End If
    'intEstadoCivil = 13
  End Sub


  Private Sub OnCreated()
    intEstadoCivil = 13
    intIdTipoDocumento = 1
    intSexo = 6
    intTipoUsuario = 8
    intZonaResidencial = 18
    dtmFechaRegistro = Now
    intMedidaEdad = 33
  End Sub
  'Private Sub OnLoaded()
  '    If intIdPaciente > 0 Then
  '        'no hace nada
  '    End If

  'End Sub

End Class

Partial Class DataClasses_SadLabDataContext
End Class

