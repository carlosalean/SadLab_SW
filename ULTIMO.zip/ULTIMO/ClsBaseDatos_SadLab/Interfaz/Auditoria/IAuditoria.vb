﻿Imports System.Data
Imports ClsUtilidades.Utilidades.Objetos

Namespace SadLab.AccesoDatos.Interfaz

  Public Interface IAuditoria

    Function CrearAuditoria(ByVal oAuditoria As Auditorias) As Integer

    Function Listar() As DataTable

  End Interface

End Namespace


