﻿Imports System.Data
Namespace SadLab.AccesoDatos.Interfaz
  Public Interface IRIPS
    Function ListarDatosArchivosRIPS() As DataTable

    Function ActualizarConsecutivoGeneracionArhvios(ByVal nIdArchivoRIPS As Integer) As Boolean

    Function CrearTrazabilidadGeneracion(ByVal nIdArchivoRIPS As Integer, ByVal nCantidadDatos As Integer) As Boolean

    Function ListarInformacionRIPS(ByVal dFechaInicio As DateTime, ByVal dFechaFinal As DateTime, ByVal nIdPrestador As Integer, ByVal nIdArchivoRIPS As Integer) As DataTable

  End Interface
End Namespace

