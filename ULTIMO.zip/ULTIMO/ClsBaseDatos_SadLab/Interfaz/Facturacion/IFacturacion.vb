﻿Imports System.Data

Namespace SadLab.AccesoDatos.Interfaz
  Public Interface IFacturacion

    Function ConsultarDatosFacturacionPaciente(ByVal nIdSede As Integer, Optional ByVal sNroIdPaciente As String = "") As DataTable

    Function ActualizarCita(ByVal nIdCita As String, ByVal sNroPacienteId As String, ByVal nEstadoCita As Integer, ByVal sNroFactura As String, ByVal nValorUnitario As Decimal _
                            , ByVal nCantidadServicios As Integer, ByVal sNroOrden As String, ByVal nIdServicio As Integer, ByVal nIdDiagnosticoPrevio As Integer, ByVal nIdDiagnosticoPosterior As Integer _
                          , ByVal nIdComplicacion As Integer, ByVal nIdClaseProcedimiento As Integer, ByVal nIdFormaRealizaActoQ As Integer, ByVal nIdPersonalAtiende As Integer _
                          , ByVal nIdTipoProcedimiento As Integer, ByVal sCondicionPaciente As String, ByVal sCodigoAtencio As String, ByVal dFechaAutorizacion As Date _
                          , ByVal nIdDiagnosticoPrincipal As Integer, ByVal nIdDiagnosticoRelacionadoN1 As Integer, ByVal nIdDiagnosticoRelacionadoN2 As Integer _
                          , ByVal nIdDiagnosticoRelacionadoN3 As Integer, ByVal nIdPrestador As Integer) As Boolean

    Function ReadUpdateConsecutivoFactPrestador(ByVal nIdPrestador As Integer) As Integer


    Function ListarCriteriosAnulacionFacturas() As DataTable

  End Interface
End Namespace


