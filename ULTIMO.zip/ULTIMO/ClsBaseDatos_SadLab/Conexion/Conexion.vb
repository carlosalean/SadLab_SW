﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text
Imports System.Configuration

Public Class Conexion
  Private cn As SqlConnection
  Private da As SqlDataAdapter
  Private dt As DataTable
  Private cm As SqlCommand
  Private dr As SqlDataReader

  Public Enum TipoProcesamiento
    NonQuery = 1
    Scalar = 2
    DataTable = 3
  End Enum


  Public Sub Conectar()
    If Not My.Computer.FileSystem.FileExists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config") Then
      My.Computer.FileSystem.CopyFile(My.Application.Info.DirectoryPath & "\" & My.Application.Info.AssemblyName & ".exe.config", _
                                      My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")
    End If

    Dim Docxml As XDocument = XDocument.Load(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")
    Dim connectionString As String = Docxml.Descendants("setting")(0).Value

    cn = New SqlConnection(connectionString)
    cn.Open()
  End Sub

  Public Sub Desconectar()
    cn.Close()
    'cn.Dispose()
  End Sub

  Public Function EjecutarConsulta(ByVal cConsulta As String, ByVal cTipoProceso As TipoProcesamiento) As Object
    Try
      Conectar()
      If cTipoProceso = TipoProcesamiento.NonQuery Then
        cm = New SqlCommand(cConsulta, cn)
        cm.ExecuteNonQuery()
        Return True
      ElseIf cTipoProceso = TipoProcesamiento.Scalar Then
        cm = New SqlCommand(cConsulta, cn)
        Return cm.ExecuteScalar()
      ElseIf cTipoProceso = TipoProcesamiento.DataTable Then
        da = New SqlDataAdapter(cConsulta, cn)
        dt = New DataTable()
        da.Fill(dt)
        Return dt
      Else
        Throw New Exception("Tipo de procesamiento no válido")
      End If
    Catch ex As Exception
      Throw New Exception(String.Format("Error al ejecutar la consulta, {1}", ex.Message))
    Finally
      Desconectar()
    End Try
  End Function

  Public Function EjecutarProcedure(ByVal cNombreProcedure As String, ByVal pParametros() As SqlParameter, ByVal cTipoProceso As TipoProcesamiento) As Object
    Try
      Conectar()
      Dim cm As New SqlCommand
      cm = New SqlCommand(cNombreProcedure, cn)
      cm.CommandType = CommandType.StoredProcedure
      cm.Parameters.AddRange(pParametros)

      If cTipoProceso = TipoProcesamiento.NonQuery Then
        cm.ExecuteNonQuery()
        Return True
      ElseIf cTipoProceso = TipoProcesamiento.Scalar Then
        Return cm.ExecuteScalar
      ElseIf cTipoProceso = TipoProcesamiento.DataTable Then
        da = New SqlDataAdapter(cm)
        dt = New DataTable()
        da.Fill(dt)
        Return dt
      Else
        Throw New Exception("Tipo de procesamiento no válido")
      End If
    Catch ex As Exception
      Throw New Exception(String.Format("Error al ejecutar el procedimiento {0}, {1}", cNombreProcedure, ex.Message))
    Finally
      Desconectar()
    End Try
  End Function
End Class
