﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCita
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DtmFechaLabel As System.Windows.Forms.Label
        Dim IntIdCitaLabel As System.Windows.Forms.Label
        Dim IntIdPacienteLabel As System.Windows.Forms.Label
        Dim IntIdProcedimientoLabel As System.Windows.Forms.Label
        Dim IntIdProfesionalLabel As System.Windows.Forms.Label
        Dim StrObservacionLabel As System.Windows.Forms.Label
        Dim TmHoraLabel As System.Windows.Forms.Label
        Dim DtmHoraFinLabel As System.Windows.Forms.Label
        Dim IntIdUsuarioLabel As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCita))
        Me.TblCitaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.TblCitaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblCitaBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripComboBoxSede = New System.Windows.Forms.ToolStripComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DataGridViewDisponibilidad = New System.Windows.Forms.DataGridView()
        Me.DtmHoraDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dtmHoraFin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNroIdPacienteDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.strObservacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DisponibilidadBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ButtonVer = New System.Windows.Forms.Button()
        Me.ButtonNuevo = New System.Windows.Forms.Button()
        Me.DtmHoraMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.IntIdEstadoCitaComboBox = New System.Windows.Forms.ComboBox()
        Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VerificationControl = New DPFP.Gui.Verification.VerificationControl()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.FechaErrorProvider = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.DtmHoraFinMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.ClaveClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.NroCitasClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdUsuarioClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblUsuarioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StrNroIdPacienteTextBox = New ClsUtilidades.ClsTextBox()
        Me.TextBoxNombre = New ClsUtilidades.ClsTextBox()
        Me.DtmFechaDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.IntIdCitaTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdProcedimientoComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblProcedimientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdProfesionalComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblEmpeadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StrObservacionTextBox = New ClsUtilidades.ClsTextBox()
        Me.cmbTipoTarifa = New ClsUtilidades.ClsComboBox()
        Me.TblTipoTarifaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        DtmFechaLabel = New System.Windows.Forms.Label()
        IntIdCitaLabel = New System.Windows.Forms.Label()
        IntIdPacienteLabel = New System.Windows.Forms.Label()
        IntIdProcedimientoLabel = New System.Windows.Forms.Label()
        IntIdProfesionalLabel = New System.Windows.Forms.Label()
        StrObservacionLabel = New System.Windows.Forms.Label()
        TmHoraLabel = New System.Windows.Forms.Label()
        DtmHoraFinLabel = New System.Windows.Forms.Label()
        IntIdUsuarioLabel = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        CType(Me.TblCitaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCitaBindingNavigator.SuspendLayout()
        CType(Me.TblCitaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridViewDisponibilidad, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DisponibilidadBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FechaErrorProvider, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblUsuarioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoTarifaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DtmFechaLabel
        '
        DtmFechaLabel.AutoSize = True
        DtmFechaLabel.Location = New System.Drawing.Point(27, 153)
        DtmFechaLabel.Name = "DtmFechaLabel"
        DtmFechaLabel.Size = New System.Drawing.Size(40, 13)
        DtmFechaLabel.TabIndex = 1
        DtmFechaLabel.Text = "Fecha:"
        '
        'IntIdCitaLabel
        '
        IntIdCitaLabel.AutoSize = True
        IntIdCitaLabel.Location = New System.Drawing.Point(27, 45)
        IntIdCitaLabel.Name = "IntIdCitaLabel"
        IntIdCitaLabel.Size = New System.Drawing.Size(19, 13)
        IntIdCitaLabel.TabIndex = 3
        IntIdCitaLabel.Text = "Id:"
        '
        'IntIdPacienteLabel
        '
        IntIdPacienteLabel.AutoSize = True
        IntIdPacienteLabel.Location = New System.Drawing.Point(27, 71)
        IntIdPacienteLabel.Name = "IntIdPacienteLabel"
        IntIdPacienteLabel.Size = New System.Drawing.Size(52, 13)
        IntIdPacienteLabel.TabIndex = 5
        IntIdPacienteLabel.Text = "Paciente:"
        '
        'IntIdProcedimientoLabel
        '
        IntIdProcedimientoLabel.AutoSize = True
        IntIdProcedimientoLabel.Location = New System.Drawing.Point(27, 98)
        IntIdProcedimientoLabel.Name = "IntIdProcedimientoLabel"
        IntIdProcedimientoLabel.Size = New System.Drawing.Size(77, 13)
        IntIdProcedimientoLabel.TabIndex = 7
        IntIdProcedimientoLabel.Text = "Procedimiento:"
        '
        'IntIdProfesionalLabel
        '
        IntIdProfesionalLabel.AutoSize = True
        IntIdProfesionalLabel.Location = New System.Drawing.Point(27, 125)
        IntIdProfesionalLabel.Name = "IntIdProfesionalLabel"
        IntIdProfesionalLabel.Size = New System.Drawing.Size(62, 13)
        IntIdProfesionalLabel.TabIndex = 9
        IntIdProfesionalLabel.Text = "Profesional:"
        '
        'StrObservacionLabel
        '
        StrObservacionLabel.AutoSize = True
        StrObservacionLabel.Location = New System.Drawing.Point(27, 178)
        StrObservacionLabel.Name = "StrObservacionLabel"
        StrObservacionLabel.Size = New System.Drawing.Size(70, 13)
        StrObservacionLabel.TabIndex = 11
        StrObservacionLabel.Text = "Observacion:"
        '
        'TmHoraLabel
        '
        TmHoraLabel.AutoSize = True
        TmHoraLabel.Location = New System.Drawing.Point(300, 153)
        TmHoraLabel.Name = "TmHoraLabel"
        TmHoraLabel.Size = New System.Drawing.Size(33, 13)
        TmHoraLabel.TabIndex = 13
        TmHoraLabel.Text = "Hora:"
        '
        'DtmHoraFinLabel
        '
        DtmHoraFinLabel.AutoSize = True
        DtmHoraFinLabel.Location = New System.Drawing.Point(432, 153)
        DtmHoraFinLabel.Name = "DtmHoraFinLabel"
        DtmHoraFinLabel.Size = New System.Drawing.Size(50, 13)
        DtmHoraFinLabel.TabIndex = 20
        DtmHoraFinLabel.Text = "Hora Fin:"
        '
        'IntIdUsuarioLabel
        '
        IntIdUsuarioLabel.AutoSize = True
        IntIdUsuarioLabel.Location = New System.Drawing.Point(383, 266)
        IntIdUsuarioLabel.Name = "IntIdUsuarioLabel"
        IntIdUsuarioLabel.Size = New System.Drawing.Size(46, 13)
        IntIdUsuarioLabel.TabIndex = 41
        IntIdUsuarioLabel.Text = "Usuario:"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Location = New System.Drawing.Point(587, 106)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(61, 13)
        Label3.TabIndex = 48
        Label3.Text = "Tipo Tarifa:"
        '
        'TblCitaBindingNavigator
        '
        Me.TblCitaBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblCitaBindingNavigator.BindingSource = Me.TblCitaBindingSource
        Me.TblCitaBindingNavigator.CountItem = Nothing
        Me.TblCitaBindingNavigator.DeleteItem = Nothing
        Me.TblCitaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorAddNewItem, Me.TblCitaBindingNavigatorSaveItem, Me.ToolStripSeparator1, Me.ToolStripLabel1, Me.ToolStripComboBoxSede})
        Me.TblCitaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCitaBindingNavigator.MoveFirstItem = Nothing
        Me.TblCitaBindingNavigator.MoveLastItem = Nothing
        Me.TblCitaBindingNavigator.MoveNextItem = Nothing
        Me.TblCitaBindingNavigator.MovePreviousItem = Nothing
        Me.TblCitaBindingNavigator.Name = "TblCitaBindingNavigator"
        Me.TblCitaBindingNavigator.PositionItem = Nothing
        Me.TblCitaBindingNavigator.Size = New System.Drawing.Size(754, 25)
        Me.TblCitaBindingNavigator.TabIndex = 0
        Me.TblCitaBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'TblCitaBindingSource
        '
        Me.TblCitaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCita)
        '
        'TblCitaBindingNavigatorSaveItem
        '
        Me.TblCitaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblCitaBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblCitaBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblCitaBindingNavigatorSaveItem.Name = "TblCitaBindingNavigatorSaveItem"
        Me.TblCitaBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblCitaBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(44, 22)
        Me.ToolStripLabel1.Text = "Sede:   "
        '
        'ToolStripComboBoxSede
        '
        Me.ToolStripComboBoxSede.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ToolStripComboBoxSede.Name = "ToolStripComboBoxSede"
        Me.ToolStripComboBoxSede.Size = New System.Drawing.Size(121, 25)
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DataGridViewDisponibilidad)
        Me.GroupBox1.Location = New System.Drawing.Point(86, 299)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(625, 208)
        Me.GroupBox1.TabIndex = 17
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Citas Asignadas "
        '
        'DataGridViewDisponibilidad
        '
        Me.DataGridViewDisponibilidad.AllowUserToAddRows = False
        Me.DataGridViewDisponibilidad.AllowUserToDeleteRows = False
        Me.DataGridViewDisponibilidad.AutoGenerateColumns = False
        Me.DataGridViewDisponibilidad.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.DataGridViewDisponibilidad.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewDisponibilidad.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DtmHoraDataGridViewTextBoxColumn, Me.dtmHoraFin, Me.StrNroIdPacienteDataGridViewTextBoxColumn, Me.strObservacion})
        Me.DataGridViewDisponibilidad.DataSource = Me.DisponibilidadBindingSource
        Me.DataGridViewDisponibilidad.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridViewDisponibilidad.Location = New System.Drawing.Point(3, 16)
        Me.DataGridViewDisponibilidad.Name = "DataGridViewDisponibilidad"
        Me.DataGridViewDisponibilidad.ReadOnly = True
        Me.DataGridViewDisponibilidad.RowHeadersVisible = False
        Me.DataGridViewDisponibilidad.Size = New System.Drawing.Size(619, 189)
        Me.DataGridViewDisponibilidad.TabIndex = 0
        '
        'DtmHoraDataGridViewTextBoxColumn
        '
        Me.DtmHoraDataGridViewTextBoxColumn.DataPropertyName = "dtmHora"
        Me.DtmHoraDataGridViewTextBoxColumn.HeaderText = "Hora Ini"
        Me.DtmHoraDataGridViewTextBoxColumn.Name = "DtmHoraDataGridViewTextBoxColumn"
        Me.DtmHoraDataGridViewTextBoxColumn.ReadOnly = True
        Me.DtmHoraDataGridViewTextBoxColumn.Width = 80
        '
        'dtmHoraFin
        '
        Me.dtmHoraFin.DataPropertyName = "dtmHoraFin"
        Me.dtmHoraFin.HeaderText = "Hora Fin"
        Me.dtmHoraFin.Name = "dtmHoraFin"
        Me.dtmHoraFin.ReadOnly = True
        '
        'StrNroIdPacienteDataGridViewTextBoxColumn
        '
        Me.StrNroIdPacienteDataGridViewTextBoxColumn.DataPropertyName = "strNroIdPaciente"
        Me.StrNroIdPacienteDataGridViewTextBoxColumn.HeaderText = "Paciente"
        Me.StrNroIdPacienteDataGridViewTextBoxColumn.Name = "StrNroIdPacienteDataGridViewTextBoxColumn"
        Me.StrNroIdPacienteDataGridViewTextBoxColumn.ReadOnly = True
        Me.StrNroIdPacienteDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.StrNroIdPacienteDataGridViewTextBoxColumn.Width = 250
        '
        'strObservacion
        '
        Me.strObservacion.DataPropertyName = "strDescripcion"
        Me.strObservacion.HeaderText = "Procedimiento"
        Me.strObservacion.Name = "strObservacion"
        Me.strObservacion.ReadOnly = True
        Me.strObservacion.Width = 190
        '
        'DisponibilidadBindingSource
        '
        Me.DisponibilidadBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCita)
        '
        'ButtonVer
        '
        Me.ButtonVer.Location = New System.Drawing.Point(139, 257)
        Me.ButtonVer.Name = "ButtonVer"
        Me.ButtonVer.Size = New System.Drawing.Size(114, 26)
        Me.ButtonVer.TabIndex = 10
        Me.ButtonVer.Text = "Ver Citas Asignadas"
        Me.ButtonVer.UseVisualStyleBackColor = True
        '
        'ButtonNuevo
        '
        Me.ButtonNuevo.Location = New System.Drawing.Point(654, 68)
        Me.ButtonNuevo.Name = "ButtonNuevo"
        Me.ButtonNuevo.Size = New System.Drawing.Size(54, 21)
        Me.ButtonNuevo.TabIndex = 20
        Me.ButtonNuevo.Text = "Nuevo"
        Me.ButtonNuevo.UseVisualStyleBackColor = True
        '
        'DtmHoraMaskedTextBox
        '
        Me.DtmHoraMaskedTextBox.BeepOnError = True
        Me.DtmHoraMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "dtmHora", True))
        Me.DtmHoraMaskedTextBox.Location = New System.Drawing.Point(339, 150)
        Me.DtmHoraMaskedTextBox.Mask = "00:00"
        Me.DtmHoraMaskedTextBox.Name = "DtmHoraMaskedTextBox"
        Me.DtmHoraMaskedTextBox.Size = New System.Drawing.Size(58, 20)
        Me.DtmHoraMaskedTextBox.TabIndex = 5
        Me.DtmHoraMaskedTextBox.ValidatingType = GetType(Date)
        '
        'IntIdEstadoCitaComboBox
        '
        Me.IntIdEstadoCitaComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdEstadoCita", True))
        Me.IntIdEstadoCitaComboBox.DataSource = Me.TblTipoBindingSource
        Me.IntIdEstadoCitaComboBox.DisplayMember = "strValor"
        Me.IntIdEstadoCitaComboBox.Enabled = False
        Me.IntIdEstadoCitaComboBox.FormattingEnabled = True
        Me.IntIdEstadoCitaComboBox.Location = New System.Drawing.Point(590, 149)
        Me.IntIdEstadoCitaComboBox.Name = "IntIdEstadoCitaComboBox"
        Me.IntIdEstadoCitaComboBox.Size = New System.Drawing.Size(121, 21)
        Me.IntIdEstadoCitaComboBox.TabIndex = 9
        Me.IntIdEstadoCitaComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoBindingSource
        '
        Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'VerificationControl
        '
        Me.VerificationControl.Active = True
        Me.VerificationControl.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.VerificationControl.Location = New System.Drawing.Point(30, 194)
        Me.VerificationControl.Name = "VerificationControl"
        Me.VerificationControl.ReaderSerialNumber = "00000000-0000-0000-0000-000000000000"
        Me.VerificationControl.Size = New System.Drawing.Size(66, 57)
        Me.VerificationControl.TabIndex = 41
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(277, 266)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "Nro Citas"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(29, 246)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 13)
        Me.Label2.TabIndex = 46
        Me.Label2.Text = "Clave:"
        '
        'FechaErrorProvider
        '
        Me.FechaErrorProvider.ContainerControl = Me
        '
        'DtmHoraFinMaskedTextBox
        '
        Me.DtmHoraFinMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "dtmHoraFin", True))
        Me.DtmHoraFinMaskedTextBox.Location = New System.Drawing.Point(488, 149)
        Me.DtmHoraFinMaskedTextBox.Mask = "00:00"
        Me.DtmHoraFinMaskedTextBox.Name = "DtmHoraFinMaskedTextBox"
        Me.DtmHoraFinMaskedTextBox.Size = New System.Drawing.Size(64, 20)
        Me.DtmHoraFinMaskedTextBox.TabIndex = 6
        Me.DtmHoraFinMaskedTextBox.ValidatingType = GetType(Date)
        '
        'ClaveClsTextBox
        '
        Me.ClaveClsTextBox.DataSource = Nothing
        Me.ClaveClsTextBox.EnterEntreCampos = True
        Me.ClaveClsTextBox.Location = New System.Drawing.Point(30, 262)
        Me.ClaveClsTextBox.Name = "ClaveClsTextBox"
        Me.ClaveClsTextBox.NombreCodigoF2 = Nothing
        Me.ClaveClsTextBox.NombreDescripcionF2 = Nothing
        Me.ClaveClsTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.ClaveClsTextBox.Size = New System.Drawing.Size(84, 20)
        Me.ClaveClsTextBox.TabIndex = 45
        Me.ClaveClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.ClaveClsTextBox.Visible = False
        '
        'NroCitasClsTextBox
        '
        Me.NroCitasClsTextBox.DataSource = Nothing
        Me.NroCitasClsTextBox.EnterEntreCampos = True
        Me.NroCitasClsTextBox.Location = New System.Drawing.Point(332, 263)
        Me.NroCitasClsTextBox.Name = "NroCitasClsTextBox"
        Me.NroCitasClsTextBox.NombreCodigoF2 = Nothing
        Me.NroCitasClsTextBox.NombreDescripcionF2 = Nothing
        Me.NroCitasClsTextBox.Size = New System.Drawing.Size(34, 20)
        Me.NroCitasClsTextBox.TabIndex = 11
        Me.NroCitasClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdUsuarioClsComboBox
        '
        Me.IntIdUsuarioClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdUsuario", True))
        Me.IntIdUsuarioClsComboBox.DataSource = Me.TblUsuarioBindingSource
        Me.IntIdUsuarioClsComboBox.DisplayMember = "strNombreUsuario"
        Me.IntIdUsuarioClsComboBox.FormattingEnabled = True
        Me.IntIdUsuarioClsComboBox.Location = New System.Drawing.Point(435, 262)
        Me.IntIdUsuarioClsComboBox.Name = "IntIdUsuarioClsComboBox"
        Me.IntIdUsuarioClsComboBox.Size = New System.Drawing.Size(276, 21)
        Me.IntIdUsuarioClsComboBox.TabIndex = 12
        Me.IntIdUsuarioClsComboBox.ValueMember = "intIdUsuario"
        '
        'TblUsuarioBindingSource
        '
        Me.TblUsuarioBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblUsuario)
        '
        'StrNroIdPacienteTextBox
        '
        Me.StrNroIdPacienteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strNroIdPaciente", True))
        Me.StrNroIdPacienteTextBox.DataSource = Nothing
        Me.StrNroIdPacienteTextBox.EnterEntreCampos = True
        Me.StrNroIdPacienteTextBox.Location = New System.Drawing.Point(136, 68)
        Me.StrNroIdPacienteTextBox.Name = "StrNroIdPacienteTextBox"
        Me.StrNroIdPacienteTextBox.NombreCodigoF2 = Nothing
        Me.StrNroIdPacienteTextBox.NombreDescripcionF2 = Nothing
        Me.StrNroIdPacienteTextBox.Size = New System.Drawing.Size(135, 20)
        Me.StrNroIdPacienteTextBox.TabIndex = 1
        Me.StrNroIdPacienteTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TextBoxNombre
        '
        Me.TextBoxNombre.DataSource = Nothing
        Me.TextBoxNombre.Enabled = False
        Me.TextBoxNombre.EnterEntreCampos = True
        Me.TextBoxNombre.Location = New System.Drawing.Point(277, 68)
        Me.TextBoxNombre.Name = "TextBoxNombre"
        Me.TextBoxNombre.NombreCodigoF2 = Nothing
        Me.TextBoxNombre.NombreDescripcionF2 = Nothing
        Me.TextBoxNombre.Size = New System.Drawing.Size(371, 20)
        Me.TextBoxNombre.TabIndex = 18
        Me.TextBoxNombre.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'DtmFechaDateTimePicker
        '
        Me.DtmFechaDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblCitaBindingSource, "dtmFecha", True))
        Me.DtmFechaDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaDateTimePicker.Location = New System.Drawing.Point(136, 149)
        Me.DtmFechaDateTimePicker.Name = "DtmFechaDateTimePicker"
        Me.DtmFechaDateTimePicker.Size = New System.Drawing.Size(101, 20)
        Me.DtmFechaDateTimePicker.TabIndex = 4
        '
        'IntIdCitaTextBox
        '
        Me.IntIdCitaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "intIdCita", True))
        Me.IntIdCitaTextBox.DataSource = Nothing
        Me.IntIdCitaTextBox.Enabled = False
        Me.IntIdCitaTextBox.EnterEntreCampos = True
        Me.IntIdCitaTextBox.Location = New System.Drawing.Point(136, 42)
        Me.IntIdCitaTextBox.Name = "IntIdCitaTextBox"
        Me.IntIdCitaTextBox.NombreCodigoF2 = Nothing
        Me.IntIdCitaTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdCitaTextBox.Size = New System.Drawing.Size(47, 20)
        Me.IntIdCitaTextBox.TabIndex = 0
        Me.IntIdCitaTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdProcedimientoComboBox
        '
        Me.IntIdProcedimientoComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.IntIdProcedimientoComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdProcedimientoComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdProcedimiento", True))
        Me.IntIdProcedimientoComboBox.DataSource = Me.TblProcedimientoBindingSource
        Me.IntIdProcedimientoComboBox.DisplayMember = "strDescripcion"
        Me.IntIdProcedimientoComboBox.FormattingEnabled = True
        Me.IntIdProcedimientoComboBox.Location = New System.Drawing.Point(136, 95)
        Me.IntIdProcedimientoComboBox.Name = "IntIdProcedimientoComboBox"
        Me.IntIdProcedimientoComboBox.Size = New System.Drawing.Size(383, 21)
        Me.IntIdProcedimientoComboBox.TabIndex = 2
        Me.IntIdProcedimientoComboBox.ValueMember = "intIdProcedimientos"
        '
        'TblProcedimientoBindingSource
        '
        Me.TblProcedimientoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        '
        'IntIdProfesionalComboBox
        '
        Me.IntIdProfesionalComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdProfesionalComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdProfesionalComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdProfesional", True))
        Me.IntIdProfesionalComboBox.DataSource = Me.TblEmpeadoBindingSource
        Me.IntIdProfesionalComboBox.DisplayMember = "strNombreEmpleado"
        Me.IntIdProfesionalComboBox.FormattingEnabled = True
        Me.IntIdProfesionalComboBox.Location = New System.Drawing.Point(136, 122)
        Me.IntIdProfesionalComboBox.Name = "IntIdProfesionalComboBox"
        Me.IntIdProfesionalComboBox.Size = New System.Drawing.Size(383, 21)
        Me.IntIdProfesionalComboBox.TabIndex = 3
        Me.IntIdProfesionalComboBox.ValueMember = "intIdCodigoEmpleado"
        '
        'TblEmpeadoBindingSource
        '
        Me.TblEmpeadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEmpeados)
        '
        'StrObservacionTextBox
        '
        Me.StrObservacionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strObservacion", True))
        Me.StrObservacionTextBox.DataSource = Nothing
        Me.StrObservacionTextBox.EnterEntreCampos = True
        Me.StrObservacionTextBox.Location = New System.Drawing.Point(136, 175)
        Me.StrObservacionTextBox.Multiline = True
        Me.StrObservacionTextBox.Name = "StrObservacionTextBox"
        Me.StrObservacionTextBox.NombreCodigoF2 = Nothing
        Me.StrObservacionTextBox.NombreDescripcionF2 = Nothing
        Me.StrObservacionTextBox.Size = New System.Drawing.Size(575, 76)
        Me.StrObservacionTextBox.TabIndex = 7
        Me.StrObservacionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'cmbTipoTarifa
        '
        Me.cmbTipoTarifa.DataSource = Me.TblTipoTarifaBindingSource
        Me.cmbTipoTarifa.DisplayMember = "strNombreTipoTarifa"
        Me.cmbTipoTarifa.FormattingEnabled = True
        Me.cmbTipoTarifa.Location = New System.Drawing.Point(590, 122)
        Me.cmbTipoTarifa.Name = "cmbTipoTarifa"
        Me.cmbTipoTarifa.Size = New System.Drawing.Size(121, 21)
        Me.cmbTipoTarifa.TabIndex = 8
        Me.cmbTipoTarifa.ValueMember = "intIdTipoTarifa"
        '
        'TblTipoTarifaBindingSource
        '
        Me.TblTipoTarifaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipoTarifa)
        '
        'FrmCita
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.ClientSize = New System.Drawing.Size(754, 519)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Me.cmbTipoTarifa)
        Me.Controls.Add(Me.DtmHoraFinMaskedTextBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ClaveClsTextBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.NroCitasClsTextBox)
        Me.Controls.Add(IntIdUsuarioLabel)
        Me.Controls.Add(Me.IntIdUsuarioClsComboBox)
        Me.Controls.Add(Me.VerificationControl)
        Me.Controls.Add(Me.IntIdEstadoCitaComboBox)
        Me.Controls.Add(DtmHoraFinLabel)
        Me.Controls.Add(Me.DtmHoraMaskedTextBox)
        Me.Controls.Add(Me.StrNroIdPacienteTextBox)
        Me.Controls.Add(Me.ButtonNuevo)
        Me.Controls.Add(Me.ButtonVer)
        Me.Controls.Add(Me.TextBoxNombre)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(DtmFechaLabel)
        Me.Controls.Add(Me.DtmFechaDateTimePicker)
        Me.Controls.Add(IntIdCitaLabel)
        Me.Controls.Add(Me.IntIdCitaTextBox)
        Me.Controls.Add(IntIdPacienteLabel)
        Me.Controls.Add(IntIdProcedimientoLabel)
        Me.Controls.Add(Me.IntIdProcedimientoComboBox)
        Me.Controls.Add(IntIdProfesionalLabel)
        Me.Controls.Add(Me.IntIdProfesionalComboBox)
        Me.Controls.Add(StrObservacionLabel)
        Me.Controls.Add(Me.StrObservacionTextBox)
        Me.Controls.Add(TmHoraLabel)
        Me.Controls.Add(Me.TblCitaBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmCita"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Asignar Cita"
        CType(Me.TblCitaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCitaBindingNavigator.ResumeLayout(False)
        Me.TblCitaBindingNavigator.PerformLayout()
        CType(Me.TblCitaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.DataGridViewDisponibilidad, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DisponibilidadBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FechaErrorProvider, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblUsuarioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoTarifaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblCitaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCitaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblCitaBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents DtmFechaDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntIdCitaTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdProcedimientoComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdProfesionalComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents StrObservacionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents DisponibilidadBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TmHoraDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TextBoxNombre As ClsUtilidades.ClsTextBox
    Friend WithEvents TblProcedimientoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblEmpeadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ButtonVer As System.Windows.Forms.Button
    Friend WithEvents ButtonNuevo As System.Windows.Forms.Button
    Friend WithEvents StrNroIdPacienteTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DtmHoraMaskedTextBox As System.Windows.Forms.MaskedTextBox
    Friend WithEvents DataGridViewDisponibilidad As System.Windows.Forms.DataGridView
    Friend WithEvents IntIdEstadoCitaComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VerificationControl As DPFP.Gui.Verification.VerificationControl
    Friend WithEvents IntIdUsuarioClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents TblUsuarioBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents NroCitasClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ClaveClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents FechaErrorProvider As System.Windows.Forms.ErrorProvider
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripComboBoxSede As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents DtmHoraFinMaskedTextBox As System.Windows.Forms.MaskedTextBox
    Friend WithEvents DtmHoraDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dtmHoraFin As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNroIdPacienteDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents strObservacion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmbTipoTarifa As ClsUtilidades.ClsComboBox
    Friend WithEvents TblTipoTarifaBindingSource As System.Windows.Forms.BindingSource
End Class
