﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPacientes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DtmFechaNacimeintoLabel As System.Windows.Forms.Label
        Dim IntEstadoCivilLabel As System.Windows.Forms.Label
        Dim IntIdDepartamentoLabel As System.Windows.Forms.Label
        Dim IntIdEpsLabel As System.Windows.Forms.Label
        Dim IntIDMunicipioLabel As System.Windows.Forms.Label
        Dim IntIdPacienteLabel As System.Windows.Forms.Label
        Dim IntIdTipoDocumentoLabel As System.Windows.Forms.Label
        Dim IntParentezcoLabel As System.Windows.Forms.Label
        Dim IntSexoLabel As System.Windows.Forms.Label
        Dim IntTipoUsuarioLabel As System.Windows.Forms.Label
        Dim IntZonaResidencialLabel As System.Windows.Forms.Label
        Dim StrAcompananteLabel As System.Windows.Forms.Label
        Dim StrBarrioLabel As System.Windows.Forms.Label
        Dim StrDireccionLabel As System.Windows.Forms.Label
        Dim StrEmailLabel As System.Windows.Forms.Label
        Dim StrFaxLabel As System.Windows.Forms.Label
        Dim StrNroIdentificacionLabel As System.Windows.Forms.Label
        Dim StrObservacionLabel As System.Windows.Forms.Label
        Dim StrOcupacionLabel As System.Windows.Forms.Label
        Dim StrPrimerApellidoLabel As System.Windows.Forms.Label
        Dim StrPrimerNombreLabel As System.Windows.Forms.Label
        Dim StrResponsableLabel As System.Windows.Forms.Label
        Dim StrTelefonoResponsabeLabel As System.Windows.Forms.Label
        Dim StrTelefonosLabel As System.Windows.Forms.Label
        Dim StrTelefonosAcompananteLabel As System.Windows.Forms.Label
        Dim IntEdadLabel As System.Windows.Forms.Label
        Dim IntIdDescuentoLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmPacientes))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.IntIdDescuentoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblPacienteBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblDescuentoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnHistoriaClinica = New System.Windows.Forms.Button()
        Me.StrEvaluacionesAnterioresClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TblPacientesProtocolosDataGridView = New System.Windows.Forms.DataGridView()
        Me.intIdProtocolos = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.TblProtocolosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdPacientesProtocolosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdPacienteDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdProtocolosDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblProtocolosDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TieneHuellaCheckBox = New System.Windows.Forms.CheckBox()
        Me.AsignarCitaButton = New System.Windows.Forms.Button()
        Me.IntMedidaEdadClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoMedidaEdadBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntEdadClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.ButtonHuella = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.IntIdTipoDocumentoComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoDocumentoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DtmFechaNacimeintoDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.IntEstadoCivilComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblEstadoCivilBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdDepartamentoComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblDepartamentoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdEpsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblEPBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIDMunicipioComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblMunicipiosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdPacienteTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntParentezcoComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblParentezcoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntSexoComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblSexoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntTipoUsuarioComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoUsuarioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntZonaResidencialComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblZonaResidencialBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StrAcompananteTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrBarrioTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrDireccionTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrEmailTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrFaxTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrNroIdentificacionTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrObservacionTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrOcupacionTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrPrimerApellidoTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrPrimerNombreTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrResponsableTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrSegundoApellidoTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrSegundoNombreTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrTelefonoResponsabeTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrTelefonosTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrTelefonosAcompananteTextBox = New ClsUtilidades.ClsTextBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TblPacienteDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn27 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblPacienteBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblPacienteBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.SeleccionToolStripComboBox = New System.Windows.Forms.ToolStripComboBox()
        Me.BusquedaToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.IntIdPacienteDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdProtocolosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblPacienteDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblProtocolosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        DtmFechaNacimeintoLabel = New System.Windows.Forms.Label()
        IntEstadoCivilLabel = New System.Windows.Forms.Label()
        IntIdDepartamentoLabel = New System.Windows.Forms.Label()
        IntIdEpsLabel = New System.Windows.Forms.Label()
        IntIDMunicipioLabel = New System.Windows.Forms.Label()
        IntIdPacienteLabel = New System.Windows.Forms.Label()
        IntIdTipoDocumentoLabel = New System.Windows.Forms.Label()
        IntParentezcoLabel = New System.Windows.Forms.Label()
        IntSexoLabel = New System.Windows.Forms.Label()
        IntTipoUsuarioLabel = New System.Windows.Forms.Label()
        IntZonaResidencialLabel = New System.Windows.Forms.Label()
        StrAcompananteLabel = New System.Windows.Forms.Label()
        StrBarrioLabel = New System.Windows.Forms.Label()
        StrDireccionLabel = New System.Windows.Forms.Label()
        StrEmailLabel = New System.Windows.Forms.Label()
        StrFaxLabel = New System.Windows.Forms.Label()
        StrNroIdentificacionLabel = New System.Windows.Forms.Label()
        StrObservacionLabel = New System.Windows.Forms.Label()
        StrOcupacionLabel = New System.Windows.Forms.Label()
        StrPrimerApellidoLabel = New System.Windows.Forms.Label()
        StrPrimerNombreLabel = New System.Windows.Forms.Label()
        StrResponsableLabel = New System.Windows.Forms.Label()
        StrTelefonoResponsabeLabel = New System.Windows.Forms.Label()
        StrTelefonosLabel = New System.Windows.Forms.Label()
        StrTelefonosAcompananteLabel = New System.Windows.Forms.Label()
        IntEdadLabel = New System.Windows.Forms.Label()
        IntIdDescuentoLabel = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblPacienteBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDescuentoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPacientesProtocolosDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProtocolosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoMedidaEdadBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoDocumentoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblEstadoCivilBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDepartamentoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblEPBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblMunicipiosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblParentezcoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblSexoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoUsuarioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblZonaResidencialBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblPacienteDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPacienteBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblPacienteBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'DtmFechaNacimeintoLabel
        '
        DtmFechaNacimeintoLabel.AutoSize = True
        DtmFechaNacimeintoLabel.Location = New System.Drawing.Point(594, 138)
        DtmFechaNacimeintoLabel.Name = "DtmFechaNacimeintoLabel"
        DtmFechaNacimeintoLabel.Size = New System.Drawing.Size(96, 13)
        DtmFechaNacimeintoLabel.TabIndex = 0
        DtmFechaNacimeintoLabel.Text = "Fecha Nacimeinto:"
        '
        'IntEstadoCivilLabel
        '
        IntEstadoCivilLabel.AutoSize = True
        IntEstadoCivilLabel.Location = New System.Drawing.Point(594, 164)
        IntEstadoCivilLabel.Name = "IntEstadoCivilLabel"
        IntEstadoCivilLabel.Size = New System.Drawing.Size(65, 13)
        IntEstadoCivilLabel.TabIndex = 2
        IntEstadoCivilLabel.Text = "Estado Civil:"
        '
        'IntIdDepartamentoLabel
        '
        IntIdDepartamentoLabel.AutoSize = True
        IntIdDepartamentoLabel.Location = New System.Drawing.Point(23, 161)
        IntIdDepartamentoLabel.Name = "IntIdDepartamentoLabel"
        IntIdDepartamentoLabel.Size = New System.Drawing.Size(77, 13)
        IntIdDepartamentoLabel.TabIndex = 4
        IntIdDepartamentoLabel.Text = "Departamento:"
        '
        'IntIdEpsLabel
        '
        IntIdEpsLabel.AutoSize = True
        IntIdEpsLabel.Location = New System.Drawing.Point(594, 60)
        IntIdEpsLabel.Name = "IntIdEpsLabel"
        IntIdEpsLabel.Size = New System.Drawing.Size(28, 13)
        IntIdEpsLabel.TabIndex = 6
        IntIdEpsLabel.Text = "Eps:"
        '
        'IntIDMunicipioLabel
        '
        IntIDMunicipioLabel.AutoSize = True
        IntIDMunicipioLabel.Location = New System.Drawing.Point(23, 189)
        IntIDMunicipioLabel.Name = "IntIDMunicipioLabel"
        IntIDMunicipioLabel.Size = New System.Drawing.Size(55, 13)
        IntIDMunicipioLabel.TabIndex = 8
        IntIDMunicipioLabel.Text = "Municipio:"
        '
        'IntIdPacienteLabel
        '
        IntIdPacienteLabel.AutoSize = True
        IntIdPacienteLabel.Location = New System.Drawing.Point(23, 32)
        IntIdPacienteLabel.Name = "IntIdPacienteLabel"
        IntIdPacienteLabel.Size = New System.Drawing.Size(19, 13)
        IntIdPacienteLabel.TabIndex = 10
        IntIdPacienteLabel.Text = "Id:"
        '
        'IntIdTipoDocumentoLabel
        '
        IntIdTipoDocumentoLabel.AutoSize = True
        IntIdTipoDocumentoLabel.Location = New System.Drawing.Point(298, 27)
        IntIdTipoDocumentoLabel.Name = "IntIdTipoDocumentoLabel"
        IntIdTipoDocumentoLabel.Size = New System.Drawing.Size(89, 13)
        IntIdTipoDocumentoLabel.TabIndex = 12
        IntIdTipoDocumentoLabel.Text = "Tipo Documento:"
        '
        'IntParentezcoLabel
        '
        IntParentezcoLabel.AutoSize = True
        IntParentezcoLabel.Location = New System.Drawing.Point(23, 292)
        IntParentezcoLabel.Name = "IntParentezcoLabel"
        IntParentezcoLabel.Size = New System.Drawing.Size(64, 13)
        IntParentezcoLabel.TabIndex = 14
        IntParentezcoLabel.Text = "Parentezco:"
        '
        'IntSexoLabel
        '
        IntSexoLabel.AutoSize = True
        IntSexoLabel.Location = New System.Drawing.Point(594, 34)
        IntSexoLabel.Name = "IntSexoLabel"
        IntSexoLabel.Size = New System.Drawing.Size(34, 13)
        IntSexoLabel.TabIndex = 16
        IntSexoLabel.Text = "Sexo:"
        '
        'IntTipoUsuarioLabel
        '
        IntTipoUsuarioLabel.AutoSize = True
        IntTipoUsuarioLabel.Location = New System.Drawing.Point(594, 86)
        IntTipoUsuarioLabel.Name = "IntTipoUsuarioLabel"
        IntTipoUsuarioLabel.Size = New System.Drawing.Size(70, 13)
        IntTipoUsuarioLabel.TabIndex = 18
        IntTipoUsuarioLabel.Text = "Tipo Usuario:"
        '
        'IntZonaResidencialLabel
        '
        IntZonaResidencialLabel.AutoSize = True
        IntZonaResidencialLabel.Location = New System.Drawing.Point(594, 190)
        IntZonaResidencialLabel.Name = "IntZonaResidencialLabel"
        IntZonaResidencialLabel.Size = New System.Drawing.Size(93, 13)
        IntZonaResidencialLabel.TabIndex = 20
        IntZonaResidencialLabel.Text = "Zona Residencial:"
        '
        'StrAcompananteLabel
        '
        StrAcompananteLabel.AutoSize = True
        StrAcompananteLabel.Location = New System.Drawing.Point(23, 318)
        StrAcompananteLabel.Name = "StrAcompananteLabel"
        StrAcompananteLabel.Size = New System.Drawing.Size(76, 13)
        StrAcompananteLabel.TabIndex = 22
        StrAcompananteLabel.Text = "Acompanante:"
        '
        'StrBarrioLabel
        '
        StrBarrioLabel.AutoSize = True
        StrBarrioLabel.Location = New System.Drawing.Point(594, 216)
        StrBarrioLabel.Name = "StrBarrioLabel"
        StrBarrioLabel.Size = New System.Drawing.Size(37, 13)
        StrBarrioLabel.TabIndex = 24
        StrBarrioLabel.Text = "Barrio:"
        '
        'StrDireccionLabel
        '
        StrDireccionLabel.AutoSize = True
        StrDireccionLabel.Location = New System.Drawing.Point(23, 214)
        StrDireccionLabel.Name = "StrDireccionLabel"
        StrDireccionLabel.Size = New System.Drawing.Size(55, 13)
        StrDireccionLabel.TabIndex = 26
        StrDireccionLabel.Text = "Dirección:"
        '
        'StrEmailLabel
        '
        StrEmailLabel.AutoSize = True
        StrEmailLabel.Location = New System.Drawing.Point(594, 242)
        StrEmailLabel.Name = "StrEmailLabel"
        StrEmailLabel.Size = New System.Drawing.Size(35, 13)
        StrEmailLabel.TabIndex = 28
        StrEmailLabel.Text = "Email:"
        '
        'StrFaxLabel
        '
        StrFaxLabel.AutoSize = True
        StrFaxLabel.Location = New System.Drawing.Point(594, 268)
        StrFaxLabel.Name = "StrFaxLabel"
        StrFaxLabel.Size = New System.Drawing.Size(27, 13)
        StrFaxLabel.TabIndex = 30
        StrFaxLabel.Text = "Fax:"
        '
        'StrNroIdentificacionLabel
        '
        StrNroIdentificacionLabel.AutoSize = True
        StrNroIdentificacionLabel.Location = New System.Drawing.Point(23, 58)
        StrNroIdentificacionLabel.Name = "StrNroIdentificacionLabel"
        StrNroIdentificacionLabel.Size = New System.Drawing.Size(93, 13)
        StrNroIdentificacionLabel.TabIndex = 32
        StrNroIdentificacionLabel.Text = "Nro Identificacion:"
        '
        'StrObservacionLabel
        '
        StrObservacionLabel.AutoSize = True
        StrObservacionLabel.Location = New System.Drawing.Point(23, 354)
        StrObservacionLabel.Name = "StrObservacionLabel"
        StrObservacionLabel.Size = New System.Drawing.Size(70, 13)
        StrObservacionLabel.TabIndex = 34
        StrObservacionLabel.Text = "Observación:"
        '
        'StrOcupacionLabel
        '
        StrOcupacionLabel.AutoSize = True
        StrOcupacionLabel.Location = New System.Drawing.Point(23, 240)
        StrOcupacionLabel.Name = "StrOcupacionLabel"
        StrOcupacionLabel.Size = New System.Drawing.Size(62, 13)
        StrOcupacionLabel.TabIndex = 36
        StrOcupacionLabel.Text = "Ocupación:"
        '
        'StrPrimerApellidoLabel
        '
        StrPrimerApellidoLabel.AutoSize = True
        StrPrimerApellidoLabel.Location = New System.Drawing.Point(23, 110)
        StrPrimerApellidoLabel.Name = "StrPrimerApellidoLabel"
        StrPrimerApellidoLabel.Size = New System.Drawing.Size(52, 13)
        StrPrimerApellidoLabel.TabIndex = 38
        StrPrimerApellidoLabel.Text = "Apellidos:"
        '
        'StrPrimerNombreLabel
        '
        StrPrimerNombreLabel.AutoSize = True
        StrPrimerNombreLabel.Location = New System.Drawing.Point(23, 84)
        StrPrimerNombreLabel.Name = "StrPrimerNombreLabel"
        StrPrimerNombreLabel.Size = New System.Drawing.Size(52, 13)
        StrPrimerNombreLabel.TabIndex = 40
        StrPrimerNombreLabel.Text = "Nombres:"
        '
        'StrResponsableLabel
        '
        StrResponsableLabel.AutoSize = True
        StrResponsableLabel.Location = New System.Drawing.Point(23, 266)
        StrResponsableLabel.Name = "StrResponsableLabel"
        StrResponsableLabel.Size = New System.Drawing.Size(72, 13)
        StrResponsableLabel.TabIndex = 42
        StrResponsableLabel.Text = "Responsable:"
        '
        'StrTelefonoResponsabeLabel
        '
        StrTelefonoResponsabeLabel.AutoSize = True
        StrTelefonoResponsabeLabel.Location = New System.Drawing.Point(594, 294)
        StrTelefonoResponsabeLabel.Name = "StrTelefonoResponsabeLabel"
        StrTelefonoResponsabeLabel.Size = New System.Drawing.Size(91, 13)
        StrTelefonoResponsabeLabel.TabIndex = 48
        StrTelefonoResponsabeLabel.Text = "Tel. Responsabe:"
        '
        'StrTelefonosLabel
        '
        StrTelefonosLabel.AutoSize = True
        StrTelefonosLabel.Location = New System.Drawing.Point(23, 134)
        StrTelefonosLabel.Name = "StrTelefonosLabel"
        StrTelefonosLabel.Size = New System.Drawing.Size(57, 13)
        StrTelefonosLabel.TabIndex = 50
        StrTelefonosLabel.Text = "Teléfonos:"
        '
        'StrTelefonosAcompananteLabel
        '
        StrTelefonosAcompananteLabel.AutoSize = True
        StrTelefonosAcompananteLabel.Location = New System.Drawing.Point(594, 318)
        StrTelefonosAcompananteLabel.Name = "StrTelefonosAcompananteLabel"
        StrTelefonosAcompananteLabel.Size = New System.Drawing.Size(97, 13)
        StrTelefonosAcompananteLabel.TabIndex = 52
        StrTelefonosAcompananteLabel.Text = "Tel. Acompanante:"
        '
        'IntEdadLabel
        '
        IntEdadLabel.AutoSize = True
        IntEdadLabel.Location = New System.Drawing.Point(594, 110)
        IntEdadLabel.Name = "IntEdadLabel"
        IntEdadLabel.Size = New System.Drawing.Size(35, 13)
        IntEdadLabel.TabIndex = 54
        IntEdadLabel.Text = "Edad:"
        '
        'IntIdDescuentoLabel
        '
        IntIdDescuentoLabel.AutoSize = True
        IntIdDescuentoLabel.Location = New System.Drawing.Point(594, 344)
        IntIdDescuentoLabel.Name = "IntIdDescuentoLabel"
        IntIdDescuentoLabel.Size = New System.Drawing.Size(62, 13)
        IntIdDescuentoLabel.TabIndex = 64
        IntIdDescuentoLabel.Text = "Descuento:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(958, 553)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.Controls.Add(IntIdDescuentoLabel)
        Me.TabPage2.Controls.Add(Me.IntIdDescuentoClsComboBox)
        Me.TabPage2.Controls.Add(Me.btnHistoriaClinica)
        Me.TabPage2.Controls.Add(Me.StrEvaluacionesAnterioresClsTextBox)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.TblPacientesProtocolosDataGridView)
        Me.TabPage2.Controls.Add(Me.TieneHuellaCheckBox)
        Me.TabPage2.Controls.Add(Me.AsignarCitaButton)
        Me.TabPage2.Controls.Add(Me.IntMedidaEdadClsComboBox)
        Me.TabPage2.Controls.Add(IntEdadLabel)
        Me.TabPage2.Controls.Add(Me.IntEdadClsTextBox)
        Me.TabPage2.Controls.Add(Me.ButtonHuella)
        Me.TabPage2.Controls.Add(Me.PictureBox1)
        Me.TabPage2.Controls.Add(Me.IntIdTipoDocumentoComboBox)
        Me.TabPage2.Controls.Add(DtmFechaNacimeintoLabel)
        Me.TabPage2.Controls.Add(Me.DtmFechaNacimeintoDateTimePicker)
        Me.TabPage2.Controls.Add(IntEstadoCivilLabel)
        Me.TabPage2.Controls.Add(Me.IntEstadoCivilComboBox)
        Me.TabPage2.Controls.Add(IntIdDepartamentoLabel)
        Me.TabPage2.Controls.Add(Me.IntIdDepartamentoComboBox)
        Me.TabPage2.Controls.Add(IntIdEpsLabel)
        Me.TabPage2.Controls.Add(Me.IntIdEpsComboBox)
        Me.TabPage2.Controls.Add(IntIDMunicipioLabel)
        Me.TabPage2.Controls.Add(Me.IntIDMunicipioComboBox)
        Me.TabPage2.Controls.Add(IntIdPacienteLabel)
        Me.TabPage2.Controls.Add(Me.IntIdPacienteTextBox)
        Me.TabPage2.Controls.Add(IntIdTipoDocumentoLabel)
        Me.TabPage2.Controls.Add(IntParentezcoLabel)
        Me.TabPage2.Controls.Add(Me.IntParentezcoComboBox)
        Me.TabPage2.Controls.Add(IntSexoLabel)
        Me.TabPage2.Controls.Add(Me.IntSexoComboBox)
        Me.TabPage2.Controls.Add(IntTipoUsuarioLabel)
        Me.TabPage2.Controls.Add(Me.IntTipoUsuarioComboBox)
        Me.TabPage2.Controls.Add(IntZonaResidencialLabel)
        Me.TabPage2.Controls.Add(Me.IntZonaResidencialComboBox)
        Me.TabPage2.Controls.Add(StrAcompananteLabel)
        Me.TabPage2.Controls.Add(Me.StrAcompananteTextBox)
        Me.TabPage2.Controls.Add(StrBarrioLabel)
        Me.TabPage2.Controls.Add(Me.StrBarrioTextBox)
        Me.TabPage2.Controls.Add(StrDireccionLabel)
        Me.TabPage2.Controls.Add(Me.StrDireccionTextBox)
        Me.TabPage2.Controls.Add(StrEmailLabel)
        Me.TabPage2.Controls.Add(Me.StrEmailTextBox)
        Me.TabPage2.Controls.Add(StrFaxLabel)
        Me.TabPage2.Controls.Add(Me.StrFaxTextBox)
        Me.TabPage2.Controls.Add(StrNroIdentificacionLabel)
        Me.TabPage2.Controls.Add(Me.StrNroIdentificacionTextBox)
        Me.TabPage2.Controls.Add(StrObservacionLabel)
        Me.TabPage2.Controls.Add(Me.StrObservacionTextBox)
        Me.TabPage2.Controls.Add(StrOcupacionLabel)
        Me.TabPage2.Controls.Add(Me.StrOcupacionTextBox)
        Me.TabPage2.Controls.Add(StrPrimerApellidoLabel)
        Me.TabPage2.Controls.Add(Me.StrPrimerApellidoTextBox)
        Me.TabPage2.Controls.Add(StrPrimerNombreLabel)
        Me.TabPage2.Controls.Add(Me.StrPrimerNombreTextBox)
        Me.TabPage2.Controls.Add(StrResponsableLabel)
        Me.TabPage2.Controls.Add(Me.StrResponsableTextBox)
        Me.TabPage2.Controls.Add(Me.StrSegundoApellidoTextBox)
        Me.TabPage2.Controls.Add(Me.StrSegundoNombreTextBox)
        Me.TabPage2.Controls.Add(StrTelefonoResponsabeLabel)
        Me.TabPage2.Controls.Add(Me.StrTelefonoResponsabeTextBox)
        Me.TabPage2.Controls.Add(StrTelefonosLabel)
        Me.TabPage2.Controls.Add(Me.StrTelefonosTextBox)
        Me.TabPage2.Controls.Add(StrTelefonosAcompananteLabel)
        Me.TabPage2.Controls.Add(Me.StrTelefonosAcompananteTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(950, 527)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'IntIdDescuentoClsComboBox
        '
        Me.IntIdDescuentoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intIdDescuento", True))
        Me.IntIdDescuentoClsComboBox.DataSource = Me.TblDescuentoBindingSource
        Me.IntIdDescuentoClsComboBox.DisplayMember = "strDescripcio"
        Me.IntIdDescuentoClsComboBox.FormattingEnabled = True
        Me.IntIdDescuentoClsComboBox.Location = New System.Drawing.Point(708, 341)
        Me.IntIdDescuentoClsComboBox.Name = "IntIdDescuentoClsComboBox"
        Me.IntIdDescuentoClsComboBox.Size = New System.Drawing.Size(127, 21)
        Me.IntIdDescuentoClsComboBox.TabIndex = 29
        Me.IntIdDescuentoClsComboBox.ValueMember = "intIdDescuento"
        '
        'TblPacienteBindingSource
        '
        Me.TblPacienteBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblPaciente)
        '
        'TblDescuentoBindingSource
        '
        Me.TblDescuentoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDescuento)
        Me.TblDescuentoBindingSource.Sort = "strDescripcio"
        '
        'btnHistoriaClinica
        '
        Me.btnHistoriaClinica.Enabled = False
        Me.btnHistoriaClinica.Image = CType(resources.GetObject("btnHistoriaClinica.Image"), System.Drawing.Image)
        Me.btnHistoriaClinica.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnHistoriaClinica.Location = New System.Drawing.Point(773, 490)
        Me.btnHistoriaClinica.Name = "btnHistoriaClinica"
        Me.btnHistoriaClinica.Size = New System.Drawing.Size(135, 34)
        Me.btnHistoriaClinica.TabIndex = 33
        Me.btnHistoriaClinica.Text = "Historia Clínica"
        Me.btnHistoriaClinica.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnHistoriaClinica.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnHistoriaClinica.UseVisualStyleBackColor = True
        '
        'StrEvaluacionesAnterioresClsTextBox
        '
        Me.StrEvaluacionesAnterioresClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strEvaluacionesAnteriores", True))
        Me.StrEvaluacionesAnterioresClsTextBox.DataSource = Nothing
        Me.StrEvaluacionesAnterioresClsTextBox.EnterEntreCampos = True
        Me.StrEvaluacionesAnterioresClsTextBox.Location = New System.Drawing.Point(169, 383)
        Me.StrEvaluacionesAnterioresClsTextBox.Multiline = True
        Me.StrEvaluacionesAnterioresClsTextBox.Name = "StrEvaluacionesAnterioresClsTextBox"
        Me.StrEvaluacionesAnterioresClsTextBox.NombreCodigoF2 = Nothing
        Me.StrEvaluacionesAnterioresClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrEvaluacionesAnterioresClsTextBox.Size = New System.Drawing.Size(413, 101)
        Me.StrEvaluacionesAnterioresClsTextBox.TabIndex = 30
        Me.StrEvaluacionesAnterioresClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(594, 364)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 62
        Me.Label2.Text = "Protocolos:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 386)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(123, 13)
        Me.Label1.TabIndex = 61
        Me.Label1.Text = "Evaluaciones anteriores:"
        '
        'TblPacientesProtocolosDataGridView
        '
        Me.TblPacientesProtocolosDataGridView.AutoGenerateColumns = False
        Me.TblPacientesProtocolosDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblPacientesProtocolosDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.intIdProtocolos, Me.IntIdPacientesProtocolosDataGridViewTextBoxColumn, Me.IntIdPacienteDataGridViewTextBoxColumn1, Me.IntIdProtocolosDataGridViewTextBoxColumn1, Me.TblProtocolosDataGridViewTextBoxColumn1})
        Me.TblPacientesProtocolosDataGridView.DataMember = "tblPacientesProtocolos"
        Me.TblPacientesProtocolosDataGridView.DataSource = Me.TblPacienteBindingSource
        Me.TblPacientesProtocolosDataGridView.Location = New System.Drawing.Point(597, 381)
        Me.TblPacientesProtocolosDataGridView.Name = "TblPacientesProtocolosDataGridView"
        Me.TblPacientesProtocolosDataGridView.Size = New System.Drawing.Size(311, 103)
        Me.TblPacientesProtocolosDataGridView.TabIndex = 31
        '
        'intIdProtocolos
        '
        Me.intIdProtocolos.DataPropertyName = "intIdProtocolos"
        Me.intIdProtocolos.DataSource = Me.TblProtocolosBindingSource
        Me.intIdProtocolos.DisplayMember = "strDescripcion"
        Me.intIdProtocolos.HeaderText = "Protocolos"
        Me.intIdProtocolos.Name = "intIdProtocolos"
        Me.intIdProtocolos.ValueMember = "intIdProtocolos"
        Me.intIdProtocolos.Width = 250
        '
        'TblProtocolosBindingSource
        '
        Me.TblProtocolosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProtocolos)
        '
        'IntIdPacientesProtocolosDataGridViewTextBoxColumn
        '
        Me.IntIdPacientesProtocolosDataGridViewTextBoxColumn.DataPropertyName = "IntIdPacientesProtocolos"
        Me.IntIdPacientesProtocolosDataGridViewTextBoxColumn.HeaderText = "IntIdPacientesProtocolos"
        Me.IntIdPacientesProtocolosDataGridViewTextBoxColumn.Name = "IntIdPacientesProtocolosDataGridViewTextBoxColumn"
        Me.IntIdPacientesProtocolosDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdPacienteDataGridViewTextBoxColumn1
        '
        Me.IntIdPacienteDataGridViewTextBoxColumn1.DataPropertyName = "intIdPaciente"
        Me.IntIdPacienteDataGridViewTextBoxColumn1.HeaderText = "intIdPaciente"
        Me.IntIdPacienteDataGridViewTextBoxColumn1.Name = "IntIdPacienteDataGridViewTextBoxColumn1"
        Me.IntIdPacienteDataGridViewTextBoxColumn1.Visible = False
        '
        'IntIdProtocolosDataGridViewTextBoxColumn1
        '
        Me.IntIdProtocolosDataGridViewTextBoxColumn1.DataPropertyName = "intIdProtocolos"
        Me.IntIdProtocolosDataGridViewTextBoxColumn1.HeaderText = "intIdProtocolos"
        Me.IntIdProtocolosDataGridViewTextBoxColumn1.Name = "IntIdProtocolosDataGridViewTextBoxColumn1"
        Me.IntIdProtocolosDataGridViewTextBoxColumn1.Visible = False
        '
        'TblProtocolosDataGridViewTextBoxColumn1
        '
        Me.TblProtocolosDataGridViewTextBoxColumn1.DataPropertyName = "tblProtocolos"
        Me.TblProtocolosDataGridViewTextBoxColumn1.HeaderText = "tblProtocolos"
        Me.TblProtocolosDataGridViewTextBoxColumn1.Name = "TblProtocolosDataGridViewTextBoxColumn1"
        Me.TblProtocolosDataGridViewTextBoxColumn1.Visible = False
        '
        'TieneHuellaCheckBox
        '
        Me.TieneHuellaCheckBox.AutoSize = True
        Me.TieneHuellaCheckBox.Enabled = False
        Me.TieneHuellaCheckBox.Location = New System.Drawing.Point(56, 494)
        Me.TieneHuellaCheckBox.Name = "TieneHuellaCheckBox"
        Me.TieneHuellaCheckBox.Size = New System.Drawing.Size(91, 17)
        Me.TieneHuellaCheckBox.TabIndex = 56
        Me.TieneHuellaCheckBox.Text = "Tiene Huellas"
        Me.TieneHuellaCheckBox.UseVisualStyleBackColor = True
        Me.TieneHuellaCheckBox.Visible = False
        '
        'AsignarCitaButton
        '
        Me.AsignarCitaButton.Location = New System.Drawing.Point(428, 48)
        Me.AsignarCitaButton.Name = "AsignarCitaButton"
        Me.AsignarCitaButton.Size = New System.Drawing.Size(95, 23)
        Me.AsignarCitaButton.TabIndex = 2
        Me.AsignarCitaButton.Text = "Asignar Cita"
        Me.AsignarCitaButton.UseVisualStyleBackColor = True
        '
        'IntMedidaEdadClsComboBox
        '
        Me.IntMedidaEdadClsComboBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IntMedidaEdadClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intMedidaEdad", True))
        Me.IntMedidaEdadClsComboBox.DataSource = Me.TblTipoMedidaEdadBindingSource
        Me.IntMedidaEdadClsComboBox.DisplayMember = "strValor"
        Me.IntMedidaEdadClsComboBox.FormattingEnabled = True
        Me.IntMedidaEdadClsComboBox.Location = New System.Drawing.Point(764, 112)
        Me.IntMedidaEdadClsComboBox.Name = "IntMedidaEdadClsComboBox"
        Me.IntMedidaEdadClsComboBox.Size = New System.Drawing.Size(121, 21)
        Me.IntMedidaEdadClsComboBox.TabIndex = 11
        Me.IntMedidaEdadClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoMedidaEdadBindingSource
        '
        Me.TblTipoMedidaEdadBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoMedidaEdadBindingSource.Sort = "strValor"
        '
        'IntEdadClsTextBox
        '
        Me.IntEdadClsTextBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IntEdadClsTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.IntEdadClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "intEdad", True))
        Me.IntEdadClsTextBox.DataSource = Nothing
        Me.IntEdadClsTextBox.EnterEntreCampos = True
        Me.IntEdadClsTextBox.Location = New System.Drawing.Point(708, 112)
        Me.IntEdadClsTextBox.Name = "IntEdadClsTextBox"
        Me.IntEdadClsTextBox.NombreCodigoF2 = Nothing
        Me.IntEdadClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntEdadClsTextBox.Size = New System.Drawing.Size(50, 20)
        Me.IntEdadClsTextBox.TabIndex = 10
        Me.IntEdadClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'ButtonHuella
        '
        Me.ButtonHuella.Location = New System.Drawing.Point(169, 490)
        Me.ButtonHuella.Name = "ButtonHuella"
        Me.ButtonHuella.Size = New System.Drawing.Size(100, 23)
        Me.ButtonHuella.TabIndex = 32
        Me.ButtonHuella.Text = "Detectar Huella"
        Me.ButtonHuella.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(57, 405)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(59, 79)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 53
        Me.PictureBox1.TabStop = False
        '
        'IntIdTipoDocumentoComboBox
        '
        Me.IntIdTipoDocumentoComboBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IntIdTipoDocumentoComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intIdTipoDocumento", True))
        Me.IntIdTipoDocumentoComboBox.DataSource = Me.TblTipoDocumentoBindingSource
        Me.IntIdTipoDocumentoComboBox.DisplayMember = "strValor"
        Me.IntIdTipoDocumentoComboBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.IntIdTipoDocumentoComboBox.FormattingEnabled = True
        Me.IntIdTipoDocumentoComboBox.Location = New System.Drawing.Point(301, 51)
        Me.IntIdTipoDocumentoComboBox.Name = "IntIdTipoDocumentoComboBox"
        Me.IntIdTipoDocumentoComboBox.Size = New System.Drawing.Size(121, 21)
        Me.IntIdTipoDocumentoComboBox.TabIndex = 1
        Me.IntIdTipoDocumentoComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoDocumentoBindingSource
        '
        Me.TblTipoDocumentoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoDocumentoBindingSource.Sort = "strValor"
        '
        'DtmFechaNacimeintoDateTimePicker
        '
        Me.DtmFechaNacimeintoDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblPacienteBindingSource, "dtmFechaNacimeinto", True))
        Me.DtmFechaNacimeintoDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaNacimeintoDateTimePicker.Location = New System.Drawing.Point(708, 137)
        Me.DtmFechaNacimeintoDateTimePicker.Name = "DtmFechaNacimeintoDateTimePicker"
        Me.DtmFechaNacimeintoDateTimePicker.Size = New System.Drawing.Size(103, 20)
        Me.DtmFechaNacimeintoDateTimePicker.TabIndex = 13
        '
        'IntEstadoCivilComboBox
        '
        Me.IntEstadoCivilComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntEstadoCivilComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntEstadoCivilComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intEstadoCivil", True))
        Me.IntEstadoCivilComboBox.DataSource = Me.TblEstadoCivilBindingSource
        Me.IntEstadoCivilComboBox.DisplayMember = "strValor"
        Me.IntEstadoCivilComboBox.FormattingEnabled = True
        Me.IntEstadoCivilComboBox.Location = New System.Drawing.Point(708, 162)
        Me.IntEstadoCivilComboBox.Name = "IntEstadoCivilComboBox"
        Me.IntEstadoCivilComboBox.Size = New System.Drawing.Size(127, 21)
        Me.IntEstadoCivilComboBox.TabIndex = 15
        Me.IntEstadoCivilComboBox.ValueMember = "intIdTipo"
        '
        'TblEstadoCivilBindingSource
        '
        Me.TblEstadoCivilBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblEstadoCivilBindingSource.Sort = "strValor"
        '
        'IntIdDepartamentoComboBox
        '
        Me.IntIdDepartamentoComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdDepartamentoComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdDepartamentoComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intIdDepartamento", True))
        Me.IntIdDepartamentoComboBox.DataSource = Me.TblDepartamentoBindingSource
        Me.IntIdDepartamentoComboBox.DisplayMember = "strNombre"
        Me.IntIdDepartamentoComboBox.FormattingEnabled = True
        Me.IntIdDepartamentoComboBox.Location = New System.Drawing.Point(169, 155)
        Me.IntIdDepartamentoComboBox.Name = "IntIdDepartamentoComboBox"
        Me.IntIdDepartamentoComboBox.Size = New System.Drawing.Size(200, 21)
        Me.IntIdDepartamentoComboBox.TabIndex = 14
        Me.IntIdDepartamentoComboBox.ValueMember = "intIdDepartamento"
        '
        'TblDepartamentoBindingSource
        '
        Me.TblDepartamentoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDepartamento)
        Me.TblDepartamentoBindingSource.Sort = "strNombre"
        '
        'IntIdEpsComboBox
        '
        Me.IntIdEpsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdEpsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdEpsComboBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IntIdEpsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intIdEps", True))
        Me.IntIdEpsComboBox.DataSource = Me.TblEPBindingSource
        Me.IntIdEpsComboBox.DisplayMember = "strNombre"
        Me.IntIdEpsComboBox.FormattingEnabled = True
        Me.IntIdEpsComboBox.Location = New System.Drawing.Point(708, 59)
        Me.IntIdEpsComboBox.Name = "IntIdEpsComboBox"
        Me.IntIdEpsComboBox.Size = New System.Drawing.Size(200, 21)
        Me.IntIdEpsComboBox.TabIndex = 8
        Me.IntIdEpsComboBox.ValueMember = "intIdEPS"
        '
        'TblEPBindingSource
        '
        Me.TblEPBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEPs)
        Me.TblEPBindingSource.Sort = "strNombre"
        '
        'IntIDMunicipioComboBox
        '
        Me.IntIDMunicipioComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIDMunicipioComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIDMunicipioComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intIDMunicipio", True))
        Me.IntIDMunicipioComboBox.DataSource = Me.TblMunicipiosBindingSource
        Me.IntIDMunicipioComboBox.DisplayMember = "strNombre"
        Me.IntIDMunicipioComboBox.FormattingEnabled = True
        Me.IntIDMunicipioComboBox.Location = New System.Drawing.Point(169, 182)
        Me.IntIDMunicipioComboBox.Name = "IntIDMunicipioComboBox"
        Me.IntIDMunicipioComboBox.Size = New System.Drawing.Size(258, 21)
        Me.IntIDMunicipioComboBox.TabIndex = 16
        Me.IntIDMunicipioComboBox.ValueMember = "intIdMunicipio"
        '
        'TblMunicipiosBindingSource
        '
        Me.TblMunicipiosBindingSource.DataMember = "tblMunicipios"
        Me.TblMunicipiosBindingSource.DataSource = Me.TblDepartamentoBindingSource
        Me.TblMunicipiosBindingSource.Sort = "strNombre"
        '
        'IntIdPacienteTextBox
        '
        Me.IntIdPacienteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "intIdPaciente", True))
        Me.IntIdPacienteTextBox.DataSource = Nothing
        Me.IntIdPacienteTextBox.Enabled = False
        Me.IntIdPacienteTextBox.EnterEntreCampos = True
        Me.IntIdPacienteTextBox.Location = New System.Drawing.Point(169, 25)
        Me.IntIdPacienteTextBox.Name = "IntIdPacienteTextBox"
        Me.IntIdPacienteTextBox.NombreCodigoF2 = Nothing
        Me.IntIdPacienteTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdPacienteTextBox.Size = New System.Drawing.Size(46, 20)
        Me.IntIdPacienteTextBox.TabIndex = 34
        Me.IntIdPacienteTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntParentezcoComboBox
        '
        Me.IntParentezcoComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intParentezco", True))
        Me.IntParentezcoComboBox.DataSource = Me.TblParentezcoBindingSource
        Me.IntParentezcoComboBox.DisplayMember = "strValor"
        Me.IntParentezcoComboBox.FormattingEnabled = True
        Me.IntParentezcoComboBox.Location = New System.Drawing.Point(169, 287)
        Me.IntParentezcoComboBox.Name = "IntParentezcoComboBox"
        Me.IntParentezcoComboBox.Size = New System.Drawing.Size(200, 21)
        Me.IntParentezcoComboBox.TabIndex = 24
        Me.IntParentezcoComboBox.ValueMember = "intIdTipo"
        '
        'TblParentezcoBindingSource
        '
        Me.TblParentezcoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblParentezcoBindingSource.Sort = "strValor"
        '
        'IntSexoComboBox
        '
        Me.IntSexoComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntSexoComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntSexoComboBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IntSexoComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intSexo", True))
        Me.IntSexoComboBox.DataSource = Me.TblSexoBindingSource
        Me.IntSexoComboBox.DisplayMember = "strValor"
        Me.IntSexoComboBox.FormattingEnabled = True
        Me.IntSexoComboBox.Location = New System.Drawing.Point(708, 33)
        Me.IntSexoComboBox.Name = "IntSexoComboBox"
        Me.IntSexoComboBox.Size = New System.Drawing.Size(116, 21)
        Me.IntSexoComboBox.TabIndex = 7
        Me.IntSexoComboBox.ValueMember = "intIdTipo"
        '
        'TblSexoBindingSource
        '
        Me.TblSexoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntTipoUsuarioComboBox
        '
        Me.IntTipoUsuarioComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntTipoUsuarioComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntTipoUsuarioComboBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.IntTipoUsuarioComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intTipoUsuario", True))
        Me.IntTipoUsuarioComboBox.DataSource = Me.TblTipoUsuarioBindingSource
        Me.IntTipoUsuarioComboBox.DisplayMember = "strValor"
        Me.IntTipoUsuarioComboBox.FormattingEnabled = True
        Me.IntTipoUsuarioComboBox.Location = New System.Drawing.Point(708, 85)
        Me.IntTipoUsuarioComboBox.Name = "IntTipoUsuarioComboBox"
        Me.IntTipoUsuarioComboBox.Size = New System.Drawing.Size(127, 21)
        Me.IntTipoUsuarioComboBox.TabIndex = 9
        Me.IntTipoUsuarioComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoUsuarioBindingSource
        '
        Me.TblTipoUsuarioBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoUsuarioBindingSource.Sort = "strValor"
        '
        'IntZonaResidencialComboBox
        '
        Me.IntZonaResidencialComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntZonaResidencialComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntZonaResidencialComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblPacienteBindingSource, "intZonaResidencial", True))
        Me.IntZonaResidencialComboBox.DataSource = Me.TblZonaResidencialBindingSource
        Me.IntZonaResidencialComboBox.DisplayMember = "strValor"
        Me.IntZonaResidencialComboBox.FormattingEnabled = True
        Me.IntZonaResidencialComboBox.Location = New System.Drawing.Point(708, 188)
        Me.IntZonaResidencialComboBox.Name = "IntZonaResidencialComboBox"
        Me.IntZonaResidencialComboBox.Size = New System.Drawing.Size(103, 21)
        Me.IntZonaResidencialComboBox.TabIndex = 17
        Me.IntZonaResidencialComboBox.ValueMember = "intIdTipo"
        '
        'TblZonaResidencialBindingSource
        '
        Me.TblZonaResidencialBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblZonaResidencialBindingSource.Sort = "strValor"
        '
        'StrAcompananteTextBox
        '
        Me.StrAcompananteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strAcompanante", True))
        Me.StrAcompananteTextBox.DataSource = Nothing
        Me.StrAcompananteTextBox.EnterEntreCampos = True
        Me.StrAcompananteTextBox.Location = New System.Drawing.Point(169, 314)
        Me.StrAcompananteTextBox.Name = "StrAcompananteTextBox"
        Me.StrAcompananteTextBox.NombreCodigoF2 = Nothing
        Me.StrAcompananteTextBox.NombreDescripcionF2 = Nothing
        Me.StrAcompananteTextBox.Size = New System.Drawing.Size(413, 20)
        Me.StrAcompananteTextBox.TabIndex = 26
        Me.StrAcompananteTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrBarrioTextBox
        '
        Me.StrBarrioTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strBarrio", True))
        Me.StrBarrioTextBox.DataSource = Nothing
        Me.StrBarrioTextBox.EnterEntreCampos = True
        Me.StrBarrioTextBox.Location = New System.Drawing.Point(708, 214)
        Me.StrBarrioTextBox.Name = "StrBarrioTextBox"
        Me.StrBarrioTextBox.NombreCodigoF2 = Nothing
        Me.StrBarrioTextBox.NombreDescripcionF2 = Nothing
        Me.StrBarrioTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrBarrioTextBox.TabIndex = 19
        Me.StrBarrioTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrDireccionTextBox
        '
        Me.StrDireccionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strDireccion", True))
        Me.StrDireccionTextBox.DataSource = Nothing
        Me.StrDireccionTextBox.EnterEntreCampos = True
        Me.StrDireccionTextBox.Location = New System.Drawing.Point(169, 209)
        Me.StrDireccionTextBox.Name = "StrDireccionTextBox"
        Me.StrDireccionTextBox.NombreCodigoF2 = Nothing
        Me.StrDireccionTextBox.NombreDescripcionF2 = Nothing
        Me.StrDireccionTextBox.Size = New System.Drawing.Size(413, 20)
        Me.StrDireccionTextBox.TabIndex = 18
        Me.StrDireccionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrEmailTextBox
        '
        Me.StrEmailTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strEmail", True))
        Me.StrEmailTextBox.DataSource = Nothing
        Me.StrEmailTextBox.EnterEntreCampos = True
        Me.StrEmailTextBox.Location = New System.Drawing.Point(708, 239)
        Me.StrEmailTextBox.Name = "StrEmailTextBox"
        Me.StrEmailTextBox.NombreCodigoF2 = Nothing
        Me.StrEmailTextBox.NombreDescripcionF2 = Nothing
        Me.StrEmailTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrEmailTextBox.TabIndex = 21
        Me.StrEmailTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrFaxTextBox
        '
        Me.StrFaxTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strFax", True))
        Me.StrFaxTextBox.DataSource = Nothing
        Me.StrFaxTextBox.EnterEntreCampos = True
        Me.StrFaxTextBox.Location = New System.Drawing.Point(708, 264)
        Me.StrFaxTextBox.Name = "StrFaxTextBox"
        Me.StrFaxTextBox.NombreCodigoF2 = Nothing
        Me.StrFaxTextBox.NombreDescripcionF2 = Nothing
        Me.StrFaxTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrFaxTextBox.TabIndex = 23
        Me.StrFaxTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrNroIdentificacionTextBox
        '
        Me.StrNroIdentificacionTextBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.StrNroIdentificacionTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.StrNroIdentificacionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strNroIdentificacion", True))
        Me.StrNroIdentificacionTextBox.DataSource = Nothing
        Me.StrNroIdentificacionTextBox.EnterEntreCampos = True
        Me.StrNroIdentificacionTextBox.Location = New System.Drawing.Point(169, 51)
        Me.StrNroIdentificacionTextBox.Name = "StrNroIdentificacionTextBox"
        Me.StrNroIdentificacionTextBox.NombreCodigoF2 = Nothing
        Me.StrNroIdentificacionTextBox.NombreDescripcionF2 = Nothing
        Me.StrNroIdentificacionTextBox.Size = New System.Drawing.Size(126, 20)
        Me.StrNroIdentificacionTextBox.TabIndex = 0
        Me.StrNroIdentificacionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrObservacionTextBox
        '
        Me.StrObservacionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strObservacion", True))
        Me.StrObservacionTextBox.DataSource = Nothing
        Me.StrObservacionTextBox.EnterEntreCampos = True
        Me.StrObservacionTextBox.Location = New System.Drawing.Point(169, 344)
        Me.StrObservacionTextBox.Multiline = True
        Me.StrObservacionTextBox.Name = "StrObservacionTextBox"
        Me.StrObservacionTextBox.NombreCodigoF2 = Nothing
        Me.StrObservacionTextBox.NombreDescripcionF2 = Nothing
        Me.StrObservacionTextBox.Size = New System.Drawing.Size(413, 33)
        Me.StrObservacionTextBox.TabIndex = 28
        Me.StrObservacionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrOcupacionTextBox
        '
        Me.StrOcupacionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strOcupacion", True))
        Me.StrOcupacionTextBox.DataSource = Nothing
        Me.StrOcupacionTextBox.EnterEntreCampos = True
        Me.StrOcupacionTextBox.Location = New System.Drawing.Point(169, 235)
        Me.StrOcupacionTextBox.Name = "StrOcupacionTextBox"
        Me.StrOcupacionTextBox.NombreCodigoF2 = Nothing
        Me.StrOcupacionTextBox.NombreDescripcionF2 = Nothing
        Me.StrOcupacionTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrOcupacionTextBox.TabIndex = 20
        Me.StrOcupacionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrPrimerApellidoTextBox
        '
        Me.StrPrimerApellidoTextBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.StrPrimerApellidoTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.StrPrimerApellidoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strPrimerApellido", True))
        Me.StrPrimerApellidoTextBox.DataSource = Nothing
        Me.StrPrimerApellidoTextBox.EnterEntreCampos = True
        Me.StrPrimerApellidoTextBox.Location = New System.Drawing.Point(169, 103)
        Me.StrPrimerApellidoTextBox.Name = "StrPrimerApellidoTextBox"
        Me.StrPrimerApellidoTextBox.NombreCodigoF2 = Nothing
        Me.StrPrimerApellidoTextBox.NombreDescripcionF2 = Nothing
        Me.StrPrimerApellidoTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrPrimerApellidoTextBox.TabIndex = 5
        Me.StrPrimerApellidoTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrPrimerNombreTextBox
        '
        Me.StrPrimerNombreTextBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.StrPrimerNombreTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.StrPrimerNombreTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strPrimerNombre", True))
        Me.StrPrimerNombreTextBox.DataSource = Nothing
        Me.StrPrimerNombreTextBox.EnterEntreCampos = True
        Me.StrPrimerNombreTextBox.Location = New System.Drawing.Point(169, 77)
        Me.StrPrimerNombreTextBox.Name = "StrPrimerNombreTextBox"
        Me.StrPrimerNombreTextBox.NombreCodigoF2 = Nothing
        Me.StrPrimerNombreTextBox.NombreDescripcionF2 = Nothing
        Me.StrPrimerNombreTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrPrimerNombreTextBox.TabIndex = 3
        Me.StrPrimerNombreTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrResponsableTextBox
        '
        Me.StrResponsableTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strResponsable", True))
        Me.StrResponsableTextBox.DataSource = Nothing
        Me.StrResponsableTextBox.EnterEntreCampos = True
        Me.StrResponsableTextBox.Location = New System.Drawing.Point(169, 261)
        Me.StrResponsableTextBox.Name = "StrResponsableTextBox"
        Me.StrResponsableTextBox.NombreCodigoF2 = Nothing
        Me.StrResponsableTextBox.NombreDescripcionF2 = Nothing
        Me.StrResponsableTextBox.Size = New System.Drawing.Size(413, 20)
        Me.StrResponsableTextBox.TabIndex = 22
        Me.StrResponsableTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrSegundoApellidoTextBox
        '
        Me.StrSegundoApellidoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strSegundoApellido", True))
        Me.StrSegundoApellidoTextBox.DataSource = Nothing
        Me.StrSegundoApellidoTextBox.EnterEntreCampos = True
        Me.StrSegundoApellidoTextBox.Location = New System.Drawing.Point(382, 103)
        Me.StrSegundoApellidoTextBox.Name = "StrSegundoApellidoTextBox"
        Me.StrSegundoApellidoTextBox.NombreCodigoF2 = Nothing
        Me.StrSegundoApellidoTextBox.NombreDescripcionF2 = Nothing
        Me.StrSegundoApellidoTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrSegundoApellidoTextBox.TabIndex = 6
        Me.StrSegundoApellidoTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrSegundoNombreTextBox
        '
        Me.StrSegundoNombreTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strSegundoNombre", True))
        Me.StrSegundoNombreTextBox.DataSource = Nothing
        Me.StrSegundoNombreTextBox.EnterEntreCampos = True
        Me.StrSegundoNombreTextBox.Location = New System.Drawing.Point(382, 77)
        Me.StrSegundoNombreTextBox.Name = "StrSegundoNombreTextBox"
        Me.StrSegundoNombreTextBox.NombreCodigoF2 = Nothing
        Me.StrSegundoNombreTextBox.NombreDescripcionF2 = Nothing
        Me.StrSegundoNombreTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrSegundoNombreTextBox.TabIndex = 4
        Me.StrSegundoNombreTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrTelefonoResponsabeTextBox
        '
        Me.StrTelefonoResponsabeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strTelefonoResponsabe", True))
        Me.StrTelefonoResponsabeTextBox.DataSource = Nothing
        Me.StrTelefonoResponsabeTextBox.EnterEntreCampos = True
        Me.StrTelefonoResponsabeTextBox.Location = New System.Drawing.Point(708, 289)
        Me.StrTelefonoResponsabeTextBox.Name = "StrTelefonoResponsabeTextBox"
        Me.StrTelefonoResponsabeTextBox.NombreCodigoF2 = Nothing
        Me.StrTelefonoResponsabeTextBox.NombreDescripcionF2 = Nothing
        Me.StrTelefonoResponsabeTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrTelefonoResponsabeTextBox.TabIndex = 25
        Me.StrTelefonoResponsabeTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrTelefonosTextBox
        '
        Me.StrTelefonosTextBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.StrTelefonosTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.StrTelefonosTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strTelefonos", True))
        Me.StrTelefonosTextBox.DataSource = Nothing
        Me.StrTelefonosTextBox.EnterEntreCampos = True
        Me.StrTelefonosTextBox.Location = New System.Drawing.Point(169, 129)
        Me.StrTelefonosTextBox.Name = "StrTelefonosTextBox"
        Me.StrTelefonosTextBox.NombreCodigoF2 = Nothing
        Me.StrTelefonosTextBox.NombreDescripcionF2 = Nothing
        Me.StrTelefonosTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrTelefonosTextBox.TabIndex = 12
        Me.StrTelefonosTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrTelefonosAcompananteTextBox
        '
        Me.StrTelefonosAcompananteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPacienteBindingSource, "strTelefonosAcompanante", True))
        Me.StrTelefonosAcompananteTextBox.DataSource = Nothing
        Me.StrTelefonosAcompananteTextBox.EnterEntreCampos = True
        Me.StrTelefonosAcompananteTextBox.Location = New System.Drawing.Point(708, 315)
        Me.StrTelefonosAcompananteTextBox.Name = "StrTelefonosAcompananteTextBox"
        Me.StrTelefonosAcompananteTextBox.NombreCodigoF2 = Nothing
        Me.StrTelefonosAcompananteTextBox.NombreDescripcionF2 = Nothing
        Me.StrTelefonosAcompananteTextBox.Size = New System.Drawing.Size(200, 20)
        Me.StrTelefonosAcompananteTextBox.TabIndex = 27
        Me.StrTelefonosAcompananteTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TblPacienteDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(950, 527)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblPacienteDataGridView
        '
        Me.TblPacienteDataGridView.AllowUserToAddRows = False
        Me.TblPacienteDataGridView.AllowUserToDeleteRows = False
        Me.TblPacienteDataGridView.AllowUserToOrderColumns = True
        Me.TblPacienteDataGridView.AutoGenerateColumns = False
        Me.TblPacienteDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblPacienteDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23, Me.DataGridViewTextBoxColumn27})
        Me.TblPacienteDataGridView.DataSource = Me.TblPacienteBindingSource
        Me.TblPacienteDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblPacienteDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblPacienteDataGridView.Name = "TblPacienteDataGridView"
        Me.TblPacienteDataGridView.ReadOnly = True
        Me.TblPacienteDataGridView.Size = New System.Drawing.Size(944, 521)
        Me.TblPacienteDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdPaciente"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strNroIdentificacion"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nro Identificacion"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 120
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "strPrimerNombre"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Primer Nombre"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 200
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "strSegundoNombre"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Segundo Nombre"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 200
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "strPrimerApellido"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Primer Apellido"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Width = 200
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "strSegundoApellido"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Segundo Apellido"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 200
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "strTelefonos"
        Me.DataGridViewTextBoxColumn10.HeaderText = "Telefonos"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.Width = 120
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "intIdEps"
        Me.DataGridViewTextBoxColumn12.DataSource = Me.TblEPBindingSource
        Me.DataGridViewTextBoxColumn12.DisplayMember = "strNombre"
        Me.DataGridViewTextBoxColumn12.HeaderText = "Eps"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        Me.DataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn12.ValueMember = "intIdEPS"
        Me.DataGridViewTextBoxColumn12.Width = 150
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "intTipoUsuario"
        Me.DataGridViewTextBoxColumn13.DataSource = Me.TblTipoUsuarioBindingSource
        Me.DataGridViewTextBoxColumn13.DisplayMember = "strValor"
        Me.DataGridViewTextBoxColumn13.HeaderText = "Tipo Usuario"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn13.ValueMember = "intIdTipo"
        Me.DataGridViewTextBoxColumn13.Width = 120
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.DataPropertyName = "strDireccion"
        Me.DataGridViewTextBoxColumn22.HeaderText = "Dirección"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        Me.DataGridViewTextBoxColumn22.Width = 250
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.DataPropertyName = "strBarrio"
        Me.DataGridViewTextBoxColumn23.HeaderText = "Barrio"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        '
        'DataGridViewTextBoxColumn27
        '
        Me.DataGridViewTextBoxColumn27.DataPropertyName = "strEmail"
        Me.DataGridViewTextBoxColumn27.HeaderText = "Email"
        Me.DataGridViewTextBoxColumn27.Name = "DataGridViewTextBoxColumn27"
        Me.DataGridViewTextBoxColumn27.ReadOnly = True
        '
        'TblPacienteBindingNavigator
        '
        Me.TblPacienteBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblPacienteBindingNavigator.BindingSource = Me.TblPacienteBindingSource
        Me.TblPacienteBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblPacienteBindingNavigator.DeleteItem = Nothing
        Me.TblPacienteBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.TblPacienteBindingNavigatorSaveItem, Me.ToolStripSeparator1, Me.ToolStripLabel1, Me.SeleccionToolStripComboBox, Me.BusquedaToolStripTextBox, Me.ToolStripSeparator2, Me.ToolStripLabel2, Me.BindingNavigatorDeleteItem})
        Me.TblPacienteBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblPacienteBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblPacienteBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblPacienteBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblPacienteBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblPacienteBindingNavigator.Name = "TblPacienteBindingNavigator"
        Me.TblPacienteBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblPacienteBindingNavigator.Size = New System.Drawing.Size(958, 25)
        Me.TblPacienteBindingNavigator.TabIndex = 2
        Me.TblPacienteBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblPacienteBindingNavigatorSaveItem
        '
        Me.TblPacienteBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblPacienteBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblPacienteBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblPacienteBindingNavigatorSaveItem.Name = "TblPacienteBindingNavigatorSaveItem"
        Me.TblPacienteBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblPacienteBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(66, 22)
        Me.ToolStripLabel1.Text = "Buscar Por:"
        '
        'SeleccionToolStripComboBox
        '
        Me.SeleccionToolStripComboBox.Items.AddRange(New Object() {"Cedula", "Nombre", "EPS", "TODOS"})
        Me.SeleccionToolStripComboBox.Name = "SeleccionToolStripComboBox"
        Me.SeleccionToolStripComboBox.Size = New System.Drawing.Size(121, 25)
        '
        'BusquedaToolStripTextBox
        '
        Me.BusquedaToolStripTextBox.Name = "BusquedaToolStripTextBox"
        Me.BusquedaToolStripTextBox.Size = New System.Drawing.Size(100, 25)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(237, 22)
        Me.ToolStripLabel2.Text = "----------------------------------------------"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'IntIdPacienteDataGridViewTextBoxColumn
        '
        Me.IntIdPacienteDataGridViewTextBoxColumn.DataPropertyName = "intIdPaciente"
        Me.IntIdPacienteDataGridViewTextBoxColumn.HeaderText = "intIdPaciente"
        Me.IntIdPacienteDataGridViewTextBoxColumn.Name = "IntIdPacienteDataGridViewTextBoxColumn"
        '
        'IntIdProtocolosDataGridViewTextBoxColumn
        '
        Me.IntIdProtocolosDataGridViewTextBoxColumn.DataPropertyName = "intIdProtocolos"
        Me.IntIdProtocolosDataGridViewTextBoxColumn.HeaderText = "intIdProtocolos"
        Me.IntIdProtocolosDataGridViewTextBoxColumn.Name = "IntIdProtocolosDataGridViewTextBoxColumn"
        '
        'TblPacienteDataGridViewTextBoxColumn
        '
        Me.TblPacienteDataGridViewTextBoxColumn.DataPropertyName = "tblPaciente"
        Me.TblPacienteDataGridViewTextBoxColumn.HeaderText = "tblPaciente"
        Me.TblPacienteDataGridViewTextBoxColumn.Name = "TblPacienteDataGridViewTextBoxColumn"
        '
        'TblProtocolosDataGridViewTextBoxColumn
        '
        Me.TblProtocolosDataGridViewTextBoxColumn.DataPropertyName = "tblProtocolos"
        Me.TblProtocolosDataGridViewTextBoxColumn.HeaderText = "tblProtocolos"
        Me.TblProtocolosDataGridViewTextBoxColumn.Name = "TblProtocolosDataGridViewTextBoxColumn"
        '
        'FrmPacientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(958, 578)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblPacienteBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmPacientes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pacientes"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblPacienteBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDescuentoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPacientesProtocolosDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProtocolosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoMedidaEdadBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoDocumentoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblEstadoCivilBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDepartamentoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblEPBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblMunicipiosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblParentezcoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblSexoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoUsuarioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblZonaResidencialBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblPacienteDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPacienteBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblPacienteBindingNavigator.ResumeLayout(False)
        Me.TblPacienteBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents TabControl1 As System.Windows.Forms.TabControl
    Public WithEvents TabPage1 As System.Windows.Forms.TabPage
    Public WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblPacienteDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblPacienteBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblPacienteBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblPacienteBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents DtmFechaNacimeintoDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntEstadoCivilComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDepartamentoComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdEpsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIDMunicipioComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdPacienteTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntParentezcoComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntSexoComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntTipoUsuarioComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntZonaResidencialComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents StrAcompananteTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrBarrioTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrDireccionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrEmailTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrFaxTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNroIdentificacionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrObservacionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrOcupacionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrPrimerApellidoTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrPrimerNombreTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrResponsableTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrSegundoApellidoTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrSegundoNombreTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrTelefonoResponsabeTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrTelefonosTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrTelefonosAcompananteTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblEPBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDepartamentoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblMunicipiosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents IntIdTipoDocumentoComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents TblTipoDocumentoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblSexoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblEstadoCivilBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblZonaResidencialBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblParentezcoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoUsuarioBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ButtonHuella As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents SeleccionToolStripComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents BusquedaToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents IntEdadClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntMedidaEdadClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents TblTipoMedidaEdadBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents AsignarCitaButton As System.Windows.Forms.Button
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents TieneHuellaCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TblPacientesProtocolosDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblProtocolosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents IntIdPacienteDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdProtocolosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblPacienteDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblProtocolosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents StrEvaluacionesAnterioresClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblPacienteDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIdProtocolos As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents IntIdPacientesProtocolosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdPacienteDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdProtocolosDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblPacientesDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblProtocolosDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnHistoriaClinica As System.Windows.Forms.Button
    Friend WithEvents IntIdDescuentoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents TblDescuentoBindingSource As System.Windows.Forms.BindingSource
End Class
