﻿Imports System.Windows.Forms

Public Class DlgRegistroHuella

    Public Templates(3) As DPFP.Template

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DlgRegistroHuella_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ExchangeData(False)
    End Sub

    Private Sub OnDataChange()
        ExchangeData(False)
    End Sub

    Public Sub ExchangeData(ByVal read As Boolean)
        EnrollmentControl.EnrolledFingerMask = 10
        EnrollmentControl.MaxEnrollFingerCount = 10
    End Sub

    Sub EnrollmentControl_OnEnroll(ByVal Control As Object, ByVal Finger As Integer, ByVal Template As DPFP.Template, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles EnrollmentControl.OnEnroll
        Templates(Finger - 1) = Template
        ExchangeData(True)
    End Sub

    Sub EnrollmentControl_OnDelete(ByVal Control As Object, ByVal Finger As Integer, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles EnrollmentControl.OnDelete
        Templates(Finger - 1) = Nothing
    End Sub

    Private Sub EnrollmentControl_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnrollmentControl.Load

    End Sub
End Class
