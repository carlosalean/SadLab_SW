﻿Imports System.Windows.Forms

Public Class uscRevisionSistemas
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mHC As Integer
    Private _btn As Windows.Forms.Button
    Private _IdUsuario As String

    Private mCambiarNodo As Boolean = True
    Private mNodoSel As TreeNode
    Private mclsUtilidadesHC As clsUtilidadesHC

    Public Sub New()

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mHC() As Integer
        Get
            Return _mHC
        End Get
        Set(ByVal value As Integer)
            _mHC = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub CargarItemRevisionSistemasHC()
        Try
            Dim mconsulta = (From p In dc.tblRevisionSistemasHC Where p.intIdHC = mHC Select p.strValorTexto, p.bitModoTexto)
            If mconsulta.Count > 0 Then
                For Each c In mconsulta
                    If c.bitModoTexto = True Then
                        ObservacionesClsTextBox.Dock = DockStyle.Fill
                        ObservacionesClsTextBox.BringToFront()
                        ObservacionesClsTextBox.ReadOnly = False
                        ObservacionesClsTextBox.Text = c.strValorTexto
                    Else
                        PrCargarDatosRevisionSistemas()
                        Exit For
                    End If
                Next
            Else
                mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
                If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
                    ObservacionesClsTextBox.Dock = DockStyle.Fill
                    ObservacionesClsTextBox.BringToFront()
                    ObservacionesClsTextBox.ReadOnly = False
                Else
                    PrCargarDatosRevisionSistemas()
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub PrCargarDatosRevisionSistemas()
        Try
            If TreeViewSistemas.Nodes.Count = 0 Then
                Dim mClsllenarTreeview As New ClsLlenarTreeViewSintomasSignosLab()
                mClsllenarTreeview.PrllenarTreeView(0, dc, TreeViewSistemas)  'PrllenarTreeView()
            End If
            TreeViewSistemas.HideSelection = True
            TreeViewSistemas.FullRowSelect = True
            Dim tblRevisionSistemas = (From r In dc.tblRevisionSistemasHC Where r.intIdHC = mHC Select r)
            For Each mtblRevisionSistemas In tblRevisionSistemas
                For Each mNodo As TreeNode In TreeViewSistemas.Nodes
                    If mNodo.Nodes.Count > 0 Then
                        If FnBuscarHijos(mtblRevisionSistemas.intIdSintSigLab, mNodo) Then
                            mNodo.Expand()
                        End If
                    Else
                        If mNodo.Tag = mtblRevisionSistemas.intIdSintSigLab Then
                            mNodo.ImageIndex = 3
                            mNodo.SelectedImageIndex = 3
                        Else
                            If mNodo.ImageIndex <> 3 Then
                                mNodo.ImageIndex = 1
                                mNodo.SelectedImageIndex = 1
                            End If
                        End If
                    End If
                Next
            Next
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Function FnBuscarHijos(ByVal pintIdSintSigLab As Integer, ByVal pNodo As TreeNode)
        Dim mBuscarHijos As Boolean = False
        For Each mNodo As TreeNode In pNodo.Nodes
            If mNodo.Nodes.Count > 0 Then
                If FnBuscarHijos(pintIdSintSigLab, mNodo) Then
                    mNodo.Expand()
                    mBuscarHijos = True
                End If
            Else
                If mNodo.Tag = pintIdSintSigLab Then
                    mNodo.ImageIndex = 3
                    mNodo.SelectedImageIndex = 3
                    mBuscarHijos = True
                Else
                    If mNodo.ImageIndex <> 3 Then
                        mNodo.ImageIndex = 1
                        mNodo.SelectedImageIndex = 1
                    End If
                End If
            End If
        Next
        FnBuscarHijos = mBuscarHijos
    End Function

    Private Sub bitValorBoolSiRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bitValorBoolSiRadioButton.CheckedChanged, bitValorBoolNoRadioButton.CheckedChanged
        Try
            If TreeViewSistemas.SelectedNode.Nodes.Count = 0 And mCambiarNodo Then
                TreeViewSistemas.SelectedNode.ImageIndex = 3
                TreeViewSistemas.SelectedNode.SelectedImageIndex = 3
                mNodoSel = TreeViewSistemas.SelectedNode
                ObservacionesClsTextBox.ReadOnly = False
                btnGuardar.Enabled = True
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Try
            If TreeViewSistemas.SelectedNode.Nodes.Count = 0 Then
                TreeViewSistemas.SelectedNode.ImageIndex = 1
                TreeViewSistemas.SelectedNode.SelectedImageIndex = 1
                ObservacionesClsTextBox.ReadOnly = True
                mCambiarNodo = False
                bitValorBoolSiRadioButton.Checked = False
                bitValorBoolNoRadioButton.Checked = False
                mCambiarNodo = True
                mNodoSel = Nothing
            End If
        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub btnRevisar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRevisar.Click
        PrCargarDatosRevisionSistemas()
    End Sub

    Private Sub TreeViewSistemas_NodeMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles TreeViewSistemas.NodeMouseClick
        Try
            txtTitulo.Text = TreeViewSistemas.SelectedNode.Text
            'btnGuardar.Enabled = False
            Dim mTag As Integer
            mTag = e.Node.Tag
            'TreeViewSistemas.HideSelection = True
            If e.Node.ImageIndex = 3 Then
                Dim tblRevisionSistemas = dc.usp_ConsultarNodoSistemasHC(mHC, mTag) '(From r In dc.tblRevisionSistemasHC Where r.intIdHC = mHC And r.intIdSintSigLab = mTag Select r)
                For Each mtblRevisionSistemas In tblRevisionSistemas
                    ObservacionesClsTextBox.Text = mtblRevisionSistemas.strValorTexto
                    ValorNumClsTextBox.Text = mtblRevisionSistemas.numValorNum
                    mCambiarNodo = False
                    If mtblRevisionSistemas.bitValorBool Then
                        bitValorBoolSiRadioButton.Checked = True
                        bitValorBoolNoRadioButton.Checked = False
                    Else
                        bitValorBoolSiRadioButton.Checked = False
                        bitValorBoolNoRadioButton.Checked = True
                    End If
                    mCambiarNodo = True

                Next
            Else
                If mNodoSel Is Nothing Then
                    ObservacionesClsTextBox.Text = ""
                    ValorNumClsTextBox.Text = 0
                    mCambiarNodo = False
                    bitValorBoolSiRadioButton.Checked = False
                    bitValorBoolNoRadioButton.Checked = False
                    mCambiarNodo = True
                    'prHabilitar()
                    'Dim mtipo As Integer = (From s In dc.tblSintomasSignosLaboratorios Where s.intID = mTag Select s.intTipoDato).Single
                    'Select Case mtipo
                    '    Case 0
                    '        Panel2.Enabled = False
                    '        btnBorrar.Enabled = False
                    '        ValorNumClsTextBox.ReadOnly = False
                    '    Case 1
                    '        Panel2.Enabled = True
                    '        btnBorrar.Enabled = True
                    '        ValorNumClsTextBox.ReadOnly = False
                    '    Case 1
                    '        Panel2.Enabled = False
                    '        btnBorrar.Enabled = False
                    '        ValorNumClsTextBox.ReadOnly = False
                    '    Case 2
                    '        ObservacionesClsTextBox.ReadOnly = False
                    'End Select
                End If
            End If


        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TreeViewSistemas_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeViewSistemas.AfterSelect
        prActualizarRevisionSistemasHC()
    End Sub

    Private Sub prActualizarRevisionSistemasHC()
        Try
            If Not mNodoSel Is Nothing Then
                Dim mValor As Decimal
                If IsNumeric(ValorNumClsTextBox.Text) Then
                    mValor = Decimal.Parse(ValorNumClsTextBox.Text)
                Else
                    mValor = 0
                End If
                dc.usp_ActualizarRevisionSistemasHC(mNodoSel.Tag, mValor, bitValorBoolSiRadioButton.Checked, ObservacionesClsTextBox.Text, mHC, False)
                mNodoSel = Nothing
                ' MsgBox("Información actualizada", MsgBoxStyle.Information, "")
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub btnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGuardar.Click
        'If Not TreeViewSistemas.SelectedNode Is Nothing Then
        'mNodoSel = TreeViewSistemas.SelectedNode
        prActualizarRevisionSistemasHC()
        'End If
        'btnGuardar.Enabled = False
    End Sub

    Private Sub btnExpandir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExpandir.Click
        TreeViewSistemas.ExpandAll()
    End Sub

    Private Sub btnContraer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnContraer.Click
        TreeViewSistemas.CollapseAll()
    End Sub

    Private Sub uscRevisionSistemas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TreeViewSistemas.Focus()
    End Sub

    Private Sub uscRevisionSistemas_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        prGuardar()
    End Sub

    Public Sub prGuardar() Implements IAbandonarUC.prGuardar
        Try

            If ObservacionesClsTextBox.Dock = DockStyle.Fill Then
                Dim mValor As Decimal
                If IsNumeric(ValorNumClsTextBox.Text) Then
                    mValor = Decimal.Parse(ValorNumClsTextBox.Text)
                Else
                    mValor = 0
                End If
                dc.usp_ActualizarRevisionSistemasHC(Nothing, mValor, bitValorBoolSiRadioButton.Checked, ObservacionesClsTextBox.Text, mHC, True)
                mNodoSel = Nothing
                'MsgBox("Información actualizada", MsgBoxStyle.Information, "")
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class
