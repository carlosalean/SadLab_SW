﻿Public Class FrmCajas
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Sub New(ByVal strStringConection As String)
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblCajasBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblCajasBindingNavigatorSaveItem.Click
        Try
            TblCajasBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmCajas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TblCajasBindingSource.DataSource = dc.tblCajas
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub
    
End Class