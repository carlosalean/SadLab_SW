﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmComerciales
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IntIdNombresComercialesLabel As System.Windows.Forms.Label
        Dim StrDescripcionLabel As System.Windows.Forms.Label
        Dim IntIdMedicamentosGenericosLabel As System.Windows.Forms.Label
        Dim IntIdTipoPresentacionComercialLabel As System.Windows.Forms.Label
        Dim IntPorLabel As System.Windows.Forms.Label
        Dim DblConcentracionLabel As System.Windows.Forms.Label
        Dim IntIdLaboratorioLabel As System.Windows.Forms.Label
        Dim DblPrecioPublicoLabel As System.Windows.Forms.Label
        Dim DtmFechaLabel As System.Windows.Forms.Label
        Dim IntIdPrincipioActivoPrincipalLabel As System.Windows.Forms.Label
        Dim IntIdPrincipioActivoAsociacionLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmComerciales))
        Me.TblNombresComercialesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblNombresComercialesBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblNombresComercialesBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.IntIdNombresComercialesTextBox = New System.Windows.Forms.TextBox()
        Me.StrDescripcionClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdMedicamentosGenericosClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblMedicamentosGenericosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdTipoPresentacionComercialClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntPorClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdPresentacionDrograsClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DblConcentracionClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdMedidasDrogasClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdLaboratorioClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblLaboratoriosfarmaceuticosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DblPrecioPublicoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.DtmFechaClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.IntIdPrincipioActivoPrincipalClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblPrincipiosActivosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdPrincipioActivoAsociacionClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblPrincipiosActivosBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        IntIdNombresComercialesLabel = New System.Windows.Forms.Label()
        StrDescripcionLabel = New System.Windows.Forms.Label()
        IntIdMedicamentosGenericosLabel = New System.Windows.Forms.Label()
        IntIdTipoPresentacionComercialLabel = New System.Windows.Forms.Label()
        IntPorLabel = New System.Windows.Forms.Label()
        DblConcentracionLabel = New System.Windows.Forms.Label()
        IntIdLaboratorioLabel = New System.Windows.Forms.Label()
        DblPrecioPublicoLabel = New System.Windows.Forms.Label()
        DtmFechaLabel = New System.Windows.Forms.Label()
        IntIdPrincipioActivoPrincipalLabel = New System.Windows.Forms.Label()
        IntIdPrincipioActivoAsociacionLabel = New System.Windows.Forms.Label()
        CType(Me.TblNombresComercialesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblNombresComercialesBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblNombresComercialesBindingNavigator.SuspendLayout()
        CType(Me.TblMedicamentosGenericosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblLaboratoriosfarmaceuticosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPrincipiosActivosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPrincipiosActivosBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntIdNombresComercialesLabel
        '
        IntIdNombresComercialesLabel.AutoSize = True
        IntIdNombresComercialesLabel.Location = New System.Drawing.Point(18, 49)
        IntIdNombresComercialesLabel.Name = "IntIdNombresComercialesLabel"
        IntIdNombresComercialesLabel.Size = New System.Drawing.Size(19, 13)
        IntIdNombresComercialesLabel.TabIndex = 1
        IntIdNombresComercialesLabel.Text = "Id:"
        '
        'StrDescripcionLabel
        '
        StrDescripcionLabel.AutoSize = True
        StrDescripcionLabel.Location = New System.Drawing.Point(19, 103)
        StrDescripcionLabel.Name = "StrDescripcionLabel"
        StrDescripcionLabel.Size = New System.Drawing.Size(66, 13)
        StrDescripcionLabel.TabIndex = 3
        StrDescripcionLabel.Text = "Descripción:"
        '
        'IntIdMedicamentosGenericosLabel
        '
        IntIdMedicamentosGenericosLabel.AutoSize = True
        IntIdMedicamentosGenericosLabel.Location = New System.Drawing.Point(19, 74)
        IntIdMedicamentosGenericosLabel.Name = "IntIdMedicamentosGenericosLabel"
        IntIdMedicamentosGenericosLabel.Size = New System.Drawing.Size(130, 13)
        IntIdMedicamentosGenericosLabel.TabIndex = 5
        IntIdMedicamentosGenericosLabel.Text = "Medicamentos Genéricos:"
        '
        'IntIdTipoPresentacionComercialLabel
        '
        IntIdTipoPresentacionComercialLabel.AutoSize = True
        IntIdTipoPresentacionComercialLabel.Location = New System.Drawing.Point(8, 22)
        IntIdTipoPresentacionComercialLabel.Name = "IntIdTipoPresentacionComercialLabel"
        IntIdTipoPresentacionComercialLabel.Size = New System.Drawing.Size(72, 13)
        IntIdTipoPresentacionComercialLabel.TabIndex = 7
        IntIdTipoPresentacionComercialLabel.Text = "P.  Comercial:"
        '
        'IntPorLabel
        '
        IntPorLabel.AutoSize = True
        IntPorLabel.Location = New System.Drawing.Point(235, 22)
        IntPorLabel.Name = "IntPorLabel"
        IntPorLabel.Size = New System.Drawing.Size(26, 13)
        IntPorLabel.TabIndex = 9
        IntPorLabel.Text = "Por:"
        '
        'DblConcentracionLabel
        '
        DblConcentracionLabel.AutoSize = True
        DblConcentracionLabel.Location = New System.Drawing.Point(9, 48)
        DblConcentracionLabel.Name = "DblConcentracionLabel"
        DblConcentracionLabel.Size = New System.Drawing.Size(79, 13)
        DblConcentracionLabel.TabIndex = 13
        DblConcentracionLabel.Text = "Concentración:"
        '
        'IntIdLaboratorioLabel
        '
        IntIdLaboratorioLabel.AutoSize = True
        IntIdLaboratorioLabel.Location = New System.Drawing.Point(22, 299)
        IntIdLaboratorioLabel.Name = "IntIdLaboratorioLabel"
        IntIdLaboratorioLabel.Size = New System.Drawing.Size(63, 13)
        IntIdLaboratorioLabel.TabIndex = 17
        IntIdLaboratorioLabel.Text = "Laboratorio:"
        '
        'DblPrecioPublicoLabel
        '
        DblPrecioPublicoLabel.AutoSize = True
        DblPrecioPublicoLabel.Location = New System.Drawing.Point(19, 326)
        DblPrecioPublicoLabel.Name = "DblPrecioPublicoLabel"
        DblPrecioPublicoLabel.Size = New System.Drawing.Size(78, 13)
        DblPrecioPublicoLabel.TabIndex = 19
        DblPrecioPublicoLabel.Text = "Precio Público:"
        '
        'DtmFechaLabel
        '
        DtmFechaLabel.AutoSize = True
        DtmFechaLabel.Location = New System.Drawing.Point(337, 330)
        DtmFechaLabel.Name = "DtmFechaLabel"
        DtmFechaLabel.Size = New System.Drawing.Size(40, 13)
        DtmFechaLabel.TabIndex = 21
        DtmFechaLabel.Text = "Fecha:"
        '
        'IntIdPrincipioActivoPrincipalLabel
        '
        IntIdPrincipioActivoPrincipalLabel.AutoSize = True
        IntIdPrincipioActivoPrincipalLabel.Location = New System.Drawing.Point(10, 22)
        IntIdPrincipioActivoPrincipalLabel.Name = "IntIdPrincipioActivoPrincipalLabel"
        IntIdPrincipioActivoPrincipalLabel.Size = New System.Drawing.Size(50, 13)
        IntIdPrincipioActivoPrincipalLabel.TabIndex = 23
        IntIdPrincipioActivoPrincipalLabel.Text = "Principal:"
        '
        'IntIdPrincipioActivoAsociacionLabel
        '
        IntIdPrincipioActivoAsociacionLabel.AutoSize = True
        IntIdPrincipioActivoAsociacionLabel.Location = New System.Drawing.Point(10, 49)
        IntIdPrincipioActivoAsociacionLabel.Name = "IntIdPrincipioActivoAsociacionLabel"
        IntIdPrincipioActivoAsociacionLabel.Size = New System.Drawing.Size(62, 13)
        IntIdPrincipioActivoAsociacionLabel.TabIndex = 25
        IntIdPrincipioActivoAsociacionLabel.Text = "Asociacion:"
        '
        'TblNombresComercialesBindingSource
        '
        Me.TblNombresComercialesBindingSource.DataSource = GetType(System.Data.Linq.EntitySet(Of ClsBaseDatos_SadLab.tblNombresComerciales))
        '
        'TblNombresComercialesBindingNavigator
        '
        Me.TblNombresComercialesBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblNombresComercialesBindingNavigator.BindingSource = Me.TblNombresComercialesBindingSource
        Me.TblNombresComercialesBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblNombresComercialesBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblNombresComercialesBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblNombresComercialesBindingNavigatorSaveItem})
        Me.TblNombresComercialesBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblNombresComercialesBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblNombresComercialesBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblNombresComercialesBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblNombresComercialesBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblNombresComercialesBindingNavigator.Name = "TblNombresComercialesBindingNavigator"
        Me.TblNombresComercialesBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblNombresComercialesBindingNavigator.Size = New System.Drawing.Size(524, 25)
        Me.TblNombresComercialesBindingNavigator.TabIndex = 0
        Me.TblNombresComercialesBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblNombresComercialesBindingNavigatorSaveItem
        '
        Me.TblNombresComercialesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblNombresComercialesBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblNombresComercialesBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblNombresComercialesBindingNavigatorSaveItem.Name = "TblNombresComercialesBindingNavigatorSaveItem"
        Me.TblNombresComercialesBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblNombresComercialesBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'IntIdNombresComercialesTextBox
        '
        Me.IntIdNombresComercialesTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblNombresComercialesBindingSource, "intIdNombresComerciales", True))
        Me.IntIdNombresComercialesTextBox.Enabled = False
        Me.IntIdNombresComercialesTextBox.Location = New System.Drawing.Point(150, 46)
        Me.IntIdNombresComercialesTextBox.Name = "IntIdNombresComercialesTextBox"
        Me.IntIdNombresComercialesTextBox.Size = New System.Drawing.Size(59, 20)
        Me.IntIdNombresComercialesTextBox.TabIndex = 2
        '
        'StrDescripcionClsTextBox
        '
        Me.StrDescripcionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblNombresComercialesBindingSource, "strDescripcion", True))
        Me.StrDescripcionClsTextBox.DataSource = Nothing
        Me.StrDescripcionClsTextBox.EnterEntreCampos = True
        Me.StrDescripcionClsTextBox.Location = New System.Drawing.Point(150, 100)
        Me.StrDescripcionClsTextBox.Name = "StrDescripcionClsTextBox"
        Me.StrDescripcionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcionClsTextBox.Size = New System.Drawing.Size(339, 20)
        Me.StrDescripcionClsTextBox.TabIndex = 4
        Me.StrDescripcionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdMedicamentosGenericosClsComboBox
        '
        Me.IntIdMedicamentosGenericosClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblNombresComercialesBindingSource, "intIdMedicamentosGenericos", True))
        Me.IntIdMedicamentosGenericosClsComboBox.DataSource = Me.TblMedicamentosGenericosBindingSource
        Me.IntIdMedicamentosGenericosClsComboBox.DisplayMember = "strdescripcion"
        Me.IntIdMedicamentosGenericosClsComboBox.Enabled = False
        Me.IntIdMedicamentosGenericosClsComboBox.FormattingEnabled = True
        Me.IntIdMedicamentosGenericosClsComboBox.Location = New System.Drawing.Point(150, 71)
        Me.IntIdMedicamentosGenericosClsComboBox.Name = "IntIdMedicamentosGenericosClsComboBox"
        Me.IntIdMedicamentosGenericosClsComboBox.Size = New System.Drawing.Size(339, 21)
        Me.IntIdMedicamentosGenericosClsComboBox.TabIndex = 6
        Me.IntIdMedicamentosGenericosClsComboBox.ValueMember = "intIdMedicamentosGenericos"
        '
        'TblMedicamentosGenericosBindingSource
        '
        Me.TblMedicamentosGenericosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblMedicamentosGenericos)
        Me.TblMedicamentosGenericosBindingSource.Sort = "strdescripcion"
        '
        'IntIdTipoPresentacionComercialClsComboBox
        '
        Me.IntIdTipoPresentacionComercialClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblNombresComercialesBindingSource, "intIdTipoPresentacionComercial", True))
        Me.IntIdTipoPresentacionComercialClsComboBox.DataSource = Me.TblTipoBindingSource
        Me.IntIdTipoPresentacionComercialClsComboBox.DisplayMember = "strValor"
        Me.IntIdTipoPresentacionComercialClsComboBox.FormattingEnabled = True
        Me.IntIdTipoPresentacionComercialClsComboBox.Location = New System.Drawing.Point(88, 19)
        Me.IntIdTipoPresentacionComercialClsComboBox.Name = "IntIdTipoPresentacionComercialClsComboBox"
        Me.IntIdTipoPresentacionComercialClsComboBox.Size = New System.Drawing.Size(140, 21)
        Me.IntIdTipoPresentacionComercialClsComboBox.TabIndex = 8
        Me.IntIdTipoPresentacionComercialClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoBindingSource
        '
        Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntPorClsTextBox
        '
        Me.IntPorClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblNombresComercialesBindingSource, "intPor", True))
        Me.IntPorClsTextBox.DataSource = Nothing
        Me.IntPorClsTextBox.EnterEntreCampos = True
        Me.IntPorClsTextBox.Location = New System.Drawing.Point(264, 19)
        Me.IntPorClsTextBox.Name = "IntPorClsTextBox"
        Me.IntPorClsTextBox.NombreCodigoF2 = Nothing
        Me.IntPorClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntPorClsTextBox.Size = New System.Drawing.Size(43, 20)
        Me.IntPorClsTextBox.TabIndex = 10
        Me.IntPorClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdPresentacionDrograsClsComboBox
        '
        Me.IntIdPresentacionDrograsClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblNombresComercialesBindingSource, "intIdPresentacionDrogras", True))
        Me.IntIdPresentacionDrograsClsComboBox.DataSource = Me.TblTipoBindingSource1
        Me.IntIdPresentacionDrograsClsComboBox.DisplayMember = "strValor"
        Me.IntIdPresentacionDrograsClsComboBox.FormattingEnabled = True
        Me.IntIdPresentacionDrograsClsComboBox.Location = New System.Drawing.Point(319, 19)
        Me.IntIdPresentacionDrograsClsComboBox.Name = "IntIdPresentacionDrograsClsComboBox"
        Me.IntIdPresentacionDrograsClsComboBox.Size = New System.Drawing.Size(148, 21)
        Me.IntIdPresentacionDrograsClsComboBox.TabIndex = 12
        Me.IntIdPresentacionDrograsClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoBindingSource1
        '
        Me.TblTipoBindingSource1.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'DblConcentracionClsTextBox
        '
        Me.DblConcentracionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblNombresComercialesBindingSource, "dblConcentracion", True))
        Me.DblConcentracionClsTextBox.DataSource = Nothing
        Me.DblConcentracionClsTextBox.EnterEntreCampos = True
        Me.DblConcentracionClsTextBox.Location = New System.Drawing.Point(88, 45)
        Me.DblConcentracionClsTextBox.Name = "DblConcentracionClsTextBox"
        Me.DblConcentracionClsTextBox.NombreCodigoF2 = Nothing
        Me.DblConcentracionClsTextBox.NombreDescripcionF2 = Nothing
        Me.DblConcentracionClsTextBox.Size = New System.Drawing.Size(99, 20)
        Me.DblConcentracionClsTextBox.TabIndex = 14
        Me.DblConcentracionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdMedidasDrogasClsComboBox
        '
        Me.IntIdMedidasDrogasClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblNombresComercialesBindingSource, "intIdMedidasDrogas", True))
        Me.IntIdMedidasDrogasClsComboBox.DataSource = Me.TblTipoBindingSource2
        Me.IntIdMedidasDrogasClsComboBox.DisplayMember = "strValor"
        Me.IntIdMedidasDrogasClsComboBox.FormattingEnabled = True
        Me.IntIdMedidasDrogasClsComboBox.Location = New System.Drawing.Point(202, 45)
        Me.IntIdMedidasDrogasClsComboBox.Name = "IntIdMedidasDrogasClsComboBox"
        Me.IntIdMedidasDrogasClsComboBox.Size = New System.Drawing.Size(138, 21)
        Me.IntIdMedidasDrogasClsComboBox.TabIndex = 16
        Me.IntIdMedidasDrogasClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoBindingSource2
        '
        Me.TblTipoBindingSource2.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntIdLaboratorioClsComboBox
        '
        Me.IntIdLaboratorioClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblNombresComercialesBindingSource, "intIdLaboratorio", True))
        Me.IntIdLaboratorioClsComboBox.DataSource = Me.TblLaboratoriosfarmaceuticosBindingSource
        Me.IntIdLaboratorioClsComboBox.DisplayMember = "strDescripcion"
        Me.IntIdLaboratorioClsComboBox.FormattingEnabled = True
        Me.IntIdLaboratorioClsComboBox.Location = New System.Drawing.Point(101, 296)
        Me.IntIdLaboratorioClsComboBox.Name = "IntIdLaboratorioClsComboBox"
        Me.IntIdLaboratorioClsComboBox.Size = New System.Drawing.Size(388, 21)
        Me.IntIdLaboratorioClsComboBox.TabIndex = 18
        Me.IntIdLaboratorioClsComboBox.ValueMember = "intIdLaboratorio"
        '
        'TblLaboratoriosfarmaceuticosBindingSource
        '
        Me.TblLaboratoriosfarmaceuticosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblLaboratoriosfarmaceuticos)
        '
        'DblPrecioPublicoClsTextBox
        '
        Me.DblPrecioPublicoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblNombresComercialesBindingSource, "dblPrecioPublico", True))
        Me.DblPrecioPublicoClsTextBox.DataSource = Nothing
        Me.DblPrecioPublicoClsTextBox.EnterEntreCampos = True
        Me.DblPrecioPublicoClsTextBox.Location = New System.Drawing.Point(101, 323)
        Me.DblPrecioPublicoClsTextBox.Name = "DblPrecioPublicoClsTextBox"
        Me.DblPrecioPublicoClsTextBox.NombreCodigoF2 = Nothing
        Me.DblPrecioPublicoClsTextBox.NombreDescripcionF2 = Nothing
        Me.DblPrecioPublicoClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.DblPrecioPublicoClsTextBox.TabIndex = 20
        Me.DblPrecioPublicoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'DtmFechaClsDateTimePicker
        '
        Me.DtmFechaClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblNombresComercialesBindingSource, "dtmFecha", True))
        Me.DtmFechaClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaClsDateTimePicker.Location = New System.Drawing.Point(383, 326)
        Me.DtmFechaClsDateTimePicker.Name = "DtmFechaClsDateTimePicker"
        Me.DtmFechaClsDateTimePicker.Size = New System.Drawing.Size(106, 20)
        Me.DtmFechaClsDateTimePicker.TabIndex = 22
        '
        'IntIdPrincipioActivoPrincipalClsComboBox
        '
        Me.IntIdPrincipioActivoPrincipalClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblNombresComercialesBindingSource, "intIdPrincipioActivoPrincipal", True))
        Me.IntIdPrincipioActivoPrincipalClsComboBox.DataSource = Me.TblPrincipiosActivosBindingSource
        Me.IntIdPrincipioActivoPrincipalClsComboBox.DisplayMember = "strDescripcion"
        Me.IntIdPrincipioActivoPrincipalClsComboBox.FormattingEnabled = True
        Me.IntIdPrincipioActivoPrincipalClsComboBox.Location = New System.Drawing.Point(75, 19)
        Me.IntIdPrincipioActivoPrincipalClsComboBox.Name = "IntIdPrincipioActivoPrincipalClsComboBox"
        Me.IntIdPrincipioActivoPrincipalClsComboBox.Size = New System.Drawing.Size(393, 21)
        Me.IntIdPrincipioActivoPrincipalClsComboBox.TabIndex = 24
        Me.IntIdPrincipioActivoPrincipalClsComboBox.ValueMember = "intIdPrincipiosActivos"
        '
        'TblPrincipiosActivosBindingSource
        '
        Me.TblPrincipiosActivosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblPrincipiosActivos)
        Me.TblPrincipiosActivosBindingSource.Sort = "strDescripcion"
        '
        'IntIdPrincipioActivoAsociacionClsComboBox
        '
        Me.IntIdPrincipioActivoAsociacionClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblNombresComercialesBindingSource, "intIdPrincipioActivoAsociacion", True))
        Me.IntIdPrincipioActivoAsociacionClsComboBox.DataSource = Me.TblPrincipiosActivosBindingSource1
        Me.IntIdPrincipioActivoAsociacionClsComboBox.DisplayMember = "strDescripcion"
        Me.IntIdPrincipioActivoAsociacionClsComboBox.FormattingEnabled = True
        Me.IntIdPrincipioActivoAsociacionClsComboBox.Location = New System.Drawing.Point(75, 46)
        Me.IntIdPrincipioActivoAsociacionClsComboBox.Name = "IntIdPrincipioActivoAsociacionClsComboBox"
        Me.IntIdPrincipioActivoAsociacionClsComboBox.Size = New System.Drawing.Size(393, 21)
        Me.IntIdPrincipioActivoAsociacionClsComboBox.TabIndex = 26
        Me.IntIdPrincipioActivoAsociacionClsComboBox.ValueMember = "intIdPrincipiosActivos"
        '
        'TblPrincipiosActivosBindingSource1
        '
        Me.TblPrincipiosActivosBindingSource1.DataSource = GetType(ClsBaseDatos_SadLab.tblPrincipiosActivos)
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(343, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(133, 26)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "En cada unidad de" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Presentación farmacéutica"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.IntIdPrincipioActivoPrincipalClsComboBox)
        Me.GroupBox1.Controls.Add(IntIdPrincipioActivoPrincipalLabel)
        Me.GroupBox1.Controls.Add(IntIdPrincipioActivoAsociacionLabel)
        Me.GroupBox1.Controls.Add(Me.IntIdPrincipioActivoAsociacionClsComboBox)
        Me.GroupBox1.Location = New System.Drawing.Point(21, 124)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(481, 82)
        Me.GroupBox1.TabIndex = 28
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Principios Activos"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.IntIdTipoPresentacionComercialClsComboBox)
        Me.GroupBox2.Controls.Add(IntIdTipoPresentacionComercialLabel)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.IntPorClsTextBox)
        Me.GroupBox2.Controls.Add(IntPorLabel)
        Me.GroupBox2.Controls.Add(Me.IntIdPresentacionDrograsClsComboBox)
        Me.GroupBox2.Controls.Add(Me.IntIdMedidasDrogasClsComboBox)
        Me.GroupBox2.Controls.Add(Me.DblConcentracionClsTextBox)
        Me.GroupBox2.Controls.Add(DblConcentracionLabel)
        Me.GroupBox2.Location = New System.Drawing.Point(22, 212)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(480, 78)
        Me.GroupBox2.TabIndex = 29
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Presentación comercial"
        '
        'FrmComerciales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(524, 364)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(DtmFechaLabel)
        Me.Controls.Add(Me.DtmFechaClsDateTimePicker)
        Me.Controls.Add(DblPrecioPublicoLabel)
        Me.Controls.Add(Me.DblPrecioPublicoClsTextBox)
        Me.Controls.Add(IntIdLaboratorioLabel)
        Me.Controls.Add(Me.IntIdLaboratorioClsComboBox)
        Me.Controls.Add(IntIdMedicamentosGenericosLabel)
        Me.Controls.Add(Me.IntIdMedicamentosGenericosClsComboBox)
        Me.Controls.Add(StrDescripcionLabel)
        Me.Controls.Add(Me.StrDescripcionClsTextBox)
        Me.Controls.Add(IntIdNombresComercialesLabel)
        Me.Controls.Add(Me.IntIdNombresComercialesTextBox)
        Me.Controls.Add(Me.TblNombresComercialesBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmComerciales"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Comerciales"
        CType(Me.TblNombresComercialesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblNombresComercialesBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblNombresComercialesBindingNavigator.ResumeLayout(False)
        Me.TblNombresComercialesBindingNavigator.PerformLayout()
        CType(Me.TblMedicamentosGenericosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblLaboratoriosfarmaceuticosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPrincipiosActivosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPrincipiosActivosBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblNombresComercialesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblNombresComercialesBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblNombresComercialesBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IntIdNombresComercialesTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrDescripcionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdMedicamentosGenericosClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdTipoPresentacionComercialClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntPorClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdPresentacionDrograsClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents DblConcentracionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdMedidasDrogasClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdLaboratorioClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents DblPrecioPublicoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DtmFechaClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntIdPrincipioActivoPrincipalClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdPrincipioActivoAsociacionClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TblMedicamentosGenericosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblPrincipiosActivosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblLaboratoriosfarmaceuticosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoBindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents TblPrincipiosActivosBindingSource1 As System.Windows.Forms.BindingSource
End Class
