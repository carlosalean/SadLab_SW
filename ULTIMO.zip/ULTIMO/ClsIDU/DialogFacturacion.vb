﻿Imports System.Windows.Forms
Imports System.Data.Linq

Public Class DialogFacturacion

  Dim mstrStringConection As String
  Public mNroFactura As String
  Public MPaciente As Boolean
  Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
  Public intIdPrestadores As Integer
  Public mEsDuplicado As Boolean
  Public nIdCriterioAnulacion As Integer
  Public sCriterioAnulacion As String
  Dim bValidarIngresoExplicacion As Boolean = False


  Public Sub New(ByVal strStringConection As String)

    ' This call is required by the Windows Form Designer.
    InitializeComponent()

    ' Add any initialization after the InitializeComponent() call.
    Try
      mstrStringConection = strStringConection
      dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub
  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    Try
      If bValidarIngresoExplicacion Then
        If String.IsNullOrWhiteSpace(txtOtroMotivo.Text) Then
          MsgBox("Debe ingresar o seleccionar un motivo de anulación valido.")
          txtOtroMotivo.Focus()
          Exit Sub
        End If
      End If
      Me.DialogResult = System.Windows.Forms.DialogResult.OK
      intIdPrestadores = ClsComboBox1.SelectedValue
      mNroFactura = ClsTextBoxNroFact.Text
      If Not String.IsNullOrWhiteSpace(txtOtroMotivo.Text) Then
        sCriterioAnulacion = txtOtroMotivo.Text
      Else
        sCriterioAnulacion = cbMotivoAbulacion.Text
      End If

      Me.Close()
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub DialogFacturacion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Try
      TblDatosPrestadoresBindingSource.DataSource = dc.tblDatosPrestadores
      'Se establecen las medidad del frm sin el texto de explicación del motivo de anulación
      Me.Width = 519
      Me.Height = 185
      'Se listan los criterios para anular una factura que se encuentran almacenados en la base de datos
      Dim FacturacionBl As ReglasNegocio.Facturacion = New ReglasNegocio.Facturacion()
      cbMotivoAbulacion.DataSource = FacturacionBl.ListarCriteriosAnulacionFacturas()
      cbMotivoAbulacion.DisplayMember = "Descripcion"
      cbMotivoAbulacion.ValueMember = "Codigo"

      cbMotivoAbulacion_SelectedIndexChanged(Nothing, Nothing)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub cbMotivoAbulacion_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbMotivoAbulacion.SelectedIndexChanged
    Try
      'Si se selecciona la opción otro se muestra el recuadro para ingresar la explicación y se ajusta la pantalla para que almacene todos los controles
      'de lo contrario se establecen los valores iniciales de la pantalla y se oculta el cajon de texto donde debe de ir la explicación del motivo de 
      'anulación de la factura
      Dim nHeight As Integer = 185

      If cbMotivoAbulacion.Text.ToLower().Contains("otro") Then
        txtOtroMotivo.Visible = True
        nHeight = 262

        bValidarIngresoExplicacion = True
      Else
        txtOtroMotivo.Text = String.Empty
        txtOtroMotivo.Visible = False

        bValidarIngresoExplicacion = False
      End If

      Me.Height = nHeight
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub
End Class
