﻿Imports System.Windows.Forms

Public Class clsAnulacionesFacturacion
  Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

  Public Sub PrAnularFacturaPaciente(ByVal strStringConection As String, ByVal mstrIntIdUsuario As String)
    Try
      Dim mNroFactura As String = ""
      Dim mintIdPrestador As String = ""

      Dim mValidaHuella As New DialogValidarHuella(strStringConection, mstrIntIdUsuario, False)
      If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then

        Dim mDialogFacturacion As New ClsIDU.DialogFacturacion(strStringConection)
        If mDialogFacturacion.ShowDialog() = Windows.Forms.DialogResult.OK Then
          mNroFactura = mDialogFacturacion.mNroFactura
          mintIdPrestador = mDialogFacturacion.intIdPrestadores
        End If

        If mNroFactura.Length > 0 And IsNumeric(mNroFactura) Then
          Dim mIntNroFactura As Integer = CInt(mNroFactura)
          dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
          Dim mFactura = (From p In dc.tblPagos Where p.intNroFactura = mIntNroFactura And p.intIdPrestadores = mintIdPrestador Select p).Single
          If mFactura Is Nothing Then
            MsgBox("Factura no existe", MsgBoxStyle.Information, "Anular Factura")
          Else
            If MsgBox("Desea asignarle otro consecutivo a la factura..?", MsgBoxStyle.YesNo, "Anular Factura") = MsgBoxResult.Yes Then
              If MsgBox("La factura Nro: " & mNroFactura & " será anulada y se le asignará un nuevo consecutivo al pago correspondiente, está seguro que desea realizar esta transacción..?", MsgBoxStyle.YesNo, "Anular Factura") = MsgBoxResult.Yes Then
                Try
                  dc.usp_AnularFacturaPaciente(mIntNroFactura, mintIdPrestador, False, mValidaHuella.mstrIntIdUsuario)

                  If Application.OpenForms("FrmFacturaMediaCarta") Is Nothing Then
                    Dim mtmpFrmFacturaMediaCarta As New ClsReportes.FrmFacturaMediaCarta(strStringConection, mFactura.intIdCita, True)
                    mtmpFrmFacturaMediaCarta.Show()
                  Else
                    Application.OpenForms("FrmFacturaMediaCarta").BringToFront()
                  End If

                  Dim mFrmFacturaMediaCarta As New ClsReportes.FrmFacturaMediaCarta(strStringConection, mFactura.intIdCita)
                  mFrmFacturaMediaCarta.Show()

                Catch ex As Exception
                  'no hace nada
                End Try
              End If
            Else
              If MsgBox("La factura Nro: " & mNroFactura & " será anulada y el pago correspondiente a dicha factura no se tendrá en cuenta para efectos de cuadres de caja, está seguro que desea realizar esta transacción..?", MsgBoxStyle.YesNo, "Anular Factura") = MsgBoxResult.Yes Then
                dc.usp_AnularFacturaPaciente(mIntNroFactura, mintIdPrestador, True, mValidaHuella.mstrIntIdUsuario)

                If Application.OpenForms("FrmFacturaMediaCarta") Is Nothing Then
                  Dim mFrmFacturaMediaCarta As New ClsReportes.FrmFacturaMediaCarta(strStringConection, mFactura.intIdCita, True)
                  mFrmFacturaMediaCarta.Show()
                Else
                  Application.OpenForms("FrmFacturaMediaCarta").BringToFront()
                End If
                MsgBox("La Factura fué anulada con exito..", MsgBoxStyle.Information, "Anular Factura")
              End If
            End If

          End If
        Else
          MsgBox("Factura no existe", MsgBoxStyle.Information, "Anular Factura")
        End If
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Public Sub PrAnularFacturaEPS(ByVal strStringConection As String, ByVal mstrIntIdUsuario As String)
    Try

      Dim mValidaHuella As New DialogValidarHuella(strStringConection, mstrIntIdUsuario, False)
      If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then

        Dim mNroFactura As String = String.Empty
        Dim mintIdPrestador As String = String.Empty
        Dim sCriterioAnulacion As String = String.Empty

        Dim mDialogFacturacion As New ClsIDU.DialogFacturacion(strStringConection)
        If mDialogFacturacion.ShowDialog() = Windows.Forms.DialogResult.OK Then
          mNroFactura = mDialogFacturacion.mNroFactura
          mintIdPrestador = mDialogFacturacion.intIdPrestadores
          sCriterioAnulacion = mDialogFacturacion.sCriterioAnulacion
        End If

        If mNroFactura.Length > 0 And IsNumeric(mNroFactura) Then
          Dim mIntNroFactura As Integer = CInt(mNroFactura)
          dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
          Dim mFacturas = (From p In dc.tblFacturacions Where p.strNroFactura = mIntNroFactura.ToString() And p.intIdPrestador = mintIdPrestador And p.bitImpresa = True Select p)
          Dim tmpFactura = Nothing
          For Each mFactura In mFacturas
            tmpFactura = mFactura
          Next mFactura

          'Variable para instaciar la clase de auditorias
          Dim AuditoriasBl As New ReglasNegocio.Auditorias()
          Dim oAuditorias As ClsUtilidades.Utilidades.Objetos.Auditorias

          If tmpFactura Is Nothing Then
            MsgBox("Factura no existe o no está cerrada, sólo se pueden anular facturas cerradas..", MsgBoxStyle.Information, "Anular Factura")
          Else
            If MsgBox("Desea asignarle otro consecutivo a la factura..?", MsgBoxStyle.YesNo, "Anular Factura") = MsgBoxResult.Yes Then
              If MsgBox("La factura Nro: " & mNroFactura & " será anulada y se le asignará un nuevo consecutivo a las citas correspondientes, está seguro que desea realizar esta transacción..?", MsgBoxStyle.YesNo, "Anular Factura") = MsgBoxResult.Yes Then
                Try
                  Dim mIntConsecutivo As Integer
                  Dim intProfesional As Integer = mDialogFacturacion.intIdPrestadores

                  Dim mConsecutivo = dc.usp_AsignarConsecutivoFacturacionPrestadores(intProfesional)
                  mIntConsecutivo = mConsecutivo

                  If mIntConsecutivo = 0 Then
                    MsgBox("El prestador del servicio no tiene configurado el consecutivo electronico de factyuración", MsgBoxStyle.Information, "Adicionar Consecutivo de Facturación")
                  Else
                    dc.usp_AnularFacturaEPS(mIntNroFactura.ToString, mintIdPrestador, True, mValidaHuella.mstrIntIdUsuario, mIntConsecutivo.ToString)
                    MsgBox("El consecutivo asignado es: " & mIntConsecutivo.ToString, MsgBoxStyle.Information, "Adicionar Consecutivo de Facturación")

                    Dim mFrmFacturacion As New ClsReportes.FrmFacturaCarta(strStringConection, mDialogFacturacion.mNroFactura, mDialogFacturacion.MPaciente, mDialogFacturacion.intIdPrestadores, False, mValidaHuella.mstrIntIdUsuario)
                    mFrmFacturacion.Show()

                    MsgBox("La Factura fué anulada con exito..", MsgBoxStyle.Information, "Anular Factura")
                  End If

                  'Se crea el registro de auditoria para el proceso de anulación de facturas con generación de un nuevo consecutivo
                  oAuditorias = New ClsUtilidades.Utilidades.Objetos.Auditorias()
                  oAuditorias.Log = String.Format("Se anula la factura {0}, por el motivo {3} y se genera nuevo consecutivo para el prestador {1}, el consecutivo generado es el {2}" _
                                                  , mNroFactura, intProfesional.ToString(), mIntConsecutivo.ToString(), sCriterioAnulacion)
                  oAuditorias.FechaRegistro = DateTime.Now
                  oAuditorias.NombreMaquina = Environment.MachineName
                  oAuditorias.UsuarioEjecuta = Convert.ToInt32(mstrIntIdUsuario)
                  oAuditorias.CodigoProceso = Convert.ToInt32(ReglasNegocio.Enumeraciones.Enumeraciones.Procesos.AsignacionConsecutivoFactuacionDespuesAanularFactura)

                  AuditoriasBl.CrearAuditoria(oAuditorias)

                Catch ex As Exception
                  'no hace nada
                End Try
              End If
            Else
              If MsgBox("La factura Nro: " & mNroFactura & " será anulada y la(s) cita(s) correspondiente(s) a esta factura podrán ser modificadas o asignadas a otra factura, está seguro que desea realizar esta transacción..?", MsgBoxStyle.YesNo, "Anular Factura") = MsgBoxResult.Yes Then

                dc.usp_AnularFacturaEPS(mIntNroFactura.ToString, mintIdPrestador, True, mValidaHuella.mstrIntIdUsuario, Nothing)

                Dim mFrmFacturacion As New ClsReportes.FrmFacturaCarta(strStringConection, mDialogFacturacion.mNroFactura, mDialogFacturacion.MPaciente, mDialogFacturacion.intIdPrestadores, False, mValidaHuella.mstrIntIdUsuario)
                mFrmFacturacion.Show()
                Try
                  oAuditorias = New ClsUtilidades.Utilidades.Objetos.Auditorias()
                  oAuditorias.Log = String.Format("Se anula la factura {0} por el motivo {2} del prestador {1}" _
                                                  , mNroFactura, mDialogFacturacion.intIdPrestadores.ToString(), sCriterioAnulacion)
                  oAuditorias.FechaRegistro = DateTime.Now
                  oAuditorias.NombreMaquina = Environment.MachineName
                  oAuditorias.UsuarioEjecuta = Convert.ToInt32(mstrIntIdUsuario)
                  oAuditorias.CodigoProceso = Convert.ToInt32(ReglasNegocio.Enumeraciones.Enumeraciones.Procesos.AnulacionFacturas)

                  AuditoriasBl.CrearAuditoria(oAuditorias)
                Catch ex As Exception
                  'TODO: CREAR REGISTRO EN EL LOG DE ERRORES
                End Try

                MsgBox("La Factura fué anulada con exito..", MsgBoxStyle.Information, "Anular Factura")
              End If
            End If
          End If

        End If
      Else
        MsgBox("Factura no existe", MsgBoxStyle.Information, "Anular Factura")
      End If
    Catch ex As Exception
      MsgBox("Factura no existe o no está cerrada, sólo se pueden anular facturas cerradas..", MsgBoxStyle.Information, "Anular Factura")
    End Try
  End Sub
End Class
