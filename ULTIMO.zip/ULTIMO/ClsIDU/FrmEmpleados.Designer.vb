﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmEmpleados
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IntIdCodigoEmpleadoLabel As System.Windows.Forms.Label
        Dim StrEspecializacionLabel As System.Windows.Forms.Label
        Dim StrNombreEmpleadoLabel As System.Windows.Forms.Label
        Dim StrNroIdentificacionLabel As System.Windows.Forms.Label
        Dim BitActivoLabel As System.Windows.Forms.Label
        Dim StrRegistroMedicoLabel As System.Windows.Forms.Label
        Dim FirmaLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmEmpleados))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TblEmpeadoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblEmpeadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.btnCargarImagen = New System.Windows.Forms.Button()
        Me.FirmaPictureBox = New System.Windows.Forms.PictureBox()
        Me.StrRegistroMedicoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TblProfesionalesProcedminentosDataGridView = New System.Windows.Forms.DataGridView()
        Me.intIdProcedimiento = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.TblProcedimientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNroIdentificacionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrEspecializacionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BitActivoDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TblEmpleadosTurnosDataGridView = New System.Windows.Forms.DataGridView()
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNroIdentificacionDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrEspecializacionDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BitActivoDataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TblProfesionalesItemsDataGridView = New System.Windows.Forms.DataGridView()
        Me.intIdItemRevision = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.TblItemRevisionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.bitSoloTexto = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TblEmpleadosPrestadoresDataGridView = New System.Windows.Forms.DataGridView()
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNroIdentificacionDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrEspecializacionDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrRegistroMedicoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BitActivoDataGridViewCheckBoxColumn2 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrAliasDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirmaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BitActivoClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.IntIdCodigoEmpleadoTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrEspecializacionTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrNombreEmpleadoTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrNroIdentificacionTextBox = New ClsUtilidades.ClsTextBox()
        Me.TblDatosPrestadoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblEmpeadoBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblEmpeadoBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TblTurnoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        IntIdCodigoEmpleadoLabel = New System.Windows.Forms.Label()
        StrEspecializacionLabel = New System.Windows.Forms.Label()
        StrNombreEmpleadoLabel = New System.Windows.Forms.Label()
        StrNroIdentificacionLabel = New System.Windows.Forms.Label()
        BitActivoLabel = New System.Windows.Forms.Label()
        StrRegistroMedicoLabel = New System.Windows.Forms.Label()
        FirmaLabel = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblEmpeadoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.FirmaPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.TblProfesionalesProcedminentosDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        CType(Me.TblEmpleadosTurnosDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.TblProfesionalesItemsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblItemRevisionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        CType(Me.TblEmpleadosPrestadoresDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblEmpeadoBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblEmpeadoBindingNavigator.SuspendLayout()
        CType(Me.TblTurnoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IntIdCodigoEmpleadoLabel
        '
        IntIdCodigoEmpleadoLabel.AutoSize = True
        IntIdCodigoEmpleadoLabel.Location = New System.Drawing.Point(17, 24)
        IntIdCodigoEmpleadoLabel.Name = "IntIdCodigoEmpleadoLabel"
        IntIdCodigoEmpleadoLabel.Size = New System.Drawing.Size(19, 13)
        IntIdCodigoEmpleadoLabel.TabIndex = 0
        IntIdCodigoEmpleadoLabel.Text = "Id:"
        '
        'StrEspecializacionLabel
        '
        StrEspecializacionLabel.AutoSize = True
        StrEspecializacionLabel.Location = New System.Drawing.Point(17, 102)
        StrEspecializacionLabel.Name = "StrEspecializacionLabel"
        StrEspecializacionLabel.Size = New System.Drawing.Size(83, 13)
        StrEspecializacionLabel.TabIndex = 2
        StrEspecializacionLabel.Text = "Especialización:"
        '
        'StrNombreEmpleadoLabel
        '
        StrNombreEmpleadoLabel.AutoSize = True
        StrNombreEmpleadoLabel.Location = New System.Drawing.Point(17, 76)
        StrNombreEmpleadoLabel.Name = "StrNombreEmpleadoLabel"
        StrNombreEmpleadoLabel.Size = New System.Drawing.Size(97, 13)
        StrNombreEmpleadoLabel.TabIndex = 4
        StrNombreEmpleadoLabel.Text = "Nombre Empleado:"
        '
        'StrNroIdentificacionLabel
        '
        StrNroIdentificacionLabel.AutoSize = True
        StrNroIdentificacionLabel.Location = New System.Drawing.Point(17, 50)
        StrNroIdentificacionLabel.Name = "StrNroIdentificacionLabel"
        StrNroIdentificacionLabel.Size = New System.Drawing.Size(93, 13)
        StrNroIdentificacionLabel.TabIndex = 6
        StrNroIdentificacionLabel.Text = "Nro Identificacion:"
        '
        'BitActivoLabel
        '
        BitActivoLabel.AutoSize = True
        BitActivoLabel.Location = New System.Drawing.Point(17, 161)
        BitActivoLabel.Name = "BitActivoLabel"
        BitActivoLabel.Size = New System.Drawing.Size(40, 13)
        BitActivoLabel.TabIndex = 9
        BitActivoLabel.Text = "Activo:"
        '
        'StrRegistroMedicoLabel
        '
        StrRegistroMedicoLabel.AutoSize = True
        StrRegistroMedicoLabel.Location = New System.Drawing.Point(17, 132)
        StrRegistroMedicoLabel.Name = "StrRegistroMedicoLabel"
        StrRegistroMedicoLabel.Size = New System.Drawing.Size(87, 13)
        StrRegistroMedicoLabel.TabIndex = 12
        StrRegistroMedicoLabel.Text = "Registro Medico:"
        '
        'FirmaLabel
        '
        FirmaLabel.AutoSize = True
        FirmaLabel.Location = New System.Drawing.Point(369, 132)
        FirmaLabel.Name = "FirmaLabel"
        FirmaLabel.Size = New System.Drawing.Size(35, 13)
        FirmaLabel.TabIndex = 13
        FirmaLabel.Text = "Firma:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(671, 485)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TblEmpeadoDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(663, 459)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblEmpeadoDataGridView
        '
        Me.TblEmpeadoDataGridView.AllowUserToAddRows = False
        Me.TblEmpeadoDataGridView.AllowUserToDeleteRows = False
        Me.TblEmpeadoDataGridView.AllowUserToOrderColumns = True
        Me.TblEmpeadoDataGridView.AutoGenerateColumns = False
        Me.TblEmpeadoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblEmpeadoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.TblEmpeadoDataGridView.DataSource = Me.TblEmpeadoBindingSource
        Me.TblEmpeadoDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblEmpeadoDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblEmpeadoDataGridView.Name = "TblEmpeadoDataGridView"
        Me.TblEmpeadoDataGridView.ReadOnly = True
        Me.TblEmpeadoDataGridView.Size = New System.Drawing.Size(657, 453)
        Me.TblEmpeadoDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdCodigoEmpleado"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strNroIdentificacion"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nro Identificacion"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 120
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "strNombreEmpleado"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 350
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "strEspecializacion"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Especializacion"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 250
        '
        'TblEmpeadoBindingSource
        '
        Me.TblEmpeadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEmpeados)
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.Controls.Add(Me.btnCargarImagen)
        Me.TabPage2.Controls.Add(FirmaLabel)
        Me.TabPage2.Controls.Add(Me.FirmaPictureBox)
        Me.TabPage2.Controls.Add(StrRegistroMedicoLabel)
        Me.TabPage2.Controls.Add(Me.StrRegistroMedicoClsTextBox)
        Me.TabPage2.Controls.Add(BitActivoLabel)
        Me.TabPage2.Controls.Add(Me.TabControl2)
        Me.TabPage2.Controls.Add(IntIdCodigoEmpleadoLabel)
        Me.TabPage2.Controls.Add(StrEspecializacionLabel)
        Me.TabPage2.Controls.Add(StrNombreEmpleadoLabel)
        Me.TabPage2.Controls.Add(StrNroIdentificacionLabel)
        Me.TabPage2.Controls.Add(Me.BitActivoClsCheckBox)
        Me.TabPage2.Controls.Add(Me.IntIdCodigoEmpleadoTextBox)
        Me.TabPage2.Controls.Add(Me.StrEspecializacionTextBox)
        Me.TabPage2.Controls.Add(Me.StrNombreEmpleadoTextBox)
        Me.TabPage2.Controls.Add(Me.StrNroIdentificacionTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(663, 459)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'btnCargarImagen
        '
        Me.btnCargarImagen.Location = New System.Drawing.Point(470, 103)
        Me.btnCargarImagen.Name = "btnCargarImagen"
        Me.btnCargarImagen.Size = New System.Drawing.Size(117, 23)
        Me.btnCargarImagen.TabIndex = 15
        Me.btnCargarImagen.Text = "Cargar Imagen.."
        Me.btnCargarImagen.UseVisualStyleBackColor = True
        '
        'FirmaPictureBox
        '
        Me.FirmaPictureBox.DataBindings.Add(New System.Windows.Forms.Binding("Image", Me.TblEmpeadoBindingSource, "Firma", True))
        Me.FirmaPictureBox.Location = New System.Drawing.Point(410, 132)
        Me.FirmaPictureBox.Name = "FirmaPictureBox"
        Me.FirmaPictureBox.Size = New System.Drawing.Size(177, 89)
        Me.FirmaPictureBox.TabIndex = 14
        Me.FirmaPictureBox.TabStop = False
        '
        'StrRegistroMedicoClsTextBox
        '
        Me.StrRegistroMedicoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblEmpeadoBindingSource, "strRegistroMedico", True))
        Me.StrRegistroMedicoClsTextBox.DataSource = Nothing
        Me.StrRegistroMedicoClsTextBox.EnterEntreCampos = True
        Me.StrRegistroMedicoClsTextBox.Location = New System.Drawing.Point(142, 125)
        Me.StrRegistroMedicoClsTextBox.Name = "StrRegistroMedicoClsTextBox"
        Me.StrRegistroMedicoClsTextBox.NombreCodigoF2 = Nothing
        Me.StrRegistroMedicoClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrRegistroMedicoClsTextBox.Size = New System.Drawing.Size(221, 20)
        Me.StrRegistroMedicoClsTextBox.TabIndex = 13
        Me.StrRegistroMedicoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage3)
        Me.TabControl2.Controls.Add(Me.TabPage4)
        Me.TabControl2.Controls.Add(Me.TabPage5)
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Location = New System.Drawing.Point(64, 227)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(527, 224)
        Me.TabControl2.TabIndex = 7
        '
        'TabPage3
        '
        Me.TabPage3.AutoScroll = True
        Me.TabPage3.Controls.Add(Me.TblProfesionalesProcedminentosDataGridView)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(519, 198)
        Me.TabPage3.TabIndex = 0
        Me.TabPage3.Text = "Procedimientos"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TblProfesionalesProcedminentosDataGridView
        '
        Me.TblProfesionalesProcedminentosDataGridView.AutoGenerateColumns = False
        Me.TblProfesionalesProcedminentosDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblProfesionalesProcedminentosDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.intIdProcedimiento, Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn1, Me.StrNroIdentificacionDataGridViewTextBoxColumn, Me.StrNombreEmpleadoDataGridViewTextBoxColumn, Me.StrEspecializacionDataGridViewTextBoxColumn, Me.BitActivoDataGridViewCheckBoxColumn, Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn})
        Me.TblProfesionalesProcedminentosDataGridView.DataSource = Me.TblEmpeadoBindingSource
        Me.TblProfesionalesProcedminentosDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblProfesionalesProcedminentosDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblProfesionalesProcedminentosDataGridView.Name = "TblProfesionalesProcedminentosDataGridView"
        Me.TblProfesionalesProcedminentosDataGridView.Size = New System.Drawing.Size(513, 192)
        Me.TblProfesionalesProcedminentosDataGridView.TabIndex = 0
        '
        'intIdProcedimiento
        '
        Me.intIdProcedimiento.DataPropertyName = "intIdProcedimiento"
        Me.intIdProcedimiento.DataSource = Me.TblProcedimientoBindingSource
        Me.intIdProcedimiento.DisplayMember = "strDescripcion"
        Me.intIdProcedimiento.HeaderText = "Procedimiento"
        Me.intIdProcedimiento.Name = "intIdProcedimiento"
        Me.intIdProcedimiento.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.intIdProcedimiento.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.intIdProcedimiento.ValueMember = "intIdProcedimientos"
        Me.intIdProcedimiento.Width = 350
        '
        'TblProcedimientoBindingSource
        '
        Me.TblProcedimientoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        '
        'IntIdCodigoEmpleadoDataGridViewTextBoxColumn1
        '
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn1.DataPropertyName = "intIdCodigoEmpleado"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn1.HeaderText = "intIdCodigoEmpleado"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn1.Name = "IntIdCodigoEmpleadoDataGridViewTextBoxColumn1"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn1.Visible = False
        '
        'StrNroIdentificacionDataGridViewTextBoxColumn
        '
        Me.StrNroIdentificacionDataGridViewTextBoxColumn.DataPropertyName = "strNroIdentificacion"
        Me.StrNroIdentificacionDataGridViewTextBoxColumn.HeaderText = "strNroIdentificacion"
        Me.StrNroIdentificacionDataGridViewTextBoxColumn.Name = "StrNroIdentificacionDataGridViewTextBoxColumn"
        Me.StrNroIdentificacionDataGridViewTextBoxColumn.Visible = False
        '
        'StrNombreEmpleadoDataGridViewTextBoxColumn
        '
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn.DataPropertyName = "strNombreEmpleado"
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn.HeaderText = "strNombreEmpleado"
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn.Name = "StrNombreEmpleadoDataGridViewTextBoxColumn"
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn.Visible = False
        '
        'StrEspecializacionDataGridViewTextBoxColumn
        '
        Me.StrEspecializacionDataGridViewTextBoxColumn.DataPropertyName = "strEspecializacion"
        Me.StrEspecializacionDataGridViewTextBoxColumn.HeaderText = "strEspecializacion"
        Me.StrEspecializacionDataGridViewTextBoxColumn.Name = "StrEspecializacionDataGridViewTextBoxColumn"
        Me.StrEspecializacionDataGridViewTextBoxColumn.Visible = False
        '
        'BitActivoDataGridViewCheckBoxColumn
        '
        Me.BitActivoDataGridViewCheckBoxColumn.DataPropertyName = "bitActivo"
        Me.BitActivoDataGridViewCheckBoxColumn.HeaderText = "bitActivo"
        Me.BitActivoDataGridViewCheckBoxColumn.Name = "BitActivoDataGridViewCheckBoxColumn"
        Me.BitActivoDataGridViewCheckBoxColumn.Visible = False
        '
        'IntIdCodigoPrestadorDataGridViewTextBoxColumn
        '
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn.DataPropertyName = "intIdCodigoPrestador"
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn.HeaderText = "intIdCodigoPrestador"
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn.Name = "IntIdCodigoPrestadorDataGridViewTextBoxColumn"
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn.Visible = False
        '
        'TabPage4
        '
        Me.TabPage4.AutoScroll = True
        Me.TabPage4.Controls.Add(Me.TblEmpleadosTurnosDataGridView)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(519, 198)
        Me.TabPage4.TabIndex = 1
        Me.TabPage4.Text = "Turnos"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'TblEmpleadosTurnosDataGridView
        '
        Me.TblEmpleadosTurnosDataGridView.AutoGenerateColumns = False
        Me.TblEmpleadosTurnosDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblEmpleadosTurnosDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn2, Me.StrNroIdentificacionDataGridViewTextBoxColumn1, Me.StrNombreEmpleadoDataGridViewTextBoxColumn1, Me.StrEspecializacionDataGridViewTextBoxColumn1, Me.BitActivoDataGridViewCheckBoxColumn1, Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn1})
        Me.TblEmpleadosTurnosDataGridView.DataSource = Me.TblEmpeadoBindingSource
        Me.TblEmpleadosTurnosDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblEmpleadosTurnosDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblEmpleadosTurnosDataGridView.Name = "TblEmpleadosTurnosDataGridView"
        Me.TblEmpleadosTurnosDataGridView.Size = New System.Drawing.Size(513, 192)
        Me.TblEmpleadosTurnosDataGridView.TabIndex = 0
        '
        'IntIdCodigoEmpleadoDataGridViewTextBoxColumn2
        '
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn2.DataPropertyName = "intIdCodigoEmpleado"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn2.HeaderText = "intIdCodigoEmpleado"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn2.Name = "IntIdCodigoEmpleadoDataGridViewTextBoxColumn2"
        '
        'StrNroIdentificacionDataGridViewTextBoxColumn1
        '
        Me.StrNroIdentificacionDataGridViewTextBoxColumn1.DataPropertyName = "strNroIdentificacion"
        Me.StrNroIdentificacionDataGridViewTextBoxColumn1.HeaderText = "strNroIdentificacion"
        Me.StrNroIdentificacionDataGridViewTextBoxColumn1.Name = "StrNroIdentificacionDataGridViewTextBoxColumn1"
        '
        'StrNombreEmpleadoDataGridViewTextBoxColumn1
        '
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn1.DataPropertyName = "strNombreEmpleado"
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn1.HeaderText = "strNombreEmpleado"
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn1.Name = "StrNombreEmpleadoDataGridViewTextBoxColumn1"
        '
        'StrEspecializacionDataGridViewTextBoxColumn1
        '
        Me.StrEspecializacionDataGridViewTextBoxColumn1.DataPropertyName = "strEspecializacion"
        Me.StrEspecializacionDataGridViewTextBoxColumn1.HeaderText = "strEspecializacion"
        Me.StrEspecializacionDataGridViewTextBoxColumn1.Name = "StrEspecializacionDataGridViewTextBoxColumn1"
        '
        'BitActivoDataGridViewCheckBoxColumn1
        '
        Me.BitActivoDataGridViewCheckBoxColumn1.DataPropertyName = "bitActivo"
        Me.BitActivoDataGridViewCheckBoxColumn1.HeaderText = "bitActivo"
        Me.BitActivoDataGridViewCheckBoxColumn1.Name = "BitActivoDataGridViewCheckBoxColumn1"
        '
        'IntIdCodigoPrestadorDataGridViewTextBoxColumn1
        '
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn1.DataPropertyName = "intIdCodigoPrestador"
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn1.HeaderText = "intIdCodigoPrestador"
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn1.Name = "IntIdCodigoPrestadorDataGridViewTextBoxColumn1"
        '
        'TabPage5
        '
        Me.TabPage5.AutoScroll = True
        Me.TabPage5.Controls.Add(Me.TblProfesionalesItemsDataGridView)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(519, 198)
        Me.TabPage5.TabIndex = 2
        Me.TabPage5.Text = "Item de Revisión en Historia Clínica"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'TblProfesionalesItemsDataGridView
        '
        Me.TblProfesionalesItemsDataGridView.AutoGenerateColumns = False
        Me.TblProfesionalesItemsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblProfesionalesItemsDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.intIdItemRevision, Me.bitSoloTexto, Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn})
        Me.TblProfesionalesItemsDataGridView.DataMember = "tblProfesionalesItems"
        Me.TblProfesionalesItemsDataGridView.DataSource = Me.TblEmpeadoBindingSource
        Me.TblProfesionalesItemsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblProfesionalesItemsDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.TblProfesionalesItemsDataGridView.Name = "TblProfesionalesItemsDataGridView"
        Me.TblProfesionalesItemsDataGridView.Size = New System.Drawing.Size(519, 198)
        Me.TblProfesionalesItemsDataGridView.TabIndex = 0
        '
        'intIdItemRevision
        '
        Me.intIdItemRevision.DataPropertyName = "intIdItemRevision"
        Me.intIdItemRevision.DataSource = Me.TblItemRevisionBindingSource
        Me.intIdItemRevision.DisplayMember = "strNombreItem"
        Me.intIdItemRevision.HeaderText = "Item Revisión"
        Me.intIdItemRevision.Name = "intIdItemRevision"
        Me.intIdItemRevision.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.intIdItemRevision.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.intIdItemRevision.ValueMember = "intIdItemRevision"
        Me.intIdItemRevision.Width = 350
        '
        'TblItemRevisionBindingSource
        '
        Me.TblItemRevisionBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblItemRevision)
        '
        'bitSoloTexto
        '
        Me.bitSoloTexto.DataPropertyName = "bitSoloTexto"
        Me.bitSoloTexto.HeaderText = "       Solo Texto"
        Me.bitSoloTexto.Name = "bitSoloTexto"
        '
        'IntIdCodigoEmpleadoDataGridViewTextBoxColumn
        '
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn.DataPropertyName = "intIdCodigoEmpleado"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn.HeaderText = "intIdCodigoEmpleado"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn.Name = "IntIdCodigoEmpleadoDataGridViewTextBoxColumn"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn.Visible = False
        '
        'TabPage6
        '
        Me.TabPage6.AutoScroll = True
        Me.TabPage6.Controls.Add(Me.TblEmpleadosPrestadoresDataGridView)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(519, 198)
        Me.TabPage6.TabIndex = 3
        Me.TabPage6.Text = "Prestadores"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'TblEmpleadosPrestadoresDataGridView
        '
        Me.TblEmpleadosPrestadoresDataGridView.AutoGenerateColumns = False
        Me.TblEmpleadosPrestadoresDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblEmpleadosPrestadoresDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn3, Me.StrNroIdentificacionDataGridViewTextBoxColumn2, Me.StrNombreEmpleadoDataGridViewTextBoxColumn2, Me.StrEspecializacionDataGridViewTextBoxColumn2, Me.StrRegistroMedicoDataGridViewTextBoxColumn, Me.BitActivoDataGridViewCheckBoxColumn2, Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn2, Me.StrAliasDataGridViewTextBoxColumn, Me.FirmaDataGridViewTextBoxColumn})
        Me.TblEmpleadosPrestadoresDataGridView.DataSource = Me.TblEmpeadoBindingSource
        Me.TblEmpleadosPrestadoresDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblEmpleadosPrestadoresDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.TblEmpleadosPrestadoresDataGridView.Name = "TblEmpleadosPrestadoresDataGridView"
        Me.TblEmpleadosPrestadoresDataGridView.Size = New System.Drawing.Size(519, 198)
        Me.TblEmpleadosPrestadoresDataGridView.TabIndex = 0
        '
        'IntIdCodigoEmpleadoDataGridViewTextBoxColumn3
        '
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn3.DataPropertyName = "intIdCodigoEmpleado"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn3.HeaderText = "intIdCodigoEmpleado"
        Me.IntIdCodigoEmpleadoDataGridViewTextBoxColumn3.Name = "IntIdCodigoEmpleadoDataGridViewTextBoxColumn3"
        '
        'StrNroIdentificacionDataGridViewTextBoxColumn2
        '
        Me.StrNroIdentificacionDataGridViewTextBoxColumn2.DataPropertyName = "strNroIdentificacion"
        Me.StrNroIdentificacionDataGridViewTextBoxColumn2.HeaderText = "strNroIdentificacion"
        Me.StrNroIdentificacionDataGridViewTextBoxColumn2.Name = "StrNroIdentificacionDataGridViewTextBoxColumn2"
        '
        'StrNombreEmpleadoDataGridViewTextBoxColumn2
        '
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn2.DataPropertyName = "strNombreEmpleado"
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn2.HeaderText = "strNombreEmpleado"
        Me.StrNombreEmpleadoDataGridViewTextBoxColumn2.Name = "StrNombreEmpleadoDataGridViewTextBoxColumn2"
        '
        'StrEspecializacionDataGridViewTextBoxColumn2
        '
        Me.StrEspecializacionDataGridViewTextBoxColumn2.DataPropertyName = "strEspecializacion"
        Me.StrEspecializacionDataGridViewTextBoxColumn2.HeaderText = "strEspecializacion"
        Me.StrEspecializacionDataGridViewTextBoxColumn2.Name = "StrEspecializacionDataGridViewTextBoxColumn2"
        '
        'StrRegistroMedicoDataGridViewTextBoxColumn
        '
        Me.StrRegistroMedicoDataGridViewTextBoxColumn.DataPropertyName = "strRegistroMedico"
        Me.StrRegistroMedicoDataGridViewTextBoxColumn.HeaderText = "strRegistroMedico"
        Me.StrRegistroMedicoDataGridViewTextBoxColumn.Name = "StrRegistroMedicoDataGridViewTextBoxColumn"
        '
        'BitActivoDataGridViewCheckBoxColumn2
        '
        Me.BitActivoDataGridViewCheckBoxColumn2.DataPropertyName = "bitActivo"
        Me.BitActivoDataGridViewCheckBoxColumn2.HeaderText = "bitActivo"
        Me.BitActivoDataGridViewCheckBoxColumn2.Name = "BitActivoDataGridViewCheckBoxColumn2"
        '
        'IntIdCodigoPrestadorDataGridViewTextBoxColumn2
        '
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn2.DataPropertyName = "intIdCodigoPrestador"
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn2.HeaderText = "intIdCodigoPrestador"
        Me.IntIdCodigoPrestadorDataGridViewTextBoxColumn2.Name = "IntIdCodigoPrestadorDataGridViewTextBoxColumn2"
        '
        'StrAliasDataGridViewTextBoxColumn
        '
        Me.StrAliasDataGridViewTextBoxColumn.DataPropertyName = "strAlias"
        Me.StrAliasDataGridViewTextBoxColumn.HeaderText = "strAlias"
        Me.StrAliasDataGridViewTextBoxColumn.Name = "StrAliasDataGridViewTextBoxColumn"
        '
        'FirmaDataGridViewTextBoxColumn
        '
        Me.FirmaDataGridViewTextBoxColumn.DataPropertyName = "Firma"
        Me.FirmaDataGridViewTextBoxColumn.HeaderText = "Firma"
        Me.FirmaDataGridViewTextBoxColumn.Name = "FirmaDataGridViewTextBoxColumn"
        '
        'BitActivoClsCheckBox
        '
        Me.BitActivoClsCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.BitActivoClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblEmpeadoBindingSource, "bitActivo", True))
        Me.BitActivoClsCheckBox.Location = New System.Drawing.Point(142, 156)
        Me.BitActivoClsCheckBox.Name = "BitActivoClsCheckBox"
        Me.BitActivoClsCheckBox.Size = New System.Drawing.Size(22, 24)
        Me.BitActivoClsCheckBox.TabIndex = 4
        Me.BitActivoClsCheckBox.UseVisualStyleBackColor = True
        '
        'IntIdCodigoEmpleadoTextBox
        '
        Me.IntIdCodigoEmpleadoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblEmpeadoBindingSource, "intIdCodigoEmpleado", True))
        Me.IntIdCodigoEmpleadoTextBox.DataSource = Nothing
        Me.IntIdCodigoEmpleadoTextBox.Enabled = False
        Me.IntIdCodigoEmpleadoTextBox.EnterEntreCampos = True
        Me.IntIdCodigoEmpleadoTextBox.Location = New System.Drawing.Point(142, 21)
        Me.IntIdCodigoEmpleadoTextBox.Name = "IntIdCodigoEmpleadoTextBox"
        Me.IntIdCodigoEmpleadoTextBox.NombreCodigoF2 = Nothing
        Me.IntIdCodigoEmpleadoTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdCodigoEmpleadoTextBox.Size = New System.Drawing.Size(36, 20)
        Me.IntIdCodigoEmpleadoTextBox.TabIndex = 0
        Me.IntIdCodigoEmpleadoTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrEspecializacionTextBox
        '
        Me.StrEspecializacionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblEmpeadoBindingSource, "strEspecializacion", True))
        Me.StrEspecializacionTextBox.DataSource = Nothing
        Me.StrEspecializacionTextBox.EnterEntreCampos = True
        Me.StrEspecializacionTextBox.Location = New System.Drawing.Point(142, 99)
        Me.StrEspecializacionTextBox.Name = "StrEspecializacionTextBox"
        Me.StrEspecializacionTextBox.NombreCodigoF2 = Nothing
        Me.StrEspecializacionTextBox.NombreDescripcionF2 = Nothing
        Me.StrEspecializacionTextBox.Size = New System.Drawing.Size(262, 20)
        Me.StrEspecializacionTextBox.TabIndex = 3
        Me.StrEspecializacionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrNombreEmpleadoTextBox
        '
        Me.StrNombreEmpleadoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblEmpeadoBindingSource, "strNombreEmpleado", True))
        Me.StrNombreEmpleadoTextBox.DataSource = Nothing
        Me.StrNombreEmpleadoTextBox.EnterEntreCampos = True
        Me.StrNombreEmpleadoTextBox.Location = New System.Drawing.Point(142, 73)
        Me.StrNombreEmpleadoTextBox.Name = "StrNombreEmpleadoTextBox"
        Me.StrNombreEmpleadoTextBox.NombreCodigoF2 = Nothing
        Me.StrNombreEmpleadoTextBox.NombreDescripcionF2 = Nothing
        Me.StrNombreEmpleadoTextBox.Size = New System.Drawing.Size(445, 20)
        Me.StrNombreEmpleadoTextBox.TabIndex = 2
        Me.StrNombreEmpleadoTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrNroIdentificacionTextBox
        '
        Me.StrNroIdentificacionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblEmpeadoBindingSource, "strNroIdentificacion", True))
        Me.StrNroIdentificacionTextBox.DataSource = Nothing
        Me.StrNroIdentificacionTextBox.EnterEntreCampos = True
        Me.StrNroIdentificacionTextBox.Location = New System.Drawing.Point(142, 47)
        Me.StrNroIdentificacionTextBox.Name = "StrNroIdentificacionTextBox"
        Me.StrNroIdentificacionTextBox.NombreCodigoF2 = Nothing
        Me.StrNroIdentificacionTextBox.NombreDescripcionF2 = Nothing
        Me.StrNroIdentificacionTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrNroIdentificacionTextBox.TabIndex = 1
        Me.StrNroIdentificacionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblDatosPrestadoresBindingSource
        '
        Me.TblDatosPrestadoresBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDatosPrestadores)
        '
        'TblEmpeadoBindingNavigator
        '
        Me.TblEmpeadoBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblEmpeadoBindingNavigator.BindingSource = Me.TblEmpeadoBindingSource
        Me.TblEmpeadoBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblEmpeadoBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblEmpeadoBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblEmpeadoBindingNavigatorSaveItem})
        Me.TblEmpeadoBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblEmpeadoBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblEmpeadoBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblEmpeadoBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblEmpeadoBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblEmpeadoBindingNavigator.Name = "TblEmpeadoBindingNavigator"
        Me.TblEmpeadoBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblEmpeadoBindingNavigator.Size = New System.Drawing.Size(671, 25)
        Me.TblEmpeadoBindingNavigator.TabIndex = 2
        Me.TblEmpeadoBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblEmpeadoBindingNavigatorSaveItem
        '
        Me.TblEmpeadoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblEmpeadoBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblEmpeadoBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblEmpeadoBindingNavigatorSaveItem.Name = "TblEmpeadoBindingNavigatorSaveItem"
        Me.TblEmpeadoBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblEmpeadoBindingNavigatorSaveItem.Text = "Save Data"
        '
        'TblTurnoBindingSource
        '
        Me.TblTurnoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTurno)
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'FrmEmpleados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(671, 510)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblEmpeadoBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmEmpleados"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Empleados"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblEmpeadoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.FirmaPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        CType(Me.TblProfesionalesProcedminentosDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        CType(Me.TblEmpleadosTurnosDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        CType(Me.TblProfesionalesItemsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblItemRevisionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        CType(Me.TblEmpleadosPrestadoresDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblEmpeadoBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblEmpeadoBindingNavigator.ResumeLayout(False)
        Me.TblEmpeadoBindingNavigator.PerformLayout()
        CType(Me.TblTurnoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents TabControl1 As System.Windows.Forms.TabControl
    Public WithEvents TabPage1 As System.Windows.Forms.TabPage
    Public WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblEmpeadoDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblEmpeadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblEmpeadoBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblEmpeadoBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdCodigoEmpleadoTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrEspecializacionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNombreEmpleadoTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNroIdentificacionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TblProfesionalesProcedminentosDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblProcedimientoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblEmpleadosTurnosDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblTurnoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TblProfesionalesItemsDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents IntIdProfesionalDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdProcedimientoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblEmpeadoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblProcedimientoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdEmpleadoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdTurnoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents TblEmpeadoDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblTurnoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblItemRevisionBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents intIdItemRevision As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents bitSoloTexto As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents IntIdCodigoEmpleadoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BitActivoClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents TblDatosPrestadoresBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents IntIdCodigoEmpleadoDataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNroIdentificacionDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNombreEmpleadoDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrEspecializacionDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BitActivoDataGridViewCheckBoxColumn1 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents IntIdCodigoPrestadorDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIdProcedimiento As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents IntIdCodigoEmpleadoDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNroIdentificacionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNombreEmpleadoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrEspecializacionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BitActivoDataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents IntIdCodigoPrestadorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TblEmpleadosPrestadoresDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents IntIdPrestadorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents IntIdPrestadoresEmpleadosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblDatosPrestadoresDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblEmpeadosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FirmaPictureBox As Windows.Forms.PictureBox
    Friend WithEvents StrRegistroMedicoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdCodigoEmpleadoDataGridViewTextBoxColumn3 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNroIdentificacionDataGridViewTextBoxColumn2 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrNombreEmpleadoDataGridViewTextBoxColumn2 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrEspecializacionDataGridViewTextBoxColumn2 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrRegistroMedicoDataGridViewTextBoxColumn As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BitActivoDataGridViewCheckBoxColumn2 As Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents IntIdCodigoPrestadorDataGridViewTextBoxColumn2 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrAliasDataGridViewTextBoxColumn As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FirmaDataGridViewTextBoxColumn As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnCargarImagen As Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As Windows.Forms.OpenFileDialog
End Class
