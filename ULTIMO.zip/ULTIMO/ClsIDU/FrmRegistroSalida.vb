﻿Imports System.Windows.Forms

Public Class FrmRegistroSalida
    Dim mstrStringConection As String
    Dim DataContext As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext()
    Dim mstrIntIdUsuario As Integer
    Dim mintIdCaja As Integer
    Dim mCita
    Dim mIntIdPrestador As Integer
    Private Templates(3) As DPFP.Template
    Dim ver As New DPFP.Verification.Verification()
    Dim res As New DPFP.Verification.Verification.Result()

    Sub New(ByVal strStringConection As String, ByVal pstrIntIdUsuario As Integer, ByVal intIdCaja As Integer)
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            mstrStringConection = strStringConection
            mstrIntIdUsuario = pstrIntIdUsuario
            mintIdCaja = intIdCaja
            DataContext = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmRegistroSalida_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim DataContext = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

            TblEmpeadoBindingSource.DataSource = DataContext.tblEmpeados
            TblProcedimientoBindingSource.DataSource = DataContext.tblProcedimiento
            'TblDisgnosticoBindingSource.DataSource = DataContext.tblDisgnostico
            'TblDisgnosticoPosBindingSource.DataSource = DataContext.tblDisgnostico
            'TblComplicacionBindingSource.DataSource = DataContext.tblDisgnostico
            'TblServicioBindingSource.DataSource = DataContext.tblServicios

            If mintIdCaja = Nothing Then
                btnPago.Enabled = False
            Else
                btnPago.Enabled = True
            End If

            'Dim mTblClase = (From p In DataContext.tblTipos _
            '    Where p.strTipo = "CLASE_PROCEDIMIENTO")
            'TblClaseBindingSource.DataSource = mTblClase

            'Dim mTblAtiende = (From p In DataContext.tblTipos _
            '   Where p.strTipo = "PERSONA_ATIENDE")
            'TblAtiendeBindingSource.DataSource = mTblAtiende

            'Dim mTblForma = (From p In DataContext.tblTipos _
            '    Where p.strTipo = "FORMA_REALIZA")
            'TblFormaBindingSource.DataSource = mTblForma

            'Dim mTblTipo = (From p In DataContext.tblTipos _
            '    Where p.strTipo = "TIPO_PROCED")
            'TblTipoBindingSource.DataSource = mTblTipo

            TextBoxNombre.Text = ""
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblCitaBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblCitaBindingNavigatorSaveItem.Click
        Try
            Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)

            If (res.Verified Or NoRegistraHuellaCheckBox.Checked) Then
                If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then

                    If NumValorCoopagoClsTextBox.TextLength > 0 Then
                        If IsNumeric(NumValorCoopagoClsTextBox.Text) Then
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).numValorCoopago = CType(NumValorCoopagoClsTextBox.Text, Integer)
                        End If
                    End If

                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmFechaHoraSaleCita = Now
                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdUsuarioSale = mValidaHuella.mstrIntIdUsuario
                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Cumplida").ReturnValue
                    If Not IsDBNull(mIntIdPrestador) And mIntIdPrestador > 0 Then
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdPrestador = mIntIdPrestador
                    Else
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdPrestador = DataContext.usp_PrestadorProfesional(TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProfesional)
                    End If

                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdClaseProcedimiento = DataContext.usp_SeleccionarTipo("CLASE_PROCEDIMIENTO", "Atención Ambulatoria").ReturnValue
                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intFormaRealizaActoQ = DataContext.usp_SeleccionarTipo("FORMA_REALIZA", "Unico o Unilateral").ReturnValue

                    Dim tmpIntIdTipoProcedimiento As Integer = DataContext.usp_TipoProcedimento(TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProcedimiento)
                    Dim tmpIntIdDiagnosticoProcedimiento As Integer = DataContext.usp_DiagnosticoProcedimento(TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProcedimiento)

                    If tmpIntIdTipoProcedimiento = DataContext.usp_SeleccionarTipo("TIPO_PROCEDIMIENTO", "Examen").ReturnValue Then
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intTipoProcedimiento = DataContext.usp_SeleccionarTipo("TIPO_PROCED", "Diagnóstico").ReturnValue
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdServicio = 2
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdPersonalAtiende = DataContext.usp_SeleccionarTipo("PERSONA_ATIENDE", "Médico Especialista").ReturnValue
                    End If

                    If tmpIntIdTipoProcedimiento = DataContext.usp_SeleccionarTipo("TIPO_PROCEDIMIENTO", "Terapia").ReturnValue Then
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intTipoProcedimiento = DataContext.usp_SeleccionarTipo("TIPO_PROCED", "Terapéutico").ReturnValue
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdServicio = 3
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdPersonalAtiende = DataContext.usp_SeleccionarTipo("PERSONA_ATIENDE", "Otro").ReturnValue
                    End If

                    If tmpIntIdTipoProcedimiento = DataContext.usp_SeleccionarTipo("TIPO_PROCEDIMIENTO", "Consulta").ReturnValue Then
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intTipoProcedimiento = DataContext.usp_SeleccionarTipo("TIPO_PROCED", "Detec Temprana enfer. Gral").ReturnValue
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdServicio = 1
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdPersonalAtiende = DataContext.usp_SeleccionarTipo("PERSONA_ATIENDE", "Médico Especialista").ReturnValue

                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdDiagNosticoPrincipal = tmpIntIdDiagnosticoProcedimiento
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdDiagnosticoRelacionadoN1 = tmpIntIdDiagnosticoProcedimiento
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdDiagnosticoRelacionadoN2 = tmpIntIdDiagnosticoProcedimiento

                    End If

                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdDiagnosticoPrevio = tmpIntIdDiagnosticoProcedimiento
                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdDiagnosticoPosterior = tmpIntIdDiagnosticoProcedimiento

                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intNroServicios = 1
                    Dim mEPS As Integer
                    mEPS = DataContext.usp_ConsultaEPSPaciente(TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNroIdPaciente)
                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).strCodAtencion = DataContext.usp_ConsultaCodigoAtencion(mEPS, TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProcedimiento, TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdTipoTarifa)
                    Try
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).numValorUnitario = DataContext.usp_ConsultaTarifa(mEPS, TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProcedimiento, TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdTipoTarifa)
                    Catch ex As Exception
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).numValorUnitario = DataContext.usp_TipoProcedimento(TblCitaBindingSource.Item(TblCitaBindingSource.Position).numValor)
                    End Try

                    TblCitaBindingSource.EndEdit()
                    DataContext.SubmitChanges()
                    NoRegistraHuellaCheckBox.Enabled = False
                    MsgBox("Los datos han sido actualizados", MsgBoxStyle.Information)
                Else
                    MsgBox("No se actualizaron los datos", MsgBoxStyle.Information)
                End If
            Else
                MsgBox("El paciente debe validarse con su huella dactilar..", MsgBoxStyle.Information)
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub StrNroIdPacienteTextBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrNroIdPacienteTextBox.Leave
        Try
            Dim mNroId As String = StrNroIdPacienteTextBox.Text
            Dim mNombre
            Dim mEstado As Integer
            Dim mEstadoLlegada As Integer
            Dim mEstadoConfirmada As Integer

            mNombre = (From p In DataContext.tblPacientes Where _
                                  p.strNroIdentificacion = mNroId Select p.strPrimerNombre & " " & IIf(p.strSegundoNombre Is Nothing, "", p.strSegundoNombre) & " " & p.strPrimerApellido & " " & IIf(p.strSegundoApellido Is Nothing, "", p.strSegundoApellido)).Single
            TextBoxNombre.Text = mNombre.ToString

            mEstado = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Asignada").ReturnValue
            mEstadoLlegada = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Esperando").ReturnValue
            mEstadoConfirmada = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Confirmada").ReturnValue

            mCita = (From c In DataContext.tblCita Where c.strNroIdPaciente = mNroId _
                         And (c.intIdEstadoCita = mEstado Or c.intIdEstadoCita = mEstadoConfirmada Or c.intIdEstadoCita = mEstadoLlegada Or c.intIdEstadoCita Is Nothing) _
                         And c.dtmFecha = Now.Date Select c)
            If mCita Is Nothing Then
                MsgBox("El paciente no tiene citas pendientes o no registró su llegada..", MsgBoxStyle.Information)
            Else

                'Dim CitaCancelada = (From p In dc2.tblPagos _
                '                         Join c In dc2.tblCitas On p.intIdCita Equals c.intIdCita _
                '                         Select c.intIdCita).Count

                'If CitaCancelada = Nothing Then
                '    btnPago.Enabled = True
                'Else
                '    btnPago.Enabled = False
                'End If

                TblCitaBindingSource.DataSource = mCita
                TblCitaBindingSource.Position = 0
                Dim mTemplate
                Dim bytes As Byte() = Nothing

                TblCitaBindingSource.Position = 0
                mTemplate = (From p In DataContext.tblPacientes Where p.strNroIdentificacion = mNroId Select p.byTemplate1).Single
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(0) = New DPFP.Template()
                    Templates(0).DeSerialize(bytes)

                End If

                mTemplate = (From p In DataContext.tblPacientes Where p.strNroIdentificacion = mNroId Select p.byTemplate2).Single
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(1) = New DPFP.Template()
                    Templates(1).DeSerialize(bytes)
                End If

                mTemplate = (From p In DataContext.tblPacientes Where p.strNroIdentificacion = mNroId Select p.byTemplate3).Single
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(2) = New DPFP.Template()
                    Templates(2).DeSerialize(bytes)
                End If

                mTemplate = (From p In DataContext.tblPacientes Where p.strNroIdentificacion = mNroId Select p.byTemplate4).Single
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(3) = New DPFP.Template()
                    Templates(3).DeSerialize(bytes)
                End If
            End If

        Catch ex As Exception
            'TextBoxNombre.Text = ""
            'StrNroIdPacienteTextBox.Text = ""
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Sub OnComplete(ByVal Control As Object, ByVal FeatureSet As DPFP.FeatureSet, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles VerificationControl.OnComplete

        For Each template As DPFP.Template In Templates    ' Compare feature set with all stored templates:
            If Not template Is Nothing Then                     '   Get template from storage.
                ver.Verify(FeatureSet, template, res)           '   Compare feature set with particular template.
                'Data.IsFeatureSetMatched = res.Verified         '   Check the result of the comparison
                'Data.FalseAcceptRate = res.FARAchieved          '   Determine the current False Accept Rate
                If res.Verified Then
                    EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Success
                    Exit For ' success
                End If
            End If
        Next
        If Not res.Verified Then EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Failure
        'Data.Update()
    End Sub

    Private Sub DtmFechaAutorizacionLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub IntIdServicioClsComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntIdServicioClsComboBox.SelectedIndexChanged

    End Sub

    Private Sub btnPago_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPago.Click
        Try
           
            If IntIdCitaTextBox.TextLength = 0 Then
                MsgBox("No ha seleccionado la salida de un paciente")
                Exit Sub
            End If

            If Windows.Forms.Application.OpenForms("DialogPago") Is Nothing Then

                Dim mDialogPago As New ClsIDU.DialogPago(mstrStringConection, mstrIntIdUsuario, TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProfesional)
                Dim mPago = (From p In DataContext.tblPagos _
                             Where p.intIdCita = CType(IntIdCitaTextBox.Text, Integer) _
                             Select p.intIdPrestadores, p.numValorPagado, p.numEfectivo, p.numDevuelta, p.bitEsCoopago)

                If mPago.LongCount() > 0 Then

                    Dim mRes As New List(Of Object)
                    For Each mR In mPago
                        mRes.Add(mR)
                    Next

                    mDialogPago.ClsTextBoxValorPagado.Text = mRes.Item(0).numValorPagado
                    mDialogPago.ClsTextBoxEfectivo.Text = mRes.Item(0).numEfectivo
                    mDialogPago.ClsTextBoxDevuelta.Text = mRes.Item(0).numDevuelta
                    mDialogPago.ClsComboBoxPrestador.SelectedValue = mRes.Item(0).intIdPrestadores
                    mDialogPago.ClsCheckBoxCoopago.Checked = mRes.Item(0).bitEsCoopago
                    mIntIdPrestador = mRes.Item(0).intIdPrestadores

                    mDialogPago.ClsTextBoxValorPagado.Enabled = False
                    mDialogPago.ClsTextBoxEfectivo.Enabled = False
                    mDialogPago.ClsTextBoxDevuelta.Enabled = False
                    mDialogPago.ClsComboBoxPrestador.Enabled = False
                    mDialogPago.ClsCheckBoxCoopago.Enabled = False

                End If

                If mDialogPago.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    Dim mintIdCuadre = (From P In DataContext.tblCajas _
                                        Where P.intIdCajas = mintIdCaja _
                                        Select P.intIdCuadre).Single

                    If DataContext.usp_GuardarPago(mintIdCuadre, mDialogPago.ClsCheckBoxCoopago.Checked, mDialogPago.mValorPagado, mDialogPago.mValorEfectivo, mDialogPago.mValorDevuelto, mDialogPago.mPrestadorServicio, CType(IntIdCitaTextBox.Text, Integer), Convert.ToInt32(mstrIntIdUsuario), CType(mDialogPago.cmbMedioPago.SelectedValue, Integer)) = 0 Then

                        mIntIdPrestador = mDialogPago.mPrestadorServicio

                        MsgBox("El pago ha sido guardado")
                        If MsgBox("Desea Imprimir la Factura..?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                            If Application.OpenForms("FrmFacturaMediaCarta") Is Nothing Then
                                Dim mFrmFacturaMediaCarta As New ClsReportes.FrmFacturaMediaCarta(mstrStringConection, CType(IntIdCitaTextBox.Text, Integer))
                                mFrmFacturaMediaCarta.Show()
                            Else
                                Application.OpenForms("FrmFacturaMediaCarta").BringToFront()
                            End If
                        End If

                        If mDialogPago.ClsCheckBoxCoopago.Checked Then NumValorCoopagoClsTextBox.Text = mDialogPago.mValorPagado
                    End If

                End If
            Else
                Windows.Forms.Application.OpenForms("DialogPago").BringToFront()
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub


    Private Sub btnHabilitarCoopago_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHabilitarCoopago.Click
        Try
            Dim mClaveIngreso
            Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
            If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then

                Dim mDlgClaveSuperUsuario As New DlgClaveSuperUsuario()
                If mDlgClaveSuperUsuario.ShowDialog = Windows.Forms.DialogResult.OK Then
                    Dim mClaveSuper = DataContext.usp_ClaveSuperUsuario(mValidaHuella.mstrIntIdUsuario)
                    mClaveIngreso = mDlgClaveSuperUsuario.strClave
                    If mClaveSuper(0).strClaveSuperUsuario = mClaveIngreso Then
                        NoRegistraHuellaCheckBox.Enabled = True
                    Else
                        MsgBox("La clave es incorrecta..")
                    End If
                End If
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class