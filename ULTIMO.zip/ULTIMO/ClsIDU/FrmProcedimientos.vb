﻿Public Class FrmProcedimientos
    'Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext()
    Public mstrStringConection As String
    Dim mDataContext 'As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext()

    Sub New(ByVal strStringConection As String)
        Try

            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
            mstrStringConection = strStringConection
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmProcedimientos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            mDataContext = dc
            Dim TipoDoc = (From p In dc.tblTipos _
                            Where p.strTipo = "TIPO_TARIFA")
            TblTipoBindingSource.DataSource = TipoDoc

            Dim TipoProc = (From p In dc.tblTipos _
                            Where p.strTipo = "TIPO_PROCEDIMIENTO")
            TblTipoBindingSource1.DataSource = TipoProc

            TblEPBindingSource.DataSource = dc.tblEPs
            TblProcedimientoBindingSource.DataSource = dc.tblProcedimiento
            TblDivisionVasculabBindingSource.DataSource = dc.tblDivisionVasculabs
            TblTipoTarifaBindingSource.DataSource = dc.tblTipoTarifa
            TblTarifaBaseBindingSource.DataSource = dc.tblTarifaBase
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblProcedimientoBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblProcedimientoBindingNavigatorSaveItem.Click
        Try
            TblProcedimientoBindingSource.EndEdit()
            mDataContext.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub

    Private Sub TblTarifasDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs)
        Try
            'no hace nada
        Catch ex As Exception
            'no hace nada
        End Try
    End Sub

    Private Sub TblTarifasDataGridView_DataError_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblTarifasDataGridView.DataError
        Try

        Catch ex As Exception
            'no hace nada
        End Try
    End Sub
End Class