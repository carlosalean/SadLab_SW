﻿Imports System.Windows.Forms
Imports System.IO

Public Class FrmDescuentos
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mstrConectionString As String
    Dim mstrIntIdUsuario As String

    Public Sub New(ByVal strConectionString As String, ByVal strIntIdUsuario As String)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Try
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strConectionString)
            mstrConectionString = strConectionString
            mstrIntIdUsuario = strIntIdUsuario
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmDescuentos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TblDescuentoBindingSource.DataSource = dc.tblDescuentos
            Dim TipoDoc = (From p In dc.tblTipos _
                Where p.strTipo = "TIPO_TARIFA")
            TblTipoBindingSource.DataSource = TipoDoc

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblDescuentoBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblDescuentoBindingNavigatorSaveItem.Click
        Try

            TblDescuentoBindingSource.EndEdit()
            dc.SubmitChanges()
            NumValorAdminClsTextBox.Visible = False
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub

    Private Sub FrmDescuentos_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
        If e.Alt Then
            If e.KeyCode = Keys.F10 Then
                Dim mValidaHuella As New DialogValidarHuella(mstrConectionString, mstrIntIdUsuario)
                Dim mClaveIngreso
                If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then
                    Dim mstrClave = dc.usp_ClaveSuperUsuario(mValidaHuella.mstrIntIdUsuario)
                    Dim mDlgClaveSuperUsuario As New DlgClaveSuperUsuario()
                    If mDlgClaveSuperUsuario.ShowDialog = Windows.Forms.DialogResult.OK Then
                        mClaveIngreso = mDlgClaveSuperUsuario.strClave
                        If mstrClave(0).strClaveSuperUsuario = mClaveIngreso Then
                            NumValorAdminClsTextBox.Visible = True
                        Else
                            MsgBox("La clave es incorrecta..")
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        Try
            If FolderBrowserDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
                Dim objStreamWriter As StreamWriter
                Dim mclsCodificar As New clsCodificaciones

                objStreamWriter = New StreamWriter(FolderBrowserDialog1.SelectedPath & "\DESCUENTOS.TXT")
                For Each mDescuento As ClsBaseDatos_SadLab.tblDescuento In TblDescuentoBindingSource.DataSource
                    If Not (mDescuento.numValorAdmin Is Nothing) Then
                        objStreamWriter.WriteLine(mclsCodificar.FnCodifica(mDescuento.intIdDescuento.ToString & "," & Decimal.Truncate(mDescuento.numValorAdmin).ToString))
                    End If
                Next
                objStreamWriter.Close()

            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class