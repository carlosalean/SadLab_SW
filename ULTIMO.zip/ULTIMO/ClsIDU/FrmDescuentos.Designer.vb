﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDescuentos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IntIdDescuentoLabel As System.Windows.Forms.Label
        Dim IntTipoLabel As System.Windows.Forms.Label
        Dim NumValorLabel As System.Windows.Forms.Label
        Dim StrDescripcioLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmDescuentos))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TblDescuentoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblDescuentoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.NumValorAdminClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdDescuentoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntTipoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.NumValorClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrDescripcioClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.TblDescuentoBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblDescuentoBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        IntIdDescuentoLabel = New System.Windows.Forms.Label()
        IntTipoLabel = New System.Windows.Forms.Label()
        NumValorLabel = New System.Windows.Forms.Label()
        StrDescripcioLabel = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblDescuentoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDescuentoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblDescuentoBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblDescuentoBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntIdDescuentoLabel
        '
        IntIdDescuentoLabel.AutoSize = True
        IntIdDescuentoLabel.Location = New System.Drawing.Point(29, 34)
        IntIdDescuentoLabel.Name = "IntIdDescuentoLabel"
        IntIdDescuentoLabel.Size = New System.Drawing.Size(19, 13)
        IntIdDescuentoLabel.TabIndex = 0
        IntIdDescuentoLabel.Text = "Id:"
        '
        'IntTipoLabel
        '
        IntTipoLabel.AutoSize = True
        IntTipoLabel.Location = New System.Drawing.Point(29, 86)
        IntTipoLabel.Name = "IntTipoLabel"
        IntTipoLabel.Size = New System.Drawing.Size(31, 13)
        IntTipoLabel.TabIndex = 2
        IntTipoLabel.Text = "Tipo:"
        '
        'NumValorLabel
        '
        NumValorLabel.AutoSize = True
        NumValorLabel.Location = New System.Drawing.Point(29, 113)
        NumValorLabel.Name = "NumValorLabel"
        NumValorLabel.Size = New System.Drawing.Size(34, 13)
        NumValorLabel.TabIndex = 4
        NumValorLabel.Text = "Valor:"
        '
        'StrDescripcioLabel
        '
        StrDescripcioLabel.AutoSize = True
        StrDescripcioLabel.Location = New System.Drawing.Point(29, 60)
        StrDescripcioLabel.Name = "StrDescripcioLabel"
        StrDescripcioLabel.Size = New System.Drawing.Size(66, 13)
        StrDescripcioLabel.TabIndex = 6
        StrDescripcioLabel.Text = "Descripción:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(590, 320)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TblDescuentoDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(582, 294)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblDescuentoDataGridView
        '
        Me.TblDescuentoDataGridView.AutoGenerateColumns = False
        Me.TblDescuentoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblDescuentoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.TblDescuentoDataGridView.DataSource = Me.TblDescuentoBindingSource
        Me.TblDescuentoDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblDescuentoDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblDescuentoDataGridView.Name = "TblDescuentoDataGridView"
        Me.TblDescuentoDataGridView.Size = New System.Drawing.Size(576, 288)
        Me.TblDescuentoDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdDescuento"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 60
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strDescripcio"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Descripción"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 250
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "intTipo"
        Me.DataGridViewTextBoxColumn3.DataSource = Me.TblTipoBindingSource
        Me.DataGridViewTextBoxColumn3.DisplayMember = "strValor"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Tipo"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn3.ValueMember = "intIdTipo"
        '
        'TblTipoBindingSource
        '
        Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoBindingSource.Sort = "strValor"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "numValor"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Valor"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'TblDescuentoBindingSource
        '
        Me.TblDescuentoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDescuento)
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.NumValorAdminClsTextBox)
        Me.TabPage2.Controls.Add(IntIdDescuentoLabel)
        Me.TabPage2.Controls.Add(Me.IntIdDescuentoClsTextBox)
        Me.TabPage2.Controls.Add(IntTipoLabel)
        Me.TabPage2.Controls.Add(Me.IntTipoClsComboBox)
        Me.TabPage2.Controls.Add(NumValorLabel)
        Me.TabPage2.Controls.Add(Me.NumValorClsTextBox)
        Me.TabPage2.Controls.Add(StrDescripcioLabel)
        Me.TabPage2.Controls.Add(Me.StrDescripcioClsTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(582, 294)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'NumValorAdminClsTextBox
        '
        Me.NumValorAdminClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDescuentoBindingSource, "numValorAdmin", True))
        Me.NumValorAdminClsTextBox.DataSource = Nothing
        Me.NumValorAdminClsTextBox.EnterEntreCampos = True
        Me.NumValorAdminClsTextBox.Location = New System.Drawing.Point(250, 110)
        Me.NumValorAdminClsTextBox.Name = "NumValorAdminClsTextBox"
        Me.NumValorAdminClsTextBox.NombreCodigoF2 = Nothing
        Me.NumValorAdminClsTextBox.NombreDescripcionF2 = Nothing
        Me.NumValorAdminClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.NumValorAdminClsTextBox.TabIndex = 9
        Me.NumValorAdminClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.NumValorAdminClsTextBox.Visible = False
        '
        'IntIdDescuentoClsTextBox
        '
        Me.IntIdDescuentoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDescuentoBindingSource, "intIdDescuento", True))
        Me.IntIdDescuentoClsTextBox.DataSource = Nothing
        Me.IntIdDescuentoClsTextBox.Enabled = False
        Me.IntIdDescuentoClsTextBox.EnterEntreCampos = True
        Me.IntIdDescuentoClsTextBox.Location = New System.Drawing.Point(123, 31)
        Me.IntIdDescuentoClsTextBox.Name = "IntIdDescuentoClsTextBox"
        Me.IntIdDescuentoClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdDescuentoClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdDescuentoClsTextBox.Size = New System.Drawing.Size(40, 20)
        Me.IntIdDescuentoClsTextBox.TabIndex = 0
        Me.IntIdDescuentoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntTipoClsComboBox
        '
        Me.IntTipoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblDescuentoBindingSource, "intTipo", True))
        Me.IntTipoClsComboBox.DataSource = Me.TblTipoBindingSource
        Me.IntTipoClsComboBox.DisplayMember = "strValor"
        Me.IntTipoClsComboBox.FormattingEnabled = True
        Me.IntTipoClsComboBox.Location = New System.Drawing.Point(123, 83)
        Me.IntTipoClsComboBox.Name = "IntTipoClsComboBox"
        Me.IntTipoClsComboBox.Size = New System.Drawing.Size(121, 21)
        Me.IntTipoClsComboBox.TabIndex = 2
        Me.IntTipoClsComboBox.ValueMember = "intIdTipo"
        '
        'NumValorClsTextBox
        '
        Me.NumValorClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDescuentoBindingSource, "numValor", True))
        Me.NumValorClsTextBox.DataSource = Nothing
        Me.NumValorClsTextBox.EnterEntreCampos = True
        Me.NumValorClsTextBox.Location = New System.Drawing.Point(123, 110)
        Me.NumValorClsTextBox.Name = "NumValorClsTextBox"
        Me.NumValorClsTextBox.NombreCodigoF2 = Nothing
        Me.NumValorClsTextBox.NombreDescripcionF2 = Nothing
        Me.NumValorClsTextBox.Size = New System.Drawing.Size(121, 20)
        Me.NumValorClsTextBox.TabIndex = 3
        Me.NumValorClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrDescripcioClsTextBox
        '
        Me.StrDescripcioClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDescuentoBindingSource, "strDescripcio", True))
        Me.StrDescripcioClsTextBox.DataSource = Nothing
        Me.StrDescripcioClsTextBox.EnterEntreCampos = True
        Me.StrDescripcioClsTextBox.Location = New System.Drawing.Point(123, 57)
        Me.StrDescripcioClsTextBox.Name = "StrDescripcioClsTextBox"
        Me.StrDescripcioClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcioClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcioClsTextBox.Size = New System.Drawing.Size(354, 20)
        Me.StrDescripcioClsTextBox.TabIndex = 1
        Me.StrDescripcioClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblDescuentoBindingNavigator
        '
        Me.TblDescuentoBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblDescuentoBindingNavigator.BindingSource = Me.TblDescuentoBindingSource
        Me.TblDescuentoBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblDescuentoBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblDescuentoBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblDescuentoBindingNavigatorSaveItem, Me.ToolStripSeparator1, Me.ToolStripButton1})
        Me.TblDescuentoBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblDescuentoBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblDescuentoBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblDescuentoBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblDescuentoBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblDescuentoBindingNavigator.Name = "TblDescuentoBindingNavigator"
        Me.TblDescuentoBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblDescuentoBindingNavigator.Size = New System.Drawing.Size(590, 25)
        Me.TblDescuentoBindingNavigator.TabIndex = 2
        Me.TblDescuentoBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblDescuentoBindingNavigatorSaveItem
        '
        Me.TblDescuentoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblDescuentoBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblDescuentoBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblDescuentoBindingNavigatorSaveItem.Name = "TblDescuentoBindingNavigatorSaveItem"
        Me.TblDescuentoBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblDescuentoBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton1.Text = "Generar Pen Drive"
        Me.ToolStripButton1.ToolTipText = "Generar Pen Drive"
        '
        'FrmDescuentos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(590, 345)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblDescuentoBindingNavigator)
        Me.KeyPreview = True
        Me.Name = "FrmDescuentos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Descuentos"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblDescuentoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDescuentoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblDescuentoBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblDescuentoBindingNavigator.ResumeLayout(False)
        Me.TblDescuentoBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents TabControl1 As System.Windows.Forms.TabControl
    Public WithEvents TabPage1 As System.Windows.Forms.TabPage
    Public WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblDescuentoDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblDescuentoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDescuentoBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblDescuentoBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IntIdDescuentoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntTipoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents NumValorClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrDescripcioClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NumValorAdminClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
End Class
