﻿Imports System.Windows.Forms

Public Class FrmCita
    Dim mstrStringConection As String
    Dim DataContext As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mMinutos As Integer
    Dim mHoras As Integer
    Dim strIntIdUsuario As Integer
    Private Templates(3) As DPFP.Template
    Dim ver As New DPFP.Verification.Verification()
    Dim res As New DPFP.Verification.Verification.Result()
    Dim strPaciente As String
    Dim mHuella
    Dim mClave
    Dim mintIdSede As Integer


    Sub New(ByVal strStringConection As String, ByVal pstrIntIdUsuario As Integer, ByVal intIdSede As Integer, Optional ByVal pstrPaciente As String = "")
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            mstrStringConection = strStringConection
            'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
            strIntIdUsuario = pstrIntIdUsuario
            strPaciente = pstrPaciente
            mintIdSede = intIdSede
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmCita_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            DataContext = dc

            'TblCitaBindingSource.DataSource = dc.tblCitas
            Dim tblEmpleados = (From p In dc.tblEmpeados Where p.bitActivo = True Select p)
            TblEmpeadoBindingSource.DataSource = tblEmpleados
            'TblPacienteBindingSource1.DataSource = dc.tblPacientes

            TblProcedimientoBindingSource.DataSource = dc.tblProcedimiento
            Dim Estado = (From p In dc.tblTipos _
                Where p.strTipo = "ESTADO_CITA")

            TblTipoBindingSource.DataSource = Estado
            TblUsuarioBindingSource.DataSource = dc.tblUsuarios

            TblTipoTarifaBindingSource.DataSource = dc.tblTipoTarifa

            Dim mTemplate
            Dim bytes As Byte() = Nothing
            Dim mintIdUsuario As Integer

            mintIdUsuario = Convert.ToInt32(strIntIdUsuario)
            Dim mtmpUsuario = dc.usp_TemplatesUsuario(mintIdUsuario)
            Dim mtmpUsuario2 = mtmpUsuario(0)

            mTemplate = mtmpUsuario2.byTemplate1
            If Not mTemplate Is Nothing Then
                bytes = mTemplate.ToArray()
                Templates(0) = New DPFP.Template()
                Templates(0).DeSerialize(bytes)
            End If

            mTemplate = mtmpUsuario2.byTemplate2
            If Not mTemplate Is Nothing Then
                bytes = mTemplate.ToArray()
                Templates(1) = New DPFP.Template()
                Templates(1).DeSerialize(bytes)
            End If


            mTemplate = mtmpUsuario2.byTemplate3
            If Not mTemplate Is Nothing Then
                bytes = mTemplate.ToArray()
                Templates(2) = New DPFP.Template()
                Templates(2).DeSerialize(bytes)
            End If

            mTemplate = mtmpUsuario2.byTemplate4
            If Not mTemplate Is Nothing Then
                bytes = mTemplate.ToArray()
                Templates(3) = New DPFP.Template()
                Templates(3).DeSerialize(bytes)
            End If

            'Dim mTemplate
            'Dim bytes As Byte() = Nothing
            'Dim mintIdUsuario As Integer
            'mintIdUsuario = Convert.ToInt32(strIntIdUsuario)
            'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = mintIdUsuario Select p.byTemplate1).Single
            'If Not mTemplate Is Nothing Then
            '    bytes = mTemplate.ToArray()
            '    Templates(0) = New DPFP.Template()
            '    Templates(0).DeSerialize(bytes)
            'End If

            'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = mintIdUsuario Select p.byTemplate2).Single
            'If Not mTemplate Is Nothing Then
            '    bytes = mTemplate.ToArray()
            '    Templates(1) = New DPFP.Template()
            '    Templates(1).DeSerialize(bytes)
            'End If


            'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = mintIdUsuario Select p.byTemplate3).Single
            'If Not mTemplate Is Nothing Then
            '    bytes = mTemplate.ToArray()
            '    Templates(2) = New DPFP.Template()
            '    Templates(2).DeSerialize(bytes)
            'End If

            'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = mintIdUsuario Select p.byTemplate4).Single
            'If Not mTemplate Is Nothing Then
            '    bytes = mTemplate.ToArray()
            '    Templates(3) = New DPFP.Template()
            '    Templates(3).DeSerialize(bytes)
            'End If

            mHuella = (From p In dc.tblUsuarios Where p.intIdUsuario = mintIdUsuario Select p.bitValidaHuella).Single
            ClaveClsTextBox.Visible = Not mHuella
            Label2.Visible = Not mHuella

            mClave = (From p In dc.tblUsuarios Where p.intIdUsuario = mintIdUsuario Select p.strClave).Single

            TblCitaBindingSource.AddNew()
            StrNroIdPacienteTextBox.Text = strPaciente
            TextBoxNombre.Text = ""
            IntIdProcedimientoComboBox.SelectedIndex = -1
            IntIdProfesionalComboBox.SelectedIndex = -1

            NroCitasClsTextBox.Text = "1"

            DtmFechaDateTimePicker.Value = Now
            IntIdEstadoCitaComboBox.SelectedIndex = 0
            cmbTipoTarifa.SelectedIndex = 0

            'IntIdPacienteComboBox.SelectedIndex = -1
            'PrCargarGrid()

            ToolStripComboBoxSede.ComboBox.DataSource = dc.tblSedes
            ToolStripComboBoxSede.ComboBox.DisplayMember = "strNombreSede"
            ToolStripComboBoxSede.ComboBox.ValueMember = "intIdSede"
            ToolStripComboBoxSede.ComboBox.SelectedIndex = mintIdSede

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblCitaBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblCitaBindingNavigatorSaveItem.Click
        Try
            Dim mstrPaciente As String = ""
            Dim mstrProcedimiento As Integer = -1
            Dim mstrProfesional As Integer = -1
            If IntIdProcedimientoComboBox.SelectedIndex >= 0 And (IntIdProcedimientoComboBox.Text.Trim.Length > 0) Then
                If Me.ValidateChildren() Then

                    If res.Verified Then
                        If MsgBox("Confirmación de cita: " & Chr(13) & _
                                  "Fecha : " & DtmFechaDateTimePicker.Value.ToString("dd/MM/yyyy") & Chr(13) & _
                                  "Hora : " & DtmHoraMaskedTextBox.Text & Chr(13) & _
                                  "Medico: " & TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).strNombreEmpleado & Chr(13) & _
                                  "Examen: " & TblProcedimientoBindingSource.Item(TblProcedimientoBindingSource.Position).strDescripcion, MsgBoxStyle.OkCancel + MsgBoxStyle.Information) = MsgBoxResult.Ok Then
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNroIdPaciente = StrNroIdPacienteTextBox.Text
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmHora = TimeSpan.Parse(DtmHoraMaskedTextBox.Text)
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdUsuario = strIntIdUsuario
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Asignada").ReturnValue
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmFecha = DtmFechaDateTimePicker.Value
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmHoraFin = TimeSpan.Parse(DtmHoraFinMaskedTextBox.Text)
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmFechaHoraTomaCita = Now
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).strObservacion = StrObservacionTextBox.Text
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdSede = ToolStripComboBoxSede.ComboBox.SelectedValue
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdTipoTarifa = cmbTipoTarifa.SelectedValue

                            Dim mValor
                            Dim mIdEPS As Integer
                            Dim mIdProcedimiento As Integer

                            mIdProcedimiento = TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProcedimiento

                            mIdEPS = (From p In DataContext.tblPacientes Where p.strNroIdentificacion = StrNroIdPacienteTextBox.Text Select p.intIdEps).Single
                            Try
                                mValor = (From p In DataContext.tblProcedimiento Join _
                                         t In DataContext.tblTarifas On p.intIdProcedimientos _
                                         Equals t.intIdProcedimiento Where t.intIdEPS = mIdEPS And p.intIdProcedimientos = mIdProcedimiento Select t.numValor).Single
                            Catch ex As Exception
                                'No hace Nada
                            End Try

                            Try
                                If mValor Is Nothing Then
                                    mValor = (From p In DataContext.tblProcedimiento _
                                        Where p.intIdProcedimientos = mIdProcedimiento Select p.numValor).Single
                                End If
                            Catch ex As Exception
                                'No hace Nada
                            End Try

                            If Not mValor Is Nothing Then
                                TblCitaBindingSource.Item(TblCitaBindingSource.Position).numValorUnitario = mValor
                            End If


                            If IsNumeric(NroCitasClsTextBox.Text) = True Then
                                If Convert.ToInt32(NroCitasClsTextBox.Text) > 1 Then
                                    mstrPaciente = StrNroIdPacienteTextBox.Text
                                    NroCitasClsTextBox.Text = (Convert.ToInt32(NroCitasClsTextBox.Text) - 1).ToString
                                    mstrProcedimiento = TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProcedimiento
                                    mstrProfesional = TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProfesional
                                End If
                            End If
                            TblCitaBindingSource.EndEdit()
                            DataContext.tblCita.InsertOnSubmit(TblCitaBindingSource.Item(TblCitaBindingSource.Position))
                            DataContext.SubmitChanges()

                            TblCitaBindingSource.AddNew()
                            If mstrPaciente.Trim.Length > 0 Then
                                StrNroIdPacienteTextBox.Text = mstrPaciente
                                TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNroIdPaciente = mstrPaciente
                                TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProcedimiento = mstrProcedimiento
                                TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProfesional = mstrProfesional
                                IntIdProcedimientoComboBox.SelectedValue = mstrProcedimiento
                                IntIdProfesionalComboBox.SelectedValue = mstrProfesional
                            Else
                                TextBoxNombre.Text = ""
                            End If


                            'DtmFechaDateTimePicker.Value = Now
                            StrNroIdPacienteTextBox.Focus()

                            res.Verified = False

                        End If
                    Else
                        If mHuella Then
                            MsgBox("Debe validarse con su huella dactilar..", MsgBoxStyle.Information)
                        Else
                            MsgBox("Clave inválida..", MsgBoxStyle.Information)
                        End If
                    End If
                Else
                    MsgBox("Tiene Errores en los campos..")
                End If
            Else
                MsgBox("Debe seleccionar el procedimiento..")
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub ButtonVer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonVer.Click
        Try
            Dim dc2 As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

            ''Dim Empleado As Integer
            ''Dim mFecha As Date
            ''Dim mEstado As Integer
            ''Dim mSede As Integer

            ''mFecha = DtmFechaDateTimePicker.Value.Date
            ''Empleado = TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).intIdCodigoEmpleado
            ''mEstado = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Asignada").ReturnValue
            ''mSede = ToolStripComboBoxSede.ComboBox.SelectedValue

            ''Dim tblDisponiblilidad = (From p In dc2.tblCitas Join pc In dc2.tblPacientes _
            ''                          Join ep In dc2.tblEPs _
            ''                          On ep.intIdEPS Equals pc.intIdEps On _
            ''        p.strNroIdPaciente Equals pc.strNroIdentificacion _
            ''    Where p.intIdProfesional = Empleado _
            ''    And p.dtmFecha.Date = mFecha _
            ''    And (p.intIdEstadoCita = mEstado Or p.intIdEstadoCita Is Nothing) _
            ''    And (p.intIdSede = mSede) _
            ''    Order By p.dtmHora Select p.dtmHora, p.dtmHoraFin, ep.strNombre, strNroIdPaciente = pc.strPrimerNombre & " " & IIf(pc.strSegundoNombre Is Nothing, "", pc.strSegundoNombre) & " " & pc.strPrimerApellido & " " & IIf(pc.strSegundoApellido Is Nothing, "", pc.strSegundoApellido)) '_


            'And p.dtmFecha.Month = DtmFechaDateTimePicker.Value.Month _
            'And p.dtmFecha.Year = DtmFechaDateTimePicker.Value.Year)

            DisponibilidadBindingSource.DataSource = dc2.usp_CitasProfesional(TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).intIdCodigoEmpleado, DtmFechaDateTimePicker.Value.Date, ToolStripComboBoxSede.ComboBox.SelectedValue)
        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub


    Private Sub DataGridView1_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles DataGridViewDisponibilidad.DataError
        Try

        Catch ex As Exception
            'No hace nada
        End Try
    End Sub

    Private Sub PrCrearPaciente()
        Try
            If Application.OpenForms("FrmPacientes") Is Nothing Then
                Dim mFrmPacientes As New FrmPacientes(mstrStringConection, strIntIdUsuario, mintIdSede, StrNroIdPacienteTextBox.Text, Nothing)
                mFrmPacientes.mstrStringConection = mstrStringConection
                mFrmPacientes.Show()
                IntIdEstadoCitaComboBox.SelectedIndex = 0
                cmbTipoTarifa.SelectedIndex = 0
            Else
                Application.OpenForms("FrmPacientes").BringToFront()
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
    Private Sub ButtonNuevo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonNuevo.Click
        PrCrearPaciente()
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click

    End Sub

    Private Sub StrNroIdPacienteTextBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrNroIdPacienteTextBox.Leave
        Try
            Dim dc2 = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            'TblPacienteBindingSource1.DataSource = dc2.tblPacientes

            Dim mNroId As String = StrNroIdPacienteTextBox.Text
            Dim mPrimerNombre = (From p In dc2.tblPacientes Where _
                                  p.strNroIdentificacion = mNroId Select p.strPrimerNombre).Single '& " " & p.strSegundoNombre & " " & p.strPrimerApellido & " " & p.strSegundoApellido).Single

            Dim mSegundoNombre = (From p In dc2.tblPacientes Where _
                                  p.strNroIdentificacion = mNroId Select p.strSegundoNombre).Single '& " " & p.strSegundoNombre & " " & p.strPrimerApellido & " " & p.strSegundoApellido).Single
            Dim mPrimerApellido = (From p In dc2.tblPacientes Where _
                                  p.strNroIdentificacion = mNroId Select p.strPrimerApellido).Single '& " " & p.strSegundoNombre & " " & p.strPrimerApellido & " " & p.strSegundoApellido).Single
            Dim mSegundoApellido = (From p In dc2.tblPacientes Where _
                                  p.strNroIdentificacion = mNroId Select p.strSegundoApellido).Single '& " " & p.strSegundoNombre & " " & p.strPrimerApellido & " " & p.strSegundoApellido).Single

            Dim mNombre As String = ""

            If Not mPrimerNombre Is Nothing Then
                mNombre = mPrimerNombre
            End If

            If Not mSegundoNombre Is Nothing Then
                mNombre = mNombre & " " & mSegundoNombre
            End If

            If Not mPrimerApellido Is Nothing Then
                mNombre = mNombre & " " & mPrimerApellido
            End If

            If Not mSegundoApellido Is Nothing Then
                mNombre = mNombre & " " & mSegundoApellido
            End If

            TextBoxNombre.Text = mNombre.ToString
        Catch ex As Exception
            If StrNroIdPacienteTextBox.Text.Trim.Length > 0 Then
                If MsgBox("El paciente no existe, desea crearlo?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                    PrCrearPaciente()
                Else
                    TextBoxNombre.Text = ""
                    StrNroIdPacienteTextBox.Text = ""
                End If
            End If
            'ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub
    Private Sub PrCargarGrid()
        With DataGridViewDisponibilidad

            .Rows.Add(30)
            Dim mHora As TimeSpan
            mHora = TimeSpan.Parse("06:00")
            For Each mRow As DataGridViewRow In .Rows
                mRow.Cells(0).Value = mHora.ToString()
                mHora = mHora.Add(New TimeSpan(0, 30, 0))
            Next
        End With
    End Sub

    Private Sub IntIdProcedimientoComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntIdProcedimientoComboBox.SelectedIndexChanged
    End Sub

    Private Sub IntIdProcedimientoComboBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntIdProcedimientoComboBox.Leave
        Try
            If IntIdProcedimientoComboBox.SelectedIndex >= 0 Then

                If TblProcedimientoBindingSource.Item(TblProcedimientoBindingSource.Position).bitTienePreparacion() Then
                    MsgBox("Este procedimiento requiere preparación: " & Chr(13) & TblProcedimientoBindingSource.Item(TblProcedimientoBindingSource.Position).strIndicacionesPreparacion, MsgBoxStyle.Information)
                End If

                If IsDBNull(TblProcedimientoBindingSource.Item(TblProcedimientoBindingSource.Position).intTiempoHoras) Then
                    mHoras = 0
                Else
                    mHoras = TblProcedimientoBindingSource.Item(TblProcedimientoBindingSource.Position).intTiempoHoras
                End If
                If IsDBNull(TblProcedimientoBindingSource.Item(TblProcedimientoBindingSource.Position).intTiempoMinutos) Then
                    mMinutos = 0
                Else
                    mMinutos = TblProcedimientoBindingSource.Item(TblProcedimientoBindingSource.Position).intTiempoMinutos
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub DtmHoraMaskedTextBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DtmHoraMaskedTextBox.Leave
        Try
            'TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmHoraFin = 
            Dim mHoraIni As TimeSpan
            Dim mHoraFin As TimeSpan
            mHoraIni = TimeSpan.Parse(DtmHoraMaskedTextBox.Text)


            mHoraFin = mHoraIni.Add(New TimeSpan(mHoras, mMinutos, 0))
            DtmHoraFinMaskedTextBox.Text = mHoraFin.ToString()
            TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmHoraFin = mHoraFin
            TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmHora = mHoraIni
            DtmHoraFinMaskedTextBox.Refresh()
            DtmHoraMaskedTextBox.Refresh()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Sub OnComplete(ByVal Control As Object, ByVal FeatureSet As DPFP.FeatureSet, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles VerificationControl.OnComplete

        For Each template As DPFP.Template In Templates    ' Compare feature set with all stored templates:
            If Not template Is Nothing Then                     '   Get template from storage.
                ver.Verify(FeatureSet, template, res)           '   Compare feature set with particular template.
                'Data.IsFeatureSetMatched = res.Verified         '   Check the result of the comparison
                'Data.FalseAcceptRate = res.FARAchieved          '   Determine the current False Accept Rate
                If res.Verified Then
                    EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Success
                    Exit For ' success
                End If
            End If
        Next
        If Not res.Verified Then EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Failure
        'Data.Update()
    End Sub

    Private Sub IntIdUsuarioClsComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntIdUsuarioClsComboBox.SelectedIndexChanged
        Try
            If Not IntIdUsuarioClsComboBox.SelectedValue Is Nothing Then

                'Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

                'Dim midUsuario As Integer

                'If IsNumeric(IntIdUsuarioClsComboBox.SelectedValue) Then
                '    midUsuario = IntIdUsuarioClsComboBox.SelectedValue
                'Else
                '    midUsuario = IntIdUsuarioClsComboBox.SelectedValue.intIdUsuario
                'End If
                'Dim mTemplate
                'Dim bytes As Byte() = Nothing

                'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = midUsuario Select p.byTemplate1).Single
                'bytes = mTemplate.ToArray()
                'Templates(0) = New DPFP.Template()
                'Templates(0).DeSerialize(bytes)

                'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = midUsuario Select p.byTemplate2).Single
                'bytes = mTemplate.ToArray()
                'Templates(1) = New DPFP.Template()
                'Templates(1).DeSerialize(bytes)

                'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = midUsuario Select p.byTemplate3).Single
                'bytes = mTemplate.ToArray()
                'Templates(2) = New DPFP.Template()
                'Templates(2).DeSerialize(bytes)

                'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = midUsuario Select p.byTemplate4).Single
                'bytes = mTemplate.ToArray()
                'Templates(3) = New DPFP.Template()
                'Templates(3).DeSerialize(bytes)

                Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

                Dim midUsuario As Integer

                If IsNumeric(IntIdUsuarioClsComboBox.SelectedValue) Then
                    midUsuario = IntIdUsuarioClsComboBox.SelectedValue
                Else
                    midUsuario = IntIdUsuarioClsComboBox.SelectedValue.intIdUsuario
                End If


                Dim mTemplate
                Dim bytes As Byte() = Nothing

                Dim mtmpUsuario = dc.usp_TemplatesUsuario(midUsuario)
                Dim mtmpUsuario2 = mtmpUsuario(0)


                mTemplate = mtmpUsuario2.byTemplate1
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(0) = New DPFP.Template()
                    Templates(0).DeSerialize(bytes)
                End If

                mTemplate = mtmpUsuario2.byTemplate2
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(1) = New DPFP.Template()
                    Templates(1).DeSerialize(bytes)
                End If


                mTemplate = mtmpUsuario2.byTemplate3
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(2) = New DPFP.Template()
                    Templates(2).DeSerialize(bytes)
                End If

                mTemplate = mtmpUsuario2.byTemplate4
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(3) = New DPFP.Template()
                    Templates(3).DeSerialize(bytes)
                End If

                strIntIdUsuario = midUsuario

                mHuella = (From p In dc.tblUsuarios Where p.intIdUsuario = midUsuario Select p.bitValidaHuella).Single
                ClaveClsTextBox.Visible = Not mHuella
                Label2.Visible = Not mHuella

                mClave = (From p In dc.tblUsuarios Where p.intIdUsuario = midUsuario Select p.strClave).Single

            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub DtmFechaDateTimePicker_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles DtmFechaDateTimePicker.Validating
        If DtmFechaDateTimePicker.Value.DayOfWeek = DayOfWeek.Sunday Then 'Or DtmFechaDateTimePicker.Value.DayOfWeek = DayOfWeek.Saturday Then
            e.Cancel = True
            FechaErrorProvider.SetError(DtmFechaDateTimePicker, "Fecha no válida")
        Else
            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim mEsFestivo As Boolean = False
            Dim mFestivos = (From f In dc.tblFestivos Where f.dtmFecha = DtmFechaDateTimePicker.Value.Date Select f.intIdFestivo)
            For Each mFestivo In mFestivos
                mEsFestivo = True
            Next
            If mEsFestivo Then
                e.Cancel = True
                FechaErrorProvider.SetError(DtmFechaDateTimePicker, "Fecha no válida")
            Else
                FechaErrorProvider.SetError(DtmFechaDateTimePicker, Nothing)
            End If
        End If
    End Sub

    Private Sub DtmHoraMaskedTextBox_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DtmHoraMaskedTextBox.KeyUp
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
        ' Seguimos ejecutando el evento en el control base
        MyBase.OnKeyUp(e)
    End Sub

    Private Sub DtmHoraFinMaskedTextBox_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DtmHoraFinMaskedTextBox.KeyUp
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
        ' Seguimos ejecutando el evento en el control base
        MyBase.OnKeyUp(e)
    End Sub

    Private Sub ClaveClsTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClaveClsTextBox.TextChanged
        res.Verified = mClave.ToString = ClaveClsTextBox.Text 
    End Sub
End Class