﻿Public Class FrmVerHistoriaClinica
    Dim mstrStringConection As String
    Dim mCedula As String
    Dim mNombre As String
    Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

    Sub New(ByVal strStringConection As String, ByVal mCedulaPaciente As String, ByVal mNombrePaciente As String)
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            mstrStringConection = strStringConection
            mCedula = mCedulaPaciente
            'txtNombre.Text = mNombrePaciente
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
    Private Sub FrmVerHistoriaClinica_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim consultarCasos = dc.usp_ConsultarCasosDelPaciente(mCedula)
            BindingSourceCasosPaciente.DataSource = consultarCasos
        Catch ex As Exception

        End Try
    End Sub

    Private Sub BindingSourceCasosPaciente_PositionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingSourceCasosPaciente.PositionChanged
        Try
            Dim idCaso As Integer = BindingSourceCasosPaciente.Item(BindingSourceCasosPaciente.Position).intIdMotivoConsulta
            Dim Nrovisitas = dc.usp_ConsultarNroVisitasCasos(idCaso)
            BindingSourceVisitas.DataSource = Nrovisitas

        Catch ex As ArgumentOutOfRangeException
            ClsError.ClsError.PrMostrarError(New System.Exception("No se encontraron visitas para el caso"))
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class