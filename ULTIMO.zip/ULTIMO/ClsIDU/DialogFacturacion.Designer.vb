﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DialogFacturacion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.ClsTextBoxNroFact = New ClsUtilidades.ClsTextBox()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.ClsComboBox1 = New ClsUtilidades.ClsComboBox()
    Me.TblDatosPrestadoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.Label1 = New System.Windows.Forms.Label()
    Me.cbMotivoAbulacion = New ClsUtilidades.ClsComboBox()
    Me.lblMotivoAnulacion = New System.Windows.Forms.Label()
    Me.txtOtroMotivo = New System.Windows.Forms.TextBox()
    Me.TableLayoutPanel1.SuspendLayout()
    CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(345, 182)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 0
    Me.OK_Button.Text = "Aceptar"
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancelar"
    '
    'ClsTextBoxNroFact
    '
    Me.ClsTextBoxNroFact.DataSource = Nothing
    Me.ClsTextBoxNroFact.EnterEntreCampos = True
    Me.ClsTextBoxNroFact.Location = New System.Drawing.Point(144, 39)
    Me.ClsTextBoxNroFact.Name = "ClsTextBoxNroFact"
    Me.ClsTextBoxNroFact.NombreCodigoF2 = Nothing
    Me.ClsTextBoxNroFact.NombreDescripcionF2 = Nothing
    Me.ClsTextBoxNroFact.Size = New System.Drawing.Size(94, 20)
    Me.ClsTextBoxNroFact.TabIndex = 1
    Me.ClsTextBoxNroFact.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'Label4
    '
    Me.Label4.AutoSize = True
    Me.Label4.Location = New System.Drawing.Point(22, 42)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(66, 13)
    Me.Label4.TabIndex = 8
    Me.Label4.Text = "Nro Factura:"
    '
    'ClsComboBox1
    '
    Me.ClsComboBox1.DataSource = Me.TblDatosPrestadoresBindingSource
    Me.ClsComboBox1.DisplayMember = "strRazonSocial"
    Me.ClsComboBox1.FormattingEnabled = True
    Me.ClsComboBox1.Location = New System.Drawing.Point(144, 12)
    Me.ClsComboBox1.Name = "ClsComboBox1"
    Me.ClsComboBox1.Size = New System.Drawing.Size(324, 21)
    Me.ClsComboBox1.TabIndex = 0
    Me.ClsComboBox1.ValueMember = "intIdPrestadores"
    '
    'TblDatosPrestadoresBindingSource
    '
    Me.TblDatosPrestadoresBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDatosPrestadores)
    Me.TblDatosPrestadoresBindingSource.Sort = "strRazonSocial"
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(22, 15)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(97, 13)
    Me.Label1.TabIndex = 13
    Me.Label1.Text = "Entidad Prestadora"
    '
    'cbMotivoAbulacion
    '
    Me.cbMotivoAbulacion.DisplayMember = "intIdPrestadores"
    Me.cbMotivoAbulacion.FormattingEnabled = True
    Me.cbMotivoAbulacion.Location = New System.Drawing.Point(144, 68)
    Me.cbMotivoAbulacion.Name = "cbMotivoAbulacion"
    Me.cbMotivoAbulacion.Size = New System.Drawing.Size(324, 21)
    Me.cbMotivoAbulacion.TabIndex = 14
    Me.cbMotivoAbulacion.ValueMember = "intIdPrestadores"
    '
    'lblMotivoAnulacion
    '
    Me.lblMotivoAnulacion.AutoSize = True
    Me.lblMotivoAnulacion.Location = New System.Drawing.Point(22, 71)
    Me.lblMotivoAnulacion.Name = "lblMotivoAnulacion"
    Me.lblMotivoAnulacion.Size = New System.Drawing.Size(88, 13)
    Me.lblMotivoAnulacion.TabIndex = 15
    Me.lblMotivoAnulacion.Text = "Motivo anulación"
    '
    'txtOtroMotivo
    '
    Me.txtOtroMotivo.Location = New System.Drawing.Point(144, 96)
    Me.txtOtroMotivo.MaxLength = 2000
    Me.txtOtroMotivo.Multiline = True
    Me.txtOtroMotivo.Name = "txtOtroMotivo"
    Me.txtOtroMotivo.Size = New System.Drawing.Size(324, 70)
    Me.txtOtroMotivo.TabIndex = 16
    Me.txtOtroMotivo.Visible = False
    '
    'DialogFacturacion
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(503, 223)
    Me.Controls.Add(Me.txtOtroMotivo)
    Me.Controls.Add(Me.cbMotivoAbulacion)
    Me.Controls.Add(Me.lblMotivoAnulacion)
    Me.Controls.Add(Me.ClsComboBox1)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.Label4)
    Me.Controls.Add(Me.ClsTextBoxNroFact)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "DialogFacturacion"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Cancelar Factura"
    Me.TableLayoutPanel1.ResumeLayout(False)
    CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents ClsTextBoxNroFact As ClsUtilidades.ClsTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ClsComboBox1 As ClsUtilidades.ClsComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents TblDatosPrestadoresBindingSource As System.Windows.Forms.BindingSource
  Friend WithEvents cbMotivoAbulacion As ClsUtilidades.ClsComboBox
  Friend WithEvents lblMotivoAnulacion As System.Windows.Forms.Label
  Friend WithEvents txtOtroMotivo As System.Windows.Forms.TextBox

End Class
