﻿Public Class FrmTarifasBase

    'Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext()
    Public mstrStringConection As String
    Dim mDataContext 'As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext()

    Sub New(ByVal strStringConection As String)
        Try

            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
            mstrStringConection = strStringConection
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmTarifasBase_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            mDataContext = dc

            TblTarifaBaseBindingSource.DataSource = dc.tblTarifaBase
            TblProcedimientoBindingSource.DataSource = dc.tblProcedimiento
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub TblTarifaBaseBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles TblTarifaBaseBindingNavigatorSaveItem.Click
        Try
            TblTarifaBaseBindingSource.EndEdit()
            mDataContext.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblTarifaBaseDetalleDataGridView_DataError(sender As Object, e As Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblTarifaBaseDetalleDataGridView.DataError
        Try

        Catch ex As Exception
            'no hace nada
        End Try
    End Sub
End Class