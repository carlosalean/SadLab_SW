﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmRegistrarDatosFacturacion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim IntIdDiagNosticoPrincipalLabel As System.Windows.Forms.Label
    Dim IntIdDiagnosticoRelacionadoN1Label As System.Windows.Forms.Label
    Dim IntIdDiagnosticoRelacionadoN2Label As System.Windows.Forms.Label
    Dim IntIdDiagnosticoRelacionadoN3Label As System.Windows.Forms.Label
    Dim IntIdProfesionalLabel As System.Windows.Forms.Label
    Dim DtmFechaLabel As System.Windows.Forms.Label
    Dim StrCondicionPacienteLabel As System.Windows.Forms.Label
    Dim IntTipoProcedimientoLabel As System.Windows.Forms.Label
    Dim IntIdPersonalAtiendeLabel As System.Windows.Forms.Label
    Dim IntFormaRealizaActoQLabel As System.Windows.Forms.Label
    Dim IntIdClaseProcedimientoLabel As System.Windows.Forms.Label
    Dim IntIdComplicacionLabel As System.Windows.Forms.Label
    Dim IntIdDiagnosticoPosteriorLabel As System.Windows.Forms.Label
    Dim IntIdDiagnosticoPrevioLabel As System.Windows.Forms.Label
    Dim IntIdProcedimientoLabel As System.Windows.Forms.Label
    Dim DtmFechaAutorizacionLabel As System.Windows.Forms.Label
    Dim StrCodAtencionLabel As System.Windows.Forms.Label
    Dim StrNroOrdenLabel As System.Windows.Forms.Label
    Dim StrNroFacturaLabel As System.Windows.Forms.Label
    Dim NumValorDescuentoLabel As System.Windows.Forms.Label
    Dim NumValorCoopagoLabel As System.Windows.Forms.Label
    Dim IntNroServiciosLabel As System.Windows.Forms.Label
    Dim NumValorUnitarioLabel As System.Windows.Forms.Label
    Dim IntIdServicioLabel As System.Windows.Forms.Label
    Dim IntIdCitaLabel As System.Windows.Forms.Label
    Dim IntIdPacienteLabel As System.Windows.Forms.Label
    Dim Label1 As System.Windows.Forms.Label
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmRegistrarDatosFacturacion))
    Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
    Me.TblCitaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblCitaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
    Me.TblCitaBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
    Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
    Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
    Me.TblEmpeadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblServicioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblProcedimientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblDisgnosticoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblDisgnosticoPosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblComplicacionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblClaseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblFormaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblAtiendeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.GroupBox1 = New System.Windows.Forms.GroupBox()
    Me.TblCitaDataGridView = New System.Windows.Forms.DataGridView()
    Me.TblTipoEstadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.GroupBox2 = New System.Windows.Forms.GroupBox()
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1 = New ClsUtilidades.ClsComboBox()
    Me.TblDisgnosticoRe3BindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1 = New ClsUtilidades.ClsComboBox()
    Me.TblDisgnosticoRe2BindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1 = New ClsUtilidades.ClsComboBox()
    Me.TblDisgnosticoRe1BindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntIdDiagNosticoPrincipalClsComboBox1 = New ClsUtilidades.ClsComboBox()
    Me.TblDisgnosticoPrincipalBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.IntIdDiagNosticoPrincipalClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.PanelPRincipal = New System.Windows.Forms.Panel()
    Me.IntIdProfesionalClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.btnHabilitarCoopago = New System.Windows.Forms.Button()
    Me.DtmFechaDateTimePicker = New System.Windows.Forms.DateTimePicker()
    Me.ClsComboBox3 = New ClsUtilidades.ClsComboBox()
    Me.ClsComboBox2 = New ClsUtilidades.ClsComboBox()
    Me.ClsComboBox1 = New ClsUtilidades.ClsComboBox()
    Me.StrCondicionPacienteClsTextBox = New ClsUtilidades.ClsTextBox()
    Me.IntTipoProcedimientoClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntIdPersonalAtiendeClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntFormaRealizaActoQClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntIdClaseProcedimientoClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntIdComplicacionClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntIdDiagnosticoPosteriorClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntIdDiagnosticoPrevioClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.IntIdProcedimientoClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.DtmFechaAutorizacionClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
    Me.StrCodAtencionClsTextBox = New ClsUtilidades.ClsTextBox()
    Me.StrNroOrdenClsTextBox = New ClsUtilidades.ClsTextBox()
    Me.StrNroFacturaClsTextBox = New ClsUtilidades.ClsTextBox()
    Me.NumValorDescuentoClsTextBox = New ClsUtilidades.ClsTextBox()
    Me.NumValorCoopagoClsTextBox = New ClsUtilidades.ClsTextBox()
    Me.IntNroServiciosClsTextBox = New ClsUtilidades.ClsTextBox()
    Me.NumValorUnitarioClsTextBox = New ClsUtilidades.ClsTextBox()
    Me.IntIdServicioClsComboBox = New ClsUtilidades.ClsComboBox()
    Me.Panel1 = New System.Windows.Forms.Panel()
    Me.ClsComboBoxPrestador = New ClsUtilidades.ClsComboBox()
    Me.TblDatosPrestadoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
    Me.StrNroIdPacienteTextBox = New ClsUtilidades.ClsTextBox()
    Me.TextBoxNombre = New ClsUtilidades.ClsTextBox()
    Me.IntIdCitaTextBox = New ClsUtilidades.ClsTextBox()
    Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewComboBoxColumn()
    Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
    IntIdDiagNosticoPrincipalLabel = New System.Windows.Forms.Label()
    IntIdDiagnosticoRelacionadoN1Label = New System.Windows.Forms.Label()
    IntIdDiagnosticoRelacionadoN2Label = New System.Windows.Forms.Label()
    IntIdDiagnosticoRelacionadoN3Label = New System.Windows.Forms.Label()
    IntIdProfesionalLabel = New System.Windows.Forms.Label()
    DtmFechaLabel = New System.Windows.Forms.Label()
    StrCondicionPacienteLabel = New System.Windows.Forms.Label()
    IntTipoProcedimientoLabel = New System.Windows.Forms.Label()
    IntIdPersonalAtiendeLabel = New System.Windows.Forms.Label()
    IntFormaRealizaActoQLabel = New System.Windows.Forms.Label()
    IntIdClaseProcedimientoLabel = New System.Windows.Forms.Label()
    IntIdComplicacionLabel = New System.Windows.Forms.Label()
    IntIdDiagnosticoPosteriorLabel = New System.Windows.Forms.Label()
    IntIdDiagnosticoPrevioLabel = New System.Windows.Forms.Label()
    IntIdProcedimientoLabel = New System.Windows.Forms.Label()
    DtmFechaAutorizacionLabel = New System.Windows.Forms.Label()
    StrCodAtencionLabel = New System.Windows.Forms.Label()
    StrNroOrdenLabel = New System.Windows.Forms.Label()
    StrNroFacturaLabel = New System.Windows.Forms.Label()
    NumValorDescuentoLabel = New System.Windows.Forms.Label()
    NumValorCoopagoLabel = New System.Windows.Forms.Label()
    IntNroServiciosLabel = New System.Windows.Forms.Label()
    NumValorUnitarioLabel = New System.Windows.Forms.Label()
    IntIdServicioLabel = New System.Windows.Forms.Label()
    IntIdCitaLabel = New System.Windows.Forms.Label()
    IntIdPacienteLabel = New System.Windows.Forms.Label()
    Label1 = New System.Windows.Forms.Label()
    CType(Me.TblCitaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblCitaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.TblCitaBindingNavigator.SuspendLayout()
    CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblServicioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblDisgnosticoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblDisgnosticoPosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblComplicacionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblClaseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblFormaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblAtiendeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GroupBox1.SuspendLayout()
    CType(Me.TblCitaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblTipoEstadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GroupBox2.SuspendLayout()
    CType(Me.TblDisgnosticoRe3BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblDisgnosticoRe2BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblDisgnosticoRe1BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.TblDisgnosticoPrincipalBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.PanelPRincipal.SuspendLayout()
    Me.Panel1.SuspendLayout()
    CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'IntIdDiagNosticoPrincipalLabel
    '
    IntIdDiagNosticoPrincipalLabel.AutoSize = True
    IntIdDiagNosticoPrincipalLabel.Location = New System.Drawing.Point(6, 22)
    IntIdDiagNosticoPrincipalLabel.Name = "IntIdDiagNosticoPrincipalLabel"
    IntIdDiagNosticoPrincipalLabel.Size = New System.Drawing.Size(109, 13)
    IntIdDiagNosticoPrincipalLabel.TabIndex = 0
    IntIdDiagNosticoPrincipalLabel.Text = "Diagnostico Principal:"
    '
    'IntIdDiagnosticoRelacionadoN1Label
    '
    IntIdDiagnosticoRelacionadoN1Label.AutoSize = True
    IntIdDiagnosticoRelacionadoN1Label.Location = New System.Drawing.Point(6, 49)
    IntIdDiagnosticoRelacionadoN1Label.Name = "IntIdDiagnosticoRelacionadoN1Label"
    IntIdDiagnosticoRelacionadoN1Label.Size = New System.Drawing.Size(146, 13)
    IntIdDiagnosticoRelacionadoN1Label.TabIndex = 3
    IntIdDiagnosticoRelacionadoN1Label.Text = "Diagnostico Relacionado N1:"
    '
    'IntIdDiagnosticoRelacionadoN2Label
    '
    IntIdDiagnosticoRelacionadoN2Label.AutoSize = True
    IntIdDiagnosticoRelacionadoN2Label.Location = New System.Drawing.Point(6, 76)
    IntIdDiagnosticoRelacionadoN2Label.Name = "IntIdDiagnosticoRelacionadoN2Label"
    IntIdDiagnosticoRelacionadoN2Label.Size = New System.Drawing.Size(146, 13)
    IntIdDiagnosticoRelacionadoN2Label.TabIndex = 6
    IntIdDiagnosticoRelacionadoN2Label.Text = "Diagnostico Relacionado N2:"
    '
    'IntIdDiagnosticoRelacionadoN3Label
    '
    IntIdDiagnosticoRelacionadoN3Label.AutoSize = True
    IntIdDiagnosticoRelacionadoN3Label.Location = New System.Drawing.Point(6, 103)
    IntIdDiagnosticoRelacionadoN3Label.Name = "IntIdDiagnosticoRelacionadoN3Label"
    IntIdDiagnosticoRelacionadoN3Label.Size = New System.Drawing.Size(146, 13)
    IntIdDiagnosticoRelacionadoN3Label.TabIndex = 9
    IntIdDiagnosticoRelacionadoN3Label.Text = "Diagnostico Relacionado N3:"
    '
    'IntIdProfesionalLabel
    '
    IntIdProfesionalLabel.AutoSize = True
    IntIdProfesionalLabel.Location = New System.Drawing.Point(27, 40)
    IntIdProfesionalLabel.Name = "IntIdProfesionalLabel"
    IntIdProfesionalLabel.Size = New System.Drawing.Size(62, 13)
    IntIdProfesionalLabel.TabIndex = 110
    IntIdProfesionalLabel.Text = "Profesional:"
    '
    'DtmFechaLabel
    '
    DtmFechaLabel.AutoSize = True
    DtmFechaLabel.Location = New System.Drawing.Point(433, 120)
    DtmFechaLabel.Name = "DtmFechaLabel"
    DtmFechaLabel.Size = New System.Drawing.Size(40, 13)
    DtmFechaLabel.TabIndex = 109
    DtmFechaLabel.Text = "Fecha:"
    '
    'StrCondicionPacienteLabel
    '
    StrCondicionPacienteLabel.AutoSize = True
    StrCondicionPacienteLabel.Location = New System.Drawing.Point(27, 308)
    StrCondicionPacienteLabel.Name = "StrCondicionPacienteLabel"
    StrCondicionPacienteLabel.Size = New System.Drawing.Size(102, 13)
    StrCondicionPacienteLabel.TabIndex = 108
    StrCondicionPacienteLabel.Text = "Condicion Paciente:"
    '
    'IntTipoProcedimientoLabel
    '
    IntTipoProcedimientoLabel.AutoSize = True
    IntTipoProcedimientoLabel.Location = New System.Drawing.Point(288, 284)
    IntTipoProcedimientoLabel.Name = "IntTipoProcedimientoLabel"
    IntTipoProcedimientoLabel.Size = New System.Drawing.Size(101, 13)
    IntTipoProcedimientoLabel.TabIndex = 107
    IntTipoProcedimientoLabel.Text = "Tipo Procedimiento:"
    '
    'IntIdPersonalAtiendeLabel
    '
    IntIdPersonalAtiendeLabel.AutoSize = True
    IntIdPersonalAtiendeLabel.Location = New System.Drawing.Point(27, 281)
    IntIdPersonalAtiendeLabel.Name = "IntIdPersonalAtiendeLabel"
    IntIdPersonalAtiendeLabel.Size = New System.Drawing.Size(90, 13)
    IntIdPersonalAtiendeLabel.TabIndex = 106
    IntIdPersonalAtiendeLabel.Text = "Personal Atiende:"
    '
    'IntFormaRealizaActoQLabel
    '
    IntFormaRealizaActoQLabel.AutoSize = True
    IntFormaRealizaActoQLabel.Location = New System.Drawing.Point(288, 257)
    IntFormaRealizaActoQLabel.Name = "IntFormaRealizaActoQLabel"
    IntFormaRealizaActoQLabel.Size = New System.Drawing.Size(153, 13)
    IntFormaRealizaActoQLabel.TabIndex = 105
    IntFormaRealizaActoQLabel.Text = "Forma Realiza Acto Quirurgico:"
    '
    'IntIdClaseProcedimientoLabel
    '
    IntIdClaseProcedimientoLabel.AutoSize = True
    IntIdClaseProcedimientoLabel.Location = New System.Drawing.Point(28, 254)
    IntIdClaseProcedimientoLabel.Name = "IntIdClaseProcedimientoLabel"
    IntIdClaseProcedimientoLabel.Size = New System.Drawing.Size(106, 13)
    IntIdClaseProcedimientoLabel.TabIndex = 104
    IntIdClaseProcedimientoLabel.Text = "Clase Procedimiento:"
    '
    'IntIdComplicacionLabel
    '
    IntIdComplicacionLabel.AutoSize = True
    IntIdComplicacionLabel.Location = New System.Drawing.Point(27, 227)
    IntIdComplicacionLabel.Name = "IntIdComplicacionLabel"
    IntIdComplicacionLabel.Size = New System.Drawing.Size(73, 13)
    IntIdComplicacionLabel.TabIndex = 103
    IntIdComplicacionLabel.Text = "Complicacion:"
    '
    'IntIdDiagnosticoPosteriorLabel
    '
    IntIdDiagnosticoPosteriorLabel.AutoSize = True
    IntIdDiagnosticoPosteriorLabel.Location = New System.Drawing.Point(27, 200)
    IntIdDiagnosticoPosteriorLabel.Name = "IntIdDiagnosticoPosteriorLabel"
    IntIdDiagnosticoPosteriorLabel.Size = New System.Drawing.Size(90, 13)
    IntIdDiagnosticoPosteriorLabel.TabIndex = 102
    IntIdDiagnosticoPosteriorLabel.Text = "Diagnostico Post:"
    '
    'IntIdDiagnosticoPrevioLabel
    '
    IntIdDiagnosticoPrevioLabel.AutoSize = True
    IntIdDiagnosticoPrevioLabel.Location = New System.Drawing.Point(27, 173)
    IntIdDiagnosticoPrevioLabel.Name = "IntIdDiagnosticoPrevioLabel"
    IntIdDiagnosticoPrevioLabel.Size = New System.Drawing.Size(99, 13)
    IntIdDiagnosticoPrevioLabel.TabIndex = 101
    IntIdDiagnosticoPrevioLabel.Text = "Diagnostico Previo:"
    '
    'IntIdProcedimientoLabel
    '
    IntIdProcedimientoLabel.AutoSize = True
    IntIdProcedimientoLabel.Location = New System.Drawing.Point(27, 146)
    IntIdProcedimientoLabel.Name = "IntIdProcedimientoLabel"
    IntIdProcedimientoLabel.Size = New System.Drawing.Size(77, 13)
    IntIdProcedimientoLabel.TabIndex = 100
    IntIdProcedimientoLabel.Text = "Procedimiento:"
    '
    'DtmFechaAutorizacionLabel
    '
    DtmFechaAutorizacionLabel.AutoSize = True
    DtmFechaAutorizacionLabel.Location = New System.Drawing.Point(27, 120)
    DtmFechaAutorizacionLabel.Name = "DtmFechaAutorizacionLabel"
    DtmFechaAutorizacionLabel.Size = New System.Drawing.Size(101, 13)
    DtmFechaAutorizacionLabel.TabIndex = 99
    DtmFechaAutorizacionLabel.Text = "Fecha Autorizacion:"
    '
    'StrCodAtencionLabel
    '
    StrCodAtencionLabel.AutoSize = True
    StrCodAtencionLabel.Location = New System.Drawing.Point(243, 120)
    StrCodAtencionLabel.Name = "StrCodAtencionLabel"
    StrCodAtencionLabel.Size = New System.Drawing.Size(74, 13)
    StrCodAtencionLabel.TabIndex = 98
    StrCodAtencionLabel.Text = "Cod Atención:"
    '
    'StrNroOrdenLabel
    '
    StrNroOrdenLabel.AutoSize = True
    StrNroOrdenLabel.Location = New System.Drawing.Point(433, 94)
    StrNroOrdenLabel.Name = "StrNroOrdenLabel"
    StrNroOrdenLabel.Size = New System.Drawing.Size(88, 13)
    StrNroOrdenLabel.TabIndex = 97
    StrNroOrdenLabel.Text = "Nro Autorización:"
    '
    'StrNroFacturaLabel
    '
    StrNroFacturaLabel.AutoSize = True
    StrNroFacturaLabel.Location = New System.Drawing.Point(243, 94)
    StrNroFacturaLabel.Name = "StrNroFacturaLabel"
    StrNroFacturaLabel.Size = New System.Drawing.Size(66, 13)
    StrNroFacturaLabel.TabIndex = 96
    StrNroFacturaLabel.Text = "Nro Factura:"
    '
    'NumValorDescuentoLabel
    '
    NumValorDescuentoLabel.AutoSize = True
    NumValorDescuentoLabel.Location = New System.Drawing.Point(27, 94)
    NumValorDescuentoLabel.Name = "NumValorDescuentoLabel"
    NumValorDescuentoLabel.Size = New System.Drawing.Size(89, 13)
    NumValorDescuentoLabel.TabIndex = 95
    NumValorDescuentoLabel.Text = "Valor Descuento:"
    '
    'NumValorCoopagoLabel
    '
    NumValorCoopagoLabel.AutoSize = True
    NumValorCoopagoLabel.Location = New System.Drawing.Point(433, 68)
    NumValorCoopagoLabel.Name = "NumValorCoopagoLabel"
    NumValorCoopagoLabel.Size = New System.Drawing.Size(80, 13)
    NumValorCoopagoLabel.TabIndex = 94
    NumValorCoopagoLabel.Text = "Valor Coopago:"
    '
    'IntNroServiciosLabel
    '
    IntNroServiciosLabel.AutoSize = True
    IntNroServiciosLabel.Location = New System.Drawing.Point(243, 68)
    IntNroServiciosLabel.Name = "IntNroServiciosLabel"
    IntNroServiciosLabel.Size = New System.Drawing.Size(73, 13)
    IntNroServiciosLabel.TabIndex = 93
    IntNroServiciosLabel.Text = "Nro Servicios:"
    '
    'NumValorUnitarioLabel
    '
    NumValorUnitarioLabel.AutoSize = True
    NumValorUnitarioLabel.Location = New System.Drawing.Point(28, 65)
    NumValorUnitarioLabel.Name = "NumValorUnitarioLabel"
    NumValorUnitarioLabel.Size = New System.Drawing.Size(73, 13)
    NumValorUnitarioLabel.TabIndex = 92
    NumValorUnitarioLabel.Text = "Valor Unitario:"
    '
    'IntIdServicioLabel
    '
    IntIdServicioLabel.AutoSize = True
    IntIdServicioLabel.Location = New System.Drawing.Point(28, 13)
    IntIdServicioLabel.Name = "IntIdServicioLabel"
    IntIdServicioLabel.Size = New System.Drawing.Size(48, 13)
    IntIdServicioLabel.TabIndex = 91
    IntIdServicioLabel.Text = "Servicio:"
    '
    'IntIdCitaLabel
    '
    IntIdCitaLabel.AutoSize = True
    IntIdCitaLabel.Location = New System.Drawing.Point(26, 17)
    IntIdCitaLabel.Name = "IntIdCitaLabel"
    IntIdCitaLabel.Size = New System.Drawing.Size(19, 13)
    IntIdCitaLabel.TabIndex = 94
    IntIdCitaLabel.Text = "Id:"
    '
    'IntIdPacienteLabel
    '
    IntIdPacienteLabel.AutoSize = True
    IntIdPacienteLabel.Location = New System.Drawing.Point(26, 43)
    IntIdPacienteLabel.Name = "IntIdPacienteLabel"
    IntIdPacienteLabel.Size = New System.Drawing.Size(52, 13)
    IntIdPacienteLabel.TabIndex = 95
    IntIdPacienteLabel.Text = "Paciente:"
    '
    'Label1
    '
    Label1.AutoSize = True
    Label1.Location = New System.Drawing.Point(188, 17)
    Label1.Name = "Label1"
    Label1.Size = New System.Drawing.Size(113, 13)
    Label1.TabIndex = 97
    Label1.Text = "Prestador del Servicio:"
    '
    'TblCitaBindingSource
    '
    Me.TblCitaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCita)
    '
    'TblCitaBindingNavigator
    '
    Me.TblCitaBindingNavigator.AddNewItem = Nothing
    Me.TblCitaBindingNavigator.BindingSource = Me.TblCitaBindingSource
    Me.TblCitaBindingNavigator.CountItem = Nothing
    Me.TblCitaBindingNavigator.DeleteItem = Nothing
    Me.TblCitaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TblCitaBindingNavigatorSaveItem, Me.ToolStripSeparator1, Me.ToolStripButton1})
    Me.TblCitaBindingNavigator.Location = New System.Drawing.Point(0, 0)
    Me.TblCitaBindingNavigator.MoveFirstItem = Nothing
    Me.TblCitaBindingNavigator.MoveLastItem = Nothing
    Me.TblCitaBindingNavigator.MoveNextItem = Nothing
    Me.TblCitaBindingNavigator.MovePreviousItem = Nothing
    Me.TblCitaBindingNavigator.Name = "TblCitaBindingNavigator"
    Me.TblCitaBindingNavigator.PositionItem = Nothing
    Me.TblCitaBindingNavigator.Size = New System.Drawing.Size(995, 25)
    Me.TblCitaBindingNavigator.TabIndex = 27
    Me.TblCitaBindingNavigator.Text = "BindingNavigator1"
    '
    'TblCitaBindingNavigatorSaveItem
    '
    Me.TblCitaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.TblCitaBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblCitaBindingNavigatorSaveItem.Image"), System.Drawing.Image)
    Me.TblCitaBindingNavigatorSaveItem.Name = "TblCitaBindingNavigatorSaveItem"
    Me.TblCitaBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
    Me.TblCitaBindingNavigatorSaveItem.Text = "Save Data"
    '
    'ToolStripSeparator1
    '
    Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
    Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
    '
    'ToolStripButton1
    '
    Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
    Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.ToolStripButton1.Name = "ToolStripButton1"
    Me.ToolStripButton1.Size = New System.Drawing.Size(23, 22)
    Me.ToolStripButton1.Text = "Adicionar Nuevo Consecutivo de Facturación"
    '
    'TblEmpeadoBindingSource
    '
    Me.TblEmpeadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEmpeados)
    Me.TblEmpeadoBindingSource.Sort = "strNombreEmpleado"
    '
    'TblServicioBindingSource
    '
    Me.TblServicioBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblServicio)
    Me.TblServicioBindingSource.Sort = "strNombre"
    '
    'TblProcedimientoBindingSource
    '
    Me.TblProcedimientoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
    Me.TblProcedimientoBindingSource.Sort = "strNombre"
    '
    'TblDisgnosticoBindingSource
    '
    Me.TblDisgnosticoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
    Me.TblDisgnosticoBindingSource.Sort = ""
    '
    'TblDisgnosticoPosBindingSource
    '
    Me.TblDisgnosticoPosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
    '
    'TblComplicacionBindingSource
    '
    Me.TblComplicacionBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
    '
    'TblClaseBindingSource
    '
    Me.TblClaseBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
    '
    'TblFormaBindingSource
    '
    Me.TblFormaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
    '
    'TblAtiendeBindingSource
    '
    Me.TblAtiendeBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
    '
    'TblTipoBindingSource
    '
    Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
    '
    'GroupBox1
    '
    Me.GroupBox1.Controls.Add(Me.TblCitaDataGridView)
    Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Right
    Me.GroupBox1.Location = New System.Drawing.Point(684, 25)
    Me.GroupBox1.Name = "GroupBox1"
    Me.GroupBox1.Size = New System.Drawing.Size(311, 553)
    Me.GroupBox1.TabIndex = 3
    Me.GroupBox1.TabStop = False
    Me.GroupBox1.Text = "Citas"
    '
    'TblCitaDataGridView
    '
    Me.TblCitaDataGridView.AllowUserToAddRows = False
    Me.TblCitaDataGridView.AllowUserToDeleteRows = False
    Me.TblCitaDataGridView.AutoGenerateColumns = False
    Me.TblCitaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
    Me.TblCitaDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn10})
    Me.TblCitaDataGridView.DataSource = Me.TblCitaBindingSource
    Me.TblCitaDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
    Me.TblCitaDataGridView.Location = New System.Drawing.Point(3, 16)
    Me.TblCitaDataGridView.Name = "TblCitaDataGridView"
    Me.TblCitaDataGridView.ReadOnly = True
    Me.TblCitaDataGridView.Size = New System.Drawing.Size(305, 534)
    Me.TblCitaDataGridView.TabIndex = 0
    '
    'TblTipoEstadoBindingSource
    '
    Me.TblTipoEstadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
    '
    'GroupBox2
    '
    Me.GroupBox2.Controls.Add(Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1)
    Me.GroupBox2.Controls.Add(IntIdDiagnosticoRelacionadoN3Label)
    Me.GroupBox2.Controls.Add(Me.IntIdDiagnosticoRelacionadoN3ClsComboBox)
    Me.GroupBox2.Controls.Add(Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1)
    Me.GroupBox2.Controls.Add(IntIdDiagnosticoRelacionadoN2Label)
    Me.GroupBox2.Controls.Add(Me.IntIdDiagnosticoRelacionadoN2ClsComboBox)
    Me.GroupBox2.Controls.Add(Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1)
    Me.GroupBox2.Controls.Add(IntIdDiagnosticoRelacionadoN1Label)
    Me.GroupBox2.Controls.Add(Me.IntIdDiagnosticoRelacionadoN1ClsComboBox)
    Me.GroupBox2.Controls.Add(Me.IntIdDiagNosticoPrincipalClsComboBox1)
    Me.GroupBox2.Controls.Add(IntIdDiagNosticoPrincipalLabel)
    Me.GroupBox2.Controls.Add(Me.IntIdDiagNosticoPrincipalClsComboBox)
    Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Bottom
    Me.GroupBox2.Location = New System.Drawing.Point(0, 447)
    Me.GroupBox2.Name = "GroupBox2"
    Me.GroupBox2.Size = New System.Drawing.Size(684, 131)
    Me.GroupBox2.TabIndex = 2
    Me.GroupBox2.TabStop = False
    Me.GroupBox2.Text = "Datos de Consulta"
    '
    'IntIdDiagnosticoRelacionadoN3ClsComboBox1
    '
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoRelacionadoN3", True))
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1.DataSource = Me.TblDisgnosticoRe3BindingSource
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1.DisplayMember = "strNombre"
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1.FormattingEnabled = True
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1.Location = New System.Drawing.Point(229, 100)
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1.Name = "IntIdDiagnosticoRelacionadoN3ClsComboBox1"
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1.Size = New System.Drawing.Size(369, 21)
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1.TabIndex = 7
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox1.ValueMember = "intIdDiagnostico"
    '
    'TblDisgnosticoRe3BindingSource
    '
    Me.TblDisgnosticoRe3BindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
    '
    'IntIdDiagnosticoRelacionadoN3ClsComboBox
    '
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoRelacionadoN3", True))
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.DataSource = Me.TblDisgnosticoRe3BindingSource
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.DisplayMember = "strCodigo"
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.FormattingEnabled = True
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.Location = New System.Drawing.Point(158, 100)
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.Name = "IntIdDiagnosticoRelacionadoN3ClsComboBox"
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.Size = New System.Drawing.Size(69, 21)
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.TabIndex = 6
    Me.IntIdDiagnosticoRelacionadoN3ClsComboBox.ValueMember = "intIdDiagnostico"
    '
    'IntIdDiagnosticoRelacionadoN2ClsComboBox1
    '
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoRelacionadoN2", True))
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.DataSource = Me.TblDisgnosticoRe2BindingSource
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.DisplayMember = "strNombre"
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.FormattingEnabled = True
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.Location = New System.Drawing.Point(229, 73)
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.Name = "IntIdDiagnosticoRelacionadoN2ClsComboBox1"
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.Size = New System.Drawing.Size(369, 21)
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.TabIndex = 5
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox1.ValueMember = "intIdDiagnostico"
    '
    'TblDisgnosticoRe2BindingSource
    '
    Me.TblDisgnosticoRe2BindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
    '
    'IntIdDiagnosticoRelacionadoN2ClsComboBox
    '
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoRelacionadoN2", True))
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.DataSource = Me.TblDisgnosticoRe2BindingSource
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.DisplayMember = "strCodigo"
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.FormattingEnabled = True
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.Location = New System.Drawing.Point(158, 73)
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.Name = "IntIdDiagnosticoRelacionadoN2ClsComboBox"
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.Size = New System.Drawing.Size(69, 21)
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.TabIndex = 4
    Me.IntIdDiagnosticoRelacionadoN2ClsComboBox.ValueMember = "intIdDiagnostico"
    '
    'IntIdDiagnosticoRelacionadoN1ClsComboBox1
    '
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoRelacionadoN1", True))
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.DataSource = Me.TblDisgnosticoRe1BindingSource
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.DisplayMember = "strNombre"
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.FormattingEnabled = True
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.Location = New System.Drawing.Point(229, 46)
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.Name = "IntIdDiagnosticoRelacionadoN1ClsComboBox1"
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.Size = New System.Drawing.Size(370, 21)
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.TabIndex = 3
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox1.ValueMember = "intIdDiagnostico"
    '
    'TblDisgnosticoRe1BindingSource
    '
    Me.TblDisgnosticoRe1BindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
    '
    'IntIdDiagnosticoRelacionadoN1ClsComboBox
    '
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoRelacionadoN1", True))
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.DataSource = Me.TblDisgnosticoRe1BindingSource
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.DisplayMember = "strCodigo"
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.FormattingEnabled = True
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.Location = New System.Drawing.Point(158, 46)
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.Name = "IntIdDiagnosticoRelacionadoN1ClsComboBox"
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.Size = New System.Drawing.Size(69, 21)
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.TabIndex = 2
    Me.IntIdDiagnosticoRelacionadoN1ClsComboBox.ValueMember = "intIdDiagnostico"
    '
    'IntIdDiagNosticoPrincipalClsComboBox1
    '
    Me.IntIdDiagNosticoPrincipalClsComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
    Me.IntIdDiagNosticoPrincipalClsComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdDiagNosticoPrincipalClsComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagNosticoPrincipal", True))
    Me.IntIdDiagNosticoPrincipalClsComboBox1.DataSource = Me.TblDisgnosticoPrincipalBindingSource
    Me.IntIdDiagNosticoPrincipalClsComboBox1.DisplayMember = "strNombre"
    Me.IntIdDiagNosticoPrincipalClsComboBox1.FormattingEnabled = True
    Me.IntIdDiagNosticoPrincipalClsComboBox1.Location = New System.Drawing.Point(229, 19)
    Me.IntIdDiagNosticoPrincipalClsComboBox1.Name = "IntIdDiagNosticoPrincipalClsComboBox1"
    Me.IntIdDiagNosticoPrincipalClsComboBox1.Size = New System.Drawing.Size(369, 21)
    Me.IntIdDiagNosticoPrincipalClsComboBox1.TabIndex = 1
    Me.IntIdDiagNosticoPrincipalClsComboBox1.ValueMember = "intIdDiagnostico"
    '
    'TblDisgnosticoPrincipalBindingSource
    '
    Me.TblDisgnosticoPrincipalBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
    '
    'IntIdDiagNosticoPrincipalClsComboBox
    '
    Me.IntIdDiagNosticoPrincipalClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
    Me.IntIdDiagNosticoPrincipalClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdDiagNosticoPrincipalClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagNosticoPrincipal", True))
    Me.IntIdDiagNosticoPrincipalClsComboBox.DataSource = Me.TblDisgnosticoPrincipalBindingSource
    Me.IntIdDiagNosticoPrincipalClsComboBox.DisplayMember = "strCodigo"
    Me.IntIdDiagNosticoPrincipalClsComboBox.FormattingEnabled = True
    Me.IntIdDiagNosticoPrincipalClsComboBox.Location = New System.Drawing.Point(158, 19)
    Me.IntIdDiagNosticoPrincipalClsComboBox.Name = "IntIdDiagNosticoPrincipalClsComboBox"
    Me.IntIdDiagNosticoPrincipalClsComboBox.Size = New System.Drawing.Size(68, 21)
    Me.IntIdDiagNosticoPrincipalClsComboBox.TabIndex = 0
    Me.IntIdDiagNosticoPrincipalClsComboBox.ValueMember = "intIdDiagnostico"
    '
    'PanelPRincipal
    '
    Me.PanelPRincipal.Controls.Add(IntIdProfesionalLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntIdProfesionalClsComboBox)
    Me.PanelPRincipal.Controls.Add(Me.btnHabilitarCoopago)
    Me.PanelPRincipal.Controls.Add(DtmFechaLabel)
    Me.PanelPRincipal.Controls.Add(Me.DtmFechaDateTimePicker)
    Me.PanelPRincipal.Controls.Add(Me.ClsComboBox3)
    Me.PanelPRincipal.Controls.Add(Me.ClsComboBox2)
    Me.PanelPRincipal.Controls.Add(Me.ClsComboBox1)
    Me.PanelPRincipal.Controls.Add(StrCondicionPacienteLabel)
    Me.PanelPRincipal.Controls.Add(Me.StrCondicionPacienteClsTextBox)
    Me.PanelPRincipal.Controls.Add(IntTipoProcedimientoLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntTipoProcedimientoClsComboBox)
    Me.PanelPRincipal.Controls.Add(IntIdPersonalAtiendeLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntIdPersonalAtiendeClsComboBox)
    Me.PanelPRincipal.Controls.Add(IntFormaRealizaActoQLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntFormaRealizaActoQClsComboBox)
    Me.PanelPRincipal.Controls.Add(IntIdClaseProcedimientoLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntIdClaseProcedimientoClsComboBox)
    Me.PanelPRincipal.Controls.Add(IntIdComplicacionLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntIdComplicacionClsComboBox)
    Me.PanelPRincipal.Controls.Add(IntIdDiagnosticoPosteriorLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntIdDiagnosticoPosteriorClsComboBox)
    Me.PanelPRincipal.Controls.Add(IntIdDiagnosticoPrevioLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntIdDiagnosticoPrevioClsComboBox)
    Me.PanelPRincipal.Controls.Add(IntIdProcedimientoLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntIdProcedimientoClsComboBox)
    Me.PanelPRincipal.Controls.Add(DtmFechaAutorizacionLabel)
    Me.PanelPRincipal.Controls.Add(Me.DtmFechaAutorizacionClsDateTimePicker)
    Me.PanelPRincipal.Controls.Add(StrCodAtencionLabel)
    Me.PanelPRincipal.Controls.Add(Me.StrCodAtencionClsTextBox)
    Me.PanelPRincipal.Controls.Add(StrNroOrdenLabel)
    Me.PanelPRincipal.Controls.Add(Me.StrNroOrdenClsTextBox)
    Me.PanelPRincipal.Controls.Add(StrNroFacturaLabel)
    Me.PanelPRincipal.Controls.Add(Me.StrNroFacturaClsTextBox)
    Me.PanelPRincipal.Controls.Add(NumValorDescuentoLabel)
    Me.PanelPRincipal.Controls.Add(Me.NumValorDescuentoClsTextBox)
    Me.PanelPRincipal.Controls.Add(NumValorCoopagoLabel)
    Me.PanelPRincipal.Controls.Add(Me.NumValorCoopagoClsTextBox)
    Me.PanelPRincipal.Controls.Add(IntNroServiciosLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntNroServiciosClsTextBox)
    Me.PanelPRincipal.Controls.Add(NumValorUnitarioLabel)
    Me.PanelPRincipal.Controls.Add(Me.NumValorUnitarioClsTextBox)
    Me.PanelPRincipal.Controls.Add(IntIdServicioLabel)
    Me.PanelPRincipal.Controls.Add(Me.IntIdServicioClsComboBox)
    Me.PanelPRincipal.Dock = System.Windows.Forms.DockStyle.Fill
    Me.PanelPRincipal.Location = New System.Drawing.Point(0, 88)
    Me.PanelPRincipal.Name = "PanelPRincipal"
    Me.PanelPRincipal.Size = New System.Drawing.Size(684, 359)
    Me.PanelPRincipal.TabIndex = 1
    '
    'IntIdProfesionalClsComboBox
    '
    Me.IntIdProfesionalClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdProfesional", True))
    Me.IntIdProfesionalClsComboBox.DataSource = Me.TblEmpeadoBindingSource
    Me.IntIdProfesionalClsComboBox.DisplayMember = "strNombreEmpleado"
    Me.IntIdProfesionalClsComboBox.Enabled = False
    Me.IntIdProfesionalClsComboBox.FormattingEnabled = True
    Me.IntIdProfesionalClsComboBox.Location = New System.Drawing.Point(136, 37)
    Me.IntIdProfesionalClsComboBox.Name = "IntIdProfesionalClsComboBox"
    Me.IntIdProfesionalClsComboBox.Size = New System.Drawing.Size(486, 21)
    Me.IntIdProfesionalClsComboBox.TabIndex = 1
    Me.IntIdProfesionalClsComboBox.ValueMember = "intIdCodigoEmpleado"
    '
    'btnHabilitarCoopago
    '
    Me.btnHabilitarCoopago.Location = New System.Drawing.Point(631, 65)
    Me.btnHabilitarCoopago.Name = "btnHabilitarCoopago"
    Me.btnHabilitarCoopago.Size = New System.Drawing.Size(26, 20)
    Me.btnHabilitarCoopago.TabIndex = 23
    Me.btnHabilitarCoopago.Text = "H"
    Me.btnHabilitarCoopago.UseVisualStyleBackColor = True
    '
    'DtmFechaDateTimePicker
    '
    Me.DtmFechaDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblCitaBindingSource, "dtmFecha", True))
    Me.DtmFechaDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
    Me.DtmFechaDateTimePicker.Location = New System.Drawing.Point(523, 116)
    Me.DtmFechaDateTimePicker.Name = "DtmFechaDateTimePicker"
    Me.DtmFechaDateTimePicker.Size = New System.Drawing.Size(101, 20)
    Me.DtmFechaDateTimePicker.TabIndex = 10
    '
    'ClsComboBox3
    '
    Me.ClsComboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.ClsComboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.ClsComboBox3.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdComplicacion", True))
    Me.ClsComboBox3.DataSource = Me.TblComplicacionBindingSource
    Me.ClsComboBox3.DisplayMember = "strCodigo"
    Me.ClsComboBox3.FormattingEnabled = True
    Me.ClsComboBox3.Location = New System.Drawing.Point(136, 224)
    Me.ClsComboBox3.Name = "ClsComboBox3"
    Me.ClsComboBox3.Size = New System.Drawing.Size(69, 21)
    Me.ClsComboBox3.TabIndex = 16
    Me.ClsComboBox3.ValueMember = "intIdDiagnostico"
    '
    'ClsComboBox2
    '
    Me.ClsComboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.ClsComboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.ClsComboBox2.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoPosterior", True))
    Me.ClsComboBox2.DataSource = Me.TblDisgnosticoPosBindingSource
    Me.ClsComboBox2.DisplayMember = "strCodigo"
    Me.ClsComboBox2.FormattingEnabled = True
    Me.ClsComboBox2.Location = New System.Drawing.Point(136, 197)
    Me.ClsComboBox2.Name = "ClsComboBox2"
    Me.ClsComboBox2.Size = New System.Drawing.Size(69, 21)
    Me.ClsComboBox2.TabIndex = 14
    Me.ClsComboBox2.ValueMember = "intIdDiagnostico"
    '
    'ClsComboBox1
    '
    Me.ClsComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.ClsComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.ClsComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoPrevio", True))
    Me.ClsComboBox1.DataSource = Me.TblDisgnosticoBindingSource
    Me.ClsComboBox1.DisplayMember = "strCodigo"
    Me.ClsComboBox1.FormattingEnabled = True
    Me.ClsComboBox1.Location = New System.Drawing.Point(136, 170)
    Me.ClsComboBox1.Name = "ClsComboBox1"
    Me.ClsComboBox1.Size = New System.Drawing.Size(69, 21)
    Me.ClsComboBox1.TabIndex = 12
    Me.ClsComboBox1.ValueMember = "intIdDiagnostico"
    '
    'StrCondicionPacienteClsTextBox
    '
    Me.StrCondicionPacienteClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strCondicionPaciente", True))
    Me.StrCondicionPacienteClsTextBox.DataSource = Nothing
    Me.StrCondicionPacienteClsTextBox.EnterEntreCampos = True
    Me.StrCondicionPacienteClsTextBox.Location = New System.Drawing.Point(136, 305)
    Me.StrCondicionPacienteClsTextBox.Multiline = True
    Me.StrCondicionPacienteClsTextBox.Name = "StrCondicionPacienteClsTextBox"
    Me.StrCondicionPacienteClsTextBox.NombreCodigoF2 = Nothing
    Me.StrCondicionPacienteClsTextBox.NombreDescripcionF2 = Nothing
    Me.StrCondicionPacienteClsTextBox.Size = New System.Drawing.Size(487, 43)
    Me.StrCondicionPacienteClsTextBox.TabIndex = 22
    Me.StrCondicionPacienteClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'IntTipoProcedimientoClsComboBox
    '
    Me.IntTipoProcedimientoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intTipoProcedimiento", True))
    Me.IntTipoProcedimientoClsComboBox.DataSource = Me.TblTipoBindingSource
    Me.IntTipoProcedimientoClsComboBox.DisplayMember = "strValor"
    Me.IntTipoProcedimientoClsComboBox.FormattingEnabled = True
    Me.IntTipoProcedimientoClsComboBox.Location = New System.Drawing.Point(395, 281)
    Me.IntTipoProcedimientoClsComboBox.Name = "IntTipoProcedimientoClsComboBox"
    Me.IntTipoProcedimientoClsComboBox.Size = New System.Drawing.Size(227, 21)
    Me.IntTipoProcedimientoClsComboBox.TabIndex = 21
    Me.IntTipoProcedimientoClsComboBox.ValueMember = "intIdTipo"
    '
    'IntIdPersonalAtiendeClsComboBox
    '
    Me.IntIdPersonalAtiendeClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdPersonalAtiende", True))
    Me.IntIdPersonalAtiendeClsComboBox.DataSource = Me.TblAtiendeBindingSource
    Me.IntIdPersonalAtiendeClsComboBox.DisplayMember = "strValor"
    Me.IntIdPersonalAtiendeClsComboBox.FormattingEnabled = True
    Me.IntIdPersonalAtiendeClsComboBox.Location = New System.Drawing.Point(136, 278)
    Me.IntIdPersonalAtiendeClsComboBox.Name = "IntIdPersonalAtiendeClsComboBox"
    Me.IntIdPersonalAtiendeClsComboBox.Size = New System.Drawing.Size(146, 21)
    Me.IntIdPersonalAtiendeClsComboBox.TabIndex = 20
    Me.IntIdPersonalAtiendeClsComboBox.ValueMember = "intIdTipo"
    '
    'IntFormaRealizaActoQClsComboBox
    '
    Me.IntFormaRealizaActoQClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intFormaRealizaActoQ", True))
    Me.IntFormaRealizaActoQClsComboBox.DataSource = Me.TblFormaBindingSource
    Me.IntFormaRealizaActoQClsComboBox.DisplayMember = "strValor"
    Me.IntFormaRealizaActoQClsComboBox.FormattingEnabled = True
    Me.IntFormaRealizaActoQClsComboBox.Location = New System.Drawing.Point(447, 254)
    Me.IntFormaRealizaActoQClsComboBox.Name = "IntFormaRealizaActoQClsComboBox"
    Me.IntFormaRealizaActoQClsComboBox.Size = New System.Drawing.Size(175, 21)
    Me.IntFormaRealizaActoQClsComboBox.TabIndex = 19
    Me.IntFormaRealizaActoQClsComboBox.ValueMember = "intIdTipo"
    '
    'IntIdClaseProcedimientoClsComboBox
    '
    Me.IntIdClaseProcedimientoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdClaseProcedimiento", True))
    Me.IntIdClaseProcedimientoClsComboBox.DataSource = Me.TblClaseBindingSource
    Me.IntIdClaseProcedimientoClsComboBox.DisplayMember = "strValor"
    Me.IntIdClaseProcedimientoClsComboBox.FormattingEnabled = True
    Me.IntIdClaseProcedimientoClsComboBox.Location = New System.Drawing.Point(136, 251)
    Me.IntIdClaseProcedimientoClsComboBox.Name = "IntIdClaseProcedimientoClsComboBox"
    Me.IntIdClaseProcedimientoClsComboBox.Size = New System.Drawing.Size(146, 21)
    Me.IntIdClaseProcedimientoClsComboBox.TabIndex = 18
    Me.IntIdClaseProcedimientoClsComboBox.ValueMember = "intIdTipo"
    '
    'IntIdComplicacionClsComboBox
    '
    Me.IntIdComplicacionClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.IntIdComplicacionClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdComplicacionClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdComplicacion", True))
    Me.IntIdComplicacionClsComboBox.DataSource = Me.TblComplicacionBindingSource
    Me.IntIdComplicacionClsComboBox.DisplayMember = "strNombre"
    Me.IntIdComplicacionClsComboBox.FormattingEnabled = True
    Me.IntIdComplicacionClsComboBox.Location = New System.Drawing.Point(207, 224)
    Me.IntIdComplicacionClsComboBox.Name = "IntIdComplicacionClsComboBox"
    Me.IntIdComplicacionClsComboBox.Size = New System.Drawing.Size(416, 21)
    Me.IntIdComplicacionClsComboBox.TabIndex = 17
    Me.IntIdComplicacionClsComboBox.ValueMember = "intIdDiagnostico"
    '
    'IntIdDiagnosticoPosteriorClsComboBox
    '
    Me.IntIdDiagnosticoPosteriorClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.IntIdDiagnosticoPosteriorClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdDiagnosticoPosteriorClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoPosterior", True))
    Me.IntIdDiagnosticoPosteriorClsComboBox.DataSource = Me.TblDisgnosticoPosBindingSource
    Me.IntIdDiagnosticoPosteriorClsComboBox.DisplayMember = "strNombre"
    Me.IntIdDiagnosticoPosteriorClsComboBox.FormattingEnabled = True
    Me.IntIdDiagnosticoPosteriorClsComboBox.Location = New System.Drawing.Point(207, 197)
    Me.IntIdDiagnosticoPosteriorClsComboBox.Name = "IntIdDiagnosticoPosteriorClsComboBox"
    Me.IntIdDiagnosticoPosteriorClsComboBox.Size = New System.Drawing.Size(416, 21)
    Me.IntIdDiagnosticoPosteriorClsComboBox.TabIndex = 15
    Me.IntIdDiagnosticoPosteriorClsComboBox.ValueMember = "intIdDiagnostico"
    '
    'IntIdDiagnosticoPrevioClsComboBox
    '
    Me.IntIdDiagnosticoPrevioClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.IntIdDiagnosticoPrevioClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdDiagnosticoPrevioClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoPrevio", True))
    Me.IntIdDiagnosticoPrevioClsComboBox.DataSource = Me.TblDisgnosticoBindingSource
    Me.IntIdDiagnosticoPrevioClsComboBox.DisplayMember = "strNombre"
    Me.IntIdDiagnosticoPrevioClsComboBox.FormattingEnabled = True
    Me.IntIdDiagnosticoPrevioClsComboBox.Location = New System.Drawing.Point(207, 170)
    Me.IntIdDiagnosticoPrevioClsComboBox.Name = "IntIdDiagnosticoPrevioClsComboBox"
    Me.IntIdDiagnosticoPrevioClsComboBox.Size = New System.Drawing.Size(416, 21)
    Me.IntIdDiagnosticoPrevioClsComboBox.TabIndex = 13
    Me.IntIdDiagnosticoPrevioClsComboBox.ValueMember = "intIdDiagnostico"
    '
    'IntIdProcedimientoClsComboBox
    '
    Me.IntIdProcedimientoClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.IntIdProcedimientoClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdProcedimientoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdProcedimiento", True))
    Me.IntIdProcedimientoClsComboBox.DataSource = Me.TblProcedimientoBindingSource
    Me.IntIdProcedimientoClsComboBox.DisplayMember = "strNombre"
    Me.IntIdProcedimientoClsComboBox.FormattingEnabled = True
    Me.IntIdProcedimientoClsComboBox.Location = New System.Drawing.Point(136, 143)
    Me.IntIdProcedimientoClsComboBox.Name = "IntIdProcedimientoClsComboBox"
    Me.IntIdProcedimientoClsComboBox.Size = New System.Drawing.Size(487, 21)
    Me.IntIdProcedimientoClsComboBox.TabIndex = 11
    Me.IntIdProcedimientoClsComboBox.ValueMember = "intIdProcedimientos"
    '
    'DtmFechaAutorizacionClsDateTimePicker
    '
    Me.DtmFechaAutorizacionClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblCitaBindingSource, "dtmFechaAutorizacion", True))
    Me.DtmFechaAutorizacionClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
    Me.DtmFechaAutorizacionClsDateTimePicker.Location = New System.Drawing.Point(136, 117)
    Me.DtmFechaAutorizacionClsDateTimePicker.Name = "DtmFechaAutorizacionClsDateTimePicker"
    Me.DtmFechaAutorizacionClsDateTimePicker.Size = New System.Drawing.Size(101, 20)
    Me.DtmFechaAutorizacionClsDateTimePicker.TabIndex = 8
    '
    'StrCodAtencionClsTextBox
    '
    Me.StrCodAtencionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strCodAtencion", True))
    Me.StrCodAtencionClsTextBox.DataSource = Nothing
    Me.StrCodAtencionClsTextBox.EnterEntreCampos = True
    Me.StrCodAtencionClsTextBox.Location = New System.Drawing.Point(322, 117)
    Me.StrCodAtencionClsTextBox.Name = "StrCodAtencionClsTextBox"
    Me.StrCodAtencionClsTextBox.NombreCodigoF2 = Nothing
    Me.StrCodAtencionClsTextBox.NombreDescripcionF2 = Nothing
    Me.StrCodAtencionClsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.StrCodAtencionClsTextBox.TabIndex = 9
    Me.StrCodAtencionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'StrNroOrdenClsTextBox
    '
    Me.StrNroOrdenClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strNroOrden", True))
    Me.StrNroOrdenClsTextBox.DataSource = Nothing
    Me.StrNroOrdenClsTextBox.EnterEntreCampos = True
    Me.StrNroOrdenClsTextBox.Location = New System.Drawing.Point(523, 91)
    Me.StrNroOrdenClsTextBox.Name = "StrNroOrdenClsTextBox"
    Me.StrNroOrdenClsTextBox.NombreCodigoF2 = Nothing
    Me.StrNroOrdenClsTextBox.NombreDescripcionF2 = Nothing
    Me.StrNroOrdenClsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.StrNroOrdenClsTextBox.TabIndex = 7
    Me.StrNroOrdenClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'StrNroFacturaClsTextBox
    '
    Me.StrNroFacturaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strNroFactura", True))
    Me.StrNroFacturaClsTextBox.DataSource = Nothing
    Me.StrNroFacturaClsTextBox.EnterEntreCampos = True
    Me.StrNroFacturaClsTextBox.Location = New System.Drawing.Point(322, 91)
    Me.StrNroFacturaClsTextBox.Name = "StrNroFacturaClsTextBox"
    Me.StrNroFacturaClsTextBox.NombreCodigoF2 = Nothing
    Me.StrNroFacturaClsTextBox.NombreDescripcionF2 = Nothing
    Me.StrNroFacturaClsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.StrNroFacturaClsTextBox.TabIndex = 6
    Me.StrNroFacturaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'NumValorDescuentoClsTextBox
    '
    Me.NumValorDescuentoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "numValorDescuento", True))
    Me.NumValorDescuentoClsTextBox.DataSource = Nothing
    Me.NumValorDescuentoClsTextBox.EnterEntreCampos = True
    Me.NumValorDescuentoClsTextBox.Location = New System.Drawing.Point(136, 91)
    Me.NumValorDescuentoClsTextBox.Name = "NumValorDescuentoClsTextBox"
    Me.NumValorDescuentoClsTextBox.NombreCodigoF2 = Nothing
    Me.NumValorDescuentoClsTextBox.NombreDescripcionF2 = Nothing
    Me.NumValorDescuentoClsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.NumValorDescuentoClsTextBox.TabIndex = 5
    Me.NumValorDescuentoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'NumValorCoopagoClsTextBox
    '
    Me.NumValorCoopagoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "numValorCoopago", True))
    Me.NumValorCoopagoClsTextBox.DataSource = Nothing
    Me.NumValorCoopagoClsTextBox.EnterEntreCampos = True
    Me.NumValorCoopagoClsTextBox.Location = New System.Drawing.Point(523, 65)
    Me.NumValorCoopagoClsTextBox.Name = "NumValorCoopagoClsTextBox"
    Me.NumValorCoopagoClsTextBox.NombreCodigoF2 = Nothing
    Me.NumValorCoopagoClsTextBox.NombreDescripcionF2 = Nothing
    Me.NumValorCoopagoClsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.NumValorCoopagoClsTextBox.TabIndex = 4
    Me.NumValorCoopagoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'IntNroServiciosClsTextBox
    '
    Me.IntNroServiciosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "intNroServicios", True))
    Me.IntNroServiciosClsTextBox.DataSource = Nothing
    Me.IntNroServiciosClsTextBox.EnterEntreCampos = True
    Me.IntNroServiciosClsTextBox.Location = New System.Drawing.Point(322, 65)
    Me.IntNroServiciosClsTextBox.Name = "IntNroServiciosClsTextBox"
    Me.IntNroServiciosClsTextBox.NombreCodigoF2 = Nothing
    Me.IntNroServiciosClsTextBox.NombreDescripcionF2 = Nothing
    Me.IntNroServiciosClsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.IntNroServiciosClsTextBox.TabIndex = 3
    Me.IntNroServiciosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'NumValorUnitarioClsTextBox
    '
    Me.NumValorUnitarioClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "numValorUnitario", True))
    Me.NumValorUnitarioClsTextBox.DataSource = Nothing
    Me.NumValorUnitarioClsTextBox.EnterEntreCampos = True
    Me.NumValorUnitarioClsTextBox.Location = New System.Drawing.Point(136, 65)
    Me.NumValorUnitarioClsTextBox.Name = "NumValorUnitarioClsTextBox"
    Me.NumValorUnitarioClsTextBox.NombreCodigoF2 = Nothing
    Me.NumValorUnitarioClsTextBox.NombreDescripcionF2 = Nothing
    Me.NumValorUnitarioClsTextBox.Size = New System.Drawing.Size(100, 20)
    Me.NumValorUnitarioClsTextBox.TabIndex = 2
    Me.NumValorUnitarioClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'IntIdServicioClsComboBox
    '
    Me.IntIdServicioClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.IntIdServicioClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.IntIdServicioClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdServicio", True))
    Me.IntIdServicioClsComboBox.DataSource = Me.TblServicioBindingSource
    Me.IntIdServicioClsComboBox.DisplayMember = "strNombre"
    Me.IntIdServicioClsComboBox.FormattingEnabled = True
    Me.IntIdServicioClsComboBox.Location = New System.Drawing.Point(136, 10)
    Me.IntIdServicioClsComboBox.Name = "IntIdServicioClsComboBox"
    Me.IntIdServicioClsComboBox.Size = New System.Drawing.Size(487, 21)
    Me.IntIdServicioClsComboBox.TabIndex = 0
    Me.IntIdServicioClsComboBox.ValueMember = "intIdServicios"
    '
    'Panel1
    '
    Me.Panel1.Controls.Add(Label1)
    Me.Panel1.Controls.Add(Me.ClsComboBoxPrestador)
    Me.Panel1.Controls.Add(Me.StrNroIdPacienteTextBox)
    Me.Panel1.Controls.Add(Me.TextBoxNombre)
    Me.Panel1.Controls.Add(IntIdCitaLabel)
    Me.Panel1.Controls.Add(Me.IntIdCitaTextBox)
    Me.Panel1.Controls.Add(IntIdPacienteLabel)
    Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
    Me.Panel1.Location = New System.Drawing.Point(0, 25)
    Me.Panel1.Name = "Panel1"
    Me.Panel1.Size = New System.Drawing.Size(684, 63)
    Me.Panel1.TabIndex = 0
    '
    'ClsComboBoxPrestador
    '
    Me.ClsComboBoxPrestador.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
    Me.ClsComboBoxPrestador.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
    Me.ClsComboBoxPrestador.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdPrestador", True))
    Me.ClsComboBoxPrestador.DataSource = Me.TblDatosPrestadoresBindingSource
    Me.ClsComboBoxPrestador.DisplayMember = "strRazonSocial"
    Me.ClsComboBoxPrestador.FormattingEnabled = True
    Me.ClsComboBoxPrestador.Location = New System.Drawing.Point(322, 13)
    Me.ClsComboBoxPrestador.Name = "ClsComboBoxPrestador"
    Me.ClsComboBoxPrestador.Size = New System.Drawing.Size(302, 21)
    Me.ClsComboBoxPrestador.TabIndex = 2
    Me.ClsComboBoxPrestador.ValueMember = "intIdPrestadores"
    '
    'TblDatosPrestadoresBindingSource
    '
    Me.TblDatosPrestadoresBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDatosPrestadores)
    Me.TblDatosPrestadoresBindingSource.Sort = "strRazonSocial"
    '
    'StrNroIdPacienteTextBox
    '
    Me.StrNroIdPacienteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strNroIdPaciente", True))
    Me.StrNroIdPacienteTextBox.DataSource = Nothing
    Me.StrNroIdPacienteTextBox.EnterEntreCampos = True
    Me.StrNroIdPacienteTextBox.Location = New System.Drawing.Point(135, 40)
    Me.StrNroIdPacienteTextBox.Name = "StrNroIdPacienteTextBox"
    Me.StrNroIdPacienteTextBox.NombreCodigoF2 = Nothing
    Me.StrNroIdPacienteTextBox.NombreDescripcionF2 = Nothing
    Me.StrNroIdPacienteTextBox.Size = New System.Drawing.Size(135, 20)
    Me.StrNroIdPacienteTextBox.TabIndex = 1
    Me.StrNroIdPacienteTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'TextBoxNombre
    '
    Me.TextBoxNombre.DataSource = Nothing
    Me.TextBoxNombre.Enabled = False
    Me.TextBoxNombre.EnterEntreCampos = True
    Me.TextBoxNombre.Location = New System.Drawing.Point(276, 40)
    Me.TextBoxNombre.Name = "TextBoxNombre"
    Me.TextBoxNombre.NombreCodigoF2 = Nothing
    Me.TextBoxNombre.NombreDescripcionF2 = Nothing
    Me.TextBoxNombre.Size = New System.Drawing.Size(346, 20)
    Me.TextBoxNombre.TabIndex = 3
    Me.TextBoxNombre.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'IntIdCitaTextBox
    '
    Me.IntIdCitaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "intIdCita", True))
    Me.IntIdCitaTextBox.DataSource = Nothing
    Me.IntIdCitaTextBox.Enabled = False
    Me.IntIdCitaTextBox.EnterEntreCampos = True
    Me.IntIdCitaTextBox.Location = New System.Drawing.Point(135, 14)
    Me.IntIdCitaTextBox.Name = "IntIdCitaTextBox"
    Me.IntIdCitaTextBox.NombreCodigoF2 = Nothing
    Me.IntIdCitaTextBox.NombreDescripcionF2 = Nothing
    Me.IntIdCitaTextBox.Size = New System.Drawing.Size(47, 20)
    Me.IntIdCitaTextBox.TabIndex = 0
    Me.IntIdCitaTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'DataGridViewTextBoxColumn10
    '
    Me.DataGridViewTextBoxColumn10.DataPropertyName = "intIdEstadoCita"
    Me.DataGridViewTextBoxColumn10.DataSource = Me.TblTipoEstadoBindingSource
    Me.DataGridViewTextBoxColumn10.DisplayMember = "strValor"
    Me.DataGridViewTextBoxColumn10.HeaderText = "Estado"
    Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
    Me.DataGridViewTextBoxColumn10.ReadOnly = True
    Me.DataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
    Me.DataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
    Me.DataGridViewTextBoxColumn10.ValueMember = "intIdTipo"
    Me.DataGridViewTextBoxColumn10.Width = 130
    '
    'DataGridViewTextBoxColumn5
    '
    Me.DataGridViewTextBoxColumn5.DataPropertyName = "dtmFecha"
    DataGridViewCellStyle1.Format = "d"
    DataGridViewCellStyle1.NullValue = Nothing
    Me.DataGridViewTextBoxColumn5.DefaultCellStyle = DataGridViewCellStyle1
    Me.DataGridViewTextBoxColumn5.HeaderText = "Fecha"
    Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
    Me.DataGridViewTextBoxColumn5.ReadOnly = True
    '
    'FrmRegistrarDatosFacturacion
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.AutoScroll = true
    Me.ClientSize = New System.Drawing.Size(995, 578)
    Me.Controls.Add(Me.PanelPRincipal)
    Me.Controls.Add(Me.GroupBox2)
    Me.Controls.Add(Me.Panel1)
    Me.Controls.Add(Me.GroupBox1)
    Me.Controls.Add(Me.TblCitaBindingNavigator)
    Me.Icon = CType(resources.GetObject("$this.Icon"),System.Drawing.Icon)
    Me.Name = "FrmRegistrarDatosFacturacion"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Registrar datos de Facturación"
    CType(Me.TblCitaBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblCitaBindingNavigator,System.ComponentModel.ISupportInitialize).EndInit
    Me.TblCitaBindingNavigator.ResumeLayout(false)
    Me.TblCitaBindingNavigator.PerformLayout
    CType(Me.TblEmpeadoBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblServicioBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblProcedimientoBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblDisgnosticoBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblDisgnosticoPosBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblComplicacionBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblClaseBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblFormaBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblAtiendeBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblTipoBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    Me.GroupBox1.ResumeLayout(false)
    CType(Me.TblCitaDataGridView,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblTipoEstadoBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    Me.GroupBox2.ResumeLayout(false)
    Me.GroupBox2.PerformLayout
    CType(Me.TblDisgnosticoRe3BindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblDisgnosticoRe2BindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblDisgnosticoRe1BindingSource,System.ComponentModel.ISupportInitialize).EndInit
    CType(Me.TblDisgnosticoPrincipalBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    Me.PanelPRincipal.ResumeLayout(false)
    Me.PanelPRincipal.PerformLayout
    Me.Panel1.ResumeLayout(false)
    Me.Panel1.PerformLayout
    CType(Me.TblDatosPrestadoresBindingSource,System.ComponentModel.ISupportInitialize).EndInit
    Me.ResumeLayout(false)
    Me.PerformLayout

End Sub
    Friend WithEvents TblCitaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblEmpeadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCitaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents TblCitaBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblServicioBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblProcedimientoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDisgnosticoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDisgnosticoPosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblComplicacionBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblClaseBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblFormaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblAtiendeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TblCitaDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblTipoEstadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents IntIdDiagNosticoPrincipalClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoRelacionadoN3ClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoRelacionadoN2ClsComboBox1 As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoRelacionadoN2ClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoRelacionadoN1ClsComboBox1 As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoRelacionadoN1ClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagNosticoPrincipalClsComboBox1 As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoRelacionadoN3ClsComboBox1 As ClsUtilidades.ClsComboBox
    Friend WithEvents TblDisgnosticoPrincipalBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDisgnosticoRe1BindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDisgnosticoRe2BindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDisgnosticoRe3BindingSource As System.Windows.Forms.BindingSource
  Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents PanelPRincipal As System.Windows.Forms.Panel
    Friend WithEvents IntIdProfesionalClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents btnHabilitarCoopago As System.Windows.Forms.Button
    Friend WithEvents DtmFechaDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents ClsComboBox3 As ClsUtilidades.ClsComboBox
    Friend WithEvents ClsComboBox2 As ClsUtilidades.ClsComboBox
    Friend WithEvents ClsComboBox1 As ClsUtilidades.ClsComboBox
    Friend WithEvents StrCondicionPacienteClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntTipoProcedimientoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdPersonalAtiendeClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntFormaRealizaActoQClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdClaseProcedimientoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdComplicacionClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoPosteriorClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoPrevioClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdProcedimientoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents DtmFechaAutorizacionClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents StrCodAtencionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNroOrdenClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNroFacturaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents NumValorDescuentoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents NumValorCoopagoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntNroServiciosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents NumValorUnitarioClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdServicioClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents StrNroIdPacienteTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TextBoxNombre As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdCitaTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents ClsComboBoxPrestador As ClsUtilidades.ClsComboBox
  Friend WithEvents TblDatosPrestadoresBindingSource As System.Windows.Forms.BindingSource
  Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewComboBoxColumn
End Class
