﻿Imports System.Windows.Forms

Public Class FrmCancelacionCita
    Dim mstrStringConection As String
    Dim DataContext 'As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext()
    Dim mstrIntIdUsuario As Integer
    Dim mBuscar As Boolean
    Dim mintIdSede As Integer

    Sub New(ByVal strStringConection As String, ByVal pstrIntIdUsuario As Integer, ByVal pintIdSede As Integer)
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            mstrStringConection = strStringConection
            mstrIntIdUsuario = pstrIntIdUsuario
            mintIdSede = pintIdSede
            'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxProfesional.CheckedChanged
        ComboBoxProfesional.SelectedIndex = -1
        ComboBoxProfesional.Enabled = CheckBoxProfesional.Checked
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxPaciente.CheckedChanged
        TextBoxPaciente.Text = ""
        TextBoxPaciente.Enabled = CheckBoxPaciente.Checked
    End Sub

    Private Sub FrmNovedadesCitas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            mBuscar = False
            DataContext = dc
            TextBoxPaciente.Text = ""
            DateTimePickerFecha.Value = Now
            ComboBoxProfesional.SelectedIndex = -1
            EstadoToolStripComboBox.SelectedIndex = 0
            ToolStripComboBoxSede.ComboBox.DataSource = dc.tblSedes
            ToolStripComboBoxSede.ComboBox.DisplayMember = "strNombreSede"
            ToolStripComboBoxSede.ComboBox.ValueMember = "intIdSede"
            ToolStripComboBoxSede.ComboBox.SelectedIndex = mintIdSede

            TblEmpeadoBindingSource.DataSource = dc.tblEmpeados
            mBuscar = True
            PrBuscar()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
    Private Sub PrBuscar()
        Try
            If mBuscar = True Then

                Dim dc2 As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
                Dim tmpCitas = dc2.usp_NovedadesCitas_Mejor(EstadoToolStripComboBox.SelectedIndex, IIf(FechaCheckBox.Checked, DateTimePickerFecha.Value, Nothing), IIf(CheckBoxProfesional.Checked, TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).intIdCodigoEmpleado, Nothing), IIf(CheckBoxPaciente.Checked, TextBoxPaciente.Text, Nothing), ToolStripComboBoxSede.ComboBox.SelectedValue) ', ToolStripComboBoxSede.ComboBox.SelectedValue))

                TblCitaBindingSource.DataSource = tmpCitas

            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub ButtonBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscar.Click
        PrBuscar()
    End Sub

    Private Sub TblCitaBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub FechaCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FechaCheckBox.CheckedChanged
        DateTimePickerFecha.Enabled = FechaCheckBox.Checked
    End Sub

    Private Sub TblCitaDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblCitaDataGridView.DataError
        Try
            'No hace nada
        Catch ex As Exception
            'No hace nada
        End Try
    End Sub

    Private Sub CancelarContextMenuStrip_Opening(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles CancelarContextMenuStrip.Opening

    End Sub

    Private Sub CancelarContextMenuStrip_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles CancelarContextMenuStrip.MouseClick
    End Sub

    Private Sub CancelarCitaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelarCitaToolStripMenuItem.Click
        'Try
        '    If (TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita.ToString() = "Asignada") Or (TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita.ToString().Trim.Length = 0) Then
        '        'If MsgBox("Confirmación de cancelación cita: " & Chr(13) & _
        '        '          "Fecha : " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmFecha.ToString() & Chr(13) & _
        '        '          "Hora : " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmHora.ToString() & Chr(13) & _
        '        '          "Medico: " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).strProfesional & Chr(13) & _
        '        '          "Examen: " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).strProcedimiento, MsgBoxStyle.OkCancel + MsgBoxStyle.Information) = MsgBoxResult.Ok Then
        '        '"Paciente: " & TblPacienteBindingSource.Item(   Item(TblPacienteBindingSource.Position).strPrimerNombre & Chr(13) & _
        '        Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
        '        If mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK Then
        '            Dim dc2 As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
        '            dc2.usp_CancelarCita(TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdCita, mValidaHuella.mstrIntIdUsuario)
        '            MsgBox("La cita fué cancelada de forma satisfactoria..")
        '            PrBuscar()
        '        Else
        '            MsgBox("La cita no fué cancelada..")
        '        End If
        '    End If
        '    'Else
        '    '   MsgBox("La cita no se puede cancelar..")
        '    'End If
        'Catch ex As Exception
        '    ClsError.ClsError.PrMostrarError(ex)
        'End Try
    End Sub

    Private Sub DateTimePickerFecha_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePickerFecha.ValueChanged
    End Sub

    Private Sub ComboBoxProfesional_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxProfesional.SelectedIndexChanged
        If ComboBoxProfesional.SelectedIndex >= 0 Then
            PrBuscar()
        End If
    End Sub

    Private Sub TextBoxPaciente_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBoxPaciente.KeyUp
        If e.KeyCode = Windows.Forms.Keys.Enter Then
            PrBuscar()
        End If
    End Sub

    Private Sub EstadoToolStripComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EstadoToolStripComboBox.SelectedIndexChanged
        Try
            PrBuscar()
        Catch ex As Exception
            'No hace nada
        End Try
    End Sub

    Private Sub ToolStripComboBoxSede_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripComboBoxSede.SelectedIndexChanged
        Try
            PrBuscar()
        Catch ex As Exception
            'No hace nada
        End Try
    End Sub


    Private Sub ToolStripButtonCancelarCita_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButtonCancelarCita.Click
        Try
            Dim dc2 As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
            If mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK Then
                For i As Integer = 0 To TblCitaDataGridView.RowCount - 1
                    TblCitaBindingSource.Position = i
                    If Not TblCitaDataGridView.Rows(i).Cells("Seleccion").Value Is Nothing Then
                        If TblCitaDataGridView.Rows(i).Cells("Seleccion").Value = True Then
                            'MessageBox.Show("La fila nº " & i.ToString & " está marcada.")
                            If (TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita.ToString() = "Asignada") Or (TblCitaBindingSource.Item(i).intIdEstadoCita.ToString().Trim.Length = 0) Then
                                dc2.usp_CancelarCita(TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdCita, mValidaHuella.mstrIntIdUsuario)
                                'MessageBox.Show("La fila nº " & i.ToString & " está eliminada")
                            End If
                        End If
                    End If
                Next
                PrBuscar()
                MsgBox("Las citas fueron canceladas de forma satisfactoria..")
            Else
                MsgBox("Las citas no fueron canceladas..")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
End Class