﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uscAntecedentesSocioEconomicos
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IntHabitacionesLabel As System.Windows.Forms.Label
        Dim IntUbicacionViviendaLabel As System.Windows.Forms.Label
        Dim IntBañosLabel As System.Windows.Forms.Label
        Dim IntAcabadosLabel As System.Windows.Forms.Label
        Dim IntEstratoLabel As System.Windows.Forms.Label
        Dim IntViviendaLabel As System.Windows.Forms.Label
        Dim IntViveLabel As System.Windows.Forms.Label
        Dim IntSostieneFamiliaLabel As System.Windows.Forms.Label
        Dim BitServicioMilitarLabel As System.Windows.Forms.Label
        Dim IntidIngresosFamiliaresLabel As System.Windows.Forms.Label
        Dim IntidIngresosLabel As System.Windows.Forms.Label
        Dim IntidOcupacionLabel As System.Windows.Forms.Label
        Dim IntidEmpleoLabel As System.Windows.Forms.Label
        Dim IntidEscolaridadLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uscAntecedentesSocioEconomicos))
        Me.TblCitasMotivosConsultaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.TblAntecedentesSocioEconomicosHCBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblEPBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.IntHabitacionesClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntUbicacionViviendaClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoUbicacionViviendaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntBañosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntAcabadosClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoAcabadosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntEstratoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoEstratoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntViviendaClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoViviendaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.IntViveClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoViveBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntSostieneFamiliaClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoSostieneFamiliaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BitServicioMilitarClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.IntidIngresosFamiliaresClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoIngresosFamiliaresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntidIngresosClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoIngresosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntidOcupacionClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblOcupacionesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntidEmpleoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoEmpleoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntidEscolaridadClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoEscolaridadBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StrHcAntEconomicosTextBox = New System.Windows.Forms.TextBox()
        IntHabitacionesLabel = New System.Windows.Forms.Label()
        IntUbicacionViviendaLabel = New System.Windows.Forms.Label()
        IntBañosLabel = New System.Windows.Forms.Label()
        IntAcabadosLabel = New System.Windows.Forms.Label()
        IntEstratoLabel = New System.Windows.Forms.Label()
        IntViviendaLabel = New System.Windows.Forms.Label()
        IntViveLabel = New System.Windows.Forms.Label()
        IntSostieneFamiliaLabel = New System.Windows.Forms.Label()
        BitServicioMilitarLabel = New System.Windows.Forms.Label()
        IntidIngresosFamiliaresLabel = New System.Windows.Forms.Label()
        IntidIngresosLabel = New System.Windows.Forms.Label()
        IntidOcupacionLabel = New System.Windows.Forms.Label()
        IntidEmpleoLabel = New System.Windows.Forms.Label()
        IntidEscolaridadLabel = New System.Windows.Forms.Label()
        CType(Me.TblCitasMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCitasMotivosConsultaBindingNavigator.SuspendLayout()
        CType(Me.TblAntecedentesSocioEconomicosHCBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.TblTipoUbicacionViviendaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoAcabadosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoEstratoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoViviendaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.TblTipoViveBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoSostieneFamiliaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoIngresosFamiliaresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoIngresosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblOcupacionesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoEmpleoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoEscolaridadBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IntHabitacionesLabel
        '
        IntHabitacionesLabel.AutoSize = True
        IntHabitacionesLabel.Location = New System.Drawing.Point(14, 80)
        IntHabitacionesLabel.Name = "IntHabitacionesLabel"
        IntHabitacionesLabel.Size = New System.Drawing.Size(112, 13)
        IntHabitacionesLabel.TabIndex = 10
        IntHabitacionesLabel.Text = "Número Habitaciones:"
        '
        'IntUbicacionViviendaLabel
        '
        IntUbicacionViviendaLabel.AutoSize = True
        IntUbicacionViviendaLabel.Location = New System.Drawing.Point(334, 22)
        IntUbicacionViviendaLabel.Name = "IntUbicacionViviendaLabel"
        IntUbicacionViviendaLabel.Size = New System.Drawing.Size(102, 13)
        IntUbicacionViviendaLabel.TabIndex = 2
        IntUbicacionViviendaLabel.Text = "Ubicación Vivienda:"
        '
        'IntBañosLabel
        '
        IntBañosLabel.AutoSize = True
        IntBañosLabel.Location = New System.Drawing.Point(337, 77)
        IntBañosLabel.Name = "IntBañosLabel"
        IntBañosLabel.Size = New System.Drawing.Size(80, 13)
        IntBañosLabel.TabIndex = 8
        IntBañosLabel.Text = "Número Baños:"
        '
        'IntAcabadosLabel
        '
        IntAcabadosLabel.AutoSize = True
        IntAcabadosLabel.Location = New System.Drawing.Point(337, 49)
        IntAcabadosLabel.Name = "IntAcabadosLabel"
        IntAcabadosLabel.Size = New System.Drawing.Size(58, 13)
        IntAcabadosLabel.TabIndex = 6
        IntAcabadosLabel.Text = "Acabados:"
        '
        'IntEstratoLabel
        '
        IntEstratoLabel.AutoSize = True
        IntEstratoLabel.Location = New System.Drawing.Point(13, 52)
        IntEstratoLabel.Name = "IntEstratoLabel"
        IntEstratoLabel.Size = New System.Drawing.Size(43, 13)
        IntEstratoLabel.TabIndex = 4
        IntEstratoLabel.Text = "Estrato:"
        '
        'IntViviendaLabel
        '
        IntViviendaLabel.AutoSize = True
        IntViviendaLabel.Location = New System.Drawing.Point(11, 22)
        IntViviendaLabel.Name = "IntViviendaLabel"
        IntViviendaLabel.Size = New System.Drawing.Size(75, 13)
        IntViviendaLabel.TabIndex = 0
        IntViviendaLabel.Text = "Tipo Vivienda:"
        '
        'IntViveLabel
        '
        IntViveLabel.AutoSize = True
        IntViveLabel.Location = New System.Drawing.Point(337, 105)
        IntViveLabel.Name = "IntViveLabel"
        IntViveLabel.Size = New System.Drawing.Size(31, 13)
        IntViveLabel.TabIndex = 14
        IntViveLabel.Text = "Vive:"
        '
        'IntSostieneFamiliaLabel
        '
        IntSostieneFamiliaLabel.AutoSize = True
        IntSostieneFamiliaLabel.Location = New System.Drawing.Point(13, 102)
        IntSostieneFamiliaLabel.Name = "IntSostieneFamiliaLabel"
        IntSostieneFamiliaLabel.Size = New System.Drawing.Size(97, 13)
        IntSostieneFamiliaLabel.TabIndex = 12
        IntSostieneFamiliaLabel.Text = "Sostiene la Familia:"
        '
        'BitServicioMilitarLabel
        '
        BitServicioMilitarLabel.AutoSize = True
        BitServicioMilitarLabel.Location = New System.Drawing.Point(13, 132)
        BitServicioMilitarLabel.Name = "BitServicioMilitarLabel"
        BitServicioMilitarLabel.Size = New System.Drawing.Size(111, 13)
        BitServicioMilitarLabel.TabIndex = 10
        BitServicioMilitarLabel.Text = "Presto Servicio Militar:"
        '
        'IntidIngresosFamiliaresLabel
        '
        IntidIngresosFamiliaresLabel.AutoSize = True
        IntidIngresosFamiliaresLabel.Location = New System.Drawing.Point(337, 76)
        IntidIngresosFamiliaresLabel.Name = "IntidIngresosFamiliaresLabel"
        IntidIngresosFamiliaresLabel.Size = New System.Drawing.Size(99, 13)
        IntidIngresosFamiliaresLabel.TabIndex = 8
        IntidIngresosFamiliaresLabel.Text = "Ingresos Familiares:"
        '
        'IntidIngresosLabel
        '
        IntidIngresosLabel.AutoSize = True
        IntidIngresosLabel.Location = New System.Drawing.Point(13, 76)
        IntidIngresosLabel.Name = "IntidIngresosLabel"
        IntidIngresosLabel.Size = New System.Drawing.Size(87, 13)
        IntidIngresosLabel.TabIndex = 6
        IntidIngresosLabel.Text = "Ingresos propios:"
        '
        'IntidOcupacionLabel
        '
        IntidOcupacionLabel.AutoSize = True
        IntidOcupacionLabel.Location = New System.Drawing.Point(13, 48)
        IntidOcupacionLabel.Name = "IntidOcupacionLabel"
        IntidOcupacionLabel.Size = New System.Drawing.Size(62, 13)
        IntidOcupacionLabel.TabIndex = 4
        IntidOcupacionLabel.Text = "Ocupación:"
        '
        'IntidEmpleoLabel
        '
        IntidEmpleoLabel.AutoSize = True
        IntidEmpleoLabel.Location = New System.Drawing.Point(337, 22)
        IntidEmpleoLabel.Name = "IntidEmpleoLabel"
        IntidEmpleoLabel.Size = New System.Drawing.Size(45, 13)
        IntidEmpleoLabel.TabIndex = 2
        IntidEmpleoLabel.Text = "Empleo:"
        '
        'IntidEscolaridadLabel
        '
        IntidEscolaridadLabel.AutoSize = True
        IntidEscolaridadLabel.Location = New System.Drawing.Point(13, 22)
        IntidEscolaridadLabel.Name = "IntidEscolaridadLabel"
        IntidEscolaridadLabel.Size = New System.Drawing.Size(65, 13)
        IntidEscolaridadLabel.TabIndex = 0
        IntidEscolaridadLabel.Text = "Escolaridad:"
        '
        'TblCitasMotivosConsultaBindingNavigator
        '
        Me.TblCitasMotivosConsultaBindingNavigator.AddNewItem = Nothing
        Me.TblCitasMotivosConsultaBindingNavigator.BindingSource = Me.TblAntecedentesSocioEconomicosHCBindingSource
        Me.TblCitasMotivosConsultaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblCitasMotivosConsultaBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblCitasMotivosConsultaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorDeleteItem, Me.TblEPBindingNavigatorSaveItem})
        Me.TblCitasMotivosConsultaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCitasMotivosConsultaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblCitasMotivosConsultaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblCitasMotivosConsultaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblCitasMotivosConsultaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblCitasMotivosConsultaBindingNavigator.Name = "TblCitasMotivosConsultaBindingNavigator"
        Me.TblCitasMotivosConsultaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblCitasMotivosConsultaBindingNavigator.Size = New System.Drawing.Size(689, 25)
        Me.TblCitasMotivosConsultaBindingNavigator.TabIndex = 87
        Me.TblCitasMotivosConsultaBindingNavigator.Text = "BindingNavigator"
        '
        'TblAntecedentesSocioEconomicosHCBindingSource
        '
        Me.TblAntecedentesSocioEconomicosHCBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblAntecedentesSocioEconomicosHC)
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblEPBindingNavigatorSaveItem
        '
        Me.TblEPBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblEPBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblEPBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblEPBindingNavigatorSaveItem.Name = "TblEPBindingNavigatorSaveItem"
        Me.TblEPBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblEPBindingNavigatorSaveItem.Text = "Save Data"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(IntHabitacionesLabel)
        Me.GroupBox6.Controls.Add(Me.IntHabitacionesClsTextBox)
        Me.GroupBox6.Controls.Add(IntUbicacionViviendaLabel)
        Me.GroupBox6.Controls.Add(Me.IntUbicacionViviendaClsComboBox)
        Me.GroupBox6.Controls.Add(IntBañosLabel)
        Me.GroupBox6.Controls.Add(Me.IntBañosClsTextBox)
        Me.GroupBox6.Controls.Add(IntAcabadosLabel)
        Me.GroupBox6.Controls.Add(Me.IntAcabadosClsComboBox)
        Me.GroupBox6.Controls.Add(IntEstratoLabel)
        Me.GroupBox6.Controls.Add(Me.IntEstratoClsComboBox)
        Me.GroupBox6.Controls.Add(IntViviendaLabel)
        Me.GroupBox6.Controls.Add(Me.IntViviendaClsComboBox)
        Me.GroupBox6.Location = New System.Drawing.Point(19, 204)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(650, 111)
        Me.GroupBox6.TabIndex = 89
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Vivienda"
        '
        'IntHabitacionesClsTextBox
        '
        Me.IntHabitacionesClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intHabitaciones", True))
        Me.IntHabitacionesClsTextBox.DataSource = Nothing
        Me.IntHabitacionesClsTextBox.EnterEntreCampos = True
        Me.IntHabitacionesClsTextBox.Location = New System.Drawing.Point(129, 77)
        Me.IntHabitacionesClsTextBox.Name = "IntHabitacionesClsTextBox"
        Me.IntHabitacionesClsTextBox.NombreCodigoF2 = Nothing
        Me.IntHabitacionesClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntHabitacionesClsTextBox.Size = New System.Drawing.Size(64, 20)
        Me.IntHabitacionesClsTextBox.TabIndex = 11
        Me.IntHabitacionesClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'IntUbicacionViviendaClsComboBox
        '
        Me.IntUbicacionViviendaClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intUbicacionVivienda", True))
        Me.IntUbicacionViviendaClsComboBox.DataSource = Me.TblTipoUbicacionViviendaBindingSource
        Me.IntUbicacionViviendaClsComboBox.DisplayMember = "strValor"
        Me.IntUbicacionViviendaClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntUbicacionViviendaClsComboBox.FormattingEnabled = True
        Me.IntUbicacionViviendaClsComboBox.Location = New System.Drawing.Point(449, 19)
        Me.IntUbicacionViviendaClsComboBox.Name = "IntUbicacionViviendaClsComboBox"
        Me.IntUbicacionViviendaClsComboBox.Size = New System.Drawing.Size(187, 21)
        Me.IntUbicacionViviendaClsComboBox.TabIndex = 3
        Me.IntUbicacionViviendaClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoUbicacionViviendaBindingSource
        '
        Me.TblTipoUbicacionViviendaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoUbicacionViviendaBindingSource.Sort = "strValor"
        '
        'IntBañosClsTextBox
        '
        Me.IntBañosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intBaños", True))
        Me.IntBañosClsTextBox.DataSource = Nothing
        Me.IntBañosClsTextBox.EnterEntreCampos = True
        Me.IntBañosClsTextBox.Location = New System.Drawing.Point(450, 74)
        Me.IntBañosClsTextBox.Name = "IntBañosClsTextBox"
        Me.IntBañosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntBañosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntBañosClsTextBox.Size = New System.Drawing.Size(64, 20)
        Me.IntBañosClsTextBox.TabIndex = 9
        Me.IntBañosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'IntAcabadosClsComboBox
        '
        Me.IntAcabadosClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intAcabados", True))
        Me.IntAcabadosClsComboBox.DataSource = Me.TblTipoAcabadosBindingSource
        Me.IntAcabadosClsComboBox.DisplayMember = "strValor"
        Me.IntAcabadosClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntAcabadosClsComboBox.FormattingEnabled = True
        Me.IntAcabadosClsComboBox.Location = New System.Drawing.Point(450, 46)
        Me.IntAcabadosClsComboBox.Name = "IntAcabadosClsComboBox"
        Me.IntAcabadosClsComboBox.Size = New System.Drawing.Size(187, 21)
        Me.IntAcabadosClsComboBox.TabIndex = 7
        Me.IntAcabadosClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoAcabadosBindingSource
        '
        Me.TblTipoAcabadosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoAcabadosBindingSource.Sort = "strValor"
        '
        'IntEstratoClsComboBox
        '
        Me.IntEstratoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intEstrato", True))
        Me.IntEstratoClsComboBox.DataSource = Me.TblTipoEstratoBindingSource
        Me.IntEstratoClsComboBox.DisplayMember = "strValor"
        Me.IntEstratoClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntEstratoClsComboBox.FormattingEnabled = True
        Me.IntEstratoClsComboBox.Location = New System.Drawing.Point(130, 49)
        Me.IntEstratoClsComboBox.Name = "IntEstratoClsComboBox"
        Me.IntEstratoClsComboBox.Size = New System.Drawing.Size(194, 21)
        Me.IntEstratoClsComboBox.TabIndex = 5
        Me.IntEstratoClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoEstratoBindingSource
        '
        Me.TblTipoEstratoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoEstratoBindingSource.Sort = "strValor"
        '
        'IntViviendaClsComboBox
        '
        Me.IntViviendaClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intVivienda", True))
        Me.IntViviendaClsComboBox.DataSource = Me.TblTipoViviendaBindingSource
        Me.IntViviendaClsComboBox.DisplayMember = "strValor"
        Me.IntViviendaClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntViviendaClsComboBox.FormattingEnabled = True
        Me.IntViviendaClsComboBox.Location = New System.Drawing.Point(129, 19)
        Me.IntViviendaClsComboBox.Name = "IntViviendaClsComboBox"
        Me.IntViviendaClsComboBox.Size = New System.Drawing.Size(194, 21)
        Me.IntViviendaClsComboBox.TabIndex = 1
        Me.IntViviendaClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoViviendaBindingSource
        '
        Me.TblTipoViviendaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoViviendaBindingSource.Sort = "strValor"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(IntViveLabel)
        Me.GroupBox5.Controls.Add(Me.IntViveClsComboBox)
        Me.GroupBox5.Controls.Add(IntSostieneFamiliaLabel)
        Me.GroupBox5.Controls.Add(Me.IntSostieneFamiliaClsComboBox)
        Me.GroupBox5.Controls.Add(BitServicioMilitarLabel)
        Me.GroupBox5.Controls.Add(Me.BitServicioMilitarClsCheckBox)
        Me.GroupBox5.Controls.Add(IntidIngresosFamiliaresLabel)
        Me.GroupBox5.Controls.Add(Me.IntidIngresosFamiliaresClsComboBox)
        Me.GroupBox5.Controls.Add(IntidIngresosLabel)
        Me.GroupBox5.Controls.Add(Me.IntidIngresosClsComboBox)
        Me.GroupBox5.Controls.Add(IntidOcupacionLabel)
        Me.GroupBox5.Controls.Add(Me.IntidOcupacionClsComboBox)
        Me.GroupBox5.Controls.Add(IntidEmpleoLabel)
        Me.GroupBox5.Controls.Add(Me.IntidEmpleoClsComboBox)
        Me.GroupBox5.Controls.Add(IntidEscolaridadLabel)
        Me.GroupBox5.Controls.Add(Me.IntidEscolaridadClsComboBox)
        Me.GroupBox5.Location = New System.Drawing.Point(19, 42)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(650, 155)
        Me.GroupBox5.TabIndex = 88
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Historia personal"
        '
        'IntViveClsComboBox
        '
        Me.IntViveClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intVive", True))
        Me.IntViveClsComboBox.DataSource = Me.TblTipoViveBindingSource
        Me.IntViveClsComboBox.DisplayMember = "strValor"
        Me.IntViveClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntViveClsComboBox.FormattingEnabled = True
        Me.IntViveClsComboBox.Location = New System.Drawing.Point(442, 102)
        Me.IntViveClsComboBox.Name = "IntViveClsComboBox"
        Me.IntViveClsComboBox.Size = New System.Drawing.Size(194, 21)
        Me.IntViveClsComboBox.TabIndex = 15
        Me.IntViveClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoViveBindingSource
        '
        Me.TblTipoViveBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntSostieneFamiliaClsComboBox
        '
        Me.IntSostieneFamiliaClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intSostieneFamilia", True))
        Me.IntSostieneFamiliaClsComboBox.DataSource = Me.TblTipoSostieneFamiliaBindingSource
        Me.IntSostieneFamiliaClsComboBox.DisplayMember = "strValor"
        Me.IntSostieneFamiliaClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntSostieneFamiliaClsComboBox.FormattingEnabled = True
        Me.IntSostieneFamiliaClsComboBox.Location = New System.Drawing.Point(129, 99)
        Me.IntSostieneFamiliaClsComboBox.Name = "IntSostieneFamiliaClsComboBox"
        Me.IntSostieneFamiliaClsComboBox.Size = New System.Drawing.Size(197, 21)
        Me.IntSostieneFamiliaClsComboBox.TabIndex = 13
        Me.IntSostieneFamiliaClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoSostieneFamiliaBindingSource
        '
        Me.TblTipoSostieneFamiliaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoSostieneFamiliaBindingSource.Sort = "strValor"
        '
        'BitServicioMilitarClsCheckBox
        '
        Me.BitServicioMilitarClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblAntecedentesSocioEconomicosHCBindingSource, "bitServicioMilitar", True))
        Me.BitServicioMilitarClsCheckBox.Location = New System.Drawing.Point(130, 127)
        Me.BitServicioMilitarClsCheckBox.Name = "BitServicioMilitarClsCheckBox"
        Me.BitServicioMilitarClsCheckBox.Size = New System.Drawing.Size(17, 24)
        Me.BitServicioMilitarClsCheckBox.TabIndex = 11
        Me.BitServicioMilitarClsCheckBox.UseVisualStyleBackColor = True
        '
        'IntidIngresosFamiliaresClsComboBox
        '
        Me.IntidIngresosFamiliaresClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intidIngresosFamiliares", True))
        Me.IntidIngresosFamiliaresClsComboBox.DataSource = Me.TblTipoIngresosFamiliaresBindingSource
        Me.IntidIngresosFamiliaresClsComboBox.DisplayMember = "strValor"
        Me.IntidIngresosFamiliaresClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntidIngresosFamiliaresClsComboBox.FormattingEnabled = True
        Me.IntidIngresosFamiliaresClsComboBox.Location = New System.Drawing.Point(442, 72)
        Me.IntidIngresosFamiliaresClsComboBox.Name = "IntidIngresosFamiliaresClsComboBox"
        Me.IntidIngresosFamiliaresClsComboBox.Size = New System.Drawing.Size(194, 21)
        Me.IntidIngresosFamiliaresClsComboBox.TabIndex = 9
        Me.IntidIngresosFamiliaresClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoIngresosFamiliaresBindingSource
        '
        Me.TblTipoIngresosFamiliaresBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoIngresosFamiliaresBindingSource.Sort = "strValor"
        '
        'IntidIngresosClsComboBox
        '
        Me.IntidIngresosClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intidIngresos", True))
        Me.IntidIngresosClsComboBox.DataSource = Me.TblTipoIngresosBindingSource
        Me.IntidIngresosClsComboBox.DisplayMember = "strValor"
        Me.IntidIngresosClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntidIngresosClsComboBox.FormattingEnabled = True
        Me.IntidIngresosClsComboBox.Location = New System.Drawing.Point(129, 72)
        Me.IntidIngresosClsComboBox.Name = "IntidIngresosClsComboBox"
        Me.IntidIngresosClsComboBox.Size = New System.Drawing.Size(197, 21)
        Me.IntidIngresosClsComboBox.TabIndex = 7
        Me.IntidIngresosClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoIngresosBindingSource
        '
        Me.TblTipoIngresosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoIngresosBindingSource.Sort = "strValor"
        '
        'IntidOcupacionClsComboBox
        '
        Me.IntidOcupacionClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intidOcupacion", True))
        Me.IntidOcupacionClsComboBox.DataSource = Me.TblOcupacionesBindingSource
        Me.IntidOcupacionClsComboBox.DisplayMember = "strdescripcion"
        Me.IntidOcupacionClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntidOcupacionClsComboBox.FormattingEnabled = True
        Me.IntidOcupacionClsComboBox.Location = New System.Drawing.Point(130, 45)
        Me.IntidOcupacionClsComboBox.Name = "IntidOcupacionClsComboBox"
        Me.IntidOcupacionClsComboBox.Size = New System.Drawing.Size(506, 21)
        Me.IntidOcupacionClsComboBox.TabIndex = 5
        Me.IntidOcupacionClsComboBox.ValueMember = "intIdOcupacion"
        '
        'TblOcupacionesBindingSource
        '
        Me.TblOcupacionesBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblOcupaciones)
        Me.TblOcupacionesBindingSource.Sort = "strdescripcion"
        '
        'IntidEmpleoClsComboBox
        '
        Me.IntidEmpleoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intidEmpleo", True))
        Me.IntidEmpleoClsComboBox.DataSource = Me.TblTipoEmpleoBindingSource
        Me.IntidEmpleoClsComboBox.DisplayMember = "strValor"
        Me.IntidEmpleoClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntidEmpleoClsComboBox.FormattingEnabled = True
        Me.IntidEmpleoClsComboBox.Location = New System.Drawing.Point(388, 19)
        Me.IntidEmpleoClsComboBox.Name = "IntidEmpleoClsComboBox"
        Me.IntidEmpleoClsComboBox.Size = New System.Drawing.Size(248, 21)
        Me.IntidEmpleoClsComboBox.TabIndex = 3
        Me.IntidEmpleoClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoEmpleoBindingSource
        '
        Me.TblTipoEmpleoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoEmpleoBindingSource.Sort = "strValor"
        '
        'IntidEscolaridadClsComboBox
        '
        Me.IntidEscolaridadClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesSocioEconomicosHCBindingSource, "intidEscolaridad", True))
        Me.IntidEscolaridadClsComboBox.DataSource = Me.TblTipoEscolaridadBindingSource
        Me.IntidEscolaridadClsComboBox.DisplayMember = "strValor"
        Me.IntidEscolaridadClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntidEscolaridadClsComboBox.FormattingEnabled = True
        Me.IntidEscolaridadClsComboBox.Location = New System.Drawing.Point(129, 19)
        Me.IntidEscolaridadClsComboBox.Name = "IntidEscolaridadClsComboBox"
        Me.IntidEscolaridadClsComboBox.Size = New System.Drawing.Size(197, 21)
        Me.IntidEscolaridadClsComboBox.TabIndex = 1
        Me.IntidEscolaridadClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoEscolaridadBindingSource
        '
        Me.TblTipoEscolaridadBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoEscolaridadBindingSource.Sort = "strValor"
        '
        'StrHcAntEconomicosTextBox
        '
        Me.StrHcAntEconomicosTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesSocioEconomicosHCBindingSource, "strHcAntEconomicos", True))
        Me.StrHcAntEconomicosTextBox.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StrHcAntEconomicosTextBox.Location = New System.Drawing.Point(274, 321)
        Me.StrHcAntEconomicosTextBox.Name = "StrHcAntEconomicosTextBox"
        Me.StrHcAntEconomicosTextBox.Size = New System.Drawing.Size(100, 26)
        Me.StrHcAntEconomicosTextBox.TabIndex = 91
        Me.StrHcAntEconomicosTextBox.Visible = False
        '
        'uscAntecedentesSocioEconomicos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.StrHcAntEconomicosTextBox)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.TblCitasMotivosConsultaBindingNavigator)
        Me.Name = "uscAntecedentesSocioEconomicos"
        Me.Size = New System.Drawing.Size(689, 439)
        CType(Me.TblCitasMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCitasMotivosConsultaBindingNavigator.ResumeLayout(False)
        Me.TblCitasMotivosConsultaBindingNavigator.PerformLayout()
        CType(Me.TblAntecedentesSocioEconomicosHCBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.TblTipoUbicacionViviendaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoAcabadosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoEstratoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoViviendaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.TblTipoViveBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoSostieneFamiliaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoIngresosFamiliaresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoIngresosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblOcupacionesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoEmpleoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoEscolaridadBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblCitasMotivosConsultaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblEPBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblAntecedentesSocioEconomicosHCBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents IntHabitacionesClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntUbicacionViviendaClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntBañosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntAcabadosClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntEstratoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntViviendaClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents IntViveClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntSostieneFamiliaClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents BitServicioMilitarClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents IntidIngresosFamiliaresClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntidIngresosClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntidOcupacionClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntidEmpleoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntidEscolaridadClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents TblTipoEscolaridadBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblOcupacionesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoEmpleoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoIngresosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoIngresosFamiliaresBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoSostieneFamiliaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoViveBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoViviendaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoUbicacionViviendaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoEstratoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoAcabadosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StrHcAntEconomicosTextBox As System.Windows.Forms.TextBox

End Class
