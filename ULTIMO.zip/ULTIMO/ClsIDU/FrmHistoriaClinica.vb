﻿Imports System.Windows.Forms
Imports System.Data.SqlClient

Public Class FrmHistoriaClinica

  ''Oscar Tabares - 23-09-2015 - Se agrega nuevas variables que almacenarán la fecha y hora al empezar y al finalizar 
  ''la atención del paciente por parte del profesional.
  Dim HoraInicioAtencion As Date
  Dim HoraFinalAtencion As Date

  Dim mstrStringConection As String
  Dim midUsuario As String
  Dim mCita As Integer
  Dim color As Object
  Dim mHC As Integer
  Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
  Dim mCambiarNodo As Boolean = True
  Dim mNodoSel As TreeNode
  Dim mclsUtilidadesHC As clsUtilidadesHC
  Dim clsTabs As New ClsUtilidades.clsTabs()
  Private mclsTabs As New ClsUtilidades.clsTabs()

  Sub New(ByVal strStringConection As String, ByVal Idusuario As String, ByVal idCita As Integer, ByVal mCedula As String, ByVal mNombre As String, ByVal mFecha As Date)
    Try
      ' This call is required by the Windows Form Designer.
      InitializeComponent()

      ' Add any initialization after the InitializeComponent() call.
      mstrStringConection = strStringConection
      midUsuario = Idusuario
      mCita = idCita
      dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
      mclsUtilidadesHC = New clsUtilidadesHC(dc, midUsuario)
      txtCedula.Text = mCedula
      txtNombre.Text = mNombre
      FechaVisitaClsTextBox.Text = mFecha


    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub FrmHistoriaClinica_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    HoraInicioAtencion = Now
    Try
      Dim existeCita = (From p In dc.tblHistoriasClinicas Where p.intIdCita = mCita).Count

      If existeCita = 0 Then
        Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, midUsuario)
        If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then
          Try
            Dim mUsuarioCita = (From u In dc.tblUsuarios Join c In dc.tblCita On u.intidEmpleado Equals c.intIdProfesional Where c.intIdCita = mCita Select u.intIdUsuario).Single
            If mUsuarioCita <> mValidaHuella.mstrIntIdUsuario Then
              MsgBox("El usuario no corresponde al profesional asignado para la cita..")
              Me.Close()
            End If
          Catch ex As Exception
            MsgBox("El usuario no tiene ningún profesional asignado para atender citas")
            Me.Close()
          End Try
        Else
          Me.Close()
        End If
        dc.usp_InsertarHistoriaClinica(mCita)
        dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
        btnMC.Focus()
      End If
      mHC = (From h In dc.tblHistoriasClinicas Where h.intIdCita = mCita Select h.intIdHC).Single
      'cambiarColor(PanelBotones, 0)
      mclsTabs.Add(New uscMotivosConsulta())
      mclsTabs.Add(New uscRevisionSistemas())
      mclsTabs.Add(New uscAntecedentesPersonales())
      mclsTabs.Add(New uscAntecedentesFamiliares())
      mclsTabs.Add(New uscAntecedentesGinecoObstetricos())
      mclsTabs.Add(New uscAntecedentesSocioEconomicos())
      mclsTabs.Add(New uscHabitos())
      mclsTabs.Add(New uscExamenesFisicos())
      mclsTabs.Add(New uscExamenesParaciclicos())
      mclsTabs.Add(New uscDiagnosticoConducta())
      mclsTabs.Add(New uscTratamiento())
      mclsTabs.Add(New uscEvolucionVisita())

      If existeCita <> 0 Then
        CType(mclsTabs.Item(0), uscMotivosConsulta).Enabled = False
        CType(mclsTabs.Item(1), uscRevisionSistemas).Enabled = False
        CType(mclsTabs.Item(2), uscAntecedentesPersonales).Enabled = False
        CType(mclsTabs.Item(3), uscAntecedentesFamiliares).Enabled = False
        CType(mclsTabs.Item(4), uscAntecedentesGinecoObstetricos).Enabled = False
        CType(mclsTabs.Item(5), uscAntecedentesSocioEconomicos).Enabled = False
        CType(mclsTabs.Item(6), uscHabitos).Enabled = False
        CType(mclsTabs.Item(7), uscExamenesFisicos).Enabled = False
        CType(mclsTabs.Item(8), uscExamenesParaciclicos).Enabled = False
        CType(mclsTabs.Item(9), uscDiagnosticoConducta).Enabled = False
        CType(mclsTabs.Item(10), uscTratamiento).Enabled = False
        CType(mclsTabs.Item(11), uscEvolucionVisita).Enabled = False
      End If

      PrSeleccionaTab(0)

    Catch ex As Exception
      'Me.Close()
      'ClsError.ClsError.PrMostrarError(ex)
      'Throw New Exception("Error..")
    End Try
  End Sub

  'Private Sub TabControl_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
  '    cambiarColor(PanelBotones, TabControl.SelectedIndex)
  'End Sub

  Private Sub btnMC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMC.Click, btnDC.Click, btnEP.Click, btnEF.Click, btnHabitos.Click, btnAE.Click, btnAG.Click, btnEvolucion.Click, btnTratamiento.Click, btnRS.Click, btnAP.Click, btnAF.Click
    Try
      'TabControl.SelectTab(sender.TabIndex)
      PrSeleccionaTab(sender.TabIndex())
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try

  End Sub

  Private Sub PrSeleccionaTab(ByVal mTab As Integer)
        'Modificación, Alejandro Torres Monsalve, alejo.torres9301@gmail.com
        'Se valida que el panel se haya cargado con alguna información para evitar errores al momento de cambiar de selección
        'If PanelMotivosConsulta.Controls.Count > 0 Then
        If PanelMotivosConsulta.Controls.Count = 1 Then
            If TypeOf (PanelMotivosConsulta.Controls.Item(0)) Is IAbandonarUC Then
                DirectCast(PanelMotivosConsulta.Controls.Item(0), IAbandonarUC).prGuardar()
            End If
        End If
        PanelMotivosConsulta.Controls.Clear()
      PanelMotivosConsulta.Controls.Add(mclsTabs.Items(mTab))
      PanelMotivosConsulta.Controls.Item(0).Dock = DockStyle.Fill
      cambiarColor(PanelBotones, mTab)
        'End If
    End Sub

  Private Sub cambiarColor(ByVal mpanel As Panel, ByVal mtabIndex As Integer)
    For Each c As Control In mpanel.Controls
      If TypeOf c Is Button Then
        If c.TabIndex = mtabIndex Then
          c.BackColor = Drawing.Color.Orange
        Else
          c.BackColor = color
        End If
      End If
    Next
    seleccionarTab()
  End Sub

  Private Sub btnSiguiente_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSiguiente.Click
    If (mclsTabs.SelectItem + 1 <= mclsTabs.Count - 1) Then
      PrSeleccionaTab(mclsTabs.SelectItem + 1)
    Else
      btnSiguiente.Enabled = False
      btnAnterior.Enabled = True
    End If
  End Sub

  Private Sub btnAnterior_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAnterior.Click
    If (mclsTabs.SelectItem - 1 >= 0) Then
      PrSeleccionaTab(mclsTabs.SelectItem - 1)
    Else
      btnAnterior.Enabled = False
      btnSiguiente.Enabled = True
    End If
  End Sub

  Private Sub seleccionarTab()
    Try

      Select Case mclsTabs.SelectItem
        Case 0
          'Motivos de consulta
          CType(PanelMotivosConsulta.Controls.Item(0), uscMotivosConsulta).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscMotivosConsulta).Boton = btnMC
          CType(PanelMotivosConsulta.Controls.Item(0), uscMotivosConsulta).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscMotivosConsulta).mCita = mCita
          CType(PanelMotivosConsulta.Controls.Item(0), uscMotivosConsulta).cargarDatosTabMC()
        Case 1
          'Revisión de sistemas
          CType(PanelMotivosConsulta.Controls.Item(0), uscRevisionSistemas).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscRevisionSistemas).mHC = mHC
          CType(PanelMotivosConsulta.Controls.Item(0), uscRevisionSistemas).Boton = btnRS
          CType(PanelMotivosConsulta.Controls.Item(0), uscRevisionSistemas).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscRevisionSistemas).CargarItemRevisionSistemasHC()
        Case 2
          'Antecedentes personales               
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesPersonales).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesPersonales).mIdentificacion = txtCedula.Text
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesPersonales).Boton = btnAP
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesPersonales).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesPersonales).cargarDatosTabAP()
        Case 3
          'Antecedentes familiares
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesFamiliares).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesFamiliares).mIdentificacion = txtCedula.Text
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesFamiliares).Boton = btnAF
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesFamiliares).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesFamiliares).cargarDatosTabAF()
        Case 4
          'Antecedentes Gineco Abstetricos
          Dim mSexo As Integer = (From c In dc.tblCita Join p In dc.tblPacientes On c.strNroIdPaciente Equals p.strNroIdentificacion Where c.intIdCita = mCita Select p.intSexo).Single
          If mSexo = 7 Then
            CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesGinecoObstetricos).dc = dc
            CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesGinecoObstetricos).mIdentificacion = txtCedula.Text
            CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesGinecoObstetricos).Boton = btnAG
            CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesGinecoObstetricos).IdUsuario = midUsuario
            CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesGinecoObstetricos).cargarDatosTabAG()
          Else
            CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesGinecoObstetricos).Enabled = False
          End If
        Case 5
          'Antecedentes Socio-Economicos
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesSocioEconomicos).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesSocioEconomicos).mIdentificacion = txtCedula.Text
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesSocioEconomicos).Boton = btnAE
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesSocioEconomicos).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscAntecedentesSocioEconomicos).cargarDatosTabASE()
        Case 6
          'Habitos
          CType(PanelMotivosConsulta.Controls.Item(0), uscHabitos).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscHabitos).mIdentificacion = txtCedula.Text
          CType(PanelMotivosConsulta.Controls.Item(0), uscHabitos).Boton = btnHabitos
          CType(PanelMotivosConsulta.Controls.Item(0), uscHabitos).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscHabitos).cargarDatosTabHabitos()
        Case 7
          'Examenes fisicos
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesFisicos).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesFisicos).mHC = mHC
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesFisicos).Boton = btnEF
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesFisicos).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesFisicos).CargarItemExamenesFisicosHC()
        Case 8
          'Examenes paraciclicos
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesParaciclicos).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesParaciclicos).mHC = mHC
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesParaciclicos).Boton = btnEP
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesParaciclicos).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesParaciclicos).CargarItemExamenes()
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesParaciclicos).mstrStringConection = mstrStringConection
          CType(PanelMotivosConsulta.Controls.Item(0), uscExamenesParaciclicos).mCita = mCita

        Case 9
          'Diagnostico y conducta
          CType(PanelMotivosConsulta.Controls.Item(0), uscDiagnosticoConducta).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscDiagnosticoConducta).mHC = mHC
          CType(PanelMotivosConsulta.Controls.Item(0), uscDiagnosticoConducta).Boton = btnDC
          CType(PanelMotivosConsulta.Controls.Item(0), uscDiagnosticoConducta).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscDiagnosticoConducta).cargarDatosTabDC()
          CType(PanelMotivosConsulta.Controls.Item(0), uscDiagnosticoConducta).mstrStringConection = mstrStringConection
          CType(PanelMotivosConsulta.Controls.Item(0), uscDiagnosticoConducta).mCita = mCita
        Case 10
          'Tratamiento()
          CType(PanelMotivosConsulta.Controls.Item(0), uscTratamiento).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscTratamiento).mHC = mHC
          CType(PanelMotivosConsulta.Controls.Item(0), uscTratamiento).Boton = btnTratamiento
          CType(PanelMotivosConsulta.Controls.Item(0), uscTratamiento).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscTratamiento).cargarDatosTabTratamiento()
          CType(PanelMotivosConsulta.Controls.Item(0), uscTratamiento).mstrStringConection = mstrStringConection
          CType(PanelMotivosConsulta.Controls.Item(0), uscTratamiento).mCita = mCita
        Case 11
          'Evolución de la visita
          CType(PanelMotivosConsulta.Controls.Item(0), uscEvolucionVisita).dc = dc
          CType(PanelMotivosConsulta.Controls.Item(0), uscEvolucionVisita).mHC = mHC
          CType(PanelMotivosConsulta.Controls.Item(0), uscEvolucionVisita).Boton = btnEvolucion
          CType(PanelMotivosConsulta.Controls.Item(0), uscEvolucionVisita).IdUsuario = midUsuario
          CType(PanelMotivosConsulta.Controls.Item(0), uscEvolucionVisita).CargarItemEvolucionHC()
          CType(PanelMotivosConsulta.Controls.Item(0), uscEvolucionVisita).mstrStringConection = mstrStringConection
          CType(PanelMotivosConsulta.Controls.Item(0), uscEvolucionVisita).mCita = mCita
      End Select
    Catch ex As Exception

    End Try
  End Sub



#Region "Procedimientos para Revisión de sistemas"

  'Private Sub CargarItemRevisionSistemasHC()
  '    Try
  '        If mclsUtilidadesHC.consultarModoTextoItems(btnRS) = True Then
  '            ObservacionesClsTextBox.Dock = DockStyle.Fill
  '            ObservacionesClsTextBox.BringToFront()
  '            ObservacionesClsTextBox.ReadOnly = False
  '        Else
  '            PrCargarDatosRevisionSistemas()
  '        End If
  '    Catch ex As Exception
  '        ClsError.ClsError.PrMostrarError(ex)
  '    End Try
  'End Sub

  'Private Sub PrCargarDatosRevisionSistemas()
  '    Try
  '        If TreeViewSistemas.Nodes.Count = 0 Then
  '            Dim mClsllenarTreeview As New ClsLlenarTreeViewSintomasSignosLab()
  '            mClsllenarTreeview.PrllenarTreeView(0, dc, TreeViewSistemas)  'PrllenarTreeView()
  '        End If
  '        TreeViewSistemas.HideSelection = False
  '        Dim tblRevisionSistemas = (From r In dc.tblRevisionSistemasHC Where r.intIdHC = mHC Select r)
  '        For Each mtblRevisionSistemas In tblRevisionSistemas
  '            For Each mNodo As TreeNode In TreeViewSistemas.Nodes
  '                If mNodo.Nodes.Count > 0 Then
  '                    If FnBuscarHijos(mtblRevisionSistemas.intIdSintSigLab, mNodo) Then
  '                        mNodo.Expand()
  '                    End If
  '                Else
  '                    If mNodo.Tag = mtblRevisionSistemas.intIdSintSigLab Then
  '                        mNodo.ImageIndex = 3
  '                        mNodo.SelectedImageIndex = 3
  '                    Else
  '                        If mNodo.ImageIndex <> 3 Then
  '                            mNodo.ImageIndex = 1
  '                            mNodo.SelectedImageIndex = 1
  '                        End If
  '                    End If
  '                End If
  '            Next
  '        Next
  '    Catch ex As Exception
  '        ClsError.ClsError.PrMostrarError(ex)
  '    End Try
  'End Sub

  'Private Function FnBuscarHijos(ByVal pintIdSintSigLab As Integer, ByVal pNodo As TreeNode)
  '    Dim mBuscarHijos As Boolean = False
  '    For Each mNodo As TreeNode In pNodo.Nodes
  '        If mNodo.Nodes.Count > 0 Then
  '            If FnBuscarHijos(pintIdSintSigLab, mNodo) Then
  '                mNodo.Expand()
  '                mBuscarHijos = True
  '            End If
  '        Else
  '            If mNodo.Tag = pintIdSintSigLab Then
  '                mNodo.ImageIndex = 3
  '                mNodo.SelectedImageIndex = 3
  '                mBuscarHijos = True
  '            Else
  '                If mNodo.ImageIndex <> 3 Then
  '                    mNodo.ImageIndex = 1
  '                    mNodo.SelectedImageIndex = 1
  '                End If
  '            End If
  '        End If
  '    Next
  '    FnBuscarHijos = mBuscarHijos
  'End Function

  'Private Sub bitValorBoolSiRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bitValorBoolSiRadioButton.CheckedChanged, bitValorBoolNoRadioButton.CheckedChanged
  '    If TreeViewSistemas.SelectedNode.Nodes.Count = 0 And mCambiarNodo Then
  '        TreeViewSistemas.SelectedNode.ImageIndex = 3
  '        TreeViewSistemas.SelectedNode.SelectedImageIndex = 3
  '        mNodoSel = TreeViewSistemas.SelectedNode
  '        ObservacionesClsTextBox.ReadOnly = False
  '    End If
  'End Sub

  'Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
  '    If TreeViewSistemas.SelectedNode.Nodes.Count = 0 Then
  '        TreeViewSistemas.SelectedNode.ImageIndex = 1
  '        TreeViewSistemas.SelectedNode.SelectedImageIndex = 1
  '        ObservacionesClsTextBox.ReadOnly = True
  '        mCambiarNodo = False
  '        bitValorBoolSiRadioButton.Checked = False
  '        bitValorBoolNoRadioButton.Checked = False
  '        mCambiarNodo = True
  '        mNodoSel = Nothing
  '    End If
  'End Sub

  'Private Sub btnRevisar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRevisar.Click
  '    PrCargarDatosRevisionSistemas()
  'End Sub

  'Private Sub TreeViewSistemas_NodeMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles TreeViewSistemas.NodeMouseClick
  '    Try
  '        If e.Node.ImageIndex = 3 Then
  '            Dim mTag As Integer
  '            mTag = e.Node.Tag
  '            Dim tblRevisionSistemas = (From r In dc.tblRevisionSistemasHC Where r.intIdHC = mHC And r.intIdSintSigLab = mTag Select r)
  '            For Each mtblRevisionSistemas In tblRevisionSistemas
  '                ObservacionesClsTextBox.Text = mtblRevisionSistemas.strValorTexto
  '                ValorNumClsTextBox.Text = mtblRevisionSistemas.numValorNum
  '                mCambiarNodo = False
  '                If mtblRevisionSistemas.bitValorBool Then
  '                    bitValorBoolSiRadioButton.Checked = True
  '                    bitValorBoolNoRadioButton.Checked = False
  '                Else
  '                    bitValorBoolSiRadioButton.Checked = False
  '                    bitValorBoolNoRadioButton.Checked = True
  '                End If
  '                mCambiarNodo = True
  '            Next

  '        Else
  '            If mNodoSel Is Nothing Then
  '                ObservacionesClsTextBox.Text = ""
  '                ValorNumClsTextBox.Text = 0
  '                mCambiarNodo = False
  '                bitValorBoolSiRadioButton.Checked = False
  '                bitValorBoolNoRadioButton.Checked = False
  '                mCambiarNodo = True
  '            End If
  '        End If
  '    Catch ex As Exception
  '        'ClsError.ClsError.PrMostrarError(ex)
  '    End Try
  'End Sub

  'Private Sub TreeViewSistemas_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeViewSistemas.AfterSelect
  '    Try
  '        If Not mNodoSel Is Nothing Then
  '            Dim mValor As Decimal
  '            If IsNumeric(ValorNumClsTextBox.Text) Then
  '                mValor = Decimal.Parse(ValorNumClsTextBox.Text)
  '            Else
  '                mValor = 0
  '            End If
  '            dc.usp_ActualizarRevisionSistemasHC(mNodoSel.Tag, mValor, bitValorBoolSiRadioButton.Checked, ObservacionesClsTextBox.Text, mHC)
  '            mNodoSel = Nothing
  '        End If
  '    Catch ex As Exception
  '        ClsError.ClsError.PrMostrarError(ex)
  '    End Try
  'End Sub

#End Region


  Private Sub btnFinalizar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFinalizar.Click

    HoraFinalAtencion = Now()

    If Application.OpenForms("FrmResumenHC") Is Nothing Then
      Dim mFrmresumenHC = New ClsReportes.FrmResumenHC(mstrStringConection, mCita, mHC, midUsuario, txtCedula.Text, HoraInicioAtencion, HoraFinalAtencion, True)
      'mFrmresumenHC.MdiParent = Me.MdiParent
      mFrmresumenHC.Show()
    Else
      Application.OpenForms("FrmResumenHC").BringToFront()
    End If

  End Sub

  Private Sub FrmHistoriaClinica_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
    If e.Alt Then
      If e.KeyCode = Keys.F10 Then
                'Modificación, Alejandro Torres Monsalve, alejo.torres9301@gmail.com
                'Se validad que en el panel se haya cargado alguna información para evitar errores al momento de cambiar de selección
                'If PanelMotivosConsulta.Controls.Count > 0 Then
                PanelMotivosConsulta.Controls.Item(0).Enabled = True
                'End If
            End If
    End If
  End Sub

End Class