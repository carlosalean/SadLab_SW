﻿Public Class FrmGenericos

    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mIntIdGenerico As Integer

    Public Sub New(ByVal pdc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext, ByVal pIntIdGenerico As Integer)
        Try
            ' Llamada necesaria para el Diseñador de Windows Forms.
            InitializeComponent()

            ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
            dc = pdc
            mIntIdGenerico = pIntIdGenerico
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
    Private Sub FrmGenericos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim tblGenericos = (From g In dc.tblMedicamentosGenericos Where g.intIdMedicamentosGenericos = mIntIdGenerico Select g)
            TblMedicamentosGenericosBindingSource.DataSource = tblGenericos
            TblMedicamentosBindingSource.DataSource = dc.tblMedicamentos
            Dim tblDosificacion = From t In dc.tblTipos Where t.strTipo = "MEDIDAS_DROGAS" Select t
            TblTipoBindingSource.DataSource = tblDosificacion
            Dim tblFrecuencia = From t In dc.tblTipos Where t.strTipo = "FRECUENCIA" Select t
            TblTipoBindingSource1.DataSource = tblFrecuencia
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblMedicamentosGenericosBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblMedicamentosGenericosBindingNavigatorSaveItem.Click
        Try
            TblMedicamentosGenericosBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblNombresComercialesDataGridView_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles TblNombresComercialesDataGridView.CellClick
        Try
            If e.ColumnIndex = 2 Then
                Dim mFrmComerciales As New FrmComerciales(dc, TblNombresComercialesDataGridView.Rows(e.RowIndex).Cells(0).Value)
                mFrmComerciales.Show()
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class