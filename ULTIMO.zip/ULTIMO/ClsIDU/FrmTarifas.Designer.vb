﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmTarifas
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim IntIdEPSLabel As System.Windows.Forms.Label
    Dim lblIPS As System.Windows.Forms.Label
    Dim lblEPS As System.Windows.Forms.Label
    Dim lblProcedimiento As System.Windows.Forms.Label
    Dim lblTipo As System.Windows.Forms.Label
    Dim lblTipoTarifa As System.Windows.Forms.Label
    Dim lblCodigoContabilidad As System.Windows.Forms.Label
    Dim lblValor As System.Windows.Forms.Label
    Dim lblTarifaBase As System.Windows.Forms.Label
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmTarifas))
    Me.TabControl1 = New System.Windows.Forms.TabControl()
    Me.TabPage1 = New System.Windows.Forms.TabPage()
    Me.TblTarifaDataGridView = New System.Windows.Forms.DataGridView()
    Me.TabPage2 = New System.Windows.Forms.TabPage()
    Me.cbTarifaBase = New System.Windows.Forms.ComboBox()
    Me.txtValor = New System.Windows.Forms.TextBox()
    Me.txtCodigoContabilidad = New System.Windows.Forms.TextBox()
    Me.cbTIpoTarifa = New System.Windows.Forms.ComboBox()
    Me.cbTipo = New System.Windows.Forms.ComboBox()
    Me.cbProcedimiento = New System.Windows.Forms.ComboBox()
    Me.cbEPS = New System.Windows.Forms.ComboBox()
    Me.cbIPS = New System.Windows.Forms.ComboBox()
    Me.txtIdTarifaIPSPorEPS = New ClsUtilidades.ClsTextBox()
    Me.TblEPsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.TblProcedimientoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.TblTarifaBaseDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.TblTipoTarifaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.IntIdTarifaBaseDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.IntIDTipoTarifaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.StrCodigoProcedimientoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.NumValorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.IntTipoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.IntIdProcedimientoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.IntIdEPSDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.IntIdTarifaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
    Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
    Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
    Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
    Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
    Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
    Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
    Me.TblTarifaBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
    Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
    Me.TblTarifaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
    IntIdEPSLabel = New System.Windows.Forms.Label()
    lblIPS = New System.Windows.Forms.Label()
    lblEPS = New System.Windows.Forms.Label()
    lblProcedimiento = New System.Windows.Forms.Label()
    lblTipo = New System.Windows.Forms.Label()
    lblTipoTarifa = New System.Windows.Forms.Label()
    lblCodigoContabilidad = New System.Windows.Forms.Label()
    lblValor = New System.Windows.Forms.Label()
    lblTarifaBase = New System.Windows.Forms.Label()
    Me.TabControl1.SuspendLayout()
    Me.TabPage1.SuspendLayout()
    CType(Me.TblTarifaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.TabPage2.SuspendLayout()
    CType(Me.TblTarifaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.TblTarifaBindingNavigator.SuspendLayout()
    Me.SuspendLayout()
    '
    'IntIdEPSLabel
    '
    IntIdEPSLabel.AutoSize = True
    IntIdEPSLabel.Location = New System.Drawing.Point(12, 14)
    IntIdEPSLabel.Name = "IntIdEPSLabel"
    IntIdEPSLabel.Size = New System.Drawing.Size(19, 13)
    IntIdEPSLabel.TabIndex = 5
    IntIdEPSLabel.Text = "Id:"
    '
    'lblIPS
    '
    lblIPS.AutoSize = True
    lblIPS.Location = New System.Drawing.Point(12, 49)
    lblIPS.Name = "lblIPS"
    lblIPS.Size = New System.Drawing.Size(27, 13)
    lblIPS.TabIndex = 7
    lblIPS.Text = "IPS:"
    '
    'lblEPS
    '
    lblEPS.AutoSize = True
    lblEPS.Location = New System.Drawing.Point(12, 78)
    lblEPS.Name = "lblEPS"
    lblEPS.Size = New System.Drawing.Size(31, 13)
    lblEPS.TabIndex = 9
    lblEPS.Text = "EPS:"
    '
    'lblProcedimiento
    '
    lblProcedimiento.AutoSize = True
    lblProcedimiento.Location = New System.Drawing.Point(12, 107)
    lblProcedimiento.Name = "lblProcedimiento"
    lblProcedimiento.Size = New System.Drawing.Size(77, 13)
    lblProcedimiento.TabIndex = 11
    lblProcedimiento.Text = "Procedimiento:"
    '
    'lblTipo
    '
    lblTipo.AutoSize = True
    lblTipo.Location = New System.Drawing.Point(12, 137)
    lblTipo.Name = "lblTipo"
    lblTipo.Size = New System.Drawing.Size(31, 13)
    lblTipo.TabIndex = 13
    lblTipo.Text = "Tipo:"
    '
    'lblTipoTarifa
    '
    lblTipoTarifa.AutoSize = True
    lblTipoTarifa.Location = New System.Drawing.Point(12, 169)
    lblTipoTarifa.Name = "lblTipoTarifa"
    lblTipoTarifa.Size = New System.Drawing.Size(57, 13)
    lblTipoTarifa.TabIndex = 15
    lblTipoTarifa.Text = "Tipo tarifa:"
    '
    'lblCodigoContabilidad
    '
    lblCodigoContabilidad.AutoSize = True
    lblCodigoContabilidad.Location = New System.Drawing.Point(12, 233)
    lblCodigoContabilidad.Name = "lblCodigoContabilidad"
    lblCodigoContabilidad.Size = New System.Drawing.Size(103, 13)
    lblCodigoContabilidad.TabIndex = 17
    lblCodigoContabilidad.Text = "Código contabilidad:"
    '
    'lblValor
    '
    lblValor.AutoSize = True
    lblValor.Location = New System.Drawing.Point(12, 263)
    lblValor.Name = "lblValor"
    lblValor.Size = New System.Drawing.Size(34, 13)
    lblValor.TabIndex = 19
    lblValor.Text = "Valor:"
    '
    'lblTarifaBase
    '
    lblTarifaBase.AutoSize = True
    lblTarifaBase.Location = New System.Drawing.Point(12, 203)
    lblTarifaBase.Name = "lblTarifaBase"
    lblTarifaBase.Size = New System.Drawing.Size(63, 13)
    lblTarifaBase.TabIndex = 21
    lblTarifaBase.Text = "Tarifa base:"
    '
    'TabControl1
    '
    Me.TabControl1.Controls.Add(Me.TabPage1)
    Me.TabControl1.Controls.Add(Me.TabPage2)
    Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.TabControl1.Location = New System.Drawing.Point(0, 25)
    Me.TabControl1.Name = "TabControl1"
    Me.TabControl1.SelectedIndex = 0
    Me.TabControl1.Size = New System.Drawing.Size(1040, 362)
    Me.TabControl1.TabIndex = 1
    Me.TabControl1.Tag = ""
    '
    'TabPage1
    '
    Me.TabPage1.Controls.Add(Me.TblTarifaDataGridView)
    Me.TabPage1.Location = New System.Drawing.Point(4, 22)
    Me.TabPage1.Name = "TabPage1"
    Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
    Me.TabPage1.Size = New System.Drawing.Size(1032, 336)
    Me.TabPage1.TabIndex = 0
    Me.TabPage1.Text = "Tabla"
    Me.TabPage1.UseVisualStyleBackColor = True
    '
    'TblTarifaDataGridView
    '
    Me.TblTarifaDataGridView.AllowUserToAddRows = False
    Me.TblTarifaDataGridView.AllowUserToDeleteRows = False
    Me.TblTarifaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
    Me.TblTarifaDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
    Me.TblTarifaDataGridView.Location = New System.Drawing.Point(3, 3)
    Me.TblTarifaDataGridView.Name = "TblTarifaDataGridView"
    Me.TblTarifaDataGridView.ReadOnly = True
    Me.TblTarifaDataGridView.Size = New System.Drawing.Size(1026, 330)
    Me.TblTarifaDataGridView.TabIndex = 0
    '
    'TabPage2
    '
    Me.TabPage2.Controls.Add(Me.cbTarifaBase)
    Me.TabPage2.Controls.Add(lblTarifaBase)
    Me.TabPage2.Controls.Add(Me.txtValor)
    Me.TabPage2.Controls.Add(lblValor)
    Me.TabPage2.Controls.Add(Me.txtCodigoContabilidad)
    Me.TabPage2.Controls.Add(lblCodigoContabilidad)
    Me.TabPage2.Controls.Add(Me.cbTIpoTarifa)
    Me.TabPage2.Controls.Add(lblTipoTarifa)
    Me.TabPage2.Controls.Add(Me.cbTipo)
    Me.TabPage2.Controls.Add(lblTipo)
    Me.TabPage2.Controls.Add(Me.cbProcedimiento)
    Me.TabPage2.Controls.Add(lblProcedimiento)
    Me.TabPage2.Controls.Add(Me.cbEPS)
    Me.TabPage2.Controls.Add(lblEPS)
    Me.TabPage2.Controls.Add(Me.cbIPS)
    Me.TabPage2.Controls.Add(IntIdEPSLabel)
    Me.TabPage2.Controls.Add(Me.txtIdTarifaIPSPorEPS)
    Me.TabPage2.Controls.Add(lblIPS)
    Me.TabPage2.Location = New System.Drawing.Point(4, 22)
    Me.TabPage2.Name = "TabPage2"
    Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
    Me.TabPage2.Size = New System.Drawing.Size(1032, 336)
    Me.TabPage2.TabIndex = 1
    Me.TabPage2.Text = "Detalle"
    Me.TabPage2.UseVisualStyleBackColor = True
    '
    'cbTarifaBase
    '
    Me.cbTarifaBase.FormattingEnabled = True
    Me.cbTarifaBase.Location = New System.Drawing.Point(136, 194)
    Me.cbTarifaBase.Name = "cbTarifaBase"
    Me.cbTarifaBase.Size = New System.Drawing.Size(121, 21)
    Me.cbTarifaBase.TabIndex = 22
    '
    'txtValor
    '
    Me.txtValor.Location = New System.Drawing.Point(136, 255)
    Me.txtValor.MaxLength = 4
    Me.txtValor.Name = "txtValor"
    Me.txtValor.Size = New System.Drawing.Size(121, 20)
    Me.txtValor.TabIndex = 20
    '
    'txtCodigoContabilidad
    '
    Me.txtCodigoContabilidad.Location = New System.Drawing.Point(136, 225)
    Me.txtCodigoContabilidad.MaxLength = 12
    Me.txtCodigoContabilidad.Name = "txtCodigoContabilidad"
    Me.txtCodigoContabilidad.Size = New System.Drawing.Size(121, 20)
    Me.txtCodigoContabilidad.TabIndex = 18
    '
    'cbTIpoTarifa
    '
    Me.cbTIpoTarifa.FormattingEnabled = True
    Me.cbTIpoTarifa.Location = New System.Drawing.Point(136, 160)
    Me.cbTIpoTarifa.Name = "cbTIpoTarifa"
    Me.cbTIpoTarifa.Size = New System.Drawing.Size(121, 21)
    Me.cbTIpoTarifa.TabIndex = 16
    '
    'cbTipo
    '
    Me.cbTipo.FormattingEnabled = True
    Me.cbTipo.Location = New System.Drawing.Point(136, 128)
    Me.cbTipo.Name = "cbTipo"
    Me.cbTipo.Size = New System.Drawing.Size(121, 21)
    Me.cbTipo.TabIndex = 14
    '
    'cbProcedimiento
    '
    Me.cbProcedimiento.FormattingEnabled = True
    Me.cbProcedimiento.Location = New System.Drawing.Point(136, 98)
    Me.cbProcedimiento.Name = "cbProcedimiento"
    Me.cbProcedimiento.Size = New System.Drawing.Size(275, 21)
    Me.cbProcedimiento.TabIndex = 12
    '
    'cbEPS
    '
    Me.cbEPS.FormattingEnabled = True
    Me.cbEPS.Location = New System.Drawing.Point(136, 69)
    Me.cbEPS.Name = "cbEPS"
    Me.cbEPS.Size = New System.Drawing.Size(275, 21)
    Me.cbEPS.TabIndex = 10
    '
    'cbIPS
    '
    Me.cbIPS.FormattingEnabled = True
    Me.cbIPS.Location = New System.Drawing.Point(136, 40)
    Me.cbIPS.Name = "cbIPS"
    Me.cbIPS.Size = New System.Drawing.Size(275, 21)
    Me.cbIPS.TabIndex = 8
    '
    'txtIdTarifaIPSPorEPS
    '
    Me.txtIdTarifaIPSPorEPS.DataSource = Nothing
    Me.txtIdTarifaIPSPorEPS.Enabled = False
    Me.txtIdTarifaIPSPorEPS.EnterEntreCampos = True
    Me.txtIdTarifaIPSPorEPS.Location = New System.Drawing.Point(136, 11)
    Me.txtIdTarifaIPSPorEPS.Name = "txtIdTarifaIPSPorEPS"
    Me.txtIdTarifaIPSPorEPS.NombreCodigoF2 = Nothing
    Me.txtIdTarifaIPSPorEPS.NombreDescripcionF2 = Nothing
    Me.txtIdTarifaIPSPorEPS.Size = New System.Drawing.Size(44, 20)
    Me.txtIdTarifaIPSPorEPS.TabIndex = 6
    Me.txtIdTarifaIPSPorEPS.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'TblEPsDataGridViewTextBoxColumn
    '
    Me.TblEPsDataGridViewTextBoxColumn.DataPropertyName = "tblEPs"
    Me.TblEPsDataGridViewTextBoxColumn.HeaderText = "tblEPs"
    Me.TblEPsDataGridViewTextBoxColumn.Name = "TblEPsDataGridViewTextBoxColumn"
    '
    'TblProcedimientoDataGridViewTextBoxColumn
    '
    Me.TblProcedimientoDataGridViewTextBoxColumn.DataPropertyName = "tblProcedimiento"
    Me.TblProcedimientoDataGridViewTextBoxColumn.HeaderText = "tblProcedimiento"
    Me.TblProcedimientoDataGridViewTextBoxColumn.Name = "TblProcedimientoDataGridViewTextBoxColumn"
    '
    'TblTarifaBaseDataGridViewTextBoxColumn
    '
    Me.TblTarifaBaseDataGridViewTextBoxColumn.DataPropertyName = "tblTarifaBase"
    Me.TblTarifaBaseDataGridViewTextBoxColumn.HeaderText = "tblTarifaBase"
    Me.TblTarifaBaseDataGridViewTextBoxColumn.Name = "TblTarifaBaseDataGridViewTextBoxColumn"
    '
    'TblTipoTarifaDataGridViewTextBoxColumn
    '
    Me.TblTipoTarifaDataGridViewTextBoxColumn.DataPropertyName = "tblTipoTarifa"
    Me.TblTipoTarifaDataGridViewTextBoxColumn.HeaderText = "tblTipoTarifa"
    Me.TblTipoTarifaDataGridViewTextBoxColumn.Name = "TblTipoTarifaDataGridViewTextBoxColumn"
    '
    'IntIdTarifaBaseDataGridViewTextBoxColumn
    '
    Me.IntIdTarifaBaseDataGridViewTextBoxColumn.DataPropertyName = "intIdTarifaBase"
    Me.IntIdTarifaBaseDataGridViewTextBoxColumn.HeaderText = "intIdTarifaBase"
    Me.IntIdTarifaBaseDataGridViewTextBoxColumn.Name = "IntIdTarifaBaseDataGridViewTextBoxColumn"
    '
    'IntIDTipoTarifaDataGridViewTextBoxColumn
    '
    Me.IntIDTipoTarifaDataGridViewTextBoxColumn.DataPropertyName = "intIDTipoTarifa"
    Me.IntIDTipoTarifaDataGridViewTextBoxColumn.HeaderText = "intIDTipoTarifa"
    Me.IntIDTipoTarifaDataGridViewTextBoxColumn.Name = "IntIDTipoTarifaDataGridViewTextBoxColumn"
    '
    'StrCodigoProcedimientoDataGridViewTextBoxColumn
    '
    Me.StrCodigoProcedimientoDataGridViewTextBoxColumn.DataPropertyName = "strCodigoProcedimiento"
    Me.StrCodigoProcedimientoDataGridViewTextBoxColumn.HeaderText = "strCodigoProcedimiento"
    Me.StrCodigoProcedimientoDataGridViewTextBoxColumn.Name = "StrCodigoProcedimientoDataGridViewTextBoxColumn"
    '
    'NumValorDataGridViewTextBoxColumn
    '
    Me.NumValorDataGridViewTextBoxColumn.DataPropertyName = "numValor"
    Me.NumValorDataGridViewTextBoxColumn.HeaderText = "numValor"
    Me.NumValorDataGridViewTextBoxColumn.Name = "NumValorDataGridViewTextBoxColumn"
    '
    'IntTipoDataGridViewTextBoxColumn
    '
    Me.IntTipoDataGridViewTextBoxColumn.DataPropertyName = "intTipo"
    Me.IntTipoDataGridViewTextBoxColumn.HeaderText = "intTipo"
    Me.IntTipoDataGridViewTextBoxColumn.Name = "IntTipoDataGridViewTextBoxColumn"
    '
    'IntIdProcedimientoDataGridViewTextBoxColumn
    '
    Me.IntIdProcedimientoDataGridViewTextBoxColumn.DataPropertyName = "intIdProcedimiento"
    Me.IntIdProcedimientoDataGridViewTextBoxColumn.HeaderText = "intIdProcedimiento"
    Me.IntIdProcedimientoDataGridViewTextBoxColumn.Name = "IntIdProcedimientoDataGridViewTextBoxColumn"
    '
    'IntIdEPSDataGridViewTextBoxColumn
    '
    Me.IntIdEPSDataGridViewTextBoxColumn.DataPropertyName = "intIdEPS"
    Me.IntIdEPSDataGridViewTextBoxColumn.HeaderText = "intIdEPS"
    Me.IntIdEPSDataGridViewTextBoxColumn.Name = "IntIdEPSDataGridViewTextBoxColumn"
    '
    'IntIdTarifaDataGridViewTextBoxColumn
    '
    Me.IntIdTarifaDataGridViewTextBoxColumn.DataPropertyName = "intIdTarifa"
    Me.IntIdTarifaDataGridViewTextBoxColumn.HeaderText = "intIdTarifa"
    Me.IntIdTarifaDataGridViewTextBoxColumn.Name = "IntIdTarifaDataGridViewTextBoxColumn"
    '
    'BindingNavigatorMoveFirstItem
    '
    Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
    Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorMoveFirstItem.Text = "Move first"
    '
    'BindingNavigatorMovePreviousItem
    '
    Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
    Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
    '
    'BindingNavigatorSeparator
    '
    Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
    Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
    '
    'BindingNavigatorPositionItem
    '
    Me.BindingNavigatorPositionItem.AccessibleName = "Position"
    Me.BindingNavigatorPositionItem.AutoSize = False
    Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
    Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
    Me.BindingNavigatorPositionItem.Text = "0"
    Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
    '
    'BindingNavigatorCountItem
    '
    Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
    Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
    Me.BindingNavigatorCountItem.Text = "of {0}"
    Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
    '
    'BindingNavigatorSeparator1
    '
    Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
    Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
    '
    'BindingNavigatorMoveNextItem
    '
    Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
    Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorMoveNextItem.Text = "Move next"
    '
    'BindingNavigatorMoveLastItem
    '
    Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
    Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorMoveLastItem.Text = "Move last"
    '
    'BindingNavigatorSeparator2
    '
    Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
    Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
    '
    'BindingNavigatorAddNewItem
    '
    Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
    Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorAddNewItem.Text = "Add new"
    '
    'BindingNavigatorDeleteItem
    '
    Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
    Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorDeleteItem.Text = "Delete"
    '
    'TblTarifaBindingNavigatorSaveItem
    '
    Me.TblTarifaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.TblTarifaBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblTarifaBindingNavigatorSaveItem.Image"), System.Drawing.Image)
    Me.TblTarifaBindingNavigatorSaveItem.Name = "TblTarifaBindingNavigatorSaveItem"
    Me.TblTarifaBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
    Me.TblTarifaBindingNavigatorSaveItem.Text = "Save Data"
    '
    'ToolStripSeparator1
    '
    Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
    Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
    '
    'TblTarifaBindingNavigator
    '
    Me.TblTarifaBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
    Me.TblTarifaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
    Me.TblTarifaBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
    Me.TblTarifaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblTarifaBindingNavigatorSaveItem, Me.ToolStripSeparator1})
    Me.TblTarifaBindingNavigator.Location = New System.Drawing.Point(0, 0)
    Me.TblTarifaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
    Me.TblTarifaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
    Me.TblTarifaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
    Me.TblTarifaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
    Me.TblTarifaBindingNavigator.Name = "TblTarifaBindingNavigator"
    Me.TblTarifaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
    Me.TblTarifaBindingNavigator.Size = New System.Drawing.Size(1040, 25)
    Me.TblTarifaBindingNavigator.TabIndex = 2
    Me.TblTarifaBindingNavigator.Text = "BindingNavigator1"
    '
    'FrmTarifas
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(1040, 387)
    Me.Controls.Add(Me.TabControl1)
    Me.Controls.Add(Me.TblTarifaBindingNavigator)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Name = "FrmTarifas"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Tarifas"
    Me.TabControl1.ResumeLayout(False)
    Me.TabPage1.ResumeLayout(False)
    CType(Me.TblTarifaDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
    Me.TabPage2.ResumeLayout(False)
    Me.TabPage2.PerformLayout()
    CType(Me.TblTarifaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
    Me.TblTarifaBindingNavigator.ResumeLayout(False)
    Me.TblTarifaBindingNavigator.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Public WithEvents TabControl1 As System.Windows.Forms.TabControl
  Public WithEvents TabPage1 As System.Windows.Forms.TabPage
  Friend WithEvents TblTarifaDataGridView As System.Windows.Forms.DataGridView
  Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents NIdTarifaIPSPorEPSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents NIdIPSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents NIdEPSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents NIdProcedimientoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents SNombreParaContabilidadDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents SCodigoContabilidadDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents NValorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents IPSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents TblEPsDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents TblProcedimientoDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents TblEPsDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents TblProcedimientoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents TblTarifaBaseDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents TblTipoTarifaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents IntIdTarifaBaseDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents IntIDTipoTarifaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents StrCodigoProcedimientoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents NumValorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents IntTipoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents IntIdProcedimientoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents IntIdEPSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents IntIdTarifaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
  Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
  Friend WithEvents txtIdTarifaIPSPorEPS As ClsUtilidades.ClsTextBox
  Friend WithEvents cbIPS As System.Windows.Forms.ComboBox
  Friend WithEvents cbEPS As System.Windows.Forms.ComboBox
  Friend WithEvents cbProcedimiento As System.Windows.Forms.ComboBox
  Friend WithEvents cbTipo As System.Windows.Forms.ComboBox
  Friend WithEvents txtValor As System.Windows.Forms.TextBox
  Friend WithEvents txtCodigoContabilidad As System.Windows.Forms.TextBox
  Friend WithEvents cbTIpoTarifa As System.Windows.Forms.ComboBox
  Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
  Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
  Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents TblTarifaBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents TblTarifaBindingNavigator As System.Windows.Forms.BindingNavigator
  Friend WithEvents cbTarifaBase As System.Windows.Forms.ComboBox
End Class
