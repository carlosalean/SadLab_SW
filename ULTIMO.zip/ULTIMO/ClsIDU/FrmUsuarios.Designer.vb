﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmUsuarios
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim BitValidaHuellaLabel As System.Windows.Forms.Label
        Dim IntIdGrupoLabel As System.Windows.Forms.Label
        Dim IntIdUsuarioLabel As System.Windows.Forms.Label
        Dim StrClaveLabel As System.Windows.Forms.Label
        Dim StrNombreUsuarioLabel As System.Windows.Forms.Label
        Dim IntIdEmpleadoLabel As System.Windows.Forms.Label
        Dim BitEsSuperUsuarioLabel As System.Windows.Forms.Label
        Dim StrClaveSuperUsuarioLabel As System.Windows.Forms.Label
        Dim BitActivoLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmUsuarios))
        Me.TblUsuarioBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.TblUsuarioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblUsuarioBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TblUsuarioDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.TblGrupoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.bitActivo = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.BitActivoCheckBox = New System.Windows.Forms.CheckBox()
        Me.StrClaveSuperUsuarioClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.BitEsSuperUsuarioClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.IntIdEmpleadoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblEmpeadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ButtonHuella = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BitValidaHuellaCheckBox = New System.Windows.Forms.CheckBox()
        Me.IntIdGrupoComboBox = New System.Windows.Forms.ComboBox()
        Me.IntIdUsuarioTextBox = New System.Windows.Forms.TextBox()
        Me.StrClaveTextBox = New System.Windows.Forms.TextBox()
        Me.StrNombreUsuarioTextBox = New System.Windows.Forms.TextBox()
        BitValidaHuellaLabel = New System.Windows.Forms.Label()
        IntIdGrupoLabel = New System.Windows.Forms.Label()
        IntIdUsuarioLabel = New System.Windows.Forms.Label()
        StrClaveLabel = New System.Windows.Forms.Label()
        StrNombreUsuarioLabel = New System.Windows.Forms.Label()
        IntIdEmpleadoLabel = New System.Windows.Forms.Label()
        BitEsSuperUsuarioLabel = New System.Windows.Forms.Label()
        StrClaveSuperUsuarioLabel = New System.Windows.Forms.Label()
        BitActivoLabel = New System.Windows.Forms.Label()
        CType(Me.TblUsuarioBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblUsuarioBindingNavigator.SuspendLayout()
        CType(Me.TblUsuarioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblUsuarioDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblGrupoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BitValidaHuellaLabel
        '
        BitValidaHuellaLabel.AutoSize = True
        BitValidaHuellaLabel.Location = New System.Drawing.Point(26, 170)
        BitValidaHuellaLabel.Name = "BitValidaHuellaLabel"
        BitValidaHuellaLabel.Size = New System.Drawing.Size(72, 13)
        BitValidaHuellaLabel.TabIndex = 0
        BitValidaHuellaLabel.Text = "Valida Huella:"
        '
        'IntIdGrupoLabel
        '
        IntIdGrupoLabel.AutoSize = True
        IntIdGrupoLabel.Location = New System.Drawing.Point(26, 85)
        IntIdGrupoLabel.Name = "IntIdGrupoLabel"
        IntIdGrupoLabel.Size = New System.Drawing.Size(39, 13)
        IntIdGrupoLabel.TabIndex = 4
        IntIdGrupoLabel.Text = "Grupo:"
        '
        'IntIdUsuarioLabel
        '
        IntIdUsuarioLabel.AutoSize = True
        IntIdUsuarioLabel.Location = New System.Drawing.Point(26, 33)
        IntIdUsuarioLabel.Name = "IntIdUsuarioLabel"
        IntIdUsuarioLabel.Size = New System.Drawing.Size(46, 13)
        IntIdUsuarioLabel.TabIndex = 6
        IntIdUsuarioLabel.Text = "Usuario:"
        '
        'StrClaveLabel
        '
        StrClaveLabel.AutoSize = True
        StrClaveLabel.Location = New System.Drawing.Point(26, 142)
        StrClaveLabel.Name = "StrClaveLabel"
        StrClaveLabel.Size = New System.Drawing.Size(37, 13)
        StrClaveLabel.TabIndex = 8
        StrClaveLabel.Text = "Clave:"
        '
        'StrNombreUsuarioLabel
        '
        StrNombreUsuarioLabel.AutoSize = True
        StrNombreUsuarioLabel.Location = New System.Drawing.Point(26, 59)
        StrNombreUsuarioLabel.Name = "StrNombreUsuarioLabel"
        StrNombreUsuarioLabel.Size = New System.Drawing.Size(86, 13)
        StrNombreUsuarioLabel.TabIndex = 10
        StrNombreUsuarioLabel.Text = "Nombre Usuario:"
        '
        'IntIdEmpleadoLabel
        '
        IntIdEmpleadoLabel.AutoSize = True
        IntIdEmpleadoLabel.Location = New System.Drawing.Point(26, 115)
        IntIdEmpleadoLabel.Name = "IntIdEmpleadoLabel"
        IntIdEmpleadoLabel.Size = New System.Drawing.Size(62, 13)
        IntIdEmpleadoLabel.TabIndex = 12
        IntIdEmpleadoLabel.Text = "Profesional:"
        '
        'BitEsSuperUsuarioLabel
        '
        BitEsSuperUsuarioLabel.AutoSize = True
        BitEsSuperUsuarioLabel.Location = New System.Drawing.Point(26, 197)
        BitEsSuperUsuarioLabel.Name = "BitEsSuperUsuarioLabel"
        BitEsSuperUsuarioLabel.Size = New System.Drawing.Size(92, 13)
        BitEsSuperUsuarioLabel.TabIndex = 14
        BitEsSuperUsuarioLabel.Text = "Es Super Usuario:"
        '
        'StrClaveSuperUsuarioLabel
        '
        StrClaveSuperUsuarioLabel.AutoSize = True
        StrClaveSuperUsuarioLabel.Location = New System.Drawing.Point(180, 197)
        StrClaveSuperUsuarioLabel.Name = "StrClaveSuperUsuarioLabel"
        StrClaveSuperUsuarioLabel.Size = New System.Drawing.Size(107, 13)
        StrClaveSuperUsuarioLabel.TabIndex = 16
        StrClaveSuperUsuarioLabel.Text = "Clave Super Usuario:"
        '
        'BitActivoLabel
        '
        BitActivoLabel.AutoSize = True
        BitActivoLabel.Location = New System.Drawing.Point(247, 170)
        BitActivoLabel.Name = "BitActivoLabel"
        BitActivoLabel.Size = New System.Drawing.Size(40, 13)
        BitActivoLabel.TabIndex = 18
        BitActivoLabel.Text = "Activo:"
        '
        'TblUsuarioBindingNavigator
        '
        Me.TblUsuarioBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblUsuarioBindingNavigator.BindingSource = Me.TblUsuarioBindingSource
        Me.TblUsuarioBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblUsuarioBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblUsuarioBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblUsuarioBindingNavigatorSaveItem})
        Me.TblUsuarioBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblUsuarioBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblUsuarioBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblUsuarioBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblUsuarioBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblUsuarioBindingNavigator.Name = "TblUsuarioBindingNavigator"
        Me.TblUsuarioBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblUsuarioBindingNavigator.Size = New System.Drawing.Size(761, 25)
        Me.TblUsuarioBindingNavigator.TabIndex = 0
        Me.TblUsuarioBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'TblUsuarioBindingSource
        '
        Me.TblUsuarioBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblUsuario)
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblUsuarioBindingNavigatorSaveItem
        '
        Me.TblUsuarioBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblUsuarioBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblUsuarioBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblUsuarioBindingNavigatorSaveItem.Name = "TblUsuarioBindingNavigatorSaveItem"
        Me.TblUsuarioBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblUsuarioBindingNavigatorSaveItem.Text = "Save Data"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(761, 269)
        Me.TabControl1.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TblUsuarioDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(753, 243)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblUsuarioDataGridView
        '
        Me.TblUsuarioDataGridView.AllowUserToAddRows = False
        Me.TblUsuarioDataGridView.AllowUserToDeleteRows = False
        Me.TblUsuarioDataGridView.AllowUserToOrderColumns = True
        Me.TblUsuarioDataGridView.AutoGenerateColumns = False
        Me.TblUsuarioDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblUsuarioDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewCheckBoxColumn1, Me.bitActivo})
        Me.TblUsuarioDataGridView.DataSource = Me.TblUsuarioBindingSource
        Me.TblUsuarioDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblUsuarioDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblUsuarioDataGridView.Name = "TblUsuarioDataGridView"
        Me.TblUsuarioDataGridView.ReadOnly = True
        Me.TblUsuarioDataGridView.Size = New System.Drawing.Size(747, 237)
        Me.TblUsuarioDataGridView.TabIndex = 2
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdUsuario"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strNombreUsuario"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 250
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "intIdGrupo"
        Me.DataGridViewTextBoxColumn3.DataSource = Me.TblGrupoBindingSource
        Me.DataGridViewTextBoxColumn3.DisplayMember = "strNombreGrupo"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Grupo"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn3.ValueMember = "intIdGrupo"
        Me.DataGridViewTextBoxColumn3.Width = 150
        '
        'TblGrupoBindingSource
        '
        Me.TblGrupoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblGrupo)
        Me.TblGrupoBindingSource.Sort = "strNombreGrupo"
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.DataPropertyName = "bitValidaHuella"
        Me.DataGridViewCheckBoxColumn1.HeaderText = "Valida Huella"
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        Me.DataGridViewCheckBoxColumn1.ReadOnly = True
        '
        'bitActivo
        '
        Me.bitActivo.DataPropertyName = "bitActivo"
        Me.bitActivo.HeaderText = "Activo"
        Me.bitActivo.Name = "bitActivo"
        Me.bitActivo.ReadOnly = True
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.Controls.Add(BitActivoLabel)
        Me.TabPage2.Controls.Add(Me.BitActivoCheckBox)
        Me.TabPage2.Controls.Add(StrClaveSuperUsuarioLabel)
        Me.TabPage2.Controls.Add(Me.StrClaveSuperUsuarioClsTextBox)
        Me.TabPage2.Controls.Add(BitEsSuperUsuarioLabel)
        Me.TabPage2.Controls.Add(Me.BitEsSuperUsuarioClsCheckBox)
        Me.TabPage2.Controls.Add(IntIdEmpleadoLabel)
        Me.TabPage2.Controls.Add(Me.IntIdEmpleadoClsComboBox)
        Me.TabPage2.Controls.Add(Me.ButtonHuella)
        Me.TabPage2.Controls.Add(Me.PictureBox1)
        Me.TabPage2.Controls.Add(BitValidaHuellaLabel)
        Me.TabPage2.Controls.Add(Me.BitValidaHuellaCheckBox)
        Me.TabPage2.Controls.Add(IntIdGrupoLabel)
        Me.TabPage2.Controls.Add(Me.IntIdGrupoComboBox)
        Me.TabPage2.Controls.Add(IntIdUsuarioLabel)
        Me.TabPage2.Controls.Add(Me.IntIdUsuarioTextBox)
        Me.TabPage2.Controls.Add(StrClaveLabel)
        Me.TabPage2.Controls.Add(Me.StrClaveTextBox)
        Me.TabPage2.Controls.Add(StrNombreUsuarioLabel)
        Me.TabPage2.Controls.Add(Me.StrNombreUsuarioTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(753, 243)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'BitActivoCheckBox
        '
        Me.BitActivoCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblUsuarioBindingSource, "bitActivo", True))
        Me.BitActivoCheckBox.Location = New System.Drawing.Point(293, 165)
        Me.BitActivoCheckBox.Name = "BitActivoCheckBox"
        Me.BitActivoCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.BitActivoCheckBox.TabIndex = 6
        Me.BitActivoCheckBox.UseVisualStyleBackColor = True
        '
        'StrClaveSuperUsuarioClsTextBox
        '
        Me.StrClaveSuperUsuarioClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblUsuarioBindingSource, "strClaveSuperUsuario", True))
        Me.StrClaveSuperUsuarioClsTextBox.DataSource = Nothing
        Me.StrClaveSuperUsuarioClsTextBox.EnterEntreCampos = True
        Me.StrClaveSuperUsuarioClsTextBox.Location = New System.Drawing.Point(293, 194)
        Me.StrClaveSuperUsuarioClsTextBox.Name = "StrClaveSuperUsuarioClsTextBox"
        Me.StrClaveSuperUsuarioClsTextBox.NombreCodigoF2 = Nothing
        Me.StrClaveSuperUsuarioClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrClaveSuperUsuarioClsTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.StrClaveSuperUsuarioClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrClaveSuperUsuarioClsTextBox.TabIndex = 8
        Me.StrClaveSuperUsuarioClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'BitEsSuperUsuarioClsCheckBox
        '
        Me.BitEsSuperUsuarioClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblUsuarioBindingSource, "bitEsSuperUsuario", True))
        Me.BitEsSuperUsuarioClsCheckBox.Location = New System.Drawing.Point(136, 192)
        Me.BitEsSuperUsuarioClsCheckBox.Name = "BitEsSuperUsuarioClsCheckBox"
        Me.BitEsSuperUsuarioClsCheckBox.Size = New System.Drawing.Size(14, 24)
        Me.BitEsSuperUsuarioClsCheckBox.TabIndex = 7
        Me.BitEsSuperUsuarioClsCheckBox.UseVisualStyleBackColor = True
        '
        'IntIdEmpleadoClsComboBox
        '
        Me.IntIdEmpleadoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblUsuarioBindingSource, "intIdEmpleado", True))
        Me.IntIdEmpleadoClsComboBox.DataSource = Me.TblEmpeadoBindingSource
        Me.IntIdEmpleadoClsComboBox.DisplayMember = "strNombreEmpleado"
        Me.IntIdEmpleadoClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntIdEmpleadoClsComboBox.FormattingEnabled = True
        Me.IntIdEmpleadoClsComboBox.Location = New System.Drawing.Point(136, 112)
        Me.IntIdEmpleadoClsComboBox.Name = "IntIdEmpleadoClsComboBox"
        Me.IntIdEmpleadoClsComboBox.Size = New System.Drawing.Size(317, 21)
        Me.IntIdEmpleadoClsComboBox.TabIndex = 3
        Me.IntIdEmpleadoClsComboBox.ValueMember = "intIdCodigoEmpleado"
        '
        'TblEmpeadoBindingSource
        '
        Me.TblEmpeadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEmpeados)
        Me.TblEmpeadoBindingSource.Sort = "strNombreEmpleado"
        '
        'ButtonHuella
        '
        Me.ButtonHuella.Location = New System.Drawing.Point(587, 160)
        Me.ButtonHuella.Name = "ButtonHuella"
        Me.ButtonHuella.Size = New System.Drawing.Size(112, 33)
        Me.ButtonHuella.TabIndex = 9
        Me.ButtonHuella.Text = "Detectar Huella"
        Me.ButtonHuella.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(587, 17)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(112, 127)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'BitValidaHuellaCheckBox
        '
        Me.BitValidaHuellaCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblUsuarioBindingSource, "bitValidaHuella", True))
        Me.BitValidaHuellaCheckBox.Location = New System.Drawing.Point(136, 165)
        Me.BitValidaHuellaCheckBox.Name = "BitValidaHuellaCheckBox"
        Me.BitValidaHuellaCheckBox.Size = New System.Drawing.Size(121, 24)
        Me.BitValidaHuellaCheckBox.TabIndex = 5
        Me.BitValidaHuellaCheckBox.UseVisualStyleBackColor = True
        '
        'IntIdGrupoComboBox
        '
        Me.IntIdGrupoComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblUsuarioBindingSource, "intIdGrupo", True))
        Me.IntIdGrupoComboBox.DataSource = Me.TblGrupoBindingSource
        Me.IntIdGrupoComboBox.DisplayMember = "strNombreGrupo"
        Me.IntIdGrupoComboBox.FormattingEnabled = True
        Me.IntIdGrupoComboBox.Location = New System.Drawing.Point(136, 82)
        Me.IntIdGrupoComboBox.Name = "IntIdGrupoComboBox"
        Me.IntIdGrupoComboBox.Size = New System.Drawing.Size(317, 21)
        Me.IntIdGrupoComboBox.TabIndex = 2
        Me.IntIdGrupoComboBox.ValueMember = "intIdGrupo"
        '
        'IntIdUsuarioTextBox
        '
        Me.IntIdUsuarioTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblUsuarioBindingSource, "intIdUsuario", True))
        Me.IntIdUsuarioTextBox.Enabled = False
        Me.IntIdUsuarioTextBox.Location = New System.Drawing.Point(136, 30)
        Me.IntIdUsuarioTextBox.Name = "IntIdUsuarioTextBox"
        Me.IntIdUsuarioTextBox.Size = New System.Drawing.Size(38, 20)
        Me.IntIdUsuarioTextBox.TabIndex = 0
        '
        'StrClaveTextBox
        '
        Me.StrClaveTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblUsuarioBindingSource, "strClave", True))
        Me.StrClaveTextBox.Location = New System.Drawing.Point(136, 139)
        Me.StrClaveTextBox.Name = "StrClaveTextBox"
        Me.StrClaveTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.StrClaveTextBox.Size = New System.Drawing.Size(121, 20)
        Me.StrClaveTextBox.TabIndex = 4
        '
        'StrNombreUsuarioTextBox
        '
        Me.StrNombreUsuarioTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblUsuarioBindingSource, "strNombreUsuario", True))
        Me.StrNombreUsuarioTextBox.Location = New System.Drawing.Point(136, 56)
        Me.StrNombreUsuarioTextBox.Name = "StrNombreUsuarioTextBox"
        Me.StrNombreUsuarioTextBox.Size = New System.Drawing.Size(435, 20)
        Me.StrNombreUsuarioTextBox.TabIndex = 1
        '
        'FrmUsuarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(761, 294)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblUsuarioBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmUsuarios"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Usuarios"
        CType(Me.TblUsuarioBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblUsuarioBindingNavigator.ResumeLayout(False)
        Me.TblUsuarioBindingNavigator.PerformLayout()
        CType(Me.TblUsuarioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblUsuarioDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblGrupoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblUsuarioBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblUsuarioBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblUsuarioBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblGrupoBindingSource As System.Windows.Forms.BindingSource
    Public WithEvents TabControl1 As System.Windows.Forms.TabControl
    Public WithEvents TabPage2 As System.Windows.Forms.TabPage
    Public WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TblUsuarioDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents BitValidaHuellaCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents IntIdGrupoComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents IntIdUsuarioTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrClaveTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrNombreUsuarioTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonHuella As System.Windows.Forms.Button
    Friend WithEvents IntIdEmpleadoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents TblEmpeadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StrClaveSuperUsuarioClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents BitEsSuperUsuarioClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents bitActivo As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents BitActivoCheckBox As System.Windows.Forms.CheckBox
End Class
