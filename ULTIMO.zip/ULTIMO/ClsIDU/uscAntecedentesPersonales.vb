﻿Imports System.Windows.Forms

Public Class uscAntecedentesPersonales
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mIdentificacion As String
    Private _btn As Windows.Forms.Button
    Private mclsUtilidadesHC As clsUtilidadesHC
    Private _IdUsuario As String
    Private mguardar As Boolean

    Public Sub New()
        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mIdentificacion() As String
        Get
            Return _mIdentificacion
        End Get
        Set(ByVal value As String)
            _mIdentificacion = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub cargarDatosTabAP()
        Try
            Dim mconsulta = (From p In dc.tblAntecedentesPersonalesHC Where p.strNroIdentificacion = mIdentificacion Select p.bitModoTexto, p.strHCtexto)
            If mconsulta.Count > 0 Then
                For Each c In mconsulta
                    If c.bitModoTexto = True Then
                        StrHCtextoTextBox.Dock = DockStyle.Fill
                        StrHCtextoTextBox.BringToFront()
                        StrHCtextoTextBox.ReadOnly = False
                        StrHCtextoTextBox.Visible = True
                        prCargarDatosAntecedentesPersonales()
                    Else
                        prCargarDatosAntecedentesPersonales()
                        Exit For
                    End If
                Next
            Else
                mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
                If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
                    StrHCtextoTextBox.Dock = DockStyle.Fill
                    StrHCtextoTextBox.BringToFront()
                    StrHCtextoTextBox.ReadOnly = False
                    StrHCtextoTextBox.Visible = True
                    prCargarDatosAntecedentesPersonales()
                Else
                    prCargarDatosAntecedentesPersonales()
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub prCargarDatosAntecedentesPersonales()
        Try
            TblDisgnosticoBindingSource.DataSource = dc.tblDisgnostico
            TblProcedimientoBindingSource.DataSource = dc.tblProcedimiento
            Dim mconsulta = (From p In dc.tblAntecedentesPersonalesHC Where p.strNroIdentificacion = mIdentificacion Select p)
            TblAntecedentesPersonalesHCBindingSource.DataSource = mconsulta
            If mconsulta.Count = 0 Then
                Panel1.Enabled = False
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    'Private Sub ToolStripButtonSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    prGuardar()
    'End Sub

    'Private Sub uscAntecedentesPersonales_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
    '    prGuardar()
    'End Sub

    Private Sub TblAntecedentesPersonalesHCDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs)
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub tblAntecedentesPersonalesHCBindingSource_AddingNew(ByVal sender As System.Object, ByVal e As System.ComponentModel.AddingNewEventArgs)
        'Try
        '    If sender.Position.ToString >= 0 Then
        '        sender.Item(sender.Position).dtmFecha = FormatDateTime(Now, DateFormat.ShortDate)
        '        posicion = sender.position
        '    End If
        'Catch ex As Exception
        '    ClsError.ClsError.PrMostrarError(ex)
        'End Try
    End Sub

    Public Sub prGuardar() Implements IAbandonarUC.prGuardar

        Try
            If mguardar = True Then
                'TblAntecedentesPersonalesHCBindingSource.Item(TblAntecedentesPersonalesHCBindingSource.Position).strHCtexto = StrHCtextoTextBox.Text
                TblAntecedentesPersonalesHCBindingSource.Item(TblAntecedentesPersonalesHCBindingSource.Position).strNroIdentificacion = mIdentificacion
                TblAntecedentesPersonalesHCBindingSource.Item(TblAntecedentesPersonalesHCBindingSource.Position).dtmFecha = FormatDateTime(Now, DateFormat.ShortDate)
                If StrHCtextoTextBox.Dock = DockStyle.Fill Then
                    TblAntecedentesPersonalesHCBindingSource.Item(TblAntecedentesPersonalesHCBindingSource.Position).bitModoTexto = True
                Else
                    TblAntecedentesPersonalesHCBindingSource.Item(TblAntecedentesPersonalesHCBindingSource.Position).bitModoTexto = False
                End If
                mguardar = False
            End If
            tblAntecedentesPersonalesHCBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblAntecedentesPersonalesHCBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblAntecedentesPersonalesHCBindingNavigatorSaveItem.Click
        prGuardar()
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        mguardar = True
        Panel1.Enabled = True
    End Sub
End Class
