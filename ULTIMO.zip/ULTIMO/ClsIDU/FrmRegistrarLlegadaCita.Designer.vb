﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmRegistrarLlegadaCita
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IntIdCitaLabel As System.Windows.Forms.Label
        Dim IntIdPacienteLabel As System.Windows.Forms.Label
        Dim DtmHoraFinLabel As System.Windows.Forms.Label
        Dim DtmFechaLabel As System.Windows.Forms.Label
        Dim IntIdProcedimientoLabel As System.Windows.Forms.Label
        Dim IntIdProfesionalLabel As System.Windows.Forms.Label
        Dim TmHoraLabel As System.Windows.Forms.Label
        Dim StrNroOrdenLabel As System.Windows.Forms.Label
        Dim NumValorCoopagoLabel As System.Windows.Forms.Label
        Dim StrObservacionLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmRegistrarLlegadaCita))
        Me.StrNroIdPacienteTextBox = New ClsUtilidades.ClsTextBox()
        Me.TblCitaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TextBoxNombre = New ClsUtilidades.ClsTextBox()
        Me.IntIdCitaTextBox = New ClsUtilidades.ClsTextBox()
        Me.TblCitaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblCitaBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnPago = New System.Windows.Forms.ToolStripButton()
        Me.IntIdEstadoCitaComboBox = New System.Windows.Forms.ComboBox()
        Me.DtmHoraFinMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.DtmHoraMaskedTextBox = New System.Windows.Forms.MaskedTextBox()
        Me.DtmFechaDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.IntIdProcedimientoComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblProcedimientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdProfesionalComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblEmpeadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StrNroOrdenTextBox = New System.Windows.Forms.TextBox()
        Me.NumValorCoopagoTextBox = New System.Windows.Forms.TextBox()
        Me.StrObservacionTextBox = New ClsUtilidades.ClsTextBox()
        Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DisponibilidadBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VerificationControl = New DPFP.Gui.Verification.VerificationControl()
        Me.NoRegistraHuellaCheckBox = New System.Windows.Forms.CheckBox()
        Me.btnHabilitarCoopago = New System.Windows.Forms.Button()
        IntIdCitaLabel = New System.Windows.Forms.Label()
        IntIdPacienteLabel = New System.Windows.Forms.Label()
        DtmHoraFinLabel = New System.Windows.Forms.Label()
        DtmFechaLabel = New System.Windows.Forms.Label()
        IntIdProcedimientoLabel = New System.Windows.Forms.Label()
        IntIdProfesionalLabel = New System.Windows.Forms.Label()
        TmHoraLabel = New System.Windows.Forms.Label()
        StrNroOrdenLabel = New System.Windows.Forms.Label()
        NumValorCoopagoLabel = New System.Windows.Forms.Label()
        StrObservacionLabel = New System.Windows.Forms.Label()
        CType(Me.TblCitaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCitaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCitaBindingNavigator.SuspendLayout()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DisponibilidadBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IntIdCitaLabel
        '
        IntIdCitaLabel.AutoSize = True
        IntIdCitaLabel.Location = New System.Drawing.Point(9, 40)
        IntIdCitaLabel.Name = "IntIdCitaLabel"
        IntIdCitaLabel.Size = New System.Drawing.Size(19, 13)
        IntIdCitaLabel.TabIndex = 22
        IntIdCitaLabel.Text = "Id:"
        '
        'IntIdPacienteLabel
        '
        IntIdPacienteLabel.AutoSize = True
        IntIdPacienteLabel.Location = New System.Drawing.Point(9, 66)
        IntIdPacienteLabel.Name = "IntIdPacienteLabel"
        IntIdPacienteLabel.Size = New System.Drawing.Size(52, 13)
        IntIdPacienteLabel.TabIndex = 23
        IntIdPacienteLabel.Text = "Paciente:"
        '
        'DtmHoraFinLabel
        '
        DtmHoraFinLabel.AutoSize = True
        DtmHoraFinLabel.Location = New System.Drawing.Point(345, 147)
        DtmHoraFinLabel.Name = "DtmHoraFinLabel"
        DtmHoraFinLabel.Size = New System.Drawing.Size(50, 13)
        DtmHoraFinLabel.TabIndex = 33
        DtmHoraFinLabel.Text = "Hora Fin:"
        '
        'DtmFechaLabel
        '
        DtmFechaLabel.AutoSize = True
        DtmFechaLabel.Location = New System.Drawing.Point(9, 147)
        DtmFechaLabel.Name = "DtmFechaLabel"
        DtmFechaLabel.Size = New System.Drawing.Size(40, 13)
        DtmFechaLabel.TabIndex = 25
        DtmFechaLabel.Text = "Fecha:"
        '
        'IntIdProcedimientoLabel
        '
        IntIdProcedimientoLabel.AutoSize = True
        IntIdProcedimientoLabel.Location = New System.Drawing.Point(9, 92)
        IntIdProcedimientoLabel.Name = "IntIdProcedimientoLabel"
        IntIdProcedimientoLabel.Size = New System.Drawing.Size(77, 13)
        IntIdProcedimientoLabel.TabIndex = 30
        IntIdProcedimientoLabel.Text = "Procedimiento:"
        '
        'IntIdProfesionalLabel
        '
        IntIdProfesionalLabel.AutoSize = True
        IntIdProfesionalLabel.Location = New System.Drawing.Point(9, 119)
        IntIdProfesionalLabel.Name = "IntIdProfesionalLabel"
        IntIdProfesionalLabel.Size = New System.Drawing.Size(62, 13)
        IntIdProfesionalLabel.TabIndex = 31
        IntIdProfesionalLabel.Text = "Profesional:"
        '
        'TmHoraLabel
        '
        TmHoraLabel.AutoSize = True
        TmHoraLabel.Location = New System.Drawing.Point(238, 147)
        TmHoraLabel.Name = "TmHoraLabel"
        TmHoraLabel.Size = New System.Drawing.Size(33, 13)
        TmHoraLabel.TabIndex = 32
        TmHoraLabel.Text = "Hora:"
        '
        'StrNroOrdenLabel
        '
        StrNroOrdenLabel.AutoSize = True
        StrNroOrdenLabel.Location = New System.Drawing.Point(9, 172)
        StrNroOrdenLabel.Name = "StrNroOrdenLabel"
        StrNroOrdenLabel.Size = New System.Drawing.Size(59, 13)
        StrNroOrdenLabel.TabIndex = 35
        StrNroOrdenLabel.Text = "Nro Orden:"
        '
        'NumValorCoopagoLabel
        '
        NumValorCoopagoLabel.AutoSize = True
        NumValorCoopagoLabel.Location = New System.Drawing.Point(239, 173)
        NumValorCoopagoLabel.Name = "NumValorCoopagoLabel"
        NumValorCoopagoLabel.Size = New System.Drawing.Size(80, 13)
        NumValorCoopagoLabel.TabIndex = 36
        NumValorCoopagoLabel.Text = "Valor Coopago:"
        '
        'StrObservacionLabel
        '
        StrObservacionLabel.AutoSize = True
        StrObservacionLabel.Location = New System.Drawing.Point(9, 199)
        StrObservacionLabel.Name = "StrObservacionLabel"
        StrObservacionLabel.Size = New System.Drawing.Size(70, 13)
        StrObservacionLabel.TabIndex = 39
        StrObservacionLabel.Text = "Observacion:"
        '
        'StrNroIdPacienteTextBox
        '
        Me.StrNroIdPacienteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strNroIdPaciente", True))
        Me.StrNroIdPacienteTextBox.DataSource = Nothing
        Me.StrNroIdPacienteTextBox.EnterEntreCampos = True
        Me.StrNroIdPacienteTextBox.Location = New System.Drawing.Point(118, 63)
        Me.StrNroIdPacienteTextBox.Name = "StrNroIdPacienteTextBox"
        Me.StrNroIdPacienteTextBox.NombreCodigoF2 = Nothing
        Me.StrNroIdPacienteTextBox.NombreDescripcionF2 = Nothing
        Me.StrNroIdPacienteTextBox.Size = New System.Drawing.Size(135, 20)
        Me.StrNroIdPacienteTextBox.TabIndex = 1
        Me.StrNroIdPacienteTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblCitaBindingSource
        '
        Me.TblCitaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCita)
        '
        'TextBoxNombre
        '
        Me.TextBoxNombre.DataSource = Nothing
        Me.TextBoxNombre.Enabled = False
        Me.TextBoxNombre.EnterEntreCampos = True
        Me.TextBoxNombre.Location = New System.Drawing.Point(259, 63)
        Me.TextBoxNombre.Name = "TextBoxNombre"
        Me.TextBoxNombre.NombreCodigoF2 = Nothing
        Me.TextBoxNombre.NombreDescripcionF2 = Nothing
        Me.TextBoxNombre.Size = New System.Drawing.Size(346, 20)
        Me.TextBoxNombre.TabIndex = 24
        Me.TextBoxNombre.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdCitaTextBox
        '
        Me.IntIdCitaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "intIdCita", True))
        Me.IntIdCitaTextBox.DataSource = Nothing
        Me.IntIdCitaTextBox.Enabled = False
        Me.IntIdCitaTextBox.EnterEntreCampos = True
        Me.IntIdCitaTextBox.Location = New System.Drawing.Point(118, 37)
        Me.IntIdCitaTextBox.Name = "IntIdCitaTextBox"
        Me.IntIdCitaTextBox.NombreCodigoF2 = Nothing
        Me.IntIdCitaTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdCitaTextBox.Size = New System.Drawing.Size(47, 20)
        Me.IntIdCitaTextBox.TabIndex = 0
        Me.IntIdCitaTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblCitaBindingNavigator
        '
        Me.TblCitaBindingNavigator.AddNewItem = Nothing
        Me.TblCitaBindingNavigator.BindingSource = Me.TblCitaBindingSource
        Me.TblCitaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblCitaBindingNavigator.DeleteItem = Nothing
        Me.TblCitaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.TblCitaBindingNavigatorSaveItem, Me.ToolStripSeparator1, Me.btnPago})
        Me.TblCitaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCitaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblCitaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblCitaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblCitaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblCitaBindingNavigator.Name = "TblCitaBindingNavigator"
        Me.TblCitaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblCitaBindingNavigator.Size = New System.Drawing.Size(625, 25)
        Me.TblCitaBindingNavigator.TabIndex = 19
        Me.TblCitaBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblCitaBindingNavigatorSaveItem
        '
        Me.TblCitaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblCitaBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblCitaBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblCitaBindingNavigatorSaveItem.Name = "TblCitaBindingNavigatorSaveItem"
        Me.TblCitaBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblCitaBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'btnPago
        '
        Me.btnPago.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnPago.Image = Global.ClsIDU.My.Resources.Resources.money
        Me.btnPago.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnPago.Name = "btnPago"
        Me.btnPago.Size = New System.Drawing.Size(23, 22)
        Me.btnPago.Text = "ToolStripButton1"
        Me.btnPago.ToolTipText = "Pagos"
        '
        'IntIdEstadoCitaComboBox
        '
        Me.IntIdEstadoCitaComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdEstadoCita", True))
        Me.IntIdEstadoCitaComboBox.DisplayMember = "strValor"
        Me.IntIdEstadoCitaComboBox.Enabled = False
        Me.IntIdEstadoCitaComboBox.FormattingEnabled = True
        Me.IntIdEstadoCitaComboBox.Location = New System.Drawing.Point(484, 143)
        Me.IntIdEstadoCitaComboBox.Name = "IntIdEstadoCitaComboBox"
        Me.IntIdEstadoCitaComboBox.Size = New System.Drawing.Size(121, 21)
        Me.IntIdEstadoCitaComboBox.TabIndex = 7
        Me.IntIdEstadoCitaComboBox.ValueMember = "intIdTipo"
        '
        'DtmHoraFinMaskedTextBox
        '
        Me.DtmHoraFinMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "dtmHoraFin", True))
        Me.DtmHoraFinMaskedTextBox.Enabled = False
        Me.DtmHoraFinMaskedTextBox.Location = New System.Drawing.Point(401, 144)
        Me.DtmHoraFinMaskedTextBox.Mask = "00:00"
        Me.DtmHoraFinMaskedTextBox.Name = "DtmHoraFinMaskedTextBox"
        Me.DtmHoraFinMaskedTextBox.Size = New System.Drawing.Size(64, 20)
        Me.DtmHoraFinMaskedTextBox.TabIndex = 6
        Me.DtmHoraFinMaskedTextBox.ValidatingType = GetType(Date)
        '
        'DtmHoraMaskedTextBox
        '
        Me.DtmHoraMaskedTextBox.BeepOnError = True
        Me.DtmHoraMaskedTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "dtmHora", True))
        Me.DtmHoraMaskedTextBox.Location = New System.Drawing.Point(277, 144)
        Me.DtmHoraMaskedTextBox.Mask = "00:00"
        Me.DtmHoraMaskedTextBox.Name = "DtmHoraMaskedTextBox"
        Me.DtmHoraMaskedTextBox.Size = New System.Drawing.Size(58, 20)
        Me.DtmHoraMaskedTextBox.TabIndex = 5
        Me.DtmHoraMaskedTextBox.TabStop = False
        Me.DtmHoraMaskedTextBox.ValidatingType = GetType(Date)
        '
        'DtmFechaDateTimePicker
        '
        Me.DtmFechaDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblCitaBindingSource, "dtmFecha", True))
        Me.DtmFechaDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaDateTimePicker.Location = New System.Drawing.Point(118, 143)
        Me.DtmFechaDateTimePicker.Name = "DtmFechaDateTimePicker"
        Me.DtmFechaDateTimePicker.Size = New System.Drawing.Size(101, 20)
        Me.DtmFechaDateTimePicker.TabIndex = 4
        '
        'IntIdProcedimientoComboBox
        '
        Me.IntIdProcedimientoComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdProcedimientoComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdProcedimientoComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdProcedimiento", True))
        Me.IntIdProcedimientoComboBox.DataSource = Me.TblProcedimientoBindingSource
        Me.IntIdProcedimientoComboBox.DisplayMember = "strDescripcion"
        Me.IntIdProcedimientoComboBox.FormattingEnabled = True
        Me.IntIdProcedimientoComboBox.Location = New System.Drawing.Point(118, 89)
        Me.IntIdProcedimientoComboBox.Name = "IntIdProcedimientoComboBox"
        Me.IntIdProcedimientoComboBox.Size = New System.Drawing.Size(383, 21)
        Me.IntIdProcedimientoComboBox.TabIndex = 2
        Me.IntIdProcedimientoComboBox.ValueMember = "intIdProcedimientos"
        '
        'TblProcedimientoBindingSource
        '
        Me.TblProcedimientoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        Me.TblProcedimientoBindingSource.Sort = "strDescripcion"
        '
        'IntIdProfesionalComboBox
        '
        Me.IntIdProfesionalComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdProfesionalComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdProfesionalComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdProfesional", True))
        Me.IntIdProfesionalComboBox.DataSource = Me.TblEmpeadoBindingSource
        Me.IntIdProfesionalComboBox.DisplayMember = "strNombreEmpleado"
        Me.IntIdProfesionalComboBox.FormattingEnabled = True
        Me.IntIdProfesionalComboBox.Location = New System.Drawing.Point(118, 116)
        Me.IntIdProfesionalComboBox.Name = "IntIdProfesionalComboBox"
        Me.IntIdProfesionalComboBox.Size = New System.Drawing.Size(383, 21)
        Me.IntIdProfesionalComboBox.TabIndex = 3
        Me.IntIdProfesionalComboBox.ValueMember = "intIdCodigoEmpleado"
        '
        'TblEmpeadoBindingSource
        '
        Me.TblEmpeadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEmpeados)
        Me.TblEmpeadoBindingSource.Sort = "strNombreEmpleado"
        '
        'StrNroOrdenTextBox
        '
        Me.StrNroOrdenTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strNroOrden", True))
        Me.StrNroOrdenTextBox.Location = New System.Drawing.Point(118, 169)
        Me.StrNroOrdenTextBox.Name = "StrNroOrdenTextBox"
        Me.StrNroOrdenTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrNroOrdenTextBox.TabIndex = 8
        '
        'NumValorCoopagoTextBox
        '
        Me.NumValorCoopagoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "numValorCoopago", True))
        Me.NumValorCoopagoTextBox.Location = New System.Drawing.Point(348, 170)
        Me.NumValorCoopagoTextBox.Name = "NumValorCoopagoTextBox"
        Me.NumValorCoopagoTextBox.ReadOnly = True
        Me.NumValorCoopagoTextBox.Size = New System.Drawing.Size(100, 20)
        Me.NumValorCoopagoTextBox.TabIndex = 9
        '
        'StrObservacionTextBox
        '
        Me.StrObservacionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strObservacion", True))
        Me.StrObservacionTextBox.DataSource = Nothing
        Me.StrObservacionTextBox.EnterEntreCampos = True
        Me.StrObservacionTextBox.Location = New System.Drawing.Point(118, 196)
        Me.StrObservacionTextBox.Multiline = True
        Me.StrObservacionTextBox.Name = "StrObservacionTextBox"
        Me.StrObservacionTextBox.NombreCodigoF2 = Nothing
        Me.StrObservacionTextBox.NombreDescripcionF2 = Nothing
        Me.StrObservacionTextBox.Size = New System.Drawing.Size(487, 123)
        Me.StrObservacionTextBox.TabIndex = 10
        Me.StrObservacionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblTipoBindingSource
        '
        Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'DisponibilidadBindingSource
        '
        Me.DisponibilidadBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCita)
        '
        'VerificationControl
        '
        Me.VerificationControl.Active = True
        Me.VerificationControl.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.VerificationControl.Location = New System.Drawing.Point(12, 230)
        Me.VerificationControl.Name = "VerificationControl"
        Me.VerificationControl.ReaderSerialNumber = "00000000-0000-0000-0000-000000000000"
        Me.VerificationControl.Size = New System.Drawing.Size(66, 71)
        Me.VerificationControl.TabIndex = 40
        '
        'NoRegistraHuellaCheckBox
        '
        Me.NoRegistraHuellaCheckBox.AutoSize = True
        Me.NoRegistraHuellaCheckBox.Enabled = False
        Me.NoRegistraHuellaCheckBox.Location = New System.Drawing.Point(12, 302)
        Me.NoRegistraHuellaCheckBox.Name = "NoRegistraHuellaCheckBox"
        Me.NoRegistraHuellaCheckBox.Size = New System.Drawing.Size(82, 17)
        Me.NoRegistraHuellaCheckBox.TabIndex = 41
        Me.NoRegistraHuellaCheckBox.Text = "No Registra"
        Me.NoRegistraHuellaCheckBox.UseVisualStyleBackColor = True
        '
        'btnHabilitarCoopago
        '
        Me.btnHabilitarCoopago.Location = New System.Drawing.Point(68, 276)
        Me.btnHabilitarCoopago.Name = "btnHabilitarCoopago"
        Me.btnHabilitarCoopago.Size = New System.Drawing.Size(26, 20)
        Me.btnHabilitarCoopago.TabIndex = 60
        Me.btnHabilitarCoopago.Text = "H"
        Me.btnHabilitarCoopago.UseVisualStyleBackColor = True
        '
        'FrmRegistrarLlegadaCita
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(625, 346)
        Me.Controls.Add(Me.btnHabilitarCoopago)
        Me.Controls.Add(Me.NoRegistraHuellaCheckBox)
        Me.Controls.Add(Me.VerificationControl)
        Me.Controls.Add(StrObservacionLabel)
        Me.Controls.Add(Me.StrObservacionTextBox)
        Me.Controls.Add(NumValorCoopagoLabel)
        Me.Controls.Add(Me.NumValorCoopagoTextBox)
        Me.Controls.Add(StrNroOrdenLabel)
        Me.Controls.Add(Me.StrNroOrdenTextBox)
        Me.Controls.Add(Me.IntIdEstadoCitaComboBox)
        Me.Controls.Add(DtmHoraFinLabel)
        Me.Controls.Add(Me.DtmHoraFinMaskedTextBox)
        Me.Controls.Add(Me.DtmHoraMaskedTextBox)
        Me.Controls.Add(DtmFechaLabel)
        Me.Controls.Add(Me.DtmFechaDateTimePicker)
        Me.Controls.Add(IntIdProcedimientoLabel)
        Me.Controls.Add(Me.IntIdProcedimientoComboBox)
        Me.Controls.Add(IntIdProfesionalLabel)
        Me.Controls.Add(Me.IntIdProfesionalComboBox)
        Me.Controls.Add(TmHoraLabel)
        Me.Controls.Add(Me.StrNroIdPacienteTextBox)
        Me.Controls.Add(Me.TextBoxNombre)
        Me.Controls.Add(IntIdCitaLabel)
        Me.Controls.Add(Me.IntIdCitaTextBox)
        Me.Controls.Add(IntIdPacienteLabel)
        Me.Controls.Add(Me.TblCitaBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmRegistrarLlegadaCita"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Registrar Llegada Cita"
        CType(Me.TblCitaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCitaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCitaBindingNavigator.ResumeLayout(False)
        Me.TblCitaBindingNavigator.PerformLayout()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DisponibilidadBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StrNroIdPacienteTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblCitaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TextBoxNombre As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdCitaTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblCitaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents TblCitaBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IntIdEstadoCitaComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DtmHoraFinMaskedTextBox As System.Windows.Forms.MaskedTextBox
    Friend WithEvents DtmHoraMaskedTextBox As System.Windows.Forms.MaskedTextBox
    Friend WithEvents DtmFechaDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntIdProcedimientoComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdProfesionalComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents StrNroOrdenTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NumValorCoopagoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrObservacionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblEmpeadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblProcedimientoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DisponibilidadBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VerificationControl As DPFP.Gui.Verification.VerificationControl
    Friend WithEvents NoRegistraHuellaCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnPago As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnHabilitarCoopago As System.Windows.Forms.Button
End Class
