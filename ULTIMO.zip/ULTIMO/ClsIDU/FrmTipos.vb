﻿Public Class FrmTipos
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

    Sub New(ByVal strStringConection As String)
        Try
            ' Llamada necesaria para el Diseñador de Windows Forms.
            InitializeComponent()

            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmTipos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TblTipoBindingSource.DataSource = dc.tblTipos
            'BindingSourceTipo.DataSource = dc.tblTipos
            'ClsComboBoxTipo.SelectedValue = TblTipoBindingSource.Item(TblTipoBindingSource.Position).IntIdTipo

            Dim i As Integer
            Dim res = (From p In dc.tblTipos Select p.strTipo).Distinct()
            Dim list As New List(Of Object)

            For Each c In res
                list.Add(c)
            Next

            For i = 0 To list.Count - 1
                StrTipoClsComboBox.Items.Add(list.Item(i))
            Next

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblTipoBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblTipoBindingNavigatorSaveItem.Click
        Try
            Dim mstrValor = StrValorClsTextBox.Text
            'TblTipoBindingSource.Item(TblTipoBindingSource.Position).IntIdTipo = CType(IntIdTipoClsTextBox.Text, Integer)
            'TblTipoBindingSource.Item(TblTipoBindingSource.Position).strTipo = ClsComboBoxTipo.Text
            'TblTipoBindingSource.Item(TblTipoBindingSource.Position).strValor = mstrValor

            TblTipoBindingSource.EndEdit()
            dc.SubmitChanges()

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub
    Private Sub TblTipoBindingSource_PositionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblTipoBindingSource.PositionChanged
        'ClsComboBoxTipo.SelectedValue = TblTipoBindingSource.Item(TblTipoBindingSource.Position).IntIdTipo
    End Sub

    Private Sub btnNuevoTipo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNuevoTipo.Click
        Dim tipo = InputBox("Ingrese el nuevo tipo", " ")
        StrTipoClsComboBox.Items.Add(tipo.ToUpper)
    End Sub
End Class