﻿Public Class uscMotivosConsulta
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mCita As Integer
    Private _btn As Windows.Forms.Button
    'Private mclsUtilidadesHC As clsUtilidadesHC
    Private _IdUsuario As String
    Private mStrDescripcionEnfermedadClsTextBox As String = ""

    Public Sub New()

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mCita() As Integer
        Get
            Return _mCita
        End Get
        Set(ByVal value As Integer)
            _mCita = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub cargarDatosTabMC()
        Try
            If Not TblMotivosConsultaBindingSource.DataSource Is Nothing Then
                TblMotivosConsultaBindingSource.DataSource = dc.tblMotivosConsulta
                Dim motivospaciente = (From p In dc.tblCitasMotivosConsulta Where p.intIdCita = mCita Select p)
                TblCitasMotivosConsultaBindingSource.DataSource = motivospaciente
                If motivospaciente.Count = 0 Then
                    Panel1.Enabled = False
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblEPBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblEPBindingNavigatorSaveItem.Click
        prGuardar()
    End Sub

    Private Sub uscMotivosConsulta_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        prGuardar()
    End Sub

    Private Sub prGuardar() Implements IAbandonarUC.prGuardar
        Try
            If Me.Enabled = True Then
                If mStrDescripcionEnfermedadClsTextBox = "" And StrDescripcionEnfermedadClsTextBox.Text.Length > 0 Then
                    mStrDescripcionEnfermedadClsTextBox = StrDescripcionEnfermedadClsTextBox.Text
                End If
                TblCitasMotivosConsultaBindingSource.Item(TblCitasMotivosConsultaBindingSource.Position).intIdCita = mCita
                TblCitasMotivosConsultaBindingSource.Item(TblCitasMotivosConsultaBindingSource.Position).intIdMotivoConsulta = IntIdMotivoConsultaClsComboBox.SelectedValue
                TblCitasMotivosConsultaBindingSource.Item(TblCitasMotivosConsultaBindingSource.Position).strDescripcionMotivo = StrDescripcionMotivoClsTextBox.Text
                'mStrDescripcionEnfermedadClsTextBox = StrDescripcionEnfermedadClsTextBox.Text
                TblCitasMotivosConsultaBindingSource.Item(TblCitasMotivosConsultaBindingSource.Position).strDescripcionEnfermedad = mStrDescripcionEnfermedadClsTextBox

                If TblCitasMotivosConsultaBindingSource.Item(TblCitasMotivosConsultaBindingSource.Position).strDescripcionMotivo() Is Nothing Then
                    TblCitasMotivosConsultaBindingSource.Item(TblCitasMotivosConsultaBindingSource.Position).strDescripcionMotivo = ""
                End If
                'If TblCitasMotivosConsultaBindingSource.Item(TblCitasMotivosConsultaBindingSource.Position).strDescripcionEnfermedad() Is Nothing Then
                '    TblCitasMotivosConsultaBindingSource.Item(TblCitasMotivosConsultaBindingSource.Position).strDescripcionEnfermedad = ""
                'End If

                StrDescripcionEnfermedadClsTextBox.Text = mStrDescripcionEnfermedadClsTextBox
                TblCitasMotivosConsultaBindingSource.Item(TblCitasMotivosConsultaBindingSource.Position).strDescripcionEnfermedad = mStrDescripcionEnfermedadClsTextBox

                TblCitasMotivosConsultaBindingSource.EndEdit()
                dc.SubmitChanges()

            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BtnNuevoMotivo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        Panel1.Enabled = True
    End Sub

    Private Sub StrDescripcionEnfermedadClsTextBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrDescripcionEnfermedadClsTextBox.Leave
        mStrDescripcionEnfermedadClsTextBox = StrDescripcionEnfermedadClsTextBox.Text
    End Sub
End Class
