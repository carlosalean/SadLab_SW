﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uscAntecedentesGinecoObstetricos
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DtmFUPLabel As System.Windows.Forms.Label
        Dim BitMasHijosLabel As System.Windows.Forms.Label
        Dim IntvivosLabel As System.Windows.Forms.Label
        Dim IntMortinatosLabel As System.Windows.Forms.Label
        Dim IntPrematurosLabel As System.Windows.Forms.Label
        Dim IntAbortosLabel As System.Windows.Forms.Label
        Dim IntAterminoLabel As System.Windows.Forms.Label
        Dim IntEmbarazosLabel As System.Windows.Forms.Label
        Dim DtmFUMLabel As System.Windows.Forms.Label
        Dim IntidTipoCiclosLabel As System.Windows.Forms.Label
        Dim IntSangradoLabel As System.Windows.Forms.Label
        Dim IntCiclosLabel As System.Windows.Forms.Label
        Dim IntPubarquiaLabel As System.Windows.Forms.Label
        Dim IntTelarquiaLabel As System.Windows.Forms.Label
        Dim IntMenarcaLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uscAntecedentesGinecoObstetricos))
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.DtmFUPClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.TblAntecedentesGinecoObstetricosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BitMasHijosClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.IntvivosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntMortinatosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntPrematurosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntAbortosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntAterminoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntEmbarazosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.DtmFUMClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.IntidTipoCiclosClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntSangradoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntCiclosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.IntPubarquiaClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.IntTelarquiaClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.IntMenarcaClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.TblEPBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblEPBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TblAntecedentesSocioEconomicosHCBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StrHcTextoGinecoObstTextBox = New System.Windows.Forms.TextBox()
        DtmFUPLabel = New System.Windows.Forms.Label()
        BitMasHijosLabel = New System.Windows.Forms.Label()
        IntvivosLabel = New System.Windows.Forms.Label()
        IntMortinatosLabel = New System.Windows.Forms.Label()
        IntPrematurosLabel = New System.Windows.Forms.Label()
        IntAbortosLabel = New System.Windows.Forms.Label()
        IntAterminoLabel = New System.Windows.Forms.Label()
        IntEmbarazosLabel = New System.Windows.Forms.Label()
        DtmFUMLabel = New System.Windows.Forms.Label()
        IntidTipoCiclosLabel = New System.Windows.Forms.Label()
        IntSangradoLabel = New System.Windows.Forms.Label()
        IntCiclosLabel = New System.Windows.Forms.Label()
        IntPubarquiaLabel = New System.Windows.Forms.Label()
        IntTelarquiaLabel = New System.Windows.Forms.Label()
        IntMenarcaLabel = New System.Windows.Forms.Label()
        Me.GroupBox4.SuspendLayout()
        CType(Me.TblAntecedentesGinecoObstetricosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.TblEPBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblEPBindingNavigator.SuspendLayout()
        CType(Me.TblAntecedentesSocioEconomicosHCBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DtmFUPLabel
        '
        DtmFUPLabel.AutoSize = True
        DtmFUPLabel.Location = New System.Drawing.Point(553, 58)
        DtmFUPLabel.Name = "DtmFUPLabel"
        DtmFUPLabel.Size = New System.Drawing.Size(37, 13)
        DtmFUPLabel.TabIndex = 14
        DtmFUPLabel.Text = "F.U.P:"
        '
        'BitMasHijosLabel
        '
        BitMasHijosLabel.AutoSize = True
        BitMasHijosLabel.Location = New System.Drawing.Point(355, 54)
        BitMasHijosLabel.Name = "BitMasHijosLabel"
        BitMasHijosLabel.Size = New System.Drawing.Size(114, 13)
        BitMasHijosLabel.TabIndex = 12
        BitMasHijosLabel.Text = "Desea tener más hijos:"
        '
        'IntvivosLabel
        '
        IntvivosLabel.AutoSize = True
        IntvivosLabel.Location = New System.Drawing.Point(553, 22)
        IntvivosLabel.Name = "IntvivosLabel"
        IntvivosLabel.Size = New System.Drawing.Size(36, 13)
        IntvivosLabel.TabIndex = 10
        IntvivosLabel.Text = "Vivos:"
        '
        'IntMortinatosLabel
        '
        IntMortinatosLabel.AutoSize = True
        IntMortinatosLabel.Location = New System.Drawing.Point(355, 22)
        IntMortinatosLabel.Name = "IntMortinatosLabel"
        IntMortinatosLabel.Size = New System.Drawing.Size(59, 13)
        IntMortinatosLabel.TabIndex = 8
        IntMortinatosLabel.Text = "Mortinatos:"
        '
        'IntPrematurosLabel
        '
        IntPrematurosLabel.AutoSize = True
        IntPrematurosLabel.Location = New System.Drawing.Point(178, 54)
        IntPrematurosLabel.Name = "IntPrematurosLabel"
        IntPrematurosLabel.Size = New System.Drawing.Size(63, 13)
        IntPrematurosLabel.TabIndex = 6
        IntPrematurosLabel.Text = "Prematuros:"
        '
        'IntAbortosLabel
        '
        IntAbortosLabel.AutoSize = True
        IntAbortosLabel.Location = New System.Drawing.Point(178, 22)
        IntAbortosLabel.Name = "IntAbortosLabel"
        IntAbortosLabel.Size = New System.Drawing.Size(46, 13)
        IntAbortosLabel.TabIndex = 4
        IntAbortosLabel.Text = "Abortos:"
        '
        'IntAterminoLabel
        '
        IntAterminoLabel.AutoSize = True
        IntAterminoLabel.Location = New System.Drawing.Point(15, 54)
        IntAterminoLabel.Name = "IntAterminoLabel"
        IntAterminoLabel.Size = New System.Drawing.Size(54, 13)
        IntAterminoLabel.TabIndex = 2
        IntAterminoLabel.Text = "A término:"
        '
        'IntEmbarazosLabel
        '
        IntEmbarazosLabel.AutoSize = True
        IntEmbarazosLabel.Location = New System.Drawing.Point(15, 22)
        IntEmbarazosLabel.Name = "IntEmbarazosLabel"
        IntEmbarazosLabel.Size = New System.Drawing.Size(62, 13)
        IntEmbarazosLabel.TabIndex = 0
        IntEmbarazosLabel.Text = "Embarazos:"
        '
        'DtmFUMLabel
        '
        DtmFUMLabel.AutoSize = True
        DtmFUMLabel.Location = New System.Drawing.Point(541, 26)
        DtmFUMLabel.Name = "DtmFUMLabel"
        DtmFUMLabel.Size = New System.Drawing.Size(39, 13)
        DtmFUMLabel.TabIndex = 6
        DtmFUMLabel.Text = "F.U.M:"
        '
        'IntidTipoCiclosLabel
        '
        IntidTipoCiclosLabel.AutoSize = True
        IntidTipoCiclosLabel.Location = New System.Drawing.Point(286, 26)
        IntidTipoCiclosLabel.Name = "IntidTipoCiclosLabel"
        IntidTipoCiclosLabel.Size = New System.Drawing.Size(62, 13)
        IntidTipoCiclosLabel.TabIndex = 4
        IntidTipoCiclosLabel.Text = "Tipo Ciclos:"
        '
        'IntSangradoLabel
        '
        IntSangradoLabel.AutoSize = True
        IntSangradoLabel.Location = New System.Drawing.Point(143, 26)
        IntSangradoLabel.Name = "IntSangradoLabel"
        IntSangradoLabel.Size = New System.Drawing.Size(56, 13)
        IntSangradoLabel.TabIndex = 2
        IntSangradoLabel.Text = "Sangrado:"
        '
        'IntCiclosLabel
        '
        IntCiclosLabel.AutoSize = True
        IntCiclosLabel.Location = New System.Drawing.Point(15, 26)
        IntCiclosLabel.Name = "IntCiclosLabel"
        IntCiclosLabel.Size = New System.Drawing.Size(38, 13)
        IntCiclosLabel.TabIndex = 0
        IntCiclosLabel.Text = "Ciclos:"
        '
        'IntPubarquiaLabel
        '
        IntPubarquiaLabel.AutoSize = True
        IntPubarquiaLabel.Location = New System.Drawing.Point(541, 20)
        IntPubarquiaLabel.Name = "IntPubarquiaLabel"
        IntPubarquiaLabel.Size = New System.Drawing.Size(58, 13)
        IntPubarquiaLabel.TabIndex = 6
        IntPubarquiaLabel.Text = "Pubarquia:"
        '
        'IntTelarquiaLabel
        '
        IntTelarquiaLabel.AutoSize = True
        IntTelarquiaLabel.Location = New System.Drawing.Point(282, 22)
        IntTelarquiaLabel.Name = "IntTelarquiaLabel"
        IntTelarquiaLabel.Size = New System.Drawing.Size(54, 13)
        IntTelarquiaLabel.TabIndex = 3
        IntTelarquiaLabel.Text = "Telarquia:"
        '
        'IntMenarcaLabel
        '
        IntMenarcaLabel.AutoSize = True
        IntMenarcaLabel.Location = New System.Drawing.Point(15, 20)
        IntMenarcaLabel.Name = "IntMenarcaLabel"
        IntMenarcaLabel.Size = New System.Drawing.Size(52, 13)
        IntMenarcaLabel.TabIndex = 0
        IntMenarcaLabel.Text = "Menarca:"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(DtmFUPLabel)
        Me.GroupBox4.Controls.Add(Me.DtmFUPClsDateTimePicker)
        Me.GroupBox4.Controls.Add(BitMasHijosLabel)
        Me.GroupBox4.Controls.Add(Me.BitMasHijosClsCheckBox)
        Me.GroupBox4.Controls.Add(IntvivosLabel)
        Me.GroupBox4.Controls.Add(Me.IntvivosClsTextBox)
        Me.GroupBox4.Controls.Add(IntMortinatosLabel)
        Me.GroupBox4.Controls.Add(Me.IntMortinatosClsTextBox)
        Me.GroupBox4.Controls.Add(IntPrematurosLabel)
        Me.GroupBox4.Controls.Add(Me.IntPrematurosClsTextBox)
        Me.GroupBox4.Controls.Add(IntAbortosLabel)
        Me.GroupBox4.Controls.Add(Me.IntAbortosClsTextBox)
        Me.GroupBox4.Controls.Add(IntAterminoLabel)
        Me.GroupBox4.Controls.Add(Me.IntAterminoClsTextBox)
        Me.GroupBox4.Controls.Add(IntEmbarazosLabel)
        Me.GroupBox4.Controls.Add(Me.IntEmbarazosClsTextBox)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 157)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(715, 87)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Historia Obstétrica"
        '
        'DtmFUPClsDateTimePicker
        '
        Me.DtmFUPClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblAntecedentesGinecoObstetricosBindingSource, "dtmFUP", True))
        Me.DtmFUPClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFUPClsDateTimePicker.Location = New System.Drawing.Point(605, 54)
        Me.DtmFUPClsDateTimePicker.Name = "DtmFUPClsDateTimePicker"
        Me.DtmFUPClsDateTimePicker.Size = New System.Drawing.Size(96, 20)
        Me.DtmFUPClsDateTimePicker.TabIndex = 15
        '
        'TblAntecedentesGinecoObstetricosBindingSource
        '
        Me.TblAntecedentesGinecoObstetricosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblAntecedentesGinecoObstetricos)
        '
        'BitMasHijosClsCheckBox
        '
        Me.BitMasHijosClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblAntecedentesGinecoObstetricosBindingSource, "bitMasHijos", True))
        Me.BitMasHijosClsCheckBox.Location = New System.Drawing.Point(471, 50)
        Me.BitMasHijosClsCheckBox.Name = "BitMasHijosClsCheckBox"
        Me.BitMasHijosClsCheckBox.Size = New System.Drawing.Size(18, 24)
        Me.BitMasHijosClsCheckBox.TabIndex = 13
        Me.BitMasHijosClsCheckBox.UseVisualStyleBackColor = True
        '
        'IntvivosClsTextBox
        '
        Me.IntvivosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intvivos", True))
        Me.IntvivosClsTextBox.DataSource = Nothing
        Me.IntvivosClsTextBox.EnterEntreCampos = True
        Me.IntvivosClsTextBox.Location = New System.Drawing.Point(604, 19)
        Me.IntvivosClsTextBox.Name = "IntvivosClsTextBox"
        Me.IntvivosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntvivosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntvivosClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntvivosClsTextBox.TabIndex = 11
        Me.IntvivosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntMortinatosClsTextBox
        '
        Me.IntMortinatosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intMortinatos", True))
        Me.IntMortinatosClsTextBox.DataSource = Nothing
        Me.IntMortinatosClsTextBox.EnterEntreCampos = True
        Me.IntMortinatosClsTextBox.Location = New System.Drawing.Point(420, 19)
        Me.IntMortinatosClsTextBox.Name = "IntMortinatosClsTextBox"
        Me.IntMortinatosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntMortinatosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntMortinatosClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntMortinatosClsTextBox.TabIndex = 9
        Me.IntMortinatosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntPrematurosClsTextBox
        '
        Me.IntPrematurosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intPrematuros", True))
        Me.IntPrematurosClsTextBox.DataSource = Nothing
        Me.IntPrematurosClsTextBox.EnterEntreCampos = True
        Me.IntPrematurosClsTextBox.Location = New System.Drawing.Point(247, 51)
        Me.IntPrematurosClsTextBox.Name = "IntPrematurosClsTextBox"
        Me.IntPrematurosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntPrematurosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntPrematurosClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntPrematurosClsTextBox.TabIndex = 7
        Me.IntPrematurosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntAbortosClsTextBox
        '
        Me.IntAbortosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intAbortos", True))
        Me.IntAbortosClsTextBox.DataSource = Nothing
        Me.IntAbortosClsTextBox.EnterEntreCampos = True
        Me.IntAbortosClsTextBox.Location = New System.Drawing.Point(247, 19)
        Me.IntAbortosClsTextBox.Name = "IntAbortosClsTextBox"
        Me.IntAbortosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntAbortosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntAbortosClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntAbortosClsTextBox.TabIndex = 5
        Me.IntAbortosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntAterminoClsTextBox
        '
        Me.IntAterminoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intAtermino", True))
        Me.IntAterminoClsTextBox.DataSource = Nothing
        Me.IntAterminoClsTextBox.EnterEntreCampos = True
        Me.IntAterminoClsTextBox.Location = New System.Drawing.Point(83, 51)
        Me.IntAterminoClsTextBox.Name = "IntAterminoClsTextBox"
        Me.IntAterminoClsTextBox.NombreCodigoF2 = Nothing
        Me.IntAterminoClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntAterminoClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntAterminoClsTextBox.TabIndex = 3
        Me.IntAterminoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntEmbarazosClsTextBox
        '
        Me.IntEmbarazosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intEmbarazos", True))
        Me.IntEmbarazosClsTextBox.DataSource = Nothing
        Me.IntEmbarazosClsTextBox.EnterEntreCampos = True
        Me.IntEmbarazosClsTextBox.Location = New System.Drawing.Point(83, 19)
        Me.IntEmbarazosClsTextBox.Name = "IntEmbarazosClsTextBox"
        Me.IntEmbarazosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntEmbarazosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntEmbarazosClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntEmbarazosClsTextBox.TabIndex = 1
        Me.IntEmbarazosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(DtmFUMLabel)
        Me.GroupBox3.Controls.Add(Me.DtmFUMClsDateTimePicker)
        Me.GroupBox3.Controls.Add(IntidTipoCiclosLabel)
        Me.GroupBox3.Controls.Add(Me.IntidTipoCiclosClsComboBox)
        Me.GroupBox3.Controls.Add(IntSangradoLabel)
        Me.GroupBox3.Controls.Add(Me.IntSangradoClsTextBox)
        Me.GroupBox3.Controls.Add(IntCiclosLabel)
        Me.GroupBox3.Controls.Add(Me.IntCiclosClsTextBox)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 91)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(715, 60)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Ciclos mestruales"
        '
        'DtmFUMClsDateTimePicker
        '
        Me.DtmFUMClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblAntecedentesGinecoObstetricosBindingSource, "dtmFUM", True))
        Me.DtmFUMClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFUMClsDateTimePicker.Location = New System.Drawing.Point(582, 23)
        Me.DtmFUMClsDateTimePicker.Name = "DtmFUMClsDateTimePicker"
        Me.DtmFUMClsDateTimePicker.Size = New System.Drawing.Size(112, 20)
        Me.DtmFUMClsDateTimePicker.TabIndex = 7
        '
        'IntidTipoCiclosClsComboBox
        '
        Me.IntidTipoCiclosClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intidTipoCiclos", True))
        Me.IntidTipoCiclosClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesGinecoObstetricosBindingSource, "intidTipoCiclos", True))
        Me.IntidTipoCiclosClsComboBox.DataSource = Me.TblTipoBindingSource
        Me.IntidTipoCiclosClsComboBox.DisplayMember = "strValor"
        Me.IntidTipoCiclosClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntidTipoCiclosClsComboBox.FormattingEnabled = True
        Me.IntidTipoCiclosClsComboBox.Location = New System.Drawing.Point(349, 22)
        Me.IntidTipoCiclosClsComboBox.Name = "IntidTipoCiclosClsComboBox"
        Me.IntidTipoCiclosClsComboBox.Size = New System.Drawing.Size(145, 21)
        Me.IntidTipoCiclosClsComboBox.TabIndex = 5
        Me.IntidTipoCiclosClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoBindingSource
        '
        Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoBindingSource.Sort = "strValor"
        '
        'IntSangradoClsTextBox
        '
        Me.IntSangradoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intSangrado", True))
        Me.IntSangradoClsTextBox.DataSource = Nothing
        Me.IntSangradoClsTextBox.EnterEntreCampos = True
        Me.IntSangradoClsTextBox.Location = New System.Drawing.Point(203, 22)
        Me.IntSangradoClsTextBox.Name = "IntSangradoClsTextBox"
        Me.IntSangradoClsTextBox.NombreCodigoF2 = Nothing
        Me.IntSangradoClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntSangradoClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntSangradoClsTextBox.TabIndex = 3
        Me.IntSangradoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntCiclosClsTextBox
        '
        Me.IntCiclosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intCiclos", True))
        Me.IntCiclosClsTextBox.DataSource = Nothing
        Me.IntCiclosClsTextBox.EnterEntreCampos = True
        Me.IntCiclosClsTextBox.Location = New System.Drawing.Point(59, 22)
        Me.IntCiclosClsTextBox.Name = "IntCiclosClsTextBox"
        Me.IntCiclosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntCiclosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntCiclosClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntCiclosClsTextBox.TabIndex = 1
        Me.IntCiclosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(IntPubarquiaLabel)
        Me.GroupBox2.Controls.Add(Me.IntPubarquiaClsTextBox)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(IntTelarquiaLabel)
        Me.GroupBox2.Controls.Add(Me.IntTelarquiaClsTextBox)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(IntMenarcaLabel)
        Me.GroupBox2.Controls.Add(Me.IntMenarcaClsTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 35)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(715, 50)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Desarrollo sexual"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(665, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(30, 13)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "años"
        '
        'IntPubarquiaClsTextBox
        '
        Me.IntPubarquiaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intPubarquia", True))
        Me.IntPubarquiaClsTextBox.DataSource = Nothing
        Me.IntPubarquiaClsTextBox.EnterEntreCampos = True
        Me.IntPubarquiaClsTextBox.Location = New System.Drawing.Point(605, 17)
        Me.IntPubarquiaClsTextBox.Name = "IntPubarquiaClsTextBox"
        Me.IntPubarquiaClsTextBox.NombreCodigoF2 = Nothing
        Me.IntPubarquiaClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntPubarquiaClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntPubarquiaClsTextBox.TabIndex = 7
        Me.IntPubarquiaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(402, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "años"
        '
        'IntTelarquiaClsTextBox
        '
        Me.IntTelarquiaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intTelarquia", True))
        Me.IntTelarquiaClsTextBox.DataSource = Nothing
        Me.IntTelarquiaClsTextBox.EnterEntreCampos = True
        Me.IntTelarquiaClsTextBox.Location = New System.Drawing.Point(342, 19)
        Me.IntTelarquiaClsTextBox.Name = "IntTelarquiaClsTextBox"
        Me.IntTelarquiaClsTextBox.NombreCodigoF2 = Nothing
        Me.IntTelarquiaClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntTelarquiaClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntTelarquiaClsTextBox.TabIndex = 4
        Me.IntTelarquiaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(129, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 13)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "años"
        '
        'IntMenarcaClsTextBox
        '
        Me.IntMenarcaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "intMenarca", True))
        Me.IntMenarcaClsTextBox.DataSource = Nothing
        Me.IntMenarcaClsTextBox.EnterEntreCampos = True
        Me.IntMenarcaClsTextBox.Location = New System.Drawing.Point(73, 17)
        Me.IntMenarcaClsTextBox.Name = "IntMenarcaClsTextBox"
        Me.IntMenarcaClsTextBox.NombreCodigoF2 = Nothing
        Me.IntMenarcaClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntMenarcaClsTextBox.Size = New System.Drawing.Size(54, 20)
        Me.IntMenarcaClsTextBox.TabIndex = 1
        Me.IntMenarcaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblEPBindingNavigator
        '
        Me.TblEPBindingNavigator.AddNewItem = Nothing
        Me.TblEPBindingNavigator.BindingSource = Me.TblAntecedentesGinecoObstetricosBindingSource
        Me.TblEPBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblEPBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblEPBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorDeleteItem, Me.TblEPBindingNavigatorSaveItem})
        Me.TblEPBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblEPBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblEPBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblEPBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblEPBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblEPBindingNavigator.Name = "TblEPBindingNavigator"
        Me.TblEPBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblEPBindingNavigator.Size = New System.Drawing.Size(747, 25)
        Me.TblEPBindingNavigator.TabIndex = 6
        Me.TblEPBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblEPBindingNavigatorSaveItem
        '
        Me.TblEPBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblEPBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblEPBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblEPBindingNavigatorSaveItem.Name = "TblEPBindingNavigatorSaveItem"
        Me.TblEPBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblEPBindingNavigatorSaveItem.Text = "Save Data"
        '
        'TblAntecedentesSocioEconomicosHCBindingSource
        '
        Me.TblAntecedentesSocioEconomicosHCBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblAntecedentesSocioEconomicosHC)
        '
        'StrHcTextoGinecoObstTextBox
        '
        Me.StrHcTextoGinecoObstTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesGinecoObstetricosBindingSource, "strHcTextoGinecoObst", True))
        Me.StrHcTextoGinecoObstTextBox.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StrHcTextoGinecoObstTextBox.Location = New System.Drawing.Point(308, 250)
        Me.StrHcTextoGinecoObstTextBox.Name = "StrHcTextoGinecoObstTextBox"
        Me.StrHcTextoGinecoObstTextBox.Size = New System.Drawing.Size(100, 26)
        Me.StrHcTextoGinecoObstTextBox.TabIndex = 8
        Me.StrHcTextoGinecoObstTextBox.Visible = False
        '
        'uscAntecedentesGinecoObstetricos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.StrHcTextoGinecoObstTextBox)
        Me.Controls.Add(Me.TblEPBindingNavigator)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Name = "uscAntecedentesGinecoObstetricos"
        Me.Size = New System.Drawing.Size(747, 464)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.TblAntecedentesGinecoObstetricosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.TblEPBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblEPBindingNavigator.ResumeLayout(False)
        Me.TblEPBindingNavigator.PerformLayout()
        CType(Me.TblAntecedentesSocioEconomicosHCBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblAntecedentesGinecoObstetricosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents DtmFUPClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents BitMasHijosClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents IntvivosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntMortinatosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntPrematurosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntAbortosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntAterminoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntEmbarazosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents DtmFUMClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntidTipoCiclosClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntSangradoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntCiclosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents IntPubarquiaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents IntTelarquiaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents IntMenarcaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblEPBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblEPBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblAntecedentesSocioEconomicosHCBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StrHcTextoGinecoObstTextBox As System.Windows.Forms.TextBox

End Class
