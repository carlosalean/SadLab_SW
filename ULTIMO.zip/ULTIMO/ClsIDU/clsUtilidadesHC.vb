﻿Public Class clsUtilidadesHC
    Private dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private midUsuario As String

    Public Sub New(ByVal pdc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext, ByVal pidUsuario As String)
        dc = pdc
        midUsuario = pidUsuario
    End Sub

    Public Function consultarModoTextoItems(ByVal btn As Windows.Forms.Button) As Boolean
        Try
            Dim idItem As Integer = (From i In dc.tblItemRevision Where i.strTAG.Equals(btn.Tag) Select i.intIdItemRevision).Single
            Dim confProfesional = (From p In dc.tblProfesionalesItems Join u In dc.tblUsuarios On p.intIdCodigoEmpleado Equals u.intidEmpleado Where u.intIdUsuario = midUsuario And p.intIdItemRevision = CType(idItem, Integer) Select p.bitSoloTexto).Single

            If CType(confProfesional, Boolean) = True Then
                consultarModoTextoItems = True
            Else
                consultarModoTextoItems = False
            End If
        Catch ex As Exception
            consultarModoTextoItems = False
        End Try
    End Function

End Class
