﻿Public Class FrmTarifasHistorico

  Public mstrStringConection As String
  Dim mDataContext As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext()

  Sub New(ByVal strStringConection As String)
    Try

      ' This call is required by the Windows Form Designer.
      InitializeComponent()

      ' Add any initialization after the InitializeComponent() call.
      'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
      mstrStringConection = strStringConection
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub


  Private Sub FrmTarifas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Try
      Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
      mDataContext = dc

      Dim TipoDoc = (From p In dc.tblTipos _
          Where p.strTipo = "TIPO_TARIFA")
      TblTipoBindingSource.DataSource = TipoDoc

      TblProcedimientoBindingSource.DataSource = dc.tblProcedimiento
      TblTarifaBindingSource.DataSource = dc.tblTarifas
      TblEPBindingSource.DataSource = dc.tblEPs
      TblTipoTarifaBindingSource.DataSource = dc.tblTipoTarifa
      TblTarifaBaseBindingSource.DataSource = dc.tblTarifaBase
      TblIPSBindingSource.DataSource = dc.IPS

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TblTarifaBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblTarifaBindingNavigatorSaveItem.Click
    Try

      TblTarifaBindingSource.EndEdit()
      mDataContext.SubmitChanges()
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TblTarifaDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblTarifaDataGridView.DataError
    Try
      'Error
    Catch ex As Exception
      'Error
    End Try
  End Sub

  Private Sub ToolStripButtonImportar_Click(sender As Object, e As EventArgs) Handles ToolStripButtonImportar.Click
    Try
      Dim mClsImportar As New ClsReportes.ClsImportarArchivo()
      Dim mDatos As New DataTable()
      If OpenFileDialogImportar.ShowDialog() = Windows.Forms.DialogResult.OK Then

        mDatos = mClsImportar.FnImportarArchivo(OpenFileDialogImportar.FileName)
        For Each mTabla In mDatos.Rows
          Dim mRegistroTarifa As New ClsBaseDatos_SadLab.tblTarifas
          Dim mValores = mTabla(0).Split(";"c)
          Dim mstrProc As String = mValores(2)
          Dim mProcedimiento = (From c In mDataContext.tblProcedimiento _
                               Where (c.strCodigoProcedimiento = mstrProc) _
                               Select c.intIdProcedimientos).Take(1)

          mRegistroTarifa.intIdEPS = mValores(0)
          mRegistroTarifa.intIdProcedimiento = mProcedimiento.Single
          mRegistroTarifa.strCodigoProcedimiento = mValores(3)
          mRegistroTarifa.intIdTarifaBase = mValores(4)
          mRegistroTarifa.intTipo = mValores(5)
          mRegistroTarifa.intIDTipoTarifa = mValores(6)
          mRegistroTarifa.numValor = mValores(7)

          TblTarifaBindingSource.Add(mRegistroTarifa)
        Next
        TblTarifaBindingSource.EndEdit()
        mDataContext.SubmitChanges()
      End If
    Catch ex As Exception

    End Try
  End Sub
End Class