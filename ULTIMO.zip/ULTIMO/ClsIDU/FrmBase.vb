﻿Public Class FrmBase

End Class