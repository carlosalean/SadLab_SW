﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSintomasSignosLaboratorios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmSintomasSignosLaboratorios))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.ClsCheckBox = New ClsUtilidades.ClsCheckBox
        Me.NumericUpDownFinal = New System.Windows.Forms.NumericUpDown
        Me.NumericUpDownInicial = New System.Windows.Forms.NumericUpDown
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.cmbTipoDato = New System.Windows.Forms.ComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.cmbTipoCampo = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtNombreNodo = New System.Windows.Forms.TextBox
        Me.TreeView = New System.Windows.Forms.TreeView
        Me.ImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        Me.ComboBoxTipo = New System.Windows.Forms.ComboBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnContraer = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.btnLimpiar = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.btnBorrar = New System.Windows.Forms.Button
        Me.btnGuardar = New System.Windows.Forms.Button
        Me.btnNuevo = New System.Windows.Forms.Button
        Me.btnModificar = New System.Windows.Forms.Button
        Me.btnExpandir = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.GroupBox2.SuspendLayout()
        CType(Me.NumericUpDownFinal, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownInicial, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.ClsCheckBox)
        Me.GroupBox2.Controls.Add(Me.NumericUpDownFinal)
        Me.GroupBox2.Controls.Add(Me.NumericUpDownInicial)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.cmbTipoDato)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.cmbTipoCampo)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtNombreNodo)
        Me.GroupBox2.Location = New System.Drawing.Point(427, 15)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(368, 151)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Agregar elemento"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(190, 133)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(0, 13)
        Me.Label7.TabIndex = 12
        '
        'ClsCheckBox
        '
        Me.ClsCheckBox.AutoSize = True
        Me.ClsCheckBox.Enabled = False
        Me.ClsCheckBox.Location = New System.Drawing.Point(13, 132)
        Me.ClsCheckBox.Name = "ClsCheckBox"
        Me.ClsCheckBox.Size = New System.Drawing.Size(182, 17)
        Me.ClsCheckBox.TabIndex = 11
        Me.ClsCheckBox.Text = "Valor por defecto tipo dato lógico"
        Me.ClsCheckBox.UseVisualStyleBackColor = True
        '
        'NumericUpDownFinal
        '
        Me.NumericUpDownFinal.Enabled = False
        Me.NumericUpDownFinal.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDownFinal.Location = New System.Drawing.Point(261, 106)
        Me.NumericUpDownFinal.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDownFinal.Name = "NumericUpDownFinal"
        Me.NumericUpDownFinal.Size = New System.Drawing.Size(97, 20)
        Me.NumericUpDownFinal.TabIndex = 10
        Me.NumericUpDownFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDownInicial
        '
        Me.NumericUpDownInicial.Enabled = False
        Me.NumericUpDownInicial.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDownInicial.Location = New System.Drawing.Point(83, 106)
        Me.NumericUpDownInicial.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDownInicial.Name = "NumericUpDownInicial"
        Me.NumericUpDownInicial.Size = New System.Drawing.Size(96, 20)
        Me.NumericUpDownInicial.TabIndex = 9
        Me.NumericUpDownInicial.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(188, 108)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Rango Final:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 108)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Rango Inicial:"
        '
        'cmbTipoDato
        '
        Me.cmbTipoDato.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTipoDato.Enabled = False
        Me.cmbTipoDato.FormattingEnabled = True
        Me.cmbTipoDato.Items.AddRange(New Object() {"Carácter", "Lógico", "Numérico"})
        Me.cmbTipoDato.Location = New System.Drawing.Point(261, 79)
        Me.cmbTipoDato.Name = "cmbTipoDato"
        Me.cmbTipoDato.Size = New System.Drawing.Size(97, 21)
        Me.cmbTipoDato.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(185, 82)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(75, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Tipo de datos:"
        '
        'cmbTipoCampo
        '
        Me.cmbTipoCampo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbTipoCampo.Enabled = False
        Me.cmbTipoCampo.FormattingEnabled = True
        Me.cmbTipoCampo.Items.AddRange(New Object() {"Título", "Información"})
        Me.cmbTipoCampo.Location = New System.Drawing.Point(83, 79)
        Me.cmbTipoCampo.Name = "cmbTipoCampo"
        Me.cmbTipoCampo.Size = New System.Drawing.Size(96, 21)
        Me.cmbTipoCampo.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(317, 26)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Para agregar elementos, seleccione un elemento a cualquier nivel" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "introduzca el n" & _
            "uevo evento y haga clic en el botón guardar"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Tipo de campo:"
        '
        'txtNombreNodo
        '
        Me.txtNombreNodo.Enabled = False
        Me.txtNombreNodo.Location = New System.Drawing.Point(6, 53)
        Me.txtNombreNodo.Name = "txtNombreNodo"
        Me.txtNombreNodo.Size = New System.Drawing.Size(352, 20)
        Me.txtNombreNodo.TabIndex = 0
        '
        'TreeView
        '
        Me.TreeView.ImageIndex = 0
        Me.TreeView.ImageList = Me.ImageList
        Me.TreeView.Location = New System.Drawing.Point(13, 45)
        Me.TreeView.Name = "TreeView"
        Me.TreeView.SelectedImageIndex = 0
        Me.TreeView.Size = New System.Drawing.Size(408, 459)
        Me.TreeView.TabIndex = 2
        '
        'ImageList
        '
        Me.ImageList.ImageStream = CType(resources.GetObject("ImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList.Images.SetKeyName(0, "tree_folder.png")
        Me.ImageList.Images.SetKeyName(1, "books_016.gif")
        Me.ImageList.Images.SetKeyName(2, "2.ico")
        Me.ImageList.Images.SetKeyName(3, "wi0054-24.png")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(140, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(31, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Tipo:"
        '
        'ComboBoxTipo
        '
        Me.ComboBoxTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBoxTipo.FormattingEnabled = True
        Me.ComboBoxTipo.Items.AddRange(New Object() {"Sintomas", "Signos", "Laboratorios"})
        Me.ComboBoxTipo.Location = New System.Drawing.Point(189, 18)
        Me.ComboBoxTipo.Name = "ComboBoxTipo"
        Me.ComboBoxTipo.Size = New System.Drawing.Size(232, 21)
        Me.ComboBoxTipo.TabIndex = 5
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnContraer)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Controls.Add(Me.btnExpandir)
        Me.GroupBox1.Location = New System.Drawing.Point(428, 169)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(367, 88)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        '
        'btnContraer
        '
        Me.btnContraer.Location = New System.Drawing.Point(177, 55)
        Me.btnContraer.Name = "btnContraer"
        Me.btnContraer.Size = New System.Drawing.Size(82, 26)
        Me.btnContraer.TabIndex = 12
        Me.btnContraer.Text = "Contraer Lista"
        Me.btnContraer.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.btnLimpiar)
        Me.Panel1.Controls.Add(Me.btnCancelar)
        Me.Panel1.Controls.Add(Me.btnBorrar)
        Me.Panel1.Controls.Add(Me.btnGuardar)
        Me.Panel1.Controls.Add(Me.btnNuevo)
        Me.Panel1.Controls.Add(Me.btnModificar)
        Me.Panel1.Location = New System.Drawing.Point(14, 11)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(341, 36)
        Me.Panel1.TabIndex = 12
        '
        'btnLimpiar
        '
        Me.btnLimpiar.Image = Global.ClsIDU.My.Resources.Resources._EXIT
        Me.btnLimpiar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnLimpiar.Location = New System.Drawing.Point(283, 0)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(58, 35)
        Me.btnLimpiar.TabIndex = 15
        Me.btnLimpiar.Text = "Salír"
        Me.btnLimpiar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnLimpiar.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.Enabled = False
        Me.btnCancelar.Image = Global.ClsIDU.My.Resources.Resources.WZUNDO
        Me.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCancelar.Location = New System.Drawing.Point(226, 0)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(58, 35)
        Me.btnCancelar.TabIndex = 14
        Me.btnCancelar.Text = "Cancelar"
        Me.btnCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'btnBorrar
        '
        Me.btnBorrar.Image = Global.ClsIDU.My.Resources.Resources._16__Delete_
        Me.btnBorrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnBorrar.Location = New System.Drawing.Point(169, 0)
        Me.btnBorrar.Name = "btnBorrar"
        Me.btnBorrar.Size = New System.Drawing.Size(58, 35)
        Me.btnBorrar.TabIndex = 13
        Me.btnBorrar.Text = "Eliminar"
        Me.btnBorrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnBorrar.UseVisualStyleBackColor = True
        '
        'btnGuardar
        '
        Me.btnGuardar.Enabled = False
        Me.btnGuardar.Image = Global.ClsIDU.My.Resources.Resources._16__Save_
        Me.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnGuardar.Location = New System.Drawing.Point(57, 0)
        Me.btnGuardar.Name = "btnGuardar"
        Me.btnGuardar.Size = New System.Drawing.Size(56, 35)
        Me.btnGuardar.TabIndex = 13
        Me.btnGuardar.Text = "Guardar"
        Me.btnGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnGuardar.UseVisualStyleBackColor = True
        '
        'btnNuevo
        '
        Me.btnNuevo.Image = Global.ClsIDU.My.Resources.Resources._NEW
        Me.btnNuevo.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnNuevo.Location = New System.Drawing.Point(0, 0)
        Me.btnNuevo.Name = "btnNuevo"
        Me.btnNuevo.Size = New System.Drawing.Size(58, 35)
        Me.btnNuevo.TabIndex = 13
        Me.btnNuevo.Text = "Nuevo"
        Me.btnNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnNuevo.UseVisualStyleBackColor = True
        '
        'btnModificar
        '
        Me.btnModificar.Image = Global.ClsIDU.My.Resources.Resources._16__Edit_3_
        Me.btnModificar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnModificar.Location = New System.Drawing.Point(112, 0)
        Me.btnModificar.Name = "btnModificar"
        Me.btnModificar.Size = New System.Drawing.Size(58, 35)
        Me.btnModificar.TabIndex = 11
        Me.btnModificar.Text = "Modificar"
        Me.btnModificar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnModificar.UseVisualStyleBackColor = True
        '
        'btnExpandir
        '
        Me.btnExpandir.Location = New System.Drawing.Point(95, 55)
        Me.btnExpandir.Name = "btnExpandir"
        Me.btnExpandir.Size = New System.Drawing.Size(82, 26)
        Me.btnExpandir.TabIndex = 11
        Me.btnExpandir.Text = "Expandir Lista"
        Me.btnExpandir.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(437, 272)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 13)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Ubicación"
        '
        'FrmSintomasSignosLaboratorios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(811, 516)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ComboBoxTipo)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.TreeView)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmSintomasSignosLaboratorios"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Sintomas Signos y Laboratorios"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.NumericUpDownFinal, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownInicial, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TreeView As System.Windows.Forms.TreeView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBoxTipo As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtNombreNodo As System.Windows.Forms.TextBox
    Friend WithEvents cmbTipoCampo As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmbTipoDato As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownInicial As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDownFinal As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ImageList As System.Windows.Forms.ImageList
    Friend WithEvents ClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnModificar As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnNuevo As System.Windows.Forms.Button
    Friend WithEvents btnGuardar As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents btnBorrar As System.Windows.Forms.Button
    Friend WithEvents btnLimpiar As System.Windows.Forms.Button
    Friend WithEvents btnExpandir As System.Windows.Forms.Button
    Friend WithEvents btnContraer As System.Windows.Forms.Button
End Class
