﻿Public Class clsCodificaciones
    Private mClaveDeCodifica() As String = {"1", "2", "3", "4", "5", "6", "7", "8", "9", ",", "0"}
    Private mClaveCodifica() As String = {"!", "@", "·", "$", "%", "&", "/", "(", ")", "?", "*"}

    Public Function FnCodifica(ByVal strPalabra As String) As String
        Dim i As Integer = 0
        Dim j As Integer = 0

        Dim mResultado As String = ""
        For i = 0 To strPalabra.Count - 1
            j = 0
            For Each m In mClaveDeCodifica
                If strPalabra(i) = m Then
                    mResultado &= mClaveCodifica(j)
                End If
                j = j + 1
            Next m
        Next i

        Return mResultado
    End Function

    Public Function FnDecodifica(ByVal strPalabra As String) As String
        Dim i As Integer = 0
        Dim mResultado As String = ""
        Dim j As Integer = 0
        For i = 0 To strPalabra.Count - 1
            j = 0
            For Each m In mClaveCodifica
                If strPalabra(i) = m Then
                    mResultado = mClaveDeCodifica(j)
                End If
                j = j + 1
            Next m
        Next
        Return mResultado
    End Function

End Class
