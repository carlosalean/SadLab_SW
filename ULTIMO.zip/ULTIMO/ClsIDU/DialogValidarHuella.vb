﻿Imports System.Windows.Forms

Public Class DialogValidarHuella
    Dim mstrStringConection As String
    Public mstrIntIdUsuario As Integer
    Private Templates(3) As DPFP.Template
    Dim ver As New DPFP.Verification.Verification()
    Dim res As New DPFP.Verification.Verification.Result()
    Dim mHuella
    Dim mClave
    Dim mbitPermitirCambiarUsuario

    Sub New(ByVal strStringConection As String, ByVal pstrIntIdUsuario As Integer, Optional ByVal pbitPermitirCambiarUsuario As Boolean = True)
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            mstrStringConection = strStringConection
            mstrIntIdUsuario = pstrIntIdUsuario
            mbitPermitirCambiarUsuario = pbitPermitirCambiarUsuario
            'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        If res.Verified Then
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        Else
            If mHuella Then
                MsgBox("La Huella no corresponde al usuario actual o al seleccionado..")
            Else
                MsgBox("Clave inválida..", MsgBoxStyle.Information)
            End If
        End If
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DialogValidarHuella_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

            TblUsuarioBindingSource.DataSource = dc.tblUsuarios

            Dim mTemplate
            Dim bytes As Byte() = Nothing
            Dim mintIdUsuario As Integer

            mintIdUsuario = mstrIntIdUsuario
            Dim mtmpUsuario = dc.usp_TemplatesUsuario(mintIdUsuario)
            Dim mtmpUsuario2 = mtmpUsuario(0)

            mTemplate = mtmpUsuario2.byTemplate1
            If Not mTemplate Is Nothing Then
                bytes = mTemplate.ToArray()
                Templates(0) = New DPFP.Template()
                Templates(0).DeSerialize(bytes)
            End If

            mTemplate = mtmpUsuario2.byTemplate2
            If Not mTemplate Is Nothing Then
                bytes = mTemplate.ToArray()
                Templates(1) = New DPFP.Template()
                Templates(1).DeSerialize(bytes)
            End If


            mTemplate = mtmpUsuario2.byTemplate3
            If Not mTemplate Is Nothing Then
                bytes = mTemplate.ToArray()
                Templates(2) = New DPFP.Template()
                Templates(2).DeSerialize(bytes)
            End If

            mTemplate = mtmpUsuario2.byTemplate4
            If Not mTemplate Is Nothing Then
                bytes = mTemplate.ToArray()
                Templates(3) = New DPFP.Template()
                Templates(3).DeSerialize(bytes)
            End If


            mHuella = (From p In dc.tblUsuarios Where p.intIdUsuario = mintIdUsuario Select p.bitValidaHuella).Single
            ClaveClsTextBox.Visible = Not mHuella
            Label2.Visible = Not mHuella

            mClave = (From p In dc.tblUsuarios Where p.intIdUsuario = mintIdUsuario Select p.strClave).Single

            IntIdUsuarioClsComboBox.SelectedIndex = -1

            IntIdUsuarioClsComboBox.Enabled = mbitPermitirCambiarUsuario

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Sub OnComplete(ByVal Control As Object, ByVal FeatureSet As DPFP.FeatureSet, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles VerificationControl.OnComplete

        For Each template As DPFP.Template In Templates    ' Compare feature set with all stored templates:
            If Not template Is Nothing Then                     '   Get template from storage.
                ver.Verify(FeatureSet, template, res)           '   Compare feature set with particular template.
                'Data.IsFeatureSetMatched = res.Verified         '   Check the result of the comparison
                'Data.FalseAcceptRate = res.FARAchieved          '   Determine the current False Accept Rate
                If res.Verified Then
                    EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Success
                    Exit For ' success
                End If
            End If
        Next
        If Not res.Verified Then EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Failure
        'Data.Update()
    End Sub

    Private Sub IntIdUsuarioClsComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntIdUsuarioClsComboBox.SelectedIndexChanged
        Try
            If (Not IntIdUsuarioClsComboBox.SelectedValue Is Nothing) And IntIdUsuarioClsComboBox.SelectedIndex >= 0 Then

                Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

                Dim midUsuario As Integer

                midUsuario = IntIdUsuarioClsComboBox.SelectedValue 'TblUsuarioBindingSource.Item(TblUsuarioBindingSource.Position).intIdUsuario

                Dim mTemplate
                Dim bytes As Byte() = Nothing

                Dim mtmpUsuario = dc.usp_TemplatesUsuario(midUsuario)
                Dim mtmpUsuario2 = mtmpUsuario(0)


                mTemplate = mtmpUsuario2.byTemplate1
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(0) = New DPFP.Template()
                    Templates(0).DeSerialize(bytes)
                End If

                mTemplate = mtmpUsuario2.byTemplate2
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(1) = New DPFP.Template()
                    Templates(1).DeSerialize(bytes)
                End If


                mTemplate = mtmpUsuario2.byTemplate3
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(2) = New DPFP.Template()
                    Templates(2).DeSerialize(bytes)
                End If

                mTemplate = mtmpUsuario2.byTemplate4
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(3) = New DPFP.Template()
                    Templates(3).DeSerialize(bytes)
                End If


                mHuella = (From p In dc.tblUsuarios Where p.intIdUsuario = midUsuario Select p.bitValidaHuella).Single
                ClaveClsTextBox.Visible = Not mHuella
                Label2.Visible = Not mHuella

                mClave = (From p In dc.tblUsuarios Where p.intIdUsuario = midUsuario Select p.strClave).Single

                mstrIntIdUsuario = midUsuario
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub ClaveClsTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClaveClsTextBox.TextChanged
        res.Verified = mClave.ToString = ClaveClsTextBox.Text
    End Sub
End Class
