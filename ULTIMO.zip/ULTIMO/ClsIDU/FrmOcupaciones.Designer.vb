﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmOcupaciones
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IntIdOcupacionLabel As System.Windows.Forms.Label
        Dim StrdescripcionLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmOcupaciones))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TblOcupacionesDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TblOcupacionesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.IntIdOcupacionClsTextBox = New ClsUtilidades.ClsTextBox
        Me.StrdescripcionClsTextBox = New ClsUtilidades.ClsTextBox
        Me.TblOcupacionesBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.TblOcupacionesBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        IntIdOcupacionLabel = New System.Windows.Forms.Label
        StrdescripcionLabel = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblOcupacionesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblOcupacionesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblOcupacionesBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblOcupacionesBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntIdOcupacionLabel
        '
        IntIdOcupacionLabel.AutoSize = True
        IntIdOcupacionLabel.Location = New System.Drawing.Point(15, 23)
        IntIdOcupacionLabel.Name = "IntIdOcupacionLabel"
        IntIdOcupacionLabel.Size = New System.Drawing.Size(22, 13)
        IntIdOcupacionLabel.TabIndex = 0
        IntIdOcupacionLabel.Text = "Id :"
        '
        'StrdescripcionLabel
        '
        StrdescripcionLabel.AutoSize = True
        StrdescripcionLabel.Location = New System.Drawing.Point(15, 49)
        StrdescripcionLabel.Name = "StrdescripcionLabel"
        StrdescripcionLabel.Size = New System.Drawing.Size(66, 13)
        StrdescripcionLabel.TabIndex = 2
        StrdescripcionLabel.Text = "Descripcion:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(474, 238)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.Controls.Add(Me.TblOcupacionesDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(466, 212)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblOcupacionesDataGridView
        '
        Me.TblOcupacionesDataGridView.AllowUserToAddRows = False
        Me.TblOcupacionesDataGridView.AllowUserToDeleteRows = False
        Me.TblOcupacionesDataGridView.AutoGenerateColumns = False
        Me.TblOcupacionesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblOcupacionesDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.TblOcupacionesDataGridView.DataSource = Me.TblOcupacionesBindingSource
        Me.TblOcupacionesDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblOcupacionesDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblOcupacionesDataGridView.Name = "TblOcupacionesDataGridView"
        Me.TblOcupacionesDataGridView.ReadOnly = True
        Me.TblOcupacionesDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TblOcupacionesDataGridView.Size = New System.Drawing.Size(460, 206)
        Me.TblOcupacionesDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdOcupacion"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strdescripcion"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Descripción"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 320
        '
        'TblOcupacionesBindingSource
        '
        Me.TblOcupacionesBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblOcupaciones)
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(IntIdOcupacionLabel)
        Me.TabPage2.Controls.Add(Me.IntIdOcupacionClsTextBox)
        Me.TabPage2.Controls.Add(StrdescripcionLabel)
        Me.TabPage2.Controls.Add(Me.StrdescripcionClsTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(466, 212)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'IntIdOcupacionClsTextBox
        '
        Me.IntIdOcupacionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblOcupacionesBindingSource, "intIdOcupacion", True))
        Me.IntIdOcupacionClsTextBox.DataSource = Nothing
        Me.IntIdOcupacionClsTextBox.Enabled = False
        Me.IntIdOcupacionClsTextBox.Location = New System.Drawing.Point(81, 20)
        Me.IntIdOcupacionClsTextBox.Name = "IntIdOcupacionClsTextBox"
        Me.IntIdOcupacionClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdOcupacionClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdOcupacionClsTextBox.Size = New System.Drawing.Size(69, 20)
        Me.IntIdOcupacionClsTextBox.TabIndex = 1
        Me.IntIdOcupacionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrdescripcionClsTextBox
        '
        Me.StrdescripcionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblOcupacionesBindingSource, "strdescripcion", True))
        Me.StrdescripcionClsTextBox.DataSource = Nothing
        Me.StrdescripcionClsTextBox.Location = New System.Drawing.Point(81, 46)
        Me.StrdescripcionClsTextBox.Name = "StrdescripcionClsTextBox"
        Me.StrdescripcionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrdescripcionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrdescripcionClsTextBox.Size = New System.Drawing.Size(363, 20)
        Me.StrdescripcionClsTextBox.TabIndex = 3
        Me.StrdescripcionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblOcupacionesBindingNavigator
        '
        Me.TblOcupacionesBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblOcupacionesBindingNavigator.BindingSource = Me.TblOcupacionesBindingSource
        Me.TblOcupacionesBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblOcupacionesBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblOcupacionesBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblOcupacionesBindingNavigatorSaveItem})
        Me.TblOcupacionesBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblOcupacionesBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblOcupacionesBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblOcupacionesBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblOcupacionesBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblOcupacionesBindingNavigator.Name = "TblOcupacionesBindingNavigator"
        Me.TblOcupacionesBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblOcupacionesBindingNavigator.Size = New System.Drawing.Size(474, 25)
        Me.TblOcupacionesBindingNavigator.TabIndex = 1
        Me.TblOcupacionesBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(38, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblOcupacionesBindingNavigatorSaveItem
        '
        Me.TblOcupacionesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblOcupacionesBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblOcupacionesBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblOcupacionesBindingNavigatorSaveItem.Name = "TblOcupacionesBindingNavigatorSaveItem"
        Me.TblOcupacionesBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblOcupacionesBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'FrmOcupaciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(474, 263)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblOcupacionesBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmOcupaciones"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ocupaciones"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblOcupacionesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblOcupacionesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblOcupacionesBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblOcupacionesBindingNavigator.ResumeLayout(False)
        Me.TblOcupacionesBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TblOcupacionesDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblOcupacionesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblOcupacionesBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblOcupacionesBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdOcupacionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrdescripcionClsTextBox As ClsUtilidades.ClsTextBox
End Class
