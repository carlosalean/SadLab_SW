﻿Imports System.Windows.Forms

Public Class DialogAbrirCaja
    Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mstrStringConection As String
    Dim mstrIntIdUsuario As String
    Public mCaja As String
    Public mintIdCaja As Integer

    Sub New(ByVal strStringConection As String, ByVal strIntIdUsuario As String)

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        mstrStringConection = strStringConection
        mstrIntIdUsuario = strIntIdUsuario
        dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Try
            If ClsTextBoxValorBase.Text = Nothing Then
                MsgBox("Debe digitar un valor para la base")
                Exit Sub
            End If

            Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
            If mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK Then
                If dc.usp_AbrirCaja(ClsComboBoxCajas.SelectedValue, Convert.ToInt32(mstrIntIdUsuario), Convert.ToInt32(ClsTextBoxValorBase.Text)) = 0 Then
                    MsgBox("La caja ha sido abierta", MsgBoxStyle.Information, " ")
                    Me.DialogResult = System.Windows.Forms.DialogResult.OK
                    mCaja = ClsComboBoxCajas.SelectedItem().strNombreCaja
                    mintIdCaja = ClsComboBoxCajas.SelectedItem().intIdCajas
                End If
            Else
                MsgBox("No se pudo abrir la caja")
            End If
            Me.Close()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DialogAbrirCaja_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            Dim result = dc.usp_CajasCerradas()
            Dim mRes As New List(Of Object)

            For Each mR In result
                mRes.Add(mR)
            Next

            If mRes.Count = 0 Then
                MsgBox("No hay cajas para abrir", MsgBoxStyle.Information, " ")
                Me.Close()
            Else
                ClsComboBoxCajas.DataSource = mRes
                ClsComboBoxCajas.DisplayMember = "strNombreCaja"
                ClsComboBoxCajas.ValueMember = "intIdCajas"
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class
