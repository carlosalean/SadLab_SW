﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmVerHistoriaClinica
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DtmfechaLabel As System.Windows.Forms.Label
        Dim StrDescripcionMotivoLabel As System.Windows.Forms.Label
        Dim StrDescripcionEnfermedadLabel As System.Windows.Forms.Label
        Dim IntVisitaNroLabel As System.Windows.Forms.Label
        Dim IntIdMotivoConsultaHCLabel As System.Windows.Forms.Label
        Dim IntIdHCLabel As System.Windows.Forms.Label
        Dim IntIdMotivoConsultaLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmVerHistoriaClinica))
        Me.IntIdHCTextBox = New System.Windows.Forms.TextBox()
        Me.TblMotivosConsultaHCBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DtmfechaDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.btnFinalizar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TblMotivosConsultaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntVisitaNroClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.NroDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DtmFechaDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BindingSourceVisitas = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdMotivoConsultaHCTextBox = New System.Windows.Forms.TextBox()
        Me.btnSiguiente = New System.Windows.Forms.Button()
        Me.IntIdMotivoConsultaClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.btnAnterior = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DtmFechaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrDescripcionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdMotivoConsultaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BindingSourceCasosPaciente = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.StrDescripcionEnfermedadClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.StrDescripcionMotivoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.PanelMotivosConsulta = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        DtmfechaLabel = New System.Windows.Forms.Label()
        StrDescripcionMotivoLabel = New System.Windows.Forms.Label()
        StrDescripcionEnfermedadLabel = New System.Windows.Forms.Label()
        IntVisitaNroLabel = New System.Windows.Forms.Label()
        IntIdMotivoConsultaHCLabel = New System.Windows.Forms.Label()
        IntIdHCLabel = New System.Windows.Forms.Label()
        IntIdMotivoConsultaLabel = New System.Windows.Forms.Label()
        CType(Me.TblMotivosConsultaHCBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSourceVisitas, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSourceCasosPaciente, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.PanelMotivosConsulta.SuspendLayout()
        Me.SuspendLayout()
        '
        'DtmfechaLabel
        '
        DtmfechaLabel.AutoSize = True
        DtmfechaLabel.Location = New System.Drawing.Point(8, 17)
        DtmfechaLabel.Name = "DtmfechaLabel"
        DtmfechaLabel.Size = New System.Drawing.Size(110, 13)
        DtmfechaLabel.TabIndex = 0
        DtmfechaLabel.Text = "Fecha de evaluación:"
        '
        'StrDescripcionMotivoLabel
        '
        StrDescripcionMotivoLabel.AutoSize = True
        StrDescripcionMotivoLabel.Location = New System.Drawing.Point(8, 78)
        StrDescripcionMotivoLabel.Name = "StrDescripcionMotivoLabel"
        StrDescripcionMotivoLabel.Size = New System.Drawing.Size(177, 13)
        StrDescripcionMotivoLabel.TabIndex = 12
        StrDescripcionMotivoLabel.Text = "Descripción del Motivo de Consulta:"
        '
        'StrDescripcionEnfermedadLabel
        '
        StrDescripcionEnfermedadLabel.AutoSize = True
        StrDescripcionEnfermedadLabel.Location = New System.Drawing.Point(8, 198)
        StrDescripcionEnfermedadLabel.Name = "StrDescripcionEnfermedadLabel"
        StrDescripcionEnfermedadLabel.Size = New System.Drawing.Size(159, 13)
        StrDescripcionEnfermedadLabel.TabIndex = 10
        StrDescripcionEnfermedadLabel.Text = "Descripción Enfermedad Actual:"
        '
        'IntVisitaNroLabel
        '
        IntVisitaNroLabel.AutoSize = True
        IntVisitaNroLabel.Location = New System.Drawing.Point(315, 16)
        IntVisitaNroLabel.Name = "IntVisitaNroLabel"
        IntVisitaNroLabel.Size = New System.Drawing.Size(35, 13)
        IntVisitaNroLabel.TabIndex = 8
        IntVisitaNroLabel.Text = "Visita:"
        '
        'IntIdMotivoConsultaHCLabel
        '
        IntIdMotivoConsultaHCLabel.AutoSize = True
        IntIdMotivoConsultaHCLabel.Location = New System.Drawing.Point(246, 70)
        IntIdMotivoConsultaHCLabel.Name = "IntIdMotivoConsultaHCLabel"
        IntIdMotivoConsultaHCLabel.Size = New System.Drawing.Size(130, 13)
        IntIdMotivoConsultaHCLabel.TabIndex = 6
        IntIdMotivoConsultaHCLabel.Text = "int Id Motivo Consulta HC:"
        IntIdMotivoConsultaHCLabel.Visible = False
        '
        'IntIdHCLabel
        '
        IntIdHCLabel.AutoSize = True
        IntIdHCLabel.Location = New System.Drawing.Point(456, 70)
        IntIdHCLabel.Name = "IntIdHCLabel"
        IntIdHCLabel.Size = New System.Drawing.Size(51, 13)
        IntIdHCLabel.TabIndex = 2
        IntIdHCLabel.Text = "int Id HC:"
        IntIdHCLabel.Visible = False
        '
        'IntIdMotivoConsultaLabel
        '
        IntIdMotivoConsultaLabel.AutoSize = True
        IntIdMotivoConsultaLabel.Location = New System.Drawing.Point(8, 44)
        IntIdMotivoConsultaLabel.Name = "IntIdMotivoConsultaLabel"
        IntIdMotivoConsultaLabel.Size = New System.Drawing.Size(143, 13)
        IntIdMotivoConsultaLabel.TabIndex = 4
        IntIdMotivoConsultaLabel.Text = "Motivo de consulta Principal:"
        '
        'IntIdHCTextBox
        '
        Me.IntIdHCTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMotivosConsultaHCBindingSource, "intIdHC", True))
        Me.IntIdHCTextBox.Location = New System.Drawing.Point(513, 67)
        Me.IntIdHCTextBox.Name = "IntIdHCTextBox"
        Me.IntIdHCTextBox.Size = New System.Drawing.Size(58, 20)
        Me.IntIdHCTextBox.TabIndex = 3
        Me.IntIdHCTextBox.Visible = False
        '
        'TblMotivosConsultaHCBindingSource
        '
        Me.TblMotivosConsultaHCBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblMotivosConsultaHC)
        '
        'DtmfechaDateTimePicker
        '
        Me.DtmfechaDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblMotivosConsultaHCBindingSource, "dtmfecha", True))
        Me.DtmfechaDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmfechaDateTimePicker.Location = New System.Drawing.Point(157, 13)
        Me.DtmfechaDateTimePicker.Name = "DtmfechaDateTimePicker"
        Me.DtmfechaDateTimePicker.Size = New System.Drawing.Size(88, 20)
        Me.DtmfechaDateTimePicker.TabIndex = 1
        '
        'btnFinalizar
        '
        Me.btnFinalizar.Location = New System.Drawing.Point(339, 13)
        Me.btnFinalizar.Name = "btnFinalizar"
        Me.btnFinalizar.Size = New System.Drawing.Size(75, 23)
        Me.btnFinalizar.TabIndex = 2
        Me.btnFinalizar.Text = "Finalizar"
        Me.btnFinalizar.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(101, 13)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Casos del Paciente:"
        '
        'TblMotivosConsultaBindingSource
        '
        Me.TblMotivosConsultaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblMotivosConsulta)
        Me.TblMotivosConsultaBindingSource.Sort = "strDescripcion"
        '
        'IntVisitaNroClsTextBox
        '
        Me.IntVisitaNroClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMotivosConsultaHCBindingSource, "intVisitaNro", True))
        Me.IntVisitaNroClsTextBox.DataSource = Nothing
        Me.IntVisitaNroClsTextBox.EnterEntreCampos = True
        Me.IntVisitaNroClsTextBox.Location = New System.Drawing.Point(356, 12)
        Me.IntVisitaNroClsTextBox.Name = "IntVisitaNroClsTextBox"
        Me.IntVisitaNroClsTextBox.NombreCodigoF2 = Nothing
        Me.IntVisitaNroClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntVisitaNroClsTextBox.Size = New System.Drawing.Size(46, 20)
        Me.IntVisitaNroClsTextBox.TabIndex = 9
        Me.IntVisitaNroClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.AutoGenerateColumns = False
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NroDataGridViewTextBoxColumn, Me.DtmFechaDataGridViewTextBoxColumn1})
        Me.DataGridView2.DataSource = Me.BindingSourceVisitas
        Me.DataGridView2.Location = New System.Drawing.Point(523, 30)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        Me.DataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridView2.Size = New System.Drawing.Size(296, 113)
        Me.DataGridView2.TabIndex = 11
        '
        'NroDataGridViewTextBoxColumn
        '
        Me.NroDataGridViewTextBoxColumn.DataPropertyName = "nro"
        Me.NroDataGridViewTextBoxColumn.HeaderText = "Número Visita"
        Me.NroDataGridViewTextBoxColumn.Name = "NroDataGridViewTextBoxColumn"
        Me.NroDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DtmFechaDataGridViewTextBoxColumn1
        '
        Me.DtmFechaDataGridViewTextBoxColumn1.DataPropertyName = "dtmFecha"
        Me.DtmFechaDataGridViewTextBoxColumn1.HeaderText = "Fecha"
        Me.DtmFechaDataGridViewTextBoxColumn1.Name = "DtmFechaDataGridViewTextBoxColumn1"
        Me.DtmFechaDataGridViewTextBoxColumn1.ReadOnly = True
        Me.DtmFechaDataGridViewTextBoxColumn1.Width = 150
        '
        'BindingSourceVisitas
        '
        Me.BindingSourceVisitas.DataSource = GetType(ClsBaseDatos_SadLab.usp_ConsultarNroVisitasCasosResult)
        '
        'IntIdMotivoConsultaHCTextBox
        '
        Me.IntIdMotivoConsultaHCTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMotivosConsultaHCBindingSource, "intIdMotivoConsultaHC", True))
        Me.IntIdMotivoConsultaHCTextBox.Location = New System.Drawing.Point(382, 67)
        Me.IntIdMotivoConsultaHCTextBox.Name = "IntIdMotivoConsultaHCTextBox"
        Me.IntIdMotivoConsultaHCTextBox.Size = New System.Drawing.Size(56, 20)
        Me.IntIdMotivoConsultaHCTextBox.TabIndex = 7
        Me.IntIdMotivoConsultaHCTextBox.Visible = False
        '
        'btnSiguiente
        '
        Me.btnSiguiente.Location = New System.Drawing.Point(258, 13)
        Me.btnSiguiente.Name = "btnSiguiente"
        Me.btnSiguiente.Size = New System.Drawing.Size(75, 23)
        Me.btnSiguiente.TabIndex = 1
        Me.btnSiguiente.Text = "Siguiente>>"
        Me.btnSiguiente.UseVisualStyleBackColor = True
        '
        'IntIdMotivoConsultaClsComboBox
        '
        Me.IntIdMotivoConsultaClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMotivosConsultaHCBindingSource, "intIdMotivoConsulta", True))
        Me.IntIdMotivoConsultaClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblMotivosConsultaHCBindingSource, "intIdMotivoConsulta", True))
        Me.IntIdMotivoConsultaClsComboBox.DataSource = Me.TblMotivosConsultaBindingSource
        Me.IntIdMotivoConsultaClsComboBox.DisplayMember = "strDescripcion"
        Me.IntIdMotivoConsultaClsComboBox.FormattingEnabled = True
        Me.IntIdMotivoConsultaClsComboBox.Location = New System.Drawing.Point(157, 41)
        Me.IntIdMotivoConsultaClsComboBox.Name = "IntIdMotivoConsultaClsComboBox"
        Me.IntIdMotivoConsultaClsComboBox.Size = New System.Drawing.Size(245, 21)
        Me.IntIdMotivoConsultaClsComboBox.TabIndex = 5
        Me.IntIdMotivoConsultaClsComboBox.ValueMember = "intIdMotivoConsulta"
        '
        'btnAnterior
        '
        Me.btnAnterior.Location = New System.Drawing.Point(177, 13)
        Me.btnAnterior.Name = "btnAnterior"
        Me.btnAnterior.Size = New System.Drawing.Size(75, 23)
        Me.btnAnterior.TabIndex = 0
        Me.btnAnterior.Text = "<<Anterior"
        Me.btnAnterior.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DtmFechaDataGridViewTextBoxColumn, Me.StrDescripcionDataGridViewTextBoxColumn, Me.IntIdMotivoConsultaDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.BindingSourceCasosPaciente
        Me.DataGridView1.Location = New System.Drawing.Point(13, 30)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DataGridView1.Size = New System.Drawing.Size(495, 113)
        Me.DataGridView1.TabIndex = 10
        '
        'DtmFechaDataGridViewTextBoxColumn
        '
        Me.DtmFechaDataGridViewTextBoxColumn.DataPropertyName = "dtmFecha"
        Me.DtmFechaDataGridViewTextBoxColumn.HeaderText = "Fecha"
        Me.DtmFechaDataGridViewTextBoxColumn.Name = "DtmFechaDataGridViewTextBoxColumn"
        Me.DtmFechaDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StrDescripcionDataGridViewTextBoxColumn
        '
        Me.StrDescripcionDataGridViewTextBoxColumn.DataPropertyName = "strDescripcion"
        Me.StrDescripcionDataGridViewTextBoxColumn.HeaderText = "Descripción"
        Me.StrDescripcionDataGridViewTextBoxColumn.Name = "StrDescripcionDataGridViewTextBoxColumn"
        Me.StrDescripcionDataGridViewTextBoxColumn.ReadOnly = True
        Me.StrDescripcionDataGridViewTextBoxColumn.Width = 350
        '
        'IntIdMotivoConsultaDataGridViewTextBoxColumn
        '
        Me.IntIdMotivoConsultaDataGridViewTextBoxColumn.DataPropertyName = "intIdMotivoConsulta"
        Me.IntIdMotivoConsultaDataGridViewTextBoxColumn.HeaderText = "Id Motivo Consulta"
        Me.IntIdMotivoConsultaDataGridViewTextBoxColumn.Name = "IntIdMotivoConsultaDataGridViewTextBoxColumn"
        Me.IntIdMotivoConsultaDataGridViewTextBoxColumn.ReadOnly = True
        Me.IntIdMotivoConsultaDataGridViewTextBoxColumn.Visible = False
        Me.IntIdMotivoConsultaDataGridViewTextBoxColumn.Width = 120
        '
        'BindingSourceCasosPaciente
        '
        Me.BindingSourceCasosPaciente.DataSource = GetType(ClsBaseDatos_SadLab.usp_ConsultarCasosDelPacienteResult)
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.btnFinalizar)
        Me.Panel3.Controls.Add(Me.btnSiguiente)
        Me.Panel3.Controls.Add(Me.btnAnterior)
        Me.Panel3.Location = New System.Drawing.Point(197, 473)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(622, 53)
        Me.Panel3.TabIndex = 9
        '
        'StrDescripcionEnfermedadClsTextBox
        '
        Me.StrDescripcionEnfermedadClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMotivosConsultaHCBindingSource, "strDescripcionEnfermedad", True))
        Me.StrDescripcionEnfermedadClsTextBox.DataSource = Nothing
        Me.StrDescripcionEnfermedadClsTextBox.EnterEntreCampos = True
        Me.StrDescripcionEnfermedadClsTextBox.Location = New System.Drawing.Point(11, 213)
        Me.StrDescripcionEnfermedadClsTextBox.Multiline = True
        Me.StrDescripcionEnfermedadClsTextBox.Name = "StrDescripcionEnfermedadClsTextBox"
        Me.StrDescripcionEnfermedadClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcionEnfermedadClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcionEnfermedadClsTextBox.Size = New System.Drawing.Size(599, 96)
        Me.StrDescripcionEnfermedadClsTextBox.TabIndex = 11
        Me.StrDescripcionEnfermedadClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Button11)
        Me.Panel1.Controls.Add(Me.Button10)
        Me.Panel1.Controls.Add(Me.Button9)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Location = New System.Drawing.Point(13, 149)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(184, 378)
        Me.Panel1.TabIndex = 7
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(3, 300)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(174, 23)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "Evolución"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(5, 271)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(174, 23)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "Tratamiento"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(5, 242)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(174, 23)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "Diagnóstico y Conducta"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(5, 213)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(174, 23)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "Examenes Paracíclicos"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(5, 184)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(174, 23)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "Examen Físico"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(5, 155)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(174, 23)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "Hábitos"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(5, 126)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(174, 23)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Antecedentes Socio-Económico"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(5, 97)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(174, 23)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Antecedentes Gineco Obstétricos"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(5, 68)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(174, 23)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Antecedentes Familiares"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(5, 39)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(174, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Revisión de Sistemas"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(5, 10)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(174, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Motivos de Consulta"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'StrDescripcionMotivoClsTextBox
        '
        Me.StrDescripcionMotivoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMotivosConsultaHCBindingSource, "strDescripcionMotivo", True))
        Me.StrDescripcionMotivoClsTextBox.DataSource = Nothing
        Me.StrDescripcionMotivoClsTextBox.EnterEntreCampos = True
        Me.StrDescripcionMotivoClsTextBox.Location = New System.Drawing.Point(11, 93)
        Me.StrDescripcionMotivoClsTextBox.Multiline = True
        Me.StrDescripcionMotivoClsTextBox.Name = "StrDescripcionMotivoClsTextBox"
        Me.StrDescripcionMotivoClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcionMotivoClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcionMotivoClsTextBox.Size = New System.Drawing.Size(599, 102)
        Me.StrDescripcionMotivoClsTextBox.TabIndex = 13
        Me.StrDescripcionMotivoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'PanelMotivosConsulta
        '
        Me.PanelMotivosConsulta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelMotivosConsulta.Controls.Add(StrDescripcionMotivoLabel)
        Me.PanelMotivosConsulta.Controls.Add(Me.StrDescripcionMotivoClsTextBox)
        Me.PanelMotivosConsulta.Controls.Add(StrDescripcionEnfermedadLabel)
        Me.PanelMotivosConsulta.Controls.Add(Me.StrDescripcionEnfermedadClsTextBox)
        Me.PanelMotivosConsulta.Controls.Add(IntVisitaNroLabel)
        Me.PanelMotivosConsulta.Controls.Add(Me.IntVisitaNroClsTextBox)
        Me.PanelMotivosConsulta.Controls.Add(IntIdMotivoConsultaHCLabel)
        Me.PanelMotivosConsulta.Controls.Add(Me.IntIdMotivoConsultaHCTextBox)
        Me.PanelMotivosConsulta.Controls.Add(IntIdMotivoConsultaLabel)
        Me.PanelMotivosConsulta.Controls.Add(Me.IntIdMotivoConsultaClsComboBox)
        Me.PanelMotivosConsulta.Controls.Add(IntIdHCLabel)
        Me.PanelMotivosConsulta.Controls.Add(Me.IntIdHCTextBox)
        Me.PanelMotivosConsulta.Controls.Add(DtmfechaLabel)
        Me.PanelMotivosConsulta.Controls.Add(Me.DtmfechaDateTimePicker)
        Me.PanelMotivosConsulta.Location = New System.Drawing.Point(197, 149)
        Me.PanelMotivosConsulta.Name = "PanelMotivosConsulta"
        Me.PanelMotivosConsulta.Size = New System.Drawing.Size(622, 324)
        Me.PanelMotivosConsulta.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(523, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Visitas del Caso"
        '
        'FrmVerHistoriaClinica
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(833, 539)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelMotivosConsulta)
        Me.Controls.Add(Me.Label2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmVerHistoriaClinica"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ver Historia Clínica"
        CType(Me.TblMotivosConsultaHCBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSourceVisitas, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSourceCasosPaciente, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.PanelMotivosConsulta.ResumeLayout(False)
        Me.PanelMotivosConsulta.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents IntIdHCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TblMotivosConsultaHCBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DtmfechaDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnFinalizar As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TblMotivosConsultaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents IntVisitaNroClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents NroDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DtmFechaDataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BindingSourceVisitas As System.Windows.Forms.BindingSource
    Friend WithEvents IntIdMotivoConsultaHCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents btnSiguiente As System.Windows.Forms.Button
    Friend WithEvents IntIdMotivoConsultaClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents btnAnterior As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DtmFechaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrDescripcionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdMotivoConsultaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BindingSourceCasosPaciente As System.Windows.Forms.BindingSource
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents StrDescripcionEnfermedadClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents StrDescripcionMotivoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents PanelMotivosConsulta As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
