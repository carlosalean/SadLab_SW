﻿Imports System.Windows.Forms
Imports ClsReportes

Public Class FrmRegistrarLlegadaCita
    Dim mstrStringConection As String
    Dim DataContext As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mstrIntIdUsuario As Integer
    Dim mintIdCaja As Integer
    Private Templates(3) As DPFP.Template
    Dim ver As New DPFP.Verification.Verification()
    Dim res As New DPFP.Verification.Verification.Result()
    Dim mCita
    Dim mIntIdPrestador As Integer

    Sub New(ByVal strStringConection As String, ByVal pstrIntIdUsuario As Integer, ByVal intIdCaja As Integer)
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            mstrStringConection = strStringConection
            mstrIntIdUsuario = pstrIntIdUsuario
            mintIdCaja = intIdCaja
            DataContext = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmRegistrarLlegadaCita_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            'DataContext = dc
            'TblCitaBindingSource.DataSource = dc.tblCitas
            TblEmpeadoBindingSource.DataSource = DataContext.tblEmpeados

            'Dim tmpPacientes = (From p In dc.tblPacientes _
            '        Select p.strNroIdentificacion, _
            '        strPrimerNombre = p.strPrimerNombre & " " & p.strSegundoNombre & " " & p.strPrimerApellido & " " & p.strSegundoApellido)

            'TblPacienteBindingSource.DataSource = tmpPacientes

            'Dim CitaCancelada = (From p In dc.tblPagos _
            '                            Join c In dc.tblCitas On p.intIdCita Equals c.intIdCita _
            '                            Select c.intIdCita).Count

            'If CitaCancelada = Nothing Then
            '    btnPago.Enabled = True
            'Else
            '    btnPago.Enabled = False
            'End If

            If (mintIdCaja = Nothing) Then
                btnPago.Enabled = False
            Else
                btnPago.Enabled = True
            End If

            TblProcedimientoBindingSource.DataSource = DataContext.tblProcedimiento
            Dim Estado = (From p In DataContext.tblTipos _
                Where p.strTipo = "ESTADO_CITA" Select p)

            TblTipoBindingSource.DataSource = Estado
            TextBoxNombre.Text = ""
            IntIdProcedimientoComboBox.SelectedIndex = -1
            IntIdProfesionalComboBox.SelectedIndex = -1
            IntIdEstadoCitaComboBox.SelectedIndex = -1
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub StrNroIdPacienteTextBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrNroIdPacienteTextBox.Leave
        Try
            'Dim dc2 = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim mNroId As String = StrNroIdPacienteTextBox.Text
            Dim mNombre
            Dim mEstado As Integer
            Dim mEstadoConfirmada As Integer

            'DataContext = dc2
            mNombre = (From p In DataContext.tblPacientes Where _
                                  p.strNroIdentificacion = mNroId Select p.strPrimerNombre & " " & IIf(p.strSegundoNombre Is Nothing, "", p.strSegundoNombre) & " " & p.strPrimerApellido & " " & IIf(p.strSegundoApellido Is Nothing, "", p.strSegundoApellido)).Single
            TextBoxNombre.Text = mNombre.ToString
            mEstado = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Asignada").ReturnValue
            mEstadoConfirmada = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Confirmada").ReturnValue

            mCita = (From c In DataContext.tblCita Where c.strNroIdPaciente = mNroId _
                         And (c.intIdEstadoCita = mEstado Or c.intIdEstadoCita = mEstadoConfirmada Or c.intIdEstadoCita Is Nothing) _
                         And c.dtmFecha = Now.Date Select c)
            If mCita Is Nothing Then
                MsgBox("No tiene citas pendientes..", MsgBoxStyle.Information)
            Else
                TblCitaBindingSource.DataSource = mCita
                TblCitaBindingSource.Position = 0
                Dim mTemplate
                Dim bytes As Byte() = Nothing

                TblCitaBindingSource.Position = 0
                mTemplate = (From p In DataContext.tblPacientes Where p.strNroIdentificacion = mNroId Select p.byTemplate1).Single
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(0) = New DPFP.Template()
                    Templates(0).DeSerialize(bytes)
                End If

                mTemplate = (From p In DataContext.tblPacientes Where p.strNroIdentificacion = mNroId Select p.byTemplate2).Single
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(1) = New DPFP.Template()
                    Templates(1).DeSerialize(bytes)
                End If

                mTemplate = (From p In DataContext.tblPacientes Where p.strNroIdentificacion = mNroId Select p.byTemplate3).Single
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(2) = New DPFP.Template()
                    Templates(2).DeSerialize(bytes)
                End If

                mTemplate = (From p In DataContext.tblPacientes Where p.strNroIdentificacion = mNroId Select p.byTemplate4).Single
                If Not mTemplate Is Nothing Then
                    bytes = mTemplate.ToArray()
                    Templates(3) = New DPFP.Template()
                    Templates(3).DeSerialize(bytes)
                End If

            End If

        Catch ex As Exception
            'TextBoxNombre.Text = ""
            'StrNroIdPacienteTextBox.Text = ""
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblCitaBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblCitaBindingNavigatorSaveItem.Click
        Try
            Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
            If (res.Verified Or NoRegistraHuellaCheckBox.Checked) Then
                'If (StrNroOrdenTextBox.Text.Count = 0) Then
                'MsgBox("Se debe ingresar el número de la Orden, Si no tiene Orden debe poner 9999", MsgBoxStyle.Information)

                'Exit Sub
                'Else
                TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNroOrden = StrNroOrdenTextBox.Text
                'End If
                If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then

                    If NumValorCoopagoTextBox.TextLength > 0 Then
                        If IsNumeric(NumValorCoopagoTextBox.Text) Then
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).numValorCoopago = CType(NumValorCoopagoTextBox.Text, Integer)
                        End If
                        ''Se modifica para que permita grabar la llegada de los pacientes que no paguen copago - Oscar Tabares 2015-07-08
                        'Else
                        'If NumValorCoopagoTextBox.TextLength = 0 Then
                        'MsgBox("Debe ingresar el valor del copago", MsgBoxStyle.Information)
                        'Exit Sub
                        'End If
                    End If

                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmFechaHoraLlegaCita = Now
                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdUsuarioIngresa = mValidaHuella.mstrIntIdUsuario
                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Esperando").ReturnValue
                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNroOrden = StrNroOrdenTextBox.Text
                    If Not IsDBNull(mIntIdPrestador) And mIntIdPrestador > 0 Then
                        TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdPrestador = mIntIdPrestador
                    End If

                    TblCitaBindingSource.EndEdit()
                    DataContext.SubmitChanges()
                    NoRegistraHuellaCheckBox.Enabled = False
                    MsgBox("Los datos han sido actualizados", MsgBoxStyle.Information)
                Else
                    MsgBox("No se actualizaron los datos", MsgBoxStyle.Information)
                End If
            Else
                MsgBox("El paciente debe validarse con su huella dactilar..", MsgBoxStyle.Information)
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Sub OnComplete(ByVal Control As Object, ByVal FeatureSet As DPFP.FeatureSet, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles VerificationControl.OnComplete

        For Each template As DPFP.Template In Templates    ' Compare feature set with all stored templates:
            If Not template Is Nothing Then                     '   Get template from storage.
                ver.Verify(FeatureSet, template, res)           '   Compare feature set with particular template.
                'Data.IsFeatureSetMatched = res.Verified         '   Check the result of the comparison
                'Data.FalseAcceptRate = res.FARAchieved          '   Determine the current False Accept Rate
                If res.Verified Then
                    EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Success
                    Exit For ' success
                End If
            End If
        Next
        If Not res.Verified Then EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Failure
        'Data.Update()
    End Sub

    Private Sub btnPago_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPago.Click

        Try
            'Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            'DataContext = dc

            If IntIdCitaTextBox.TextLength = 0 Then
                MsgBox("No ha seleccionado la llegada de un paciente")
                Exit Sub
            End If

            If Windows.Forms.Application.OpenForms("DialogPago") Is Nothing Then

                Dim mDialogPago As New ClsIDU.DialogPago(mstrStringConection, mstrIntIdUsuario, TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProfesional)
                Dim mPago = (From p In DataContext.tblPagos _
                                 Where p.intIdCita = CType(IntIdCitaTextBox.Text, Integer) _
                                 Select p.intIdPrestadores, p.numValorPagado, p.numEfectivo, p.numDevuelta, p.bitEsCoopago)

                If mPago.LongCount() > 0 Then

                    Dim mRes As New List(Of Object)
                    For Each mR In mPago
                        mRes.Add(mR)
                    Next

                    mDialogPago.ClsTextBoxValorPagado.Text = mRes.Item(0).numValorPagado
                    mDialogPago.ClsTextBoxEfectivo.Text = mRes.Item(0).numEfectivo
                    mDialogPago.ClsTextBoxDevuelta.Text = mRes.Item(0).numDevuelta
                    mDialogPago.ClsComboBoxPrestador.SelectedValue = mRes.Item(0).intIdPrestadores
                    mDialogPago.ClsCheckBoxCoopago.Checked = mRes.Item(0).bitEsCoopago
                    mIntIdPrestador = mRes.Item(0).intIdPrestadores


                    mDialogPago.ClsTextBoxValorPagado.Enabled = False
                    mDialogPago.ClsTextBoxEfectivo.Enabled = False
                    mDialogPago.ClsTextBoxDevuelta.Enabled = False
                    mDialogPago.ClsComboBoxPrestador.Enabled = False
                    mDialogPago.ClsCheckBoxCoopago.Enabled = False

                    'mDialogPago.ClsTextBoxValorPagado.Text = mPago.numValorPagado
                    'mDialogPago.ClsTextBoxEfectivo.Text = mPago.numEfectivo
                    'mDialogPago.ClsTextBoxDevuelta.Text = mPago.numDevuelta
                    'mDialogPago.ClsComboBoxPrestador.SelectedValue = mPago.intIdPrestadores

                End If

                If mDialogPago.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    Dim mintIdCuadre = (From P In DataContext.tblCajas Where P.intIdCajas = mintIdCaja Select P.intIdCuadre).Single

                    If DataContext.usp_GuardarPago(mintIdCuadre, mDialogPago.ClsCheckBoxCoopago.Checked, mDialogPago.mValorPagado, mDialogPago.mValorEfectivo, mDialogPago.mValorDevuelto, mDialogPago.mPrestadorServicio, CType(IntIdCitaTextBox.Text, Integer), Convert.ToInt32(mstrIntIdUsuario), CType(mDialogPago.cmbMedioPago.SelectedValue, Integer)) = 0 Then

                        mIntIdPrestador = mDialogPago.mPrestadorServicio

                        MsgBox("El pago ha sido guardado")
                        If MsgBox("Desea Imprimir la Factura..?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                            If Application.OpenForms("FrmFacturaMediaCarta") Is Nothing Then
                                Dim mFrmFacturaMediaCarta As New ClsReportes.FrmFacturaMediaCarta(mstrStringConection, CType(IntIdCitaTextBox.Text, Integer))
                                mFrmFacturaMediaCarta.Show()
                            Else
                                Application.OpenForms("FrmFacturaMediaCarta").BringToFront()
                            End If
                        End If

                        If mDialogPago.ClsCheckBoxCoopago.Checked Then
                            TblCitaBindingSource.Item(TblCitaBindingSource.Position).NumValorCoopago = mDialogPago.mValorPagado
                        End If
                    End If
                End If

            Else
                Windows.Forms.Application.OpenForms("DialogPago").BringToFront()
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub btnHabilitarCoopago_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHabilitarCoopago.Click
        Try
            Dim mClaveIngreso
            Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
            If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then

                Dim mDlgClaveSuperUsuario As New DlgClaveSuperUsuario()
                If mDlgClaveSuperUsuario.ShowDialog = Windows.Forms.DialogResult.OK Then
                    Dim mClaveSuper = DataContext.usp_ClaveSuperUsuario(mValidaHuella.mstrIntIdUsuario)
                    mClaveIngreso = mDlgClaveSuperUsuario.strClave
                    If mClaveSuper(0).strClaveSuperUsuario = mClaveIngreso Then
                        NoRegistraHuellaCheckBox.Enabled = True
                    Else
                        MsgBox("La clave es incorrecta..")
                    End If
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class