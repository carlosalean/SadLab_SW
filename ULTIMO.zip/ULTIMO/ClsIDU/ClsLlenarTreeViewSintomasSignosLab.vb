﻿Imports System.Windows.Forms

Public Class ClsLlenarTreeViewSintomasSignosLab
    Public Sub PrllenarTreeView(ByVal Index As Integer, ByVal dc As Object, ByVal TreeView As TreeView)
        Try
            'Dim mRes As New List(Of Object)
            Dim mConsulta = dc.usp_ConsultarSintomasSignosLab(Index)
            For Each mR In mConsulta
                Dim nuevoNodo As New TreeNode
                nuevoNodo.Text = mR.strDescripcion
                nuevoNodo.Name = mR.intIdSintomasSignosLaboratorios
                nuevoNodo.Tag = "P"
                PrLlenarHijos(mR, nuevoNodo, dc, Index)
                TreeView.Nodes.Add(nuevoNodo)
            Next
            'CrearNodosDelPadre(0, Nothing)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub PrLlenarHijos(ByVal mHijo As Object, ByRef mNodoPadre As TreeNode, ByVal dc As Object, ByVal Index As Integer)
        Try
            Dim mConsulta = dc.usp_ConsultarSintomasSignosLabHijos(Index, mHijo.intIdSintomasSignosLaboratorios)
            For Each mR In mConsulta
                Dim nuevoNodo As New TreeNode
                nuevoNodo.Text = mR.strDescripcion
                nuevoNodo.Name = mR.intIdSintomasSignosLaboratorios
                nuevoNodo.Tag = mR.intID
                If mR.intTipoDato Is Nothing Or mR.intTipoDato = -1 Then
                    nuevoNodo.ImageIndex = 0
                    nuevoNodo.SelectedImageIndex = 0
                Else
                    nuevoNodo.ImageIndex = 1
                    nuevoNodo.SelectedImageIndex = 1
                End If
                PrLlenarHijos(mR, nuevoNodo, dc, Index)
                mNodoPadre.Nodes.Add(nuevoNodo)
            Next
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

End Class
