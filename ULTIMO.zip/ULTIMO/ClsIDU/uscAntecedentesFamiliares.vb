﻿Imports System.Windows.Forms

Public Class uscAntecedentesFamiliares
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mIdentificacion As String
    Private _btn As Windows.Forms.Button
    Private mclsUtilidadesHC As clsUtilidadesHC
    Private _IdUsuario As String
    Private mguardar As Boolean
    Private _ModoTexto As Boolean

    Public Sub New()

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mIdentificacion() As String
        Get
            Return _mIdentificacion
        End Get
        Set(ByVal value As String)
            _mIdentificacion = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub cargarDatosTabAF()
        Try
            Dim mconsulta = (From p In dc.tblAntecedentesFamiliaresHC Where p.strNroIdentificacion = mIdentificacion Select p.bitModoTexto, p.strHCtexto)
            If mconsulta.Count > 0 Then
                For Each c In mconsulta
                    If c.bitModoTexto = True Then
                        StrHCtextoClsTextBoxAF.Dock = DockStyle.Fill
                        StrHCtextoClsTextBoxAF.BringToFront()
                        StrHCtextoClsTextBoxAF.Multiline = True
                        StrHCtextoClsTextBoxAF.Visible = True
                        prCargarDatosAntecedentesFamiliares()
                    Else
                        prCargarDatosAntecedentesFamiliares()
                        Exit For
                    End If
                Next
            Else
                mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
                If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
                    StrHCtextoClsTextBoxAF.Dock = DockStyle.Fill
                    StrHCtextoClsTextBoxAF.BringToFront()
                    StrHCtextoClsTextBoxAF.Multiline = True
                    StrHCtextoClsTextBoxAF.Visible = True
                    prCargarDatosAntecedentesFamiliares()
                Else
                    prCargarDatosAntecedentesFamiliares()
                End If
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub prCargarDatosAntecedentesFamiliares()
        Try
            TblDisgnosticoBindingSource.DataSource = dc.tblDisgnostico
            Dim mconsultaTipo = (From t In dc.tblTipos Where t.strTipo = "PARENTEZCO" Select t)
            TblTipoBindingSource.DataSource = mconsultaTipo
            Dim mconsultaAntFam = (From f In dc.tblAntecedentesFamiliaresHC Where f.strNroIdentificacion = mIdentificacion Select f)
            TblAntecedentesFamiliaresBindingSource.DataSource = mconsultaAntFam
            If mconsultaAntFam.Count = 0 Then
                Panel1.Enabled = False
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblAntecedentesFamiliaresBindingSource_AddingNew(ByVal sender As System.Object, ByVal e As System.ComponentModel.AddingNewEventArgs) Handles TblAntecedentesFamiliaresBindingSource.AddingNew
        'Try
        '    If sender.Position.ToString >= 0 Then
        '        sender.Item(sender.Position).dtmFecha = FormatDateTime(Now, DateFormat.ShortDate)
        '    End If
        'Catch ex As Exception
        '    ClsError.ClsError.PrMostrarError(ex)
        'End Try
    End Sub

    Private Sub TblAntecedentesFamiliaresHCDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs)
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TblEPBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblEPBindingNavigatorSaveItem.Click
        prGuardar()
    End Sub

    Private Sub uscAntecedentesFamiliares_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        prGuardar()
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        mguardar = True
        Panel1.Enabled = True
    End Sub

    Public Sub prGuardar() Implements IAbandonarUC.prGuardar
        Try
            If mguardar = True Then
                TblAntecedentesFamiliaresBindingSource.Item(TblAntecedentesFamiliaresBindingSource.Position).StrHCtexto = StrHCtextoClsTextBoxAF.Text
                TblAntecedentesFamiliaresBindingSource.Item(TblAntecedentesFamiliaresBindingSource.Position).strNroIdentificacion = mIdentificacion
                TblAntecedentesFamiliaresBindingSource.Item(TblAntecedentesFamiliaresBindingSource.Position).dtmFecha = FormatDateTime(Now, DateFormat.ShortDate)

                If StrHCtextoClsTextBoxAF.Dock = DockStyle.Fill Then
                    TblAntecedentesFamiliaresBindingSource.Item(TblAntecedentesFamiliaresBindingSource.Position).bitModoTexto = True
                Else
                    TblAntecedentesFamiliaresBindingSource.Item(TblAntecedentesFamiliaresBindingSource.Position).bitModoTexto = False
                End If
                mguardar = False
            End If
            TblAntecedentesFamiliaresBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

End Class
