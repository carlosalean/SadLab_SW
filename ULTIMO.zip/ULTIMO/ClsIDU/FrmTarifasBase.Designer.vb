﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmTarifasBase
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IntIdTarifaBaseLabel As System.Windows.Forms.Label
        Dim NombreTarifaLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmTarifasBase))
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TblTarifaBaseBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.IntIdTarifaBaseTextBox = New System.Windows.Forms.TextBox()
        Me.NombreTarifaTextBox = New System.Windows.Forms.TextBox()
        Me.TblProcedimientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblTarifaBaseDetalleBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblTarifaBaseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.TblTarifaBaseBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TblTarifaBaseDetalleDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        IntIdTarifaBaseLabel = New System.Windows.Forms.Label()
        NombreTarifaLabel = New System.Windows.Forms.Label()
        CType(Me.TblTarifaBaseBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblTarifaBaseBindingNavigator.SuspendLayout()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTarifaBaseDetalleBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTarifaBaseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTarifaBaseDetalleDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TblTarifaBaseBindingNavigator
        '
        Me.TblTarifaBaseBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblTarifaBaseBindingNavigator.BindingSource = Me.TblTarifaBaseBindingSource
        Me.TblTarifaBaseBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblTarifaBaseBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblTarifaBaseBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblTarifaBaseBindingNavigatorSaveItem})
        Me.TblTarifaBaseBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblTarifaBaseBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblTarifaBaseBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblTarifaBaseBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblTarifaBaseBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblTarifaBaseBindingNavigator.Name = "TblTarifaBaseBindingNavigator"
        Me.TblTarifaBaseBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblTarifaBaseBindingNavigator.Size = New System.Drawing.Size(603, 25)
        Me.TblTarifaBaseBindingNavigator.TabIndex = 0
        Me.TblTarifaBaseBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'IntIdTarifaBaseLabel
        '
        IntIdTarifaBaseLabel.AutoSize = True
        IntIdTarifaBaseLabel.Location = New System.Drawing.Point(21, 44)
        IntIdTarifaBaseLabel.Name = "IntIdTarifaBaseLabel"
        IntIdTarifaBaseLabel.Size = New System.Drawing.Size(76, 13)
        IntIdTarifaBaseLabel.TabIndex = 6
        IntIdTarifaBaseLabel.Text = "Id Tarifa Base:"
        '
        'IntIdTarifaBaseTextBox
        '
        Me.IntIdTarifaBaseTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblTarifaBaseBindingSource, "intIdTarifaBase", True))
        Me.IntIdTarifaBaseTextBox.Location = New System.Drawing.Point(117, 41)
        Me.IntIdTarifaBaseTextBox.Name = "IntIdTarifaBaseTextBox"
        Me.IntIdTarifaBaseTextBox.ReadOnly = True
        Me.IntIdTarifaBaseTextBox.Size = New System.Drawing.Size(64, 20)
        Me.IntIdTarifaBaseTextBox.TabIndex = 7
        '
        'NombreTarifaLabel
        '
        NombreTarifaLabel.AutoSize = True
        NombreTarifaLabel.Location = New System.Drawing.Point(21, 70)
        NombreTarifaLabel.Name = "NombreTarifaLabel"
        NombreTarifaLabel.Size = New System.Drawing.Size(77, 13)
        NombreTarifaLabel.TabIndex = 8
        NombreTarifaLabel.Text = "Nombre Tarifa:"
        '
        'NombreTarifaTextBox
        '
        Me.NombreTarifaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblTarifaBaseBindingSource, "NombreTarifa", True))
        Me.NombreTarifaTextBox.Location = New System.Drawing.Point(117, 67)
        Me.NombreTarifaTextBox.Name = "NombreTarifaTextBox"
        Me.NombreTarifaTextBox.Size = New System.Drawing.Size(370, 20)
        Me.NombreTarifaTextBox.TabIndex = 9
        '
        'TblProcedimientoBindingSource
        '
        Me.TblProcedimientoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        '
        'TblTarifaBaseDetalleBindingSource
        '
        Me.TblTarifaBaseDetalleBindingSource.DataMember = "tblTarifaBaseDetalle"
        Me.TblTarifaBaseDetalleBindingSource.DataSource = Me.TblTarifaBaseBindingSource
        '
        'TblTarifaBaseBindingSource
        '
        Me.TblTarifaBaseBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTarifaBase)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'TblTarifaBaseBindingNavigatorSaveItem
        '
        Me.TblTarifaBaseBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblTarifaBaseBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblTarifaBaseBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblTarifaBaseBindingNavigatorSaveItem.Name = "TblTarifaBaseBindingNavigatorSaveItem"
        Me.TblTarifaBaseBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblTarifaBaseBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'TblTarifaBaseDetalleDataGridView
        '
        Me.TblTarifaBaseDetalleDataGridView.AutoGenerateColumns = False
        Me.TblTarifaBaseDetalleDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblTarifaBaseDetalleDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.TblTarifaBaseDetalleDataGridView.DataSource = Me.TblTarifaBaseDetalleBindingSource
        Me.TblTarifaBaseDetalleDataGridView.Location = New System.Drawing.Point(24, 123)
        Me.TblTarifaBaseDetalleDataGridView.Name = "TblTarifaBaseDetalleDataGridView"
        Me.TblTarifaBaseDetalleDataGridView.Size = New System.Drawing.Size(528, 243)
        Me.TblTarifaBaseDetalleDataGridView.TabIndex = 9
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "IntIdTBase_Detalle"
        Me.DataGridViewTextBoxColumn1.HeaderText = "IntIdTBase_Detalle"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Visible = False
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "intIdTarifaBase"
        Me.DataGridViewTextBoxColumn2.HeaderText = "intIdTarifaBase"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Visible = False
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "IntIdProdecimiento"
        Me.DataGridViewTextBoxColumn3.DataSource = Me.TblProcedimientoBindingSource
        Me.DataGridViewTextBoxColumn3.DisplayMember = "strDescripcion"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Prodecimiento"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn3.ValueMember = "intIdProcedimientos"
        Me.DataGridViewTextBoxColumn3.Width = 350
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "numValor"
        DataGridViewCellStyle3.Format = "C0"
        DataGridViewCellStyle3.NullValue = Nothing
        Me.DataGridViewTextBoxColumn4.DefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridViewTextBoxColumn4.HeaderText = "Valor"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "tblProcedimiento"
        Me.DataGridViewTextBoxColumn5.HeaderText = "tblProcedimiento"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Visible = False
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "tblTarifaBase"
        Me.DataGridViewTextBoxColumn6.HeaderText = "tblTarifaBase"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Visible = False
        '
        'FrmTarifasBase
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(603, 391)
        Me.Controls.Add(Me.TblTarifaBaseDetalleDataGridView)
        Me.Controls.Add(IntIdTarifaBaseLabel)
        Me.Controls.Add(Me.IntIdTarifaBaseTextBox)
        Me.Controls.Add(NombreTarifaLabel)
        Me.Controls.Add(Me.NombreTarifaTextBox)
        Me.Controls.Add(Me.TblTarifaBaseBindingNavigator)
        Me.Name = "FrmTarifasBase"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Tarifas Base"
        CType(Me.TblTarifaBaseBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblTarifaBaseBindingNavigator.ResumeLayout(False)
        Me.TblTarifaBaseBindingNavigator.PerformLayout()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTarifaBaseDetalleBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTarifaBaseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTarifaBaseDetalleDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblTarifaBaseBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTarifaBaseBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblTarifaBaseBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IntIdTarifaBaseTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NombreTarifaTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TblTarifaBaseDetalleBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblProcedimientoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTarifaBaseDetalleDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
