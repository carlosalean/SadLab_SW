﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DialogCierreCaja
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.ClsTextBoxUsuario = New ClsUtilidades.ClsTextBox()
        Me.ClsTextBoxCaja = New ClsUtilidades.ClsTextBox()
        Me.BindingSourcePagos = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DataGridView = New System.Windows.Forms.DataGridView()
        Me.NombreDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DtmHoraDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumValorPagadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumEfectivoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumDevueltaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ClsTextBoxDiferencia = New ClsUtilidades.ClsTextBox()
        Me.ClsTextBoxEfectivo = New ClsUtilidades.ClsTextBox()
        Me.ClsTextBoxBase = New ClsUtilidades.ClsTextBox()
        Me.ClsTextBoxTotal = New ClsUtilidades.ClsTextBox()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.BindingSourcePagos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(494, 310)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "Aceptar"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancelar"
        '
        'ClsTextBoxUsuario
        '
        Me.ClsTextBoxUsuario.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClsTextBoxUsuario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ClsTextBoxUsuario.DataSource = Nothing
        Me.ClsTextBoxUsuario.Enabled = False
        Me.ClsTextBoxUsuario.EnterEntreCampos = True
        Me.ClsTextBoxUsuario.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClsTextBoxUsuario.Location = New System.Drawing.Point(77, 17)
        Me.ClsTextBoxUsuario.Name = "ClsTextBoxUsuario"
        Me.ClsTextBoxUsuario.NombreCodigoF2 = Nothing
        Me.ClsTextBoxUsuario.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxUsuario.Size = New System.Drawing.Size(241, 20)
        Me.ClsTextBoxUsuario.TabIndex = 14
        Me.ClsTextBoxUsuario.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'ClsTextBoxCaja
        '
        Me.ClsTextBoxCaja.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClsTextBoxCaja.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ClsTextBoxCaja.DataSource = Me.BindingSourcePagos
        Me.ClsTextBoxCaja.Enabled = False
        Me.ClsTextBoxCaja.EnterEntreCampos = True
        Me.ClsTextBoxCaja.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClsTextBoxCaja.Location = New System.Drawing.Point(77, 43)
        Me.ClsTextBoxCaja.Name = "ClsTextBoxCaja"
        Me.ClsTextBoxCaja.NombreCodigoF2 = Nothing
        Me.ClsTextBoxCaja.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxCaja.Size = New System.Drawing.Size(241, 20)
        Me.ClsTextBoxCaja.TabIndex = 13
        Me.ClsTextBoxCaja.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'BindingSourcePagos
        '
        Me.BindingSourcePagos.DataSource = GetType(ClsBaseDatos_SadLab.usp_ConsultarPagosResult)
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Usuario:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DataGridView)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 67)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(627, 170)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Detalle de pagos"
        '
        'DataGridView
        '
        Me.DataGridView.AllowUserToAddRows = False
        Me.DataGridView.AllowUserToDeleteRows = False
        Me.DataGridView.AutoGenerateColumns = False
        Me.DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NombreDataGridViewTextBoxColumn, Me.DtmHoraDataGridViewTextBoxColumn, Me.NumValorPagadoDataGridViewTextBoxColumn, Me.NumEfectivoDataGridViewTextBoxColumn, Me.NumDevueltaDataGridViewTextBoxColumn})
        Me.DataGridView.DataSource = Me.BindingSourcePagos
        Me.DataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DataGridView.Location = New System.Drawing.Point(3, 16)
        Me.DataGridView.Name = "DataGridView"
        Me.DataGridView.ReadOnly = True
        Me.DataGridView.Size = New System.Drawing.Size(621, 151)
        Me.DataGridView.TabIndex = 0
        '
        'NombreDataGridViewTextBoxColumn
        '
        Me.NombreDataGridViewTextBoxColumn.DataPropertyName = "Nombre"
        Me.NombreDataGridViewTextBoxColumn.HeaderText = "Paciente"
        Me.NombreDataGridViewTextBoxColumn.Name = "NombreDataGridViewTextBoxColumn"
        Me.NombreDataGridViewTextBoxColumn.ReadOnly = True
        Me.NombreDataGridViewTextBoxColumn.Width = 200
        '
        'DtmHoraDataGridViewTextBoxColumn
        '
        Me.DtmHoraDataGridViewTextBoxColumn.DataPropertyName = "dtmHora"
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DtmHoraDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle1
        Me.DtmHoraDataGridViewTextBoxColumn.HeaderText = "Hora"
        Me.DtmHoraDataGridViewTextBoxColumn.Name = "DtmHoraDataGridViewTextBoxColumn"
        Me.DtmHoraDataGridViewTextBoxColumn.ReadOnly = True
        Me.DtmHoraDataGridViewTextBoxColumn.Width = 50
        '
        'NumValorPagadoDataGridViewTextBoxColumn
        '
        Me.NumValorPagadoDataGridViewTextBoxColumn.DataPropertyName = "numValorPagado"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle2.Format = "C0"
        DataGridViewCellStyle2.NullValue = Nothing
        Me.NumValorPagadoDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle2
        Me.NumValorPagadoDataGridViewTextBoxColumn.HeaderText = "Valor Pagado"
        Me.NumValorPagadoDataGridViewTextBoxColumn.Name = "NumValorPagadoDataGridViewTextBoxColumn"
        Me.NumValorPagadoDataGridViewTextBoxColumn.ReadOnly = True
        '
        'NumEfectivoDataGridViewTextBoxColumn
        '
        Me.NumEfectivoDataGridViewTextBoxColumn.DataPropertyName = "numEfectivo"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle3.Format = "C0"
        DataGridViewCellStyle3.NullValue = Nothing
        Me.NumEfectivoDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle3
        Me.NumEfectivoDataGridViewTextBoxColumn.HeaderText = "Efectivo"
        Me.NumEfectivoDataGridViewTextBoxColumn.Name = "NumEfectivoDataGridViewTextBoxColumn"
        Me.NumEfectivoDataGridViewTextBoxColumn.ReadOnly = True
        '
        'NumDevueltaDataGridViewTextBoxColumn
        '
        Me.NumDevueltaDataGridViewTextBoxColumn.DataPropertyName = "numDevuelta"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.Format = "C0"
        DataGridViewCellStyle4.NullValue = Nothing
        Me.NumDevueltaDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle4
        Me.NumDevueltaDataGridViewTextBoxColumn.HeaderText = "Devuelta"
        Me.NumDevueltaDataGridViewTextBoxColumn.Name = "NumDevueltaDataGridViewTextBoxColumn"
        Me.NumDevueltaDataGridViewTextBoxColumn.ReadOnly = True
        Me.NumDevueltaDataGridViewTextBoxColumn.Width = 126
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(31, 13)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Caja:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(471, 281)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(58, 13)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Diferencia:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(283, 281)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 13)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Total Efectivo:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(471, 249)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Base Inicial:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(283, 249)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 13)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Total pago:"
        '
        'ClsTextBoxDiferencia
        '
        Me.ClsTextBoxDiferencia.BackColor = System.Drawing.Color.Snow
        Me.ClsTextBoxDiferencia.DataSource = Nothing
        Me.ClsTextBoxDiferencia.EnterEntreCampos = True
        Me.ClsTextBoxDiferencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClsTextBoxDiferencia.Location = New System.Drawing.Point(535, 278)
        Me.ClsTextBoxDiferencia.Name = "ClsTextBoxDiferencia"
        Me.ClsTextBoxDiferencia.NombreCodigoF2 = Nothing
        Me.ClsTextBoxDiferencia.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxDiferencia.ReadOnly = True
        Me.ClsTextBoxDiferencia.Size = New System.Drawing.Size(100, 20)
        Me.ClsTextBoxDiferencia.TabIndex = 21
        Me.ClsTextBoxDiferencia.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'ClsTextBoxEfectivo
        '
        Me.ClsTextBoxEfectivo.BackColor = System.Drawing.SystemColors.HighlightText
        Me.ClsTextBoxEfectivo.DataSource = Nothing
        Me.ClsTextBoxEfectivo.EnterEntreCampos = True
        Me.ClsTextBoxEfectivo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClsTextBoxEfectivo.Location = New System.Drawing.Point(361, 277)
        Me.ClsTextBoxEfectivo.Name = "ClsTextBoxEfectivo"
        Me.ClsTextBoxEfectivo.NombreCodigoF2 = Nothing
        Me.ClsTextBoxEfectivo.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxEfectivo.Size = New System.Drawing.Size(100, 20)
        Me.ClsTextBoxEfectivo.TabIndex = 20
        Me.ClsTextBoxEfectivo.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'ClsTextBoxBase
        '
        Me.ClsTextBoxBase.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClsTextBoxBase.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ClsTextBoxBase.DataSource = Nothing
        Me.ClsTextBoxBase.Enabled = False
        Me.ClsTextBoxBase.EnterEntreCampos = True
        Me.ClsTextBoxBase.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClsTextBoxBase.Location = New System.Drawing.Point(536, 245)
        Me.ClsTextBoxBase.Name = "ClsTextBoxBase"
        Me.ClsTextBoxBase.NombreCodigoF2 = Nothing
        Me.ClsTextBoxBase.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxBase.Size = New System.Drawing.Size(100, 20)
        Me.ClsTextBoxBase.TabIndex = 19
        Me.ClsTextBoxBase.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'ClsTextBoxTotal
        '
        Me.ClsTextBoxTotal.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClsTextBoxTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ClsTextBoxTotal.DataSource = Nothing
        Me.ClsTextBoxTotal.Enabled = False
        Me.ClsTextBoxTotal.EnterEntreCampos = True
        Me.ClsTextBoxTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClsTextBoxTotal.Location = New System.Drawing.Point(361, 245)
        Me.ClsTextBoxTotal.Name = "ClsTextBoxTotal"
        Me.ClsTextBoxTotal.NombreCodigoF2 = Nothing
        Me.ClsTextBoxTotal.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxTotal.Size = New System.Drawing.Size(100, 20)
        Me.ClsTextBoxTotal.TabIndex = 18
        Me.ClsTextBoxTotal.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'DialogCierreCaja
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(652, 351)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ClsTextBoxDiferencia)
        Me.Controls.Add(Me.ClsTextBoxEfectivo)
        Me.Controls.Add(Me.ClsTextBoxBase)
        Me.Controls.Add(Me.ClsTextBoxTotal)
        Me.Controls.Add(Me.ClsTextBoxUsuario)
        Me.Controls.Add(Me.ClsTextBoxCaja)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DialogCierreCaja"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Cierre Caja"
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.BindingSourcePagos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.DataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents BindingSourcePagos As System.Windows.Forms.BindingSource
    Friend WithEvents ClsTextBoxUsuario As ClsUtilidades.ClsTextBox
    Friend WithEvents ClsTextBoxCaja As ClsUtilidades.ClsTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents DataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ClsTextBoxDiferencia As ClsUtilidades.ClsTextBox
    Friend WithEvents ClsTextBoxEfectivo As ClsUtilidades.ClsTextBox
    Friend WithEvents ClsTextBoxBase As ClsUtilidades.ClsTextBox
    Friend WithEvents ClsTextBoxTotal As ClsUtilidades.ClsTextBox
    Friend WithEvents NombreDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DtmHoraDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NumValorPagadoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NumEfectivoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NumDevueltaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
