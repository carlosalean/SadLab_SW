﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uscAntecedentesPersonales
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IntidAntecedentesPersonalesLabel As System.Windows.Forms.Label
        Dim StrHCtextoLabel As System.Windows.Forms.Label
        Dim DtmFechaLabel1 As System.Windows.Forms.Label
        Dim IntIdDiagnosticoLabel As System.Windows.Forms.Label
        Dim DtmFechaLabel As System.Windows.Forms.Label
        Dim StrNotasAdicionalesLabel As System.Windows.Forms.Label
        Dim IntidProcedimientosLabel As System.Windows.Forms.Label
        Dim BitTratamientoNoFarmacologicoLabel As System.Windows.Forms.Label
        Dim BitTratamientoFarmacologicoLabel As System.Windows.Forms.Label
        Dim BitRealizaronProcedimientosLabel As System.Windows.Forms.Label
        Dim BitResueltoLabel As System.Windows.Forms.Label
        Dim BitMedidasGeneralesLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uscAntecedentesPersonales))
        Me.TblAntecedentesPersonalesHCBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblAntecedentesPersonalesHCBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblAntecedentesPersonalesHCBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TblDisgnosticoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblProcedimientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.IntidAntecedentesPersonalesClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrNotasAdicionalesTextBox = New System.Windows.Forms.TextBox()
        Me.StrHCtextoTextBox = New System.Windows.Forms.TextBox()
        Me.IntidProcedimientosClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.DtmFechaProcedimientoClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.IntIdDiagnosticoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.DtmFechaClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BitRealizaronProcedimientosClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.BitTratamientoNoFarmacologicoClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.BitTratamientoFarmacologicoClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.BitMedidasGeneralesClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.BitResueltoClsCheckBox = New ClsUtilidades.ClsCheckBox()
        IntidAntecedentesPersonalesLabel = New System.Windows.Forms.Label()
        StrHCtextoLabel = New System.Windows.Forms.Label()
        DtmFechaLabel1 = New System.Windows.Forms.Label()
        IntIdDiagnosticoLabel = New System.Windows.Forms.Label()
        DtmFechaLabel = New System.Windows.Forms.Label()
        StrNotasAdicionalesLabel = New System.Windows.Forms.Label()
        IntidProcedimientosLabel = New System.Windows.Forms.Label()
        BitTratamientoNoFarmacologicoLabel = New System.Windows.Forms.Label()
        BitTratamientoFarmacologicoLabel = New System.Windows.Forms.Label()
        BitRealizaronProcedimientosLabel = New System.Windows.Forms.Label()
        BitResueltoLabel = New System.Windows.Forms.Label()
        BitMedidasGeneralesLabel = New System.Windows.Forms.Label()
        CType(Me.TblAntecedentesPersonalesHCBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblAntecedentesPersonalesHCBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblAntecedentesPersonalesHCBindingNavigator.SuspendLayout()
        CType(Me.TblDisgnosticoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntidAntecedentesPersonalesLabel
        '
        IntidAntecedentesPersonalesLabel.AutoSize = True
        IntidAntecedentesPersonalesLabel.Location = New System.Drawing.Point(279, 31)
        IntidAntecedentesPersonalesLabel.Name = "IntidAntecedentesPersonalesLabel"
        IntidAntecedentesPersonalesLabel.Size = New System.Drawing.Size(19, 13)
        IntidAntecedentesPersonalesLabel.TabIndex = 118
        IntidAntecedentesPersonalesLabel.Text = "Id:"
        IntidAntecedentesPersonalesLabel.Visible = False
        '
        'StrHCtextoLabel
        '
        StrHCtextoLabel.AutoSize = True
        StrHCtextoLabel.Location = New System.Drawing.Point(527, 27)
        StrHCtextoLabel.Name = "StrHCtextoLabel"
        StrHCtextoLabel.Size = New System.Drawing.Size(62, 13)
        StrHCtextoLabel.TabIndex = 115
        StrHCtextoLabel.Text = "str HCtexto:"
        StrHCtextoLabel.Visible = False
        '
        'DtmFechaLabel1
        '
        DtmFechaLabel1.AutoSize = True
        DtmFechaLabel1.Location = New System.Drawing.Point(26, 31)
        DtmFechaLabel1.Name = "DtmFechaLabel1"
        DtmFechaLabel1.Size = New System.Drawing.Size(40, 13)
        DtmFechaLabel1.TabIndex = 111
        DtmFechaLabel1.Text = "Fecha:"
        '
        'IntIdDiagnosticoLabel
        '
        IntIdDiagnosticoLabel.AutoSize = True
        IntIdDiagnosticoLabel.Location = New System.Drawing.Point(26, 56)
        IntIdDiagnosticoLabel.Name = "IntIdDiagnosticoLabel"
        IntIdDiagnosticoLabel.Size = New System.Drawing.Size(66, 13)
        IntIdDiagnosticoLabel.TabIndex = 110
        IntIdDiagnosticoLabel.Text = "Diagnóstico:"
        '
        'DtmFechaLabel
        '
        DtmFechaLabel.AutoSize = True
        DtmFechaLabel.Location = New System.Drawing.Point(26, 84)
        DtmFechaLabel.Name = "DtmFechaLabel"
        DtmFechaLabel.Size = New System.Drawing.Size(110, 13)
        DtmFechaLabel.TabIndex = 109
        DtmFechaLabel.Text = "Fecha Procedimiento:"
        '
        'StrNotasAdicionalesLabel
        '
        StrNotasAdicionalesLabel.AutoSize = True
        StrNotasAdicionalesLabel.Location = New System.Drawing.Point(26, 199)
        StrNotasAdicionalesLabel.Name = "StrNotasAdicionalesLabel"
        StrNotasAdicionalesLabel.Size = New System.Drawing.Size(95, 13)
        StrNotasAdicionalesLabel.TabIndex = 108
        StrNotasAdicionalesLabel.Text = "Notas Adicionales:"
        '
        'IntidProcedimientosLabel
        '
        IntidProcedimientosLabel.AutoSize = True
        IntidProcedimientosLabel.Location = New System.Drawing.Point(256, 84)
        IntidProcedimientosLabel.Name = "IntidProcedimientosLabel"
        IntidProcedimientosLabel.Size = New System.Drawing.Size(125, 13)
        IntidProcedimientosLabel.TabIndex = 107
        IntidProcedimientosLabel.Text = "Procedimientos Principal:"
        '
        'BitTratamientoNoFarmacologicoLabel
        '
        BitTratamientoNoFarmacologicoLabel.AutoSize = True
        BitTratamientoNoFarmacologicoLabel.Location = New System.Drawing.Point(5, 54)
        BitTratamientoNoFarmacologicoLabel.Name = "BitTratamientoNoFarmacologicoLabel"
        BitTratamientoNoFarmacologicoLabel.Size = New System.Drawing.Size(185, 13)
        BitTratamientoNoFarmacologicoLabel.TabIndex = 8
        BitTratamientoNoFarmacologicoLabel.Text = "Se dió Tratamiento No Farmacológico"
        '
        'BitTratamientoFarmacologicoLabel
        '
        BitTratamientoFarmacologicoLabel.AutoSize = True
        BitTratamientoFarmacologicoLabel.Location = New System.Drawing.Point(7, 34)
        BitTratamientoFarmacologicoLabel.Name = "BitTratamientoFarmacologicoLabel"
        BitTratamientoFarmacologicoLabel.Size = New System.Drawing.Size(173, 13)
        BitTratamientoFarmacologicoLabel.TabIndex = 6
        BitTratamientoFarmacologicoLabel.Text = "Se hizo Tratamiento Farmacológico"
        '
        'BitRealizaronProcedimientosLabel
        '
        BitRealizaronProcedimientosLabel.AutoSize = True
        BitRealizaronProcedimientosLabel.Location = New System.Drawing.Point(291, 34)
        BitRealizaronProcedimientosLabel.Name = "BitRealizaronProcedimientosLabel"
        BitRealizaronProcedimientosLabel.Size = New System.Drawing.Size(132, 13)
        BitRealizaronProcedimientosLabel.TabIndex = 2
        BitRealizaronProcedimientosLabel.Text = "Realizaron Procedimientos"
        '
        'BitResueltoLabel
        '
        BitResueltoLabel.AutoSize = True
        BitResueltoLabel.Location = New System.Drawing.Point(7, 15)
        BitResueltoLabel.Name = "BitResueltoLabel"
        BitResueltoLabel.Size = New System.Drawing.Size(49, 13)
        BitResueltoLabel.TabIndex = 4
        BitResueltoLabel.Text = "Resuelto"
        '
        'BitMedidasGeneralesLabel
        '
        BitMedidasGeneralesLabel.AutoSize = True
        BitMedidasGeneralesLabel.Location = New System.Drawing.Point(291, 15)
        BitMedidasGeneralesLabel.Name = "BitMedidasGeneralesLabel"
        BitMedidasGeneralesLabel.Size = New System.Drawing.Size(170, 13)
        BitMedidasGeneralesLabel.TabIndex = 0
        BitMedidasGeneralesLabel.Text = "Se  Realizaron Medidas Generales"
        '
        'TblAntecedentesPersonalesHCBindingSource
        '
        Me.TblAntecedentesPersonalesHCBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblAntecedentesPersonalesHC)
        '
        'TblAntecedentesPersonalesHCBindingNavigator
        '
        Me.TblAntecedentesPersonalesHCBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblAntecedentesPersonalesHCBindingNavigator.BindingSource = Me.TblAntecedentesPersonalesHCBindingSource
        Me.TblAntecedentesPersonalesHCBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblAntecedentesPersonalesHCBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblAntecedentesPersonalesHCBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblAntecedentesPersonalesHCBindingNavigatorSaveItem})
        Me.TblAntecedentesPersonalesHCBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblAntecedentesPersonalesHCBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblAntecedentesPersonalesHCBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblAntecedentesPersonalesHCBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblAntecedentesPersonalesHCBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblAntecedentesPersonalesHCBindingNavigator.Name = "TblAntecedentesPersonalesHCBindingNavigator"
        Me.TblAntecedentesPersonalesHCBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblAntecedentesPersonalesHCBindingNavigator.Size = New System.Drawing.Size(830, 25)
        Me.TblAntecedentesPersonalesHCBindingNavigator.TabIndex = 98
        Me.TblAntecedentesPersonalesHCBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblAntecedentesPersonalesHCBindingNavigatorSaveItem
        '
        Me.TblAntecedentesPersonalesHCBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblAntecedentesPersonalesHCBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblAntecedentesPersonalesHCBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblAntecedentesPersonalesHCBindingNavigatorSaveItem.Name = "TblAntecedentesPersonalesHCBindingNavigatorSaveItem"
        Me.TblAntecedentesPersonalesHCBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblAntecedentesPersonalesHCBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'TblDisgnosticoBindingSource
        '
        Me.TblDisgnosticoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
        Me.TblDisgnosticoBindingSource.Sort = "strNombre"
        '
        'TblProcedimientoBindingSource
        '
        Me.TblProcedimientoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        Me.TblProcedimientoBindingSource.Sort = "strDescripcion"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(IntidAntecedentesPersonalesLabel)
        Me.Panel1.Controls.Add(Me.IntidAntecedentesPersonalesClsTextBox)
        Me.Panel1.Controls.Add(Me.StrNotasAdicionalesTextBox)
        Me.Panel1.Controls.Add(StrHCtextoLabel)
        Me.Panel1.Controls.Add(Me.StrHCtextoTextBox)
        Me.Panel1.Controls.Add(Me.IntidProcedimientosClsComboBox)
        Me.Panel1.Controls.Add(Me.DtmFechaProcedimientoClsDateTimePicker)
        Me.Panel1.Controls.Add(Me.IntIdDiagnosticoClsComboBox)
        Me.Panel1.Controls.Add(DtmFechaLabel1)
        Me.Panel1.Controls.Add(Me.DtmFechaClsDateTimePicker)
        Me.Panel1.Controls.Add(IntIdDiagnosticoLabel)
        Me.Panel1.Controls.Add(DtmFechaLabel)
        Me.Panel1.Controls.Add(StrNotasAdicionalesLabel)
        Me.Panel1.Controls.Add(IntidProcedimientosLabel)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 25)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(830, 462)
        Me.Panel1.TabIndex = 99
        '
        'IntidAntecedentesPersonalesClsTextBox
        '
        Me.IntidAntecedentesPersonalesClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesPersonalesHCBindingSource, "intidAntecedentesPersonales", True))
        Me.IntidAntecedentesPersonalesClsTextBox.DataSource = Nothing
        Me.IntidAntecedentesPersonalesClsTextBox.EnterEntreCampos = True
        Me.IntidAntecedentesPersonalesClsTextBox.Location = New System.Drawing.Point(304, 27)
        Me.IntidAntecedentesPersonalesClsTextBox.Name = "IntidAntecedentesPersonalesClsTextBox"
        Me.IntidAntecedentesPersonalesClsTextBox.NombreCodigoF2 = Nothing
        Me.IntidAntecedentesPersonalesClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntidAntecedentesPersonalesClsTextBox.ReadOnly = True
        Me.IntidAntecedentesPersonalesClsTextBox.Size = New System.Drawing.Size(42, 20)
        Me.IntidAntecedentesPersonalesClsTextBox.TabIndex = 120
        Me.IntidAntecedentesPersonalesClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.IntidAntecedentesPersonalesClsTextBox.Visible = False
        '
        'StrNotasAdicionalesTextBox
        '
        Me.StrNotasAdicionalesTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesPersonalesHCBindingSource, "strNotasAdicionales", True))
        Me.StrNotasAdicionalesTextBox.Location = New System.Drawing.Point(29, 215)
        Me.StrNotasAdicionalesTextBox.Multiline = True
        Me.StrNotasAdicionalesTextBox.Name = "StrNotasAdicionalesTextBox"
        Me.StrNotasAdicionalesTextBox.Size = New System.Drawing.Size(727, 140)
        Me.StrNotasAdicionalesTextBox.TabIndex = 119
        '
        'StrHCtextoTextBox
        '
        Me.StrHCtextoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblAntecedentesPersonalesHCBindingSource, "strHCtexto", True))
        Me.StrHCtextoTextBox.Location = New System.Drawing.Point(595, 24)
        Me.StrHCtextoTextBox.Multiline = True
        Me.StrHCtextoTextBox.Name = "StrHCtextoTextBox"
        Me.StrHCtextoTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrHCtextoTextBox.TabIndex = 117
        Me.StrHCtextoTextBox.Visible = False
        '
        'IntidProcedimientosClsComboBox
        '
        Me.IntidProcedimientosClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesPersonalesHCBindingSource, "intidProcedimientos", True))
        Me.IntidProcedimientosClsComboBox.DataSource = Me.TblProcedimientoBindingSource
        Me.IntidProcedimientosClsComboBox.DisplayMember = "strDescripcion"
        Me.IntidProcedimientosClsComboBox.FormattingEnabled = True
        Me.IntidProcedimientosClsComboBox.Location = New System.Drawing.Point(387, 81)
        Me.IntidProcedimientosClsComboBox.Name = "IntidProcedimientosClsComboBox"
        Me.IntidProcedimientosClsComboBox.Size = New System.Drawing.Size(369, 21)
        Me.IntidProcedimientosClsComboBox.TabIndex = 116
        Me.IntidProcedimientosClsComboBox.ValueMember = "intIdProcedimientos"
        '
        'DtmFechaProcedimientoClsDateTimePicker
        '
        Me.DtmFechaProcedimientoClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblAntecedentesPersonalesHCBindingSource, "dtmFechaProcedimiento", True))
        Me.DtmFechaProcedimientoClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaProcedimientoClsDateTimePicker.Location = New System.Drawing.Point(142, 80)
        Me.DtmFechaProcedimientoClsDateTimePicker.Name = "DtmFechaProcedimientoClsDateTimePicker"
        Me.DtmFechaProcedimientoClsDateTimePicker.Size = New System.Drawing.Size(93, 20)
        Me.DtmFechaProcedimientoClsDateTimePicker.TabIndex = 114
        '
        'IntIdDiagnosticoClsComboBox
        '
        Me.IntIdDiagnosticoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblAntecedentesPersonalesHCBindingSource, "intIdDiagnostico", True))
        Me.IntIdDiagnosticoClsComboBox.DataSource = Me.TblDisgnosticoBindingSource
        Me.IntIdDiagnosticoClsComboBox.DisplayMember = "strNombre"
        Me.IntIdDiagnosticoClsComboBox.FormattingEnabled = True
        Me.IntIdDiagnosticoClsComboBox.Location = New System.Drawing.Point(142, 53)
        Me.IntIdDiagnosticoClsComboBox.Name = "IntIdDiagnosticoClsComboBox"
        Me.IntIdDiagnosticoClsComboBox.Size = New System.Drawing.Size(392, 21)
        Me.IntIdDiagnosticoClsComboBox.TabIndex = 113
        Me.IntIdDiagnosticoClsComboBox.ValueMember = "intIdDiagnostico"
        '
        'DtmFechaClsDateTimePicker
        '
        Me.DtmFechaClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblAntecedentesPersonalesHCBindingSource, "dtmFecha", True))
        Me.DtmFechaClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaClsDateTimePicker.Location = New System.Drawing.Point(142, 27)
        Me.DtmFechaClsDateTimePicker.Name = "DtmFechaClsDateTimePicker"
        Me.DtmFechaClsDateTimePicker.Size = New System.Drawing.Size(93, 20)
        Me.DtmFechaClsDateTimePicker.TabIndex = 112
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(BitTratamientoNoFarmacologicoLabel)
        Me.GroupBox1.Controls.Add(Me.BitRealizaronProcedimientosClsCheckBox)
        Me.GroupBox1.Controls.Add(Me.BitTratamientoNoFarmacologicoClsCheckBox)
        Me.GroupBox1.Controls.Add(BitTratamientoFarmacologicoLabel)
        Me.GroupBox1.Controls.Add(Me.BitTratamientoFarmacologicoClsCheckBox)
        Me.GroupBox1.Controls.Add(BitRealizaronProcedimientosLabel)
        Me.GroupBox1.Controls.Add(BitResueltoLabel)
        Me.GroupBox1.Controls.Add(Me.BitMedidasGeneralesClsCheckBox)
        Me.GroupBox1.Controls.Add(Me.BitResueltoClsCheckBox)
        Me.GroupBox1.Controls.Add(BitMedidasGeneralesLabel)
        Me.GroupBox1.Location = New System.Drawing.Point(29, 108)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(727, 85)
        Me.GroupBox1.TabIndex = 106
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tipo de manejo"
        '
        'BitRealizaronProcedimientosClsCheckBox
        '
        Me.BitRealizaronProcedimientosClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblAntecedentesPersonalesHCBindingSource, "bitRealizaronProcedimientos", True))
        Me.BitRealizaronProcedimientosClsCheckBox.Location = New System.Drawing.Point(467, 31)
        Me.BitRealizaronProcedimientosClsCheckBox.Name = "BitRealizaronProcedimientosClsCheckBox"
        Me.BitRealizaronProcedimientosClsCheckBox.Size = New System.Drawing.Size(18, 24)
        Me.BitRealizaronProcedimientosClsCheckBox.TabIndex = 108
        Me.BitRealizaronProcedimientosClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitTratamientoNoFarmacologicoClsCheckBox
        '
        Me.BitTratamientoNoFarmacologicoClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblAntecedentesPersonalesHCBindingSource, "bitTratamientoNoFarmacologico", True))
        Me.BitTratamientoNoFarmacologicoClsCheckBox.Location = New System.Drawing.Point(196, 54)
        Me.BitTratamientoNoFarmacologicoClsCheckBox.Name = "BitTratamientoNoFarmacologicoClsCheckBox"
        Me.BitTratamientoNoFarmacologicoClsCheckBox.Size = New System.Drawing.Size(21, 24)
        Me.BitTratamientoNoFarmacologicoClsCheckBox.TabIndex = 111
        Me.BitTratamientoNoFarmacologicoClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitTratamientoFarmacologicoClsCheckBox
        '
        Me.BitTratamientoFarmacologicoClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblAntecedentesPersonalesHCBindingSource, "bitTratamientoFarmacologico", True))
        Me.BitTratamientoFarmacologicoClsCheckBox.Location = New System.Drawing.Point(196, 31)
        Me.BitTratamientoFarmacologicoClsCheckBox.Name = "BitTratamientoFarmacologicoClsCheckBox"
        Me.BitTratamientoFarmacologicoClsCheckBox.Size = New System.Drawing.Size(21, 24)
        Me.BitTratamientoFarmacologicoClsCheckBox.TabIndex = 110
        Me.BitTratamientoFarmacologicoClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitMedidasGeneralesClsCheckBox
        '
        Me.BitMedidasGeneralesClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblAntecedentesPersonalesHCBindingSource, "bitMedidasGenerales", True))
        Me.BitMedidasGeneralesClsCheckBox.Location = New System.Drawing.Point(467, 10)
        Me.BitMedidasGeneralesClsCheckBox.Name = "BitMedidasGeneralesClsCheckBox"
        Me.BitMedidasGeneralesClsCheckBox.Size = New System.Drawing.Size(18, 24)
        Me.BitMedidasGeneralesClsCheckBox.TabIndex = 106
        Me.BitMedidasGeneralesClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitResueltoClsCheckBox
        '
        Me.BitResueltoClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblAntecedentesPersonalesHCBindingSource, "bitResuelto", True))
        Me.BitResueltoClsCheckBox.Location = New System.Drawing.Point(196, 10)
        Me.BitResueltoClsCheckBox.Name = "BitResueltoClsCheckBox"
        Me.BitResueltoClsCheckBox.Size = New System.Drawing.Size(21, 24)
        Me.BitResueltoClsCheckBox.TabIndex = 109
        Me.BitResueltoClsCheckBox.UseVisualStyleBackColor = True
        '
        'uscAntecedentesPersonales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TblAntecedentesPersonalesHCBindingNavigator)
        Me.Name = "uscAntecedentesPersonales"
        Me.Size = New System.Drawing.Size(830, 487)
        CType(Me.TblAntecedentesPersonalesHCBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblAntecedentesPersonalesHCBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblAntecedentesPersonalesHCBindingNavigator.ResumeLayout(False)
        Me.TblAntecedentesPersonalesHCBindingNavigator.PerformLayout()
        CType(Me.TblDisgnosticoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblAntecedentesPersonalesHCBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblAntecedentesPersonalesHCBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblAntecedentesPersonalesHCBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblDisgnosticoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblProcedimientoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents IntidAntecedentesPersonalesClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNotasAdicionalesTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrHCtextoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents IntidProcedimientosClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents DtmFechaProcedimientoClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntIdDiagnosticoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents DtmFechaClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents BitRealizaronProcedimientosClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitTratamientoNoFarmacologicoClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitTratamientoFarmacologicoClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitMedidasGeneralesClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitResueltoClsCheckBox As ClsUtilidades.ClsCheckBox

End Class
