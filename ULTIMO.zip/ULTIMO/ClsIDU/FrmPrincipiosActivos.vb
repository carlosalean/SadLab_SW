﻿Public Class FrmPrincipiosActivos
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

    Sub New(ByVal strStringConection As String)
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmPrincipiosActivos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TblPrincipiosActivosBindingSource.DataSource = dc.tblPrincipiosActivos
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub
   
    Private Sub TblPrincipiosActivosBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblPrincipiosActivosBindingNavigatorSaveItem.Click
        Try
            TblPrincipiosActivosBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BindingNavigatorDeleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorDeleteItem.Click
        'If Me.StrDescripcionClsTextBox.TextLength = 0 Then
        '    RemoveHandler BindingNavigatorDeleteItem.Click, AddressOf Me.BindingNavigatorDeleteItem_Click
        '    Me.BindingNavigatorDeleteItem = Nothing
        '    Exit Sub
        'End If
    End Sub
End Class