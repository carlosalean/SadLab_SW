﻿Imports System.Windows.Forms

Public Class uscDiagnosticoConducta
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mHC As Integer
    Private _btn As Windows.Forms.Button
    Private mclsUtilidadesHC As clsUtilidadesHC
    Private _IdUsuario As String
    Private mNuevo As Boolean
    Private _mstrStringConection As String
    Private _mCita As Integer

    Public Sub New()

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub



    Public Property mstrStringConection() As String
        Get
            Return _mstrStringConection
        End Get
        Set(ByVal value As String)
            _mstrStringConection = value
        End Set
    End Property

    Public Property mCita() As Integer
        Get
            Return _mCita
        End Get
        Set(ByVal value As Integer)
            _mCita = value
        End Set
    End Property

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mHC() As Integer
        Get
            Return _mHC
        End Get
        Set(ByVal value As Integer)
            _mHC = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub cargarDatosTabDC()
        Try
            Dim mconsulta = (From p In dc.tblDiagnosticoConductaHC Where p.intidHC = mHC Select p.bitModoTexto, p.strDiagnosticoConductaTextoHC)
            If mconsulta.Count > 0 Then
                For Each c In mconsulta
                    If c.bitModoTexto = True Then
                        StrDiagnosticoConductaTextoHCClsTextBox.Dock = DockStyle.Fill
                        StrDiagnosticoConductaTextoHCClsTextBox.BringToFront()
                        StrDiagnosticoConductaTextoHCClsTextBox.Multiline = True
                        StrDiagnosticoConductaTextoHCClsTextBox.Visible = True
                        prCargarDatosDiagnosticoConducta()
                    Else
                        prCargarDatosDiagnosticoConducta()
                        Exit For
                    End If
                Next
            Else
                mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
                If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
                    StrDiagnosticoConductaTextoHCClsTextBox.Dock = DockStyle.Fill
                    StrDiagnosticoConductaTextoHCClsTextBox.BringToFront()
                    StrDiagnosticoConductaTextoHCClsTextBox.Multiline = True
                    StrDiagnosticoConductaTextoHCClsTextBox.Visible = True
                    prCargarDatosDiagnosticoConducta()
                Else
                    prCargarDatosDiagnosticoConducta()
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub prCargarDatosDiagnosticoConducta()
        Try
            TblDisgnosticoBindingSource.DataSource = dc.tblDisgnostico
            TblProcedimientoBindingSource.DataSource = dc.tblProcedimiento
            TblProcedimientoBindingSource1.DataSource = dc.tblProcedimiento
            TblProcedimientoBindingSource2.DataSource = dc.tblProcedimiento

            Dim mconsultaTipo = (From D In dc.tblDiagnosticoConductaHC Where D.intidHC = mHC Select D)

            If mconsultaTipo.Count > 0 Then
                TblDiagnosticoConductaHCBindingSource.DataSource = mconsultaTipo
                mNuevo = False
            Else
                'TblDiagnosticoConductaHCBindingSource.AddNew()
                'mNuevo = True
                Panel1.Enabled = False
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub TblEPBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblEPBindingNavigatorSaveItem.Click
        prGuardar()
        'Try
        '    TblDiagnosticoConductaHCBindingSource.Item(TblDiagnosticoConductaHCBindingSource.Position).intidHC = mHC
        '    TblDiagnosticoConductaHCBindingSource.Item(TblDiagnosticoConductaHCBindingSource.Position).strDiagnosticoConductaTextoHC = StrDiagnosticoConductaTextoHCClsTextBox.Text
        '    TblDiagnosticoConductaHCBindingSource.EndEdit()
        '    dc.SubmitChanges()
        'Catch ex As Exception
        '    ClsError.ClsError.PrMostrarError(ex)
        'End Try

    End Sub

    Private Sub TblDiagnosticoConductaHCBindingSource_AddingNew(ByVal sender As System.Object, ByVal e As System.ComponentModel.AddingNewEventArgs) Handles TblDiagnosticoConductaHCBindingSource.AddingNew
        'Try
        '    If sender.Position.ToString >= 0 Then
        '        sender.Item(sender.Position).dtmFecha = FormatDateTime(Now, DateFormat.ShortDate)
        '    End If
        'Catch ex As Exception
        '    ClsError.ClsError.PrMostrarError(ex)
        'End Try
    End Sub

    Public Sub prGuardar() Implements IAbandonarUC.prGuardar

        Try
            If TblDiagnosticoConductaHCBindingSource.Position = 0 Then
                TblDiagnosticoConductaHCBindingSource.Item(TblDiagnosticoConductaHCBindingSource.Position).strDiagnosticoConductaTextoHC = StrDiagnosticoConductaTextoHCClsTextBox.Text
                TblDiagnosticoConductaHCBindingSource.Item(TblDiagnosticoConductaHCBindingSource.Position).intidHC = mHC
                TblDiagnosticoConductaHCBindingSource.Item(TblDiagnosticoConductaHCBindingSource.Position).dtmFecha = FormatDateTime(Now, DateFormat.ShortDate)
                If StrDiagnosticoConductaTextoHCClsTextBox.Dock = DockStyle.Fill Then
                    TblDiagnosticoConductaHCBindingSource.Item(TblDiagnosticoConductaHCBindingSource.Position).bitModoTexto = True
                Else
                    TblDiagnosticoConductaHCBindingSource.Item(TblDiagnosticoConductaHCBindingSource.Position).bitModoTexto = False
                End If
                TblDiagnosticoConductaHCBindingSource.EndEdit()
                If mNuevo = True Then
                    dc.tblDiagnosticoConductaHC.InsertOnSubmit(TblDiagnosticoConductaHCBindingSource.Item(TblDiagnosticoConductaHCBindingSource.Position))
                End If
                dc.SubmitChanges()
                mNuevo = False
            End If
            TblDiagnosticoConductaHCBindingSource.EndEdit()
            dc.SubmitChanges()

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub uscDiagnosticoConducta_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        prGuardar()
    End Sub


    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        Panel1.Enabled = True
        mNuevo = True
    End Sub

    Private Sub ToolStripButtonImprimir_Click(sender As Object, e As EventArgs) Handles ToolStripButtonImprimir.Click

        If Application.OpenForms("FrmAnexosHC") Is Nothing Then
            Dim mFrmresumenHC = New ClsReportes.FrmAnexosHC(Me.mstrStringConection, Me.mCita, Me.mHC, 1)
            mFrmresumenHC.Show()
        Else
            Application.OpenForms("FrmAnexosHC").BringToFront()
        End If

    End Sub
End Class
