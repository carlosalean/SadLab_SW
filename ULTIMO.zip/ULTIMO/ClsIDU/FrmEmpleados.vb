﻿Public Class FrmEmpleados
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Sub New(ByVal strStringConection As String)
        Try

            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmEmpleados_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TblEmpeadoBindingSource.DataSource = dc.tblEmpeados
            TblProcedimientoBindingSource.DataSource = dc.tblProcedimiento
            TblTurnoBindingSource.DataSource = dc.tblTurnos
            TblItemRevisionBindingSource.DataSource = dc.tblItemRevision
            TblDatosPrestadoresBindingSource.DataSource = dc.tblDatosPrestadores
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblEmpeadoBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblEmpeadoBindingNavigatorSaveItem.Click
        Try

            If FirmaPictureBox.Image() IsNot Nothing Then
                Dim imageConverter As New System.Drawing.ImageConverter()
                Dim imageByte As Byte() = DirectCast(imageConverter.ConvertTo(FirmaPictureBox.Image, GetType(Byte())), Byte())
                TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).Firma = imageByte
            End If

            TblEmpeadoBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub

    Private Sub TblProfesionalesProcedminentosDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblProfesionalesProcedminentosDataGridView.DataError
        Try

        Catch ex As Exception
            'No hace nada
        End Try
    End Sub

    Private Sub TblEmpleadosTurnosDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblEmpleadosTurnosDataGridView.DataError
        Try

        Catch ex As Exception
            'No hace nada
        End Try
    End Sub

    Private Sub TblProfesionalesItemsDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblProfesionalesItemsDataGridView.DataError
        Try

        Catch ex As Exception
            'No hace nada
        End Try
    End Sub

    Private Sub TblEmpleadosPrestadoresDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblEmpleadosPrestadoresDataGridView.DataError
        Try
            'Error
        Catch ex As Exception
            'Error
        End Try
    End Sub

    Private Sub btnCargarImagen_Click(sender As Object, e As EventArgs) Handles btnCargarImagen.Click
        Try
            Dim apppath As String
            OpenFileDialog1.Title = "Select Application Configeration Files Path"
            OpenFileDialog1.InitialDirectory = "C:\"
            OpenFileDialog1.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
            OpenFileDialog1.FilterIndex = 2
            OpenFileDialog1.RestoreDirectory = True
            If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
                apppath = OpenFileDialog1.FileName
            End If
            FirmaPictureBox.Image = Drawing.Image.FromFile(apppath)
        Catch ex As Exception
            ''Error
        End Try
    End Sub

    Private Sub TblEmpeadoBindingNavigator_LocationChanged(sender As Object, e As EventArgs) Handles TblEmpeadoBindingNavigator.LocationChanged
    End Sub

    Private Sub TblEmpeadoBindingSource_PositionChanged(sender As Object, e As EventArgs) Handles TblEmpeadoBindingSource.PositionChanged
        Try
            Dim stream As System.IO.MemoryStream
            Dim Img As System.Drawing.Image
            If TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).Firma IsNot Nothing Then
                Dim imageConverter As New System.Drawing.ImageConverter()
                Dim ImgByte As Byte() = CType(TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).Firma.ToArray, Byte())
                stream = New System.IO.MemoryStream(ImgByte, 0, ImgByte.Length)
                Img = System.Drawing.Image.FromStream(stream)
                FirmaPictureBox.Image = Img 'EmpImg.Image = Img
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class