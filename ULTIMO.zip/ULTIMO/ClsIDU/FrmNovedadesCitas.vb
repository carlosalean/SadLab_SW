﻿Imports System.Windows.Forms

Public Class FrmNovedadesCitas
  Dim mstrStringConection As String
  Dim DataContext As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
  Dim mstrIntIdUsuario As Integer
  Dim mBuscar As Boolean
  Dim mintIdSede As Integer
  Dim mPermisosHC As ClsUtilidades.ClsPermisos.ClsHistoriasClinicas

  Sub New(ByVal strStringConection As String, ByVal pstrIntIdUsuario As Integer, ByVal pintIdSede As Integer, ByVal pPermisosHC As ClsUtilidades.ClsPermisos.ClsHistoriasClinicas)
    Try
      ' This call is required by the Windows Form Designer.
      InitializeComponent()

      ' Add any initialization after the InitializeComponent() call.
      mstrStringConection = strStringConection
      mstrIntIdUsuario = pstrIntIdUsuario
      mintIdSede = pintIdSede
      'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
      If Not pPermisosHC Is Nothing Then
        CrearOVerificarHistoriaClinicaToolStripMenuItem.Visible = pPermisosHC.Crear Or pPermisosHC.Modificar
      End If

      mPermisosHC = pPermisosHC

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxProfesional.CheckedChanged
    ComboBoxProfesional.SelectedIndex = -1
    ComboBoxProfesional.Enabled = CheckBoxProfesional.Checked
  End Sub

  Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBoxPaciente.CheckedChanged
    TextBoxPaciente.Text = ""
    TextBoxPaciente.Enabled = CheckBoxPaciente.Checked
  End Sub

  Private Sub FrmNovedadesCitas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Try
      Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
      mBuscar = False
      DataContext = dc
      TextBoxPaciente.Text = ""
      DateTimePickerFecha.Value = Now
      ComboBoxProfesional.SelectedIndex = -1
      EstadoToolStripComboBox.SelectedIndex = 0
      ToolStripComboBoxSede.ComboBox.DataSource = dc.tblSedes
      ToolStripComboBoxSede.ComboBox.DisplayMember = "strNombreSede"
      ToolStripComboBoxSede.ComboBox.ValueMember = "intIdSede"
      ToolStripComboBoxSede.ComboBox.SelectedIndex = mintIdSede

      Dim tblEmpleados = (From p In dc.tblEmpeados Where p.bitActivo = True Select p)
      TblEmpeadoBindingSource.DataSource = tblEmpleados

      'TblEmpeadoBindingSource.DataSource = dc.tblEmpeados

      Dim mProfesional As Integer = 0
      Dim tmpProfesional = (From p In dc.tblUsuarios Where p.intIdUsuario = mstrIntIdUsuario And p.bitActivo = True Select p.intidEmpleado).Single
      If Not tmpProfesional Is Nothing Then
        mProfesional = tmpProfesional
        ComboBoxProfesional.SelectedValue = mProfesional
      End If
      mBuscar = True
            ToolStripComboBox1.ComboBox.SelectedIndex = 0
            PrBuscar()
        Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub
  Private Sub PrBuscar()
    Try
      If mBuscar = True Then

        Dim dc2 As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
        Dim tmpCitas = dc2.usp_NovedadesCitas_Mejor(EstadoToolStripComboBox.SelectedIndex, IIf(FechaCheckBox.Checked, DateTimePickerFecha.Value, Nothing), IIf(CheckBoxProfesional.Checked, TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).intIdCodigoEmpleado, Nothing), IIf(CheckBoxPaciente.Checked, TextBoxPaciente.Text, Nothing), ToolStripComboBoxSede.ComboBox.SelectedValue) ', ToolStripComboBoxSede.ComboBox.SelectedValue))

        TblCitaBindingSource.DataSource = tmpCitas

        'DataContext = dc2
        'Dim Empleado As Integer
        'Dim mFecha As Date
        'Dim mEstado As Integer
        'Dim mEstado2 As Integer

        'Dim Paciente As String

        'Dim tmpPacientes = (From p In dc2.tblPacientes _
        '        Select p.strNroIdentificacion, _
        '        strPrimerNombre = p.strPrimerNombre & " " & IIf(p.strSegundoNombre Is Nothing, "", p.strSegundoNombre) & " " & p.strPrimerApellido & " " & IIf(p.strSegundoApellido Is Nothing, "", p.strSegundoApellido))
        'TblPacienteBindingSource.DataSource = tmpPacientes
        'TblProcedimientoBindingSource.DataSource = dc2.tblProcedimientos
        'TblUsuarioBindingSource.DataSource = dc2.tblUsuario
        'TblUsuarioBindingSource1.DataSource = dc2.tblUsuario
        'Dim Estado = (From p In dc2.tblTipos _
        '    Where p.strTipo = "ESTADO_CITA")
        'TblTipoBindingSource.DataSource = Estado

        'If EstadoToolStripComboBox.SelectedIndex = 0 Then
        '    mEstado = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Asignada").ReturnValue
        '    mEstado2 = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Esperando").ReturnValue
        'End If
        'If EstadoToolStripComboBox.SelectedIndex = 1 Then
        '    mEstado = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Cumplida").ReturnValue
        '    mEstado2 = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Facturada").ReturnValue
        'End If
        'If EstadoToolStripComboBox.SelectedIndex = 2 Then
        '    mEstado = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Cancelada").ReturnValue
        '    mEstado2 = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Cancelada").ReturnValue
        'End If

        'mFecha = DateTimePickerFecha.Value.Date
        'Empleado = TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).intIdCodigoEmpleado

        'Paciente = TextBoxPaciente.Text
        'If FechaCheckBox.Checked And CheckBox1.Checked And CheckBox2.Checked Then
        '    If EstadoToolStripComboBox.SelectedIndex = 0 Then
        '        Dim tblCita = (From p In dc2.tblCitas Join em In dc2.tblPacientes Join ep In dc2.tblEPs On em.intIdEps Equals ep.intIdEPS On p.strNroIdPaciente Equals em.strNroIdentificacion _
        '        Where p.intIdProfesional = Empleado _
        '            And p.dtmFecha.Date = mFecha _
        '            And p.strNroIdPaciente = Paciente _
        '            And (mEstado = p.intIdEstadoCita Or mEstado2 = p.intIdEstadoCita Or p.intIdEstadoCita Is Nothing) _
        '                Order By p.dtmHora Select p.intIdCita, p.dtmHora, p.intIdUsuario, p.dtmFecha, p.intIdEstadoCita, p.strNroIdPaciente, p.intIdProcedimiento, p.intIdProfesional, p.strObservacion, p.intIdCausaCancela, p.intIdUsuarioCancela, ep.strNombre, em.strTelefonos) '_
        '        TblCitaBindingSource.DataSource = tblCita
        '    Else
        '        Dim tblCita = (From p In dc2.tblCitas Join em In dc2.tblPacientes Join ep In dc2.tblEPs On em.intIdEps Equals ep.intIdEPS On p.strNroIdPaciente Equals em.strNroIdentificacion _
        '        Where p.intIdProfesional = Empleado _
        '            And p.dtmFecha.Date = mFecha _
        '            And p.strNroIdPaciente = Paciente _
        '            And (mEstado = p.intIdEstadoCita Or mEstado2 = p.intIdEstadoCita) _
        '                Order By p.dtmHora Select p.intIdCita, p.dtmHora, p.intIdUsuario, p.dtmFecha, p.intIdEstadoCita, p.strNroIdPaciente, p.intIdProcedimiento, p.intIdProfesional, p.strObservacion, p.intIdCausaCancela, p.intIdUsuarioCancela, ep.strNombre, em.strTelefonos) '_
        '        TblCitaBindingSource.DataSource = tblCita
        '    End If
        'Else
        '    If FechaCheckBox.Checked And CheckBox1.Checked Then
        '        'Dim tblCita = (From p In dc2.tblCitas _
        '        If EstadoToolStripComboBox.SelectedIndex = 0 Then
        '            Dim tblCita = (From p In dc2.tblCitas Join em In dc2.tblPacientes Join ep In dc2.tblEPs On em.intIdEps Equals ep.intIdEPS On p.strNroIdPaciente Equals em.strNroIdentificacion _
        '            Where p.intIdProfesional = Empleado _
        '                And p.dtmFecha.Date = mFecha _
        '                And (mEstado = p.intIdEstadoCita Or mEstado2 = p.intIdEstadoCita Or p.intIdEstadoCita Is Nothing) _
        '                Order By p.dtmHora Select p.intIdCita, p.dtmHora, p.intIdUsuario, p.dtmFecha, p.intIdEstadoCita, p.strNroIdPaciente, p.intIdProcedimiento, p.intIdProfesional, p.strObservacion, p.intIdCausaCancela, p.intIdUsuarioCancela, ep.strNombre, em.strTelefonos) '_
        '            TblCitaBindingSource.DataSource = tblCita
        '        Else
        '            Dim tblCita = (From p In dc2.tblCitas Join em In dc2.tblPacientes Join ep In dc2.tblEPs On em.intIdEps Equals ep.intIdEPS On p.strNroIdPaciente Equals em.strNroIdentificacion _
        '            Where p.intIdProfesional = Empleado _
        '                And p.dtmFecha.Date = mFecha _
        '                And (mEstado = p.intIdEstadoCita Or mEstado2 = p.intIdEstadoCita) _
        '                Order By p.dtmHora Select p.intIdCita, p.dtmHora, p.intIdUsuario, p.dtmFecha, p.intIdEstadoCita, p.strNroIdPaciente, p.intIdProcedimiento, p.intIdProfesional, p.strObservacion, p.intIdCausaCancela, p.intIdUsuarioCancela, ep.strNombre, em.strTelefonos) '_
        '            TblCitaBindingSource.DataSource = tblCita
        '        End If
        '    Else
        '        If FechaCheckBox.Checked And CheckBox2.Checked Then
        '            If EstadoToolStripComboBox.SelectedIndex = 0 Then
        '                Dim tblCita = (From p In dc2.tblCitas Join em In dc2.tblPacientes Join ep In dc2.tblEPs On em.intIdEps Equals ep.intIdEPS On p.strNroIdPaciente Equals em.strNroIdentificacion _
        '                Where p.dtmFecha.Date = mFecha _
        '                    And p.strNroIdPaciente = Paciente _
        '                    And (mEstado = p.intIdEstadoCita Or mEstado2 = p.intIdEstadoCita Or p.intIdEstadoCita Is Nothing) _
        '                Order By p.dtmHora Select p.intIdCita, p.dtmHora, p.intIdUsuario, p.dtmFecha, p.intIdEstadoCita, p.strNroIdPaciente, p.intIdProcedimiento, p.intIdProfesional, p.strObservacion, p.intIdCausaCancela, p.intIdUsuarioCancela, ep.strNombre, em.strTelefonos) '_
        '                TblCitaBindingSource.DataSource = tblCita
        '            Else
        '                Dim tblCita = (From p In dc2.tblCitas Join em In dc2.tblPacientes Join ep In dc2.tblEPs On em.intIdEps Equals ep.intIdEPS On p.strNroIdPaciente Equals em.strNroIdentificacion _
        '                Where p.dtmFecha.Date = mFecha _
        '                    And p.strNroIdPaciente = Paciente _
        '                    And (mEstado = p.intIdEstadoCita Or mEstado2 = p.intIdEstadoCita) _
        '                Order By p.dtmHora Select p.intIdCita, p.dtmHora, p.intIdUsuario, p.dtmFecha, p.intIdEstadoCita, p.strNroIdPaciente, p.intIdProcedimiento, p.intIdProfesional, p.strObservacion, p.intIdCausaCancela, p.intIdUsuarioCancela, ep.strNombre, em.strTelefonos) '_
        '                TblCitaBindingSource.DataSource = tblCita
        '            End If
        '        Else
        '            If CheckBox2.Checked Then
        '                If EstadoToolStripComboBox.SelectedIndex = 0 Then
        '                    Dim tblCita = (From p In dc2.tblCitas Join em In dc2.tblPacientes Join ep In dc2.tblEPs On em.intIdEps Equals ep.intIdEPS On p.strNroIdPaciente Equals em.strNroIdentificacion _
        '                    Where p.strNroIdPaciente = Paciente _
        '                    And (mEstado = p.intIdEstadoCita Or mEstado2 = p.intIdEstadoCita Or p.intIdEstadoCita Is Nothing) _
        '                    Order By p.dtmFecha, p.dtmHora Select p.intIdCita, p.dtmHora, p.intIdUsuario, p.dtmFecha, p.intIdEstadoCita, p.strNroIdPaciente, p.intIdProcedimiento, p.intIdProfesional, p.strObservacion, p.intIdCausaCancela, p.intIdUsuarioCancela, ep.strNombre, em.strTelefonos) '_
        '                    TblCitaBindingSource.DataSource = tblCita
        '                Else
        '                    Dim tblCita = (From p In dc2.tblCitas Join em In dc2.tblPacientes Join ep In dc2.tblEPs On em.intIdEps Equals ep.intIdEPS On p.strNroIdPaciente Equals em.strNroIdentificacion _
        '                    Where p.strNroIdPaciente = Paciente _
        '                    And (mEstado = p.intIdEstadoCita Or mEstado2 = p.intIdEstadoCita) _
        '                    Order By p.dtmFecha, p.dtmHora Select p.intIdCita, p.dtmHora, p.intIdUsuario, p.dtmFecha, p.intIdEstadoCita, p.strNroIdPaciente, p.intIdProcedimiento, p.intIdProfesional, p.strObservacion, p.intIdCausaCancela, p.intIdUsuarioCancela, ep.strNombre, em.strTelefonos) '_
        '                    TblCitaBindingSource.DataSource = tblCita
        '                End If
        '            End If
        '        End If
        '    End If
        'End If
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ButtonBuscar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonBuscar.Click
    PrBuscar()
  End Sub

  Private Sub TblCitaBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

  End Sub

  Private Sub FechaCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FechaCheckBox.CheckedChanged
    DateTimePickerFecha.Enabled = FechaCheckBox.Checked
  End Sub

  Private Sub TblCitaDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblCitaDataGridView.DataError
    Try
      'No hace nada
    Catch ex As Exception
      'No hace nada
    End Try
  End Sub

  Private Sub CancelarContextMenuStrip_Opening(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles CancelarContextMenuStrip.Opening

  End Sub

  Private Sub CancelarContextMenuStrip_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles CancelarContextMenuStrip.MouseClick
  End Sub

  Private Sub CancelarCitaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelarCitaToolStripMenuItem.Click
    Try
      If (TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita.ToString() = "Asignada") Or (TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita.ToString() = "Confirmada") Or (TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita.ToString() = "Esperando") Or (TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita.ToString().Trim.Length = 0) Then
        If MsgBox("Confirmación de cancelación cita: " & Chr(13) &
                  "Fecha : " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmFecha.ToString() & Chr(13) &
                  "Hora : " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmHora.ToString() & Chr(13) &
                  "Medico: " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).strProfesional & Chr(13) &
                  "Examen: " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).strProcedimiento, MsgBoxStyle.OkCancel + MsgBoxStyle.Information) = MsgBoxResult.Ok Then
          '"Paciente: " & TblPacienteBindingSource.Item(   Item(TblPacienteBindingSource.Position).strPrimerNombre & Chr(13) & _
          Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
          If mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Dim dc2 As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            dc2.usp_CancelarCita(TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdCita, mValidaHuella.mstrIntIdUsuario)
            MsgBox("La cita fué cancelada de forma satisfactoria..")
            PrBuscar()
          Else
            MsgBox("La cita no fué cancelada..")
          End If
        End If
      Else
        MsgBox("La cita no se puede cancelar..")
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub DateTimePickerFecha_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateTimePickerFecha.ValueChanged
  End Sub

  Private Sub ComboBoxProfesional_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxProfesional.SelectedIndexChanged
    If ComboBoxProfesional.SelectedIndex >= 0 Then
      PrBuscar()
    End If
  End Sub

  Private Sub TextBoxPaciente_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBoxPaciente.KeyUp
    If e.KeyCode = Windows.Forms.Keys.Enter Then
      PrBuscar()
    End If
  End Sub

  Private Sub EstadoToolStripComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EstadoToolStripComboBox.SelectedIndexChanged
    Try
      PrBuscar()
    Catch ex As Exception
      'No hace nada
    End Try
  End Sub

  Private Sub ToolStripComboBoxSede_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripComboBoxSede.SelectedIndexChanged
    Try
      PrBuscar()
    Catch ex As Exception
      'No hace nada
    End Try
  End Sub

  Private Sub CrearOVerificarHistoriaClinicaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrearOVerificarHistoriaClinicaToolStripMenuItem.Click
    Try
      Dim idcita = TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdCita
      If Application.OpenForms("FrmHistoriaClinica") Is Nothing Then
        Dim mDate As Date = (From p In DataContext.tblCita Where p.intIdCita.Equals(idcita) Select p.dtmFecha).Single
        Dim mFrmHistoriaClinica As New ClsIDU.FrmHistoriaClinica(mstrStringConection, mstrIntIdUsuario, idcita, TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNroIdPaciente, TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNombrePaciente, mDate)
        Try
          mFrmHistoriaClinica.MdiParent = Me.MdiParent
          mFrmHistoriaClinica.Show()
        Catch ex As Exception
          mFrmHistoriaClinica.Close()
        End Try
      Else
        Application.OpenForms("FrmHistoriaClinica").BringToFront()
      End If
    Catch ex As Exception
      'ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ConfirmaCitaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConfirmaCitaToolStripMenuItem.Click
    Try
      If (TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita.ToString() = "Asignada") Or (TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita.ToString().Trim.Length = 0) Then
        If MsgBox("Confirmación cita: " & Chr(13) &
                  "Fecha : " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmFecha.ToString() & Chr(13) &
                  "Hora : " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).dtmHora.ToString() & Chr(13) &
                  "Medico: " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).strProfesional & Chr(13) &
                  "Examen: " & TblCitaBindingSource.Item(TblCitaBindingSource.Position).strProcedimiento, MsgBoxStyle.OkCancel + MsgBoxStyle.Information) = MsgBoxResult.Ok Then
          Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
          If mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Dim dc2 As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            dc2.usp_ConfirmarCita(TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdCita, mValidaHuella.mstrIntIdUsuario)
            MsgBox("La cita fué confirmada de forma satisfactoria..")
            PrBuscar()
          Else
            MsgBox("La cita no fué confirmada..")
          End If
        End If
      Else
        MsgBox("La cita no se puede confirmar..")
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ImprimirFacturaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImprimirFacturaToolStripMenuItem.Click
    Try
      If Application.OpenForms("FrmFacturaMediaCarta") Is Nothing Then
        Dim mFrmFacturaMediaCarta As New ClsReportes.FrmFacturaMediaCarta(mstrStringConection, TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdCita)
        mFrmFacturaMediaCarta.Show()
      Else
        Application.OpenForms("FrmFacturaMediaCarta").BringToFront()
      End If
    Catch ex As Exception

    End Try
  End Sub

  Private Sub VerificarHistoriaClinicaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VerificarHistoriaClinicaToolStripMenuItem.Click
    Try
      Dim idcita = TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdCita
      If Application.OpenForms("FrmResumenHC") Is Nothing Then
        Dim mFrmresumenHC = New ClsReportes.FrmResumenHC(mstrStringConection, idcita, 0, mstrIntIdUsuario, TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNroIdPaciente, Now, Now, True)
        mFrmresumenHC.Show()
      Else
        Application.OpenForms("FrmResumenHC").BringToFront()
      End If
    Catch ex As Exception
      'ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub SeleccionarCitasAImprimirEnHistoriaClínicaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SeleccionarCitasAImprimirEnHistoriaClínicaToolStripMenuItem.Click
    If Application.OpenForms("FrmSeleccionarItemsImprimirHC") Is Nothing Then
      Dim mFrmresumenHC = New ClsIDU.FrmSeleccionarItemsHCImprimir(mstrStringConection, TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNroIdPaciente, mstrIntIdUsuario)
      If mFrmresumenHC.MostrarPantalla Then
        mFrmresumenHC.Show()
      End If

    Else
      Application.OpenForms("FrmSeleccionarItemsImprimirHC").BringToFront()
    End If
  End Sub

    Private Sub ToolStripComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ToolStripComboBox1.SelectedIndexChanged
        Try
            Dim mFont As New Drawing.Font(vbCurrency, ToolStripComboBox1.ComboBox.SelectedItem.ToString) '= TblCitaDataGridView.Columns.Item(1).DefaultCellStyle.Font
            Dim i As Integer = 0
            For Each mCol In TblCitaDataGridView.Columns
                TblCitaDataGridView.Columns.Item(i).DefaultCellStyle.Font = mFont ''ToolStripComboBox1.ComboBox.SelectedValue
                i = i + 1
            Next
        Catch ex As Exception

        End Try
    End Sub
End Class