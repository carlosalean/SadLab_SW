﻿Imports System.Windows.Forms

Public Class uscEvolucionVisita
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mHC As Integer
    Private _btn As Windows.Forms.Button
    Private _IdUsuario As String
    Private mNuevo As Boolean
    Private _mstrStringConection As String
    Private _mCita As Integer

    Public Sub New()

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub



    Public Property mstrStringConection() As String
        Get
            Return _mstrStringConection
        End Get
        Set(ByVal value As String)
            _mstrStringConection = value
        End Set
    End Property

    Public Property mCita() As Integer
        Get
            Return _mCita
        End Get
        Set(ByVal value As Integer)
            _mCita = value
        End Set
    End Property

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mHC() As Integer
        Get
            Return _mHC
        End Get
        Set(ByVal value As Integer)
            _mHC = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub CargarItemEvolucionHC()
        Try
            PrCargarDatosEvolucionHC()

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub PrCargarDatosEvolucionHC()
        Try
            Dim mEvolucion = (From e In dc.tblEvolucionHCs Where e.intidHC = mHC Select e)

            If mEvolucion.Count = 0 Then
                mNuevo = True
                TblEvolucionHCBindingSource.AddNew()
            Else
                mNuevo = False
                TblEvolucionHCBindingSource.DataSource = mEvolucion
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblEvolucionHCBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblEvolucionHCBindingNavigatorSaveItem.Click
        prGuardar()
    End Sub
    Public Sub prGuardar() Implements IAbandonarUC.prGuardar

        Try
            If TblEvolucionHCBindingSource.Position = 0 And mNuevo = True Then
                TblEvolucionHCBindingSource.Item(TblEvolucionHCBindingSource.Position).Strdescripcion = StrdescripcionTextBox.Text
                TblEvolucionHCBindingSource.Item(TblEvolucionHCBindingSource.Position).intidHC = mHC
                TblEvolucionHCBindingSource.EndEdit()
                If mNuevo = True Then
                    dc.tblEvolucionHCs.InsertOnSubmit(TblEvolucionHCBindingSource.Item(TblEvolucionHCBindingSource.Position))
                End If
                dc.SubmitChanges()
                mNuevo = False
            Else
                TblEvolucionHCBindingSource.EndEdit()
                dc.SubmitChanges()
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub uscEvolucionVisita_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        prGuardar()
    End Sub

    Private Sub ToolStripButtonImprimir_Click(sender As Object, e As EventArgs) Handles ToolStripButtonImprimir.Click
        If Application.OpenForms("FrmAnexosHC") Is Nothing Then
            Dim mFrmresumenHC = New ClsReportes.FrmAnexosHC(Me.mstrStringConection, Me.mCita, Me.mHC, 3)
            mFrmresumenHC.Show()
        Else
            Application.OpenForms("FrmAnexosHC").BringToFront()
        End If
    End Sub
End Class
