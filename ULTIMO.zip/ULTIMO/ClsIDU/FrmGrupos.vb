﻿Imports System.Windows.Forms
Imports System.Data
Imports System.Data.SqlClient
Public Class FrmGrupos
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mtmpMenu As Object
    Dim mstrStringConection As String
    Dim mConetion As System.Data.SqlClient.SqlConnection

    Sub New(ByVal strStringConection As String, ByVal mMenu As Object)

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
        mConetion = New System.Data.SqlClient.SqlConnection(strStringConection)
        mtmpMenu = mMenu
        mstrStringConection = strStringConection
    End Sub

    Private Sub FrmGrupos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TblGrupoBindingSource.DataSource = dc.tblGrupo
            mConetion.Open()

            Dim _ClsAsignarAccesos As New ClsAsignarAccesos.ClsAsignacionAccesos()
            _ClsAsignarAccesos.PrLlenarTreeViewAccesos(CType(mtmpMenu, System.Windows.Forms.MenuStrip), TrVwAccesos)
            Dim _ClsAccesosMenu As New ClsAsignarAccesos.ClsAccesosMenu()
            If TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString().Length > 0 Then _ClsAccesosMenu.PrAsignarMenu(TrVwAccesos, TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString(), mConetion)


        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblGrupoBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblGrupoBindingNavigatorSaveItem.Click
        Try
            TblGrupoBindingSource.EndEdit()
            dc.SubmitChanges()

            Dim _ClsAccesosMenu As New ClsAsignarAccesos.ClsAccesosMenu()
            _ClsAccesosMenu.PrBorrarAccesosMenu(TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString(), mConetion)
            For Each mNode As System.Windows.Forms.TreeNode In TrVwAccesos.Nodes
                If TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString().Length > 0 Then _ClsAccesosMenu.PrGrabarAccesosMenu(TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString(), mNode.Tag, mNode.Checked, mNode.Tag, mConetion)
                PrGrabarNodos(TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString(), mNode)
            Next mNode

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
    Private Sub PrGrabarNodos(ByVal mNivelAcceso As Int16, ByVal mNodo As TreeNode)
        Dim _ClsAccesosMenu As New ClsAsignarAccesos.ClsAccesosMenu()
        For Each mNode As System.Windows.Forms.TreeNode In mNodo.Nodes
            _ClsAccesosMenu.PrGrabarAccesosMenu(mNivelAcceso, mNode.Tag, mNode.Checked, mNode.Parent.Tag, mConetion)
            PrGrabarNodos(mNivelAcceso, mNode)
        Next mNode
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub

    Private Sub TrVwAccesos_AfterCheck(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs)
        For Each mNode As System.Windows.Forms.TreeNode In e.Node.Nodes
            mNode.Checked = e.Node.Checked
        Next mNode
    End Sub

    Private Sub TblGrupoBindingSource_CurrentItemChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblGrupoBindingSource.CurrentItemChanged
        Try
            Dim _ClsAccesosMenu As New ClsAsignarAccesos.ClsAccesosMenu()
            If TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString().Length > 0 Then _ClsAccesosMenu.PrAsignarMenu(TrVwAccesos, TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString(), mConetion)
        Catch ex As Exception
            'No muestra error
        End Try
    End Sub

    Private Sub BindingNavigatorDeleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorDeleteItem.Click
        Try
            Dim _ClsAccesosMenu As New ClsAsignarAccesos.ClsAccesosMenu()
            If TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString().Length > 0 Then _ClsAccesosMenu.PrBorrarAccesosMenu(TblGrupoBindingSource.Item(TblGrupoBindingSource.Position).IntIdGrupo.ToString(), mConetion)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class