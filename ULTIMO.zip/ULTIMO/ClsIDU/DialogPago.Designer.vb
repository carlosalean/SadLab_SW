﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DialogPago
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.ClsTextBoxValorPagado = New ClsUtilidades.ClsTextBox()
        Me.ClsTextBoxEfectivo = New ClsUtilidades.ClsTextBox()
        Me.ClsTextBoxDevuelta = New ClsUtilidades.ClsTextBox()
        Me.ClsComboBoxPrestador = New ClsUtilidades.ClsComboBox()
        Me.TblDatosPrestadoresBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ClsCheckBoxCoopago = New ClsUtilidades.ClsCheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox = New System.Windows.Forms.GroupBox()
        Me.MsjNegativo = New System.Windows.Forms.Label()
        Me.cmbMedioPago = New ClsUtilidades.ClsComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox.SuspendLayout()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(171, 200)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "Aceptar"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancelar"
        '
        'ClsTextBoxValorPagado
        '
        Me.ClsTextBoxValorPagado.DataSource = Nothing
        Me.ClsTextBoxValorPagado.EnterEntreCampos = True
        Me.ClsTextBoxValorPagado.Location = New System.Drawing.Point(105, 69)
        Me.ClsTextBoxValorPagado.Name = "ClsTextBoxValorPagado"
        Me.ClsTextBoxValorPagado.NombreCodigoF2 = Nothing
        Me.ClsTextBoxValorPagado.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxValorPagado.Size = New System.Drawing.Size(100, 20)
        Me.ClsTextBoxValorPagado.TabIndex = 2
        Me.ClsTextBoxValorPagado.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'ClsTextBoxEfectivo
        '
        Me.ClsTextBoxEfectivo.DataSource = Nothing
        Me.ClsTextBoxEfectivo.EnterEntreCampos = True
        Me.ClsTextBoxEfectivo.Location = New System.Drawing.Point(105, 95)
        Me.ClsTextBoxEfectivo.Name = "ClsTextBoxEfectivo"
        Me.ClsTextBoxEfectivo.NombreCodigoF2 = Nothing
        Me.ClsTextBoxEfectivo.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxEfectivo.Size = New System.Drawing.Size(100, 20)
        Me.ClsTextBoxEfectivo.TabIndex = 3
        Me.ClsTextBoxEfectivo.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Moneda
        '
        'ClsTextBoxDevuelta
        '
        Me.ClsTextBoxDevuelta.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.ClsTextBoxDevuelta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ClsTextBoxDevuelta.DataSource = Nothing
        Me.ClsTextBoxDevuelta.Enabled = False
        Me.ClsTextBoxDevuelta.EnterEntreCampos = True
        Me.ClsTextBoxDevuelta.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClsTextBoxDevuelta.Location = New System.Drawing.Point(105, 121)
        Me.ClsTextBoxDevuelta.Name = "ClsTextBoxDevuelta"
        Me.ClsTextBoxDevuelta.NombreCodigoF2 = Nothing
        Me.ClsTextBoxDevuelta.NombreDescripcionF2 = Nothing
        Me.ClsTextBoxDevuelta.Size = New System.Drawing.Size(100, 20)
        Me.ClsTextBoxDevuelta.TabIndex = 4
        Me.ClsTextBoxDevuelta.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Moneda
        '
        'ClsComboBoxPrestador
        '
        Me.ClsComboBoxPrestador.DataSource = Me.TblDatosPrestadoresBindingSource
        Me.ClsComboBoxPrestador.DisplayMember = "strRazonSocial"
        Me.ClsComboBoxPrestador.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ClsComboBoxPrestador.FormattingEnabled = True
        Me.ClsComboBoxPrestador.Location = New System.Drawing.Point(105, 14)
        Me.ClsComboBoxPrestador.Name = "ClsComboBoxPrestador"
        Me.ClsComboBoxPrestador.Size = New System.Drawing.Size(193, 21)
        Me.ClsComboBoxPrestador.TabIndex = 0
        Me.ClsComboBoxPrestador.ValueMember = "intIdPrestadores"
        '
        'TblDatosPrestadoresBindingSource
        '
        Me.TblDatosPrestadoresBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDatosPrestadores)
        Me.TblDatosPrestadoresBindingSource.Sort = "strRazonSocial"
        '
        'ClsCheckBoxCoopago
        '
        Me.ClsCheckBoxCoopago.AutoSize = True
        Me.ClsCheckBoxCoopago.Location = New System.Drawing.Point(105, 147)
        Me.ClsCheckBoxCoopago.Name = "ClsCheckBoxCoopago"
        Me.ClsCheckBoxCoopago.Size = New System.Drawing.Size(15, 14)
        Me.ClsCheckBoxCoopago.TabIndex = 5
        Me.ClsCheckBoxCoopago.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Prestador servicio:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 13)
        Me.Label2.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Valor pagado:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(8, 99)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Efectivo:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 125)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Devuelta"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 148)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Es coopago"
        '
        'GroupBox
        '
        Me.GroupBox.Controls.Add(Me.Label7)
        Me.GroupBox.Controls.Add(Me.cmbMedioPago)
        Me.GroupBox.Controls.Add(Me.MsjNegativo)
        Me.GroupBox.Controls.Add(Me.Label1)
        Me.GroupBox.Controls.Add(Me.Label6)
        Me.GroupBox.Controls.Add(Me.ClsTextBoxValorPagado)
        Me.GroupBox.Controls.Add(Me.Label5)
        Me.GroupBox.Controls.Add(Me.ClsTextBoxEfectivo)
        Me.GroupBox.Controls.Add(Me.Label4)
        Me.GroupBox.Controls.Add(Me.ClsTextBoxDevuelta)
        Me.GroupBox.Controls.Add(Me.Label3)
        Me.GroupBox.Controls.Add(Me.ClsComboBoxPrestador)
        Me.GroupBox.Controls.Add(Me.ClsCheckBoxCoopago)
        Me.GroupBox.Location = New System.Drawing.Point(9, 5)
        Me.GroupBox.Name = "GroupBox"
        Me.GroupBox.Size = New System.Drawing.Size(306, 181)
        Me.GroupBox.TabIndex = 12
        Me.GroupBox.TabStop = False
        '
        'MsjNegativo
        '
        Me.MsjNegativo.AutoSize = True
        Me.MsjNegativo.ForeColor = System.Drawing.Color.Red
        Me.MsjNegativo.Location = New System.Drawing.Point(211, 125)
        Me.MsjNegativo.Name = "MsjNegativo"
        Me.MsjNegativo.Size = New System.Drawing.Size(82, 13)
        Me.MsjNegativo.TabIndex = 12
        Me.MsjNegativo.Text = "* Valor negativo"
        Me.MsjNegativo.Visible = False
        '
        'cmbMedioPago
        '
        Me.cmbMedioPago.DataSource = Me.TblTipoBindingSource
        Me.cmbMedioPago.DisplayMember = "strValor"
        Me.cmbMedioPago.FormattingEnabled = True
        Me.cmbMedioPago.Location = New System.Drawing.Point(105, 42)
        Me.cmbMedioPago.Name = "cmbMedioPago"
        Me.cmbMedioPago.Size = New System.Drawing.Size(193, 21)
        Me.cmbMedioPago.TabIndex = 1
        Me.cmbMedioPago.ValueMember = "intIdTipo"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(8, 45)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(82, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Medio de Pago:"
        '
        'TblTipoBindingSource
        '
        Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'DialogPago
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(323, 238)
        Me.Controls.Add(Me.GroupBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DialogPago"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Pagos"
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.TblDatosPrestadoresBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox.ResumeLayout(False)
        Me.GroupBox.PerformLayout()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents ClsTextBoxValorPagado As ClsUtilidades.ClsTextBox
    Friend WithEvents ClsTextBoxEfectivo As ClsUtilidades.ClsTextBox
    Friend WithEvents ClsTextBoxDevuelta As ClsUtilidades.ClsTextBox
    Friend WithEvents ClsComboBoxPrestador As ClsUtilidades.ClsComboBox
    Friend WithEvents ClsCheckBoxCoopago As ClsUtilidades.ClsCheckBox
    Friend WithEvents TblDatosPrestadoresBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents MsjNegativo As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmbMedioPago As ClsUtilidades.ClsComboBox
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource

End Class
