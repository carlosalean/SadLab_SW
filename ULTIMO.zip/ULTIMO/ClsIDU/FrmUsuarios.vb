﻿Public Class FrmUsuarios
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mTemplate(3)

    Sub New(ByVal strStringConection As String)
        Try

            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmUsuarios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TblUsuarioBindingSource.DataSource = dc.tblUsuarios
            TblGrupoBindingSource.DataSource = dc.tblGrupo
            TblEmpeadoBindingSource.DataSource = dc.tblEmpeados
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblUsuarioBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblUsuarioBindingNavigatorSaveItem.Click
        Try
            Dim bytes As Byte() = Nothing
            Dim mTemplatetmp As DPFP.Template

            If TypeOf mTemplate(0) Is DPFP.Template Then
                mTemplatetmp = mTemplate(0)
                mTemplatetmp.Serialize(bytes)
                If Not mTemplate(0) Is Nothing Then TblUsuarioBindingSource.Item(TblUsuarioBindingSource.Position).byTemplate1 = mTemplate(0)
            Else
                If Not mTemplate(0) Is Nothing Then TblUsuarioBindingSource.Item(TblUsuarioBindingSource.Position).byTemplate1 = mTemplate(0)
            End If
            If TypeOf mTemplate(1) Is DPFP.Template Then
                mTemplatetmp = mTemplate(1)
                mTemplatetmp.Serialize(bytes)
                If Not mTemplate(1) Is Nothing Then TblUsuarioBindingSource.Item(TblUsuarioBindingSource.Position).byTemplate2 = mTemplate(1)
            Else
                If Not mTemplate(1) Is Nothing Then TblUsuarioBindingSource.Item(TblUsuarioBindingSource.Position).byTemplate2 = mTemplate(1)
            End If
            If TypeOf mTemplate(2) Is DPFP.Template Then
                mTemplatetmp = mTemplate(2)
                mTemplatetmp.Serialize(bytes)
                If Not mTemplate(2) Is Nothing Then TblUsuarioBindingSource.Item(TblUsuarioBindingSource.Position).byTemplate3 = mTemplate(2)
            Else
                If Not mTemplate(2) Is Nothing Then TblUsuarioBindingSource.Item(TblUsuarioBindingSource.Position).byTemplate3 = mTemplate(2)
            End If
            If TypeOf mTemplate(3) Is DPFP.Template Then
                mTemplatetmp = mTemplate(3)
                mTemplatetmp.Serialize(bytes)
                If Not mTemplate(3) Is Nothing Then TblUsuarioBindingSource.Item(TblUsuarioBindingSource.Position).byTemplate4 = bytes
            Else
                If Not mTemplate(3) Is Nothing Then TblUsuarioBindingSource.Item(TblUsuarioBindingSource.Position).byTemplate4 = mTemplate(3)
            End If


            TblUsuarioBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub

    Private Sub ButtonHuella_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonHuella.Click
        Try
            Dim mDetectar As New DlgRegistroHuella()
            If mDetectar.ShowDialog() = Windows.Forms.DialogResult.OK Then
                Dim bytes As Byte() = Nothing
                If Not mDetectar.Templates(0) Is Nothing Then
                    mDetectar.Templates(0).Serialize(bytes)
                    mTemplate(0) = bytes
                End If
                bytes = Nothing
                If Not mDetectar.Templates(1) Is Nothing Then
                    mDetectar.Templates(1).Serialize(bytes)
                    mTemplate(1) = bytes
                End If
                bytes = Nothing
                If Not mDetectar.Templates(2) Is Nothing Then
                    mDetectar.Templates(2).Serialize(bytes)
                    mTemplate(2) = bytes
                End If
                bytes = Nothing
                If Not mDetectar.Templates(3) Is Nothing Then
                    mDetectar.Templates(3).Serialize(bytes)
                    mTemplate(3) = bytes
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BitEsSuperUsuarioClsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BitEsSuperUsuarioClsCheckBox.CheckedChanged
        StrClaveSuperUsuarioClsTextBox.Enabled = BitEsSuperUsuarioClsCheckBox.Checked
    End Sub

End Class