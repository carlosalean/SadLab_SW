﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmGenericos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DblDosificacionmayorLabel As System.Windows.Forms.Label
        Dim DblDosificacionMediaLabel As System.Windows.Forms.Label
        Dim DblDosificacionMinimaLabel As System.Windows.Forms.Label
        Dim DblDosificacionPediatricaLabel As System.Windows.Forms.Label
        Dim IntIdDosificacionLabel As System.Windows.Forms.Label
        Dim IntIdFrecuenciaDosificacionLabel As System.Windows.Forms.Label
        Dim IntIdMedicamentosLabel As System.Windows.Forms.Label
        Dim IntIdMedicamentosGenericosLabel As System.Windows.Forms.Label
        Dim StrAccionLabel As System.Windows.Forms.Label
        Dim StrContraindicacionesLabel As System.Windows.Forms.Label
        Dim StrdescripcionLabel As System.Windows.Forms.Label
        Dim StrInteraccionesLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmGenericos))
        Me.TblMedicamentosGenericosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblMedicamentosGenericosBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblMedicamentosGenericosBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.DblDosificacionmayorClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.DblDosificacionMediaClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.DblDosificacionMinimaClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.DblDosificacionPediatricaClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdDosificacionClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdFrecuenciaDosificacionClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdMedicamentosClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblMedicamentosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdMedicamentosGenericosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrAccionClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrContraindicacionesClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrdescripcionClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrInteraccionesClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TblNombresComercialesDataGridView = New System.Windows.Forms.DataGridView()
        Me.intIdNombresComerciales = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.strDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Detalle = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.IntIdNombresComercialesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrDescripcionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdMedicamentosGenericosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdTipoPresentacionComercialDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntPorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdPresentacionDrograsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DblConcentracionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdMedidasDrogasDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdLaboratorioDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DblPrecioPublicoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DtmFechaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdPrincipioActivoPrincipalDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdPrincipioActivoAsociacionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblLaboratoriosfarmaceuticosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblMedicamentosGenericosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblTipoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblTipo1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblTipo2DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblPrincipiosActivosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblPrincipiosActivos1DataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        DblDosificacionmayorLabel = New System.Windows.Forms.Label()
        DblDosificacionMediaLabel = New System.Windows.Forms.Label()
        DblDosificacionMinimaLabel = New System.Windows.Forms.Label()
        DblDosificacionPediatricaLabel = New System.Windows.Forms.Label()
        IntIdDosificacionLabel = New System.Windows.Forms.Label()
        IntIdFrecuenciaDosificacionLabel = New System.Windows.Forms.Label()
        IntIdMedicamentosLabel = New System.Windows.Forms.Label()
        IntIdMedicamentosGenericosLabel = New System.Windows.Forms.Label()
        StrAccionLabel = New System.Windows.Forms.Label()
        StrContraindicacionesLabel = New System.Windows.Forms.Label()
        StrdescripcionLabel = New System.Windows.Forms.Label()
        StrInteraccionesLabel = New System.Windows.Forms.Label()
        CType(Me.TblMedicamentosGenericosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblMedicamentosGenericosBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblMedicamentosGenericosBindingNavigator.SuspendLayout()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblMedicamentosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.TblNombresComercialesDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'DblDosificacionmayorLabel
        '
        DblDosificacionmayorLabel.AutoSize = True
        DblDosificacionmayorLabel.Location = New System.Drawing.Point(44, 22)
        DblDosificacionmayorLabel.Name = "DblDosificacionmayorLabel"
        DblDosificacionmayorLabel.Size = New System.Drawing.Size(36, 13)
        DblDosificacionmayorLabel.TabIndex = 1
        DblDosificacionmayorLabel.Text = "Mayor"
        '
        'DblDosificacionMediaLabel
        '
        DblDosificacionMediaLabel.AutoSize = True
        DblDosificacionMediaLabel.Location = New System.Drawing.Point(195, 22)
        DblDosificacionMediaLabel.Name = "DblDosificacionMediaLabel"
        DblDosificacionMediaLabel.Size = New System.Drawing.Size(36, 13)
        DblDosificacionMediaLabel.TabIndex = 3
        DblDosificacionMediaLabel.Text = "Media"
        '
        'DblDosificacionMinimaLabel
        '
        DblDosificacionMinimaLabel.AutoSize = True
        DblDosificacionMinimaLabel.Location = New System.Drawing.Point(336, 22)
        DblDosificacionMinimaLabel.Name = "DblDosificacionMinimaLabel"
        DblDosificacionMinimaLabel.Size = New System.Drawing.Size(42, 13)
        DblDosificacionMinimaLabel.TabIndex = 5
        DblDosificacionMinimaLabel.Text = "Mínima"
        '
        'DblDosificacionPediatricaLabel
        '
        DblDosificacionPediatricaLabel.AutoSize = True
        DblDosificacionPediatricaLabel.Location = New System.Drawing.Point(471, 22)
        DblDosificacionPediatricaLabel.Name = "DblDosificacionPediatricaLabel"
        DblDosificacionPediatricaLabel.Size = New System.Drawing.Size(54, 13)
        DblDosificacionPediatricaLabel.TabIndex = 7
        DblDosificacionPediatricaLabel.Text = "Pediatrica"
        '
        'IntIdDosificacionLabel
        '
        IntIdDosificacionLabel.AutoSize = True
        IntIdDosificacionLabel.Location = New System.Drawing.Point(29, 74)
        IntIdDosificacionLabel.Name = "IntIdDosificacionLabel"
        IntIdDosificacionLabel.Size = New System.Drawing.Size(68, 13)
        IntIdDosificacionLabel.TabIndex = 9
        IntIdDosificacionLabel.Text = "Dosificacion:"
        '
        'IntIdFrecuenciaDosificacionLabel
        '
        IntIdFrecuenciaDosificacionLabel.AutoSize = True
        IntIdFrecuenciaDosificacionLabel.Location = New System.Drawing.Point(285, 74)
        IntIdFrecuenciaDosificacionLabel.Name = "IntIdFrecuenciaDosificacionLabel"
        IntIdFrecuenciaDosificacionLabel.Size = New System.Drawing.Size(124, 13)
        IntIdFrecuenciaDosificacionLabel.TabIndex = 11
        IntIdFrecuenciaDosificacionLabel.Text = "Frecuencia Dosificacion:"
        '
        'IntIdMedicamentosLabel
        '
        IntIdMedicamentosLabel.AutoSize = True
        IntIdMedicamentosLabel.Location = New System.Drawing.Point(17, 79)
        IntIdMedicamentosLabel.Name = "IntIdMedicamentosLabel"
        IntIdMedicamentosLabel.Size = New System.Drawing.Size(79, 13)
        IntIdMedicamentosLabel.TabIndex = 13
        IntIdMedicamentosLabel.Text = "Medicamentos:"
        '
        'IntIdMedicamentosGenericosLabel
        '
        IntIdMedicamentosGenericosLabel.AutoSize = True
        IntIdMedicamentosGenericosLabel.Location = New System.Drawing.Point(17, 50)
        IntIdMedicamentosGenericosLabel.Name = "IntIdMedicamentosGenericosLabel"
        IntIdMedicamentosGenericosLabel.Size = New System.Drawing.Size(19, 13)
        IntIdMedicamentosGenericosLabel.TabIndex = 15
        IntIdMedicamentosGenericosLabel.Text = "Id:"
        '
        'StrAccionLabel
        '
        StrAccionLabel.AutoSize = True
        StrAccionLabel.Location = New System.Drawing.Point(17, 132)
        StrAccionLabel.Name = "StrAccionLabel"
        StrAccionLabel.Size = New System.Drawing.Size(43, 13)
        StrAccionLabel.TabIndex = 17
        StrAccionLabel.Text = "Accion:"
        '
        'StrContraindicacionesLabel
        '
        StrContraindicacionesLabel.AutoSize = True
        StrContraindicacionesLabel.Location = New System.Drawing.Point(17, 265)
        StrContraindicacionesLabel.Name = "StrContraindicacionesLabel"
        StrContraindicacionesLabel.Size = New System.Drawing.Size(100, 13)
        StrContraindicacionesLabel.TabIndex = 19
        StrContraindicacionesLabel.Text = "Contraindicaciones:"
        '
        'StrdescripcionLabel
        '
        StrdescripcionLabel.AutoSize = True
        StrdescripcionLabel.Location = New System.Drawing.Point(17, 106)
        StrdescripcionLabel.Name = "StrdescripcionLabel"
        StrdescripcionLabel.Size = New System.Drawing.Size(66, 13)
        StrdescripcionLabel.TabIndex = 21
        StrdescripcionLabel.Text = "Descripción:"
        '
        'StrInteraccionesLabel
        '
        StrInteraccionesLabel.AutoSize = True
        StrInteraccionesLabel.Location = New System.Drawing.Point(17, 185)
        StrInteraccionesLabel.Name = "StrInteraccionesLabel"
        StrInteraccionesLabel.Size = New System.Drawing.Size(74, 13)
        StrInteraccionesLabel.TabIndex = 23
        StrInteraccionesLabel.Text = "Interacciones:"
        '
        'TblMedicamentosGenericosBindingSource
        '
        Me.TblMedicamentosGenericosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblMedicamentosGenericos)
        '
        'TblMedicamentosGenericosBindingNavigator
        '
        Me.TblMedicamentosGenericosBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblMedicamentosGenericosBindingNavigator.BindingSource = Me.TblMedicamentosGenericosBindingSource
        Me.TblMedicamentosGenericosBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblMedicamentosGenericosBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblMedicamentosGenericosBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblMedicamentosGenericosBindingNavigatorSaveItem})
        Me.TblMedicamentosGenericosBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblMedicamentosGenericosBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblMedicamentosGenericosBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblMedicamentosGenericosBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblMedicamentosGenericosBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblMedicamentosGenericosBindingNavigator.Name = "TblMedicamentosGenericosBindingNavigator"
        Me.TblMedicamentosGenericosBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblMedicamentosGenericosBindingNavigator.Size = New System.Drawing.Size(609, 25)
        Me.TblMedicamentosGenericosBindingNavigator.TabIndex = 0
        Me.TblMedicamentosGenericosBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblMedicamentosGenericosBindingNavigatorSaveItem
        '
        Me.TblMedicamentosGenericosBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblMedicamentosGenericosBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblMedicamentosGenericosBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblMedicamentosGenericosBindingNavigatorSaveItem.Name = "TblMedicamentosGenericosBindingNavigatorSaveItem"
        Me.TblMedicamentosGenericosBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblMedicamentosGenericosBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'DblDosificacionmayorClsTextBox
        '
        Me.DblDosificacionmayorClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMedicamentosGenericosBindingSource, "dblDosificacionmayor", True))
        Me.DblDosificacionmayorClsTextBox.DataSource = Nothing
        Me.DblDosificacionmayorClsTextBox.EnterEntreCampos = True
        Me.DblDosificacionmayorClsTextBox.Location = New System.Drawing.Point(33, 38)
        Me.DblDosificacionmayorClsTextBox.Name = "DblDosificacionmayorClsTextBox"
        Me.DblDosificacionmayorClsTextBox.NombreCodigoF2 = Nothing
        Me.DblDosificacionmayorClsTextBox.NombreDescripcionF2 = Nothing
        Me.DblDosificacionmayorClsTextBox.Size = New System.Drawing.Size(68, 20)
        Me.DblDosificacionmayorClsTextBox.TabIndex = 2
        Me.DblDosificacionmayorClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Doble
        '
        'DblDosificacionMediaClsTextBox
        '
        Me.DblDosificacionMediaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMedicamentosGenericosBindingSource, "dblDosificacionMedia", True))
        Me.DblDosificacionMediaClsTextBox.DataSource = Nothing
        Me.DblDosificacionMediaClsTextBox.EnterEntreCampos = True
        Me.DblDosificacionMediaClsTextBox.Location = New System.Drawing.Point(178, 38)
        Me.DblDosificacionMediaClsTextBox.Name = "DblDosificacionMediaClsTextBox"
        Me.DblDosificacionMediaClsTextBox.NombreCodigoF2 = Nothing
        Me.DblDosificacionMediaClsTextBox.NombreDescripcionF2 = Nothing
        Me.DblDosificacionMediaClsTextBox.Size = New System.Drawing.Size(68, 20)
        Me.DblDosificacionMediaClsTextBox.TabIndex = 4
        Me.DblDosificacionMediaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Doble
        '
        'DblDosificacionMinimaClsTextBox
        '
        Me.DblDosificacionMinimaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMedicamentosGenericosBindingSource, "dblDosificacionMinima", True))
        Me.DblDosificacionMinimaClsTextBox.DataSource = Nothing
        Me.DblDosificacionMinimaClsTextBox.EnterEntreCampos = True
        Me.DblDosificacionMinimaClsTextBox.Location = New System.Drawing.Point(323, 38)
        Me.DblDosificacionMinimaClsTextBox.Name = "DblDosificacionMinimaClsTextBox"
        Me.DblDosificacionMinimaClsTextBox.NombreCodigoF2 = Nothing
        Me.DblDosificacionMinimaClsTextBox.NombreDescripcionF2 = Nothing
        Me.DblDosificacionMinimaClsTextBox.Size = New System.Drawing.Size(68, 20)
        Me.DblDosificacionMinimaClsTextBox.TabIndex = 6
        Me.DblDosificacionMinimaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Doble
        '
        'DblDosificacionPediatricaClsTextBox
        '
        Me.DblDosificacionPediatricaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMedicamentosGenericosBindingSource, "dblDosificacionPediatrica", True))
        Me.DblDosificacionPediatricaClsTextBox.DataSource = Nothing
        Me.DblDosificacionPediatricaClsTextBox.EnterEntreCampos = True
        Me.DblDosificacionPediatricaClsTextBox.Location = New System.Drawing.Point(468, 38)
        Me.DblDosificacionPediatricaClsTextBox.Name = "DblDosificacionPediatricaClsTextBox"
        Me.DblDosificacionPediatricaClsTextBox.NombreCodigoF2 = Nothing
        Me.DblDosificacionPediatricaClsTextBox.NombreDescripcionF2 = Nothing
        Me.DblDosificacionPediatricaClsTextBox.Size = New System.Drawing.Size(68, 20)
        Me.DblDosificacionPediatricaClsTextBox.TabIndex = 8
        Me.DblDosificacionPediatricaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Doble
        '
        'IntIdDosificacionClsComboBox
        '
        Me.IntIdDosificacionClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblMedicamentosGenericosBindingSource, "intIdDosificacion", True))
        Me.IntIdDosificacionClsComboBox.DataSource = Me.TblTipoBindingSource
        Me.IntIdDosificacionClsComboBox.DisplayMember = "strValor"
        Me.IntIdDosificacionClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntIdDosificacionClsComboBox.FormattingEnabled = True
        Me.IntIdDosificacionClsComboBox.Location = New System.Drawing.Point(103, 71)
        Me.IntIdDosificacionClsComboBox.Name = "IntIdDosificacionClsComboBox"
        Me.IntIdDosificacionClsComboBox.Size = New System.Drawing.Size(143, 21)
        Me.IntIdDosificacionClsComboBox.TabIndex = 10
        Me.IntIdDosificacionClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoBindingSource
        '
        Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoBindingSource.Sort = "strValor"
        '
        'IntIdFrecuenciaDosificacionClsComboBox
        '
        Me.IntIdFrecuenciaDosificacionClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblMedicamentosGenericosBindingSource, "intIdFrecuenciaDosificacion", True))
        Me.IntIdFrecuenciaDosificacionClsComboBox.DataSource = Me.TblTipoBindingSource1
        Me.IntIdFrecuenciaDosificacionClsComboBox.DisplayMember = "strValor"
        Me.IntIdFrecuenciaDosificacionClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntIdFrecuenciaDosificacionClsComboBox.FormattingEnabled = True
        Me.IntIdFrecuenciaDosificacionClsComboBox.Location = New System.Drawing.Point(415, 69)
        Me.IntIdFrecuenciaDosificacionClsComboBox.Name = "IntIdFrecuenciaDosificacionClsComboBox"
        Me.IntIdFrecuenciaDosificacionClsComboBox.Size = New System.Drawing.Size(121, 21)
        Me.IntIdFrecuenciaDosificacionClsComboBox.TabIndex = 12
        Me.IntIdFrecuenciaDosificacionClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoBindingSource1
        '
        Me.TblTipoBindingSource1.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoBindingSource1.Sort = "strValor"
        '
        'IntIdMedicamentosClsComboBox
        '
        Me.IntIdMedicamentosClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblMedicamentosGenericosBindingSource, "intIdMedicamentos", True))
        Me.IntIdMedicamentosClsComboBox.DataSource = Me.TblMedicamentosBindingSource
        Me.IntIdMedicamentosClsComboBox.DisplayMember = "strdescripcion"
        Me.IntIdMedicamentosClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntIdMedicamentosClsComboBox.Enabled = False
        Me.IntIdMedicamentosClsComboBox.FormattingEnabled = True
        Me.IntIdMedicamentosClsComboBox.Location = New System.Drawing.Point(120, 76)
        Me.IntIdMedicamentosClsComboBox.Name = "IntIdMedicamentosClsComboBox"
        Me.IntIdMedicamentosClsComboBox.Size = New System.Drawing.Size(246, 21)
        Me.IntIdMedicamentosClsComboBox.TabIndex = 14
        Me.IntIdMedicamentosClsComboBox.ValueMember = "intIdMedicamentos"
        '
        'TblMedicamentosBindingSource
        '
        Me.TblMedicamentosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblMedicamentos)
        '
        'IntIdMedicamentosGenericosClsTextBox
        '
        Me.IntIdMedicamentosGenericosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMedicamentosGenericosBindingSource, "intIdMedicamentosGenericos", True))
        Me.IntIdMedicamentosGenericosClsTextBox.DataSource = Nothing
        Me.IntIdMedicamentosGenericosClsTextBox.Enabled = False
        Me.IntIdMedicamentosGenericosClsTextBox.EnterEntreCampos = True
        Me.IntIdMedicamentosGenericosClsTextBox.Location = New System.Drawing.Point(120, 47)
        Me.IntIdMedicamentosGenericosClsTextBox.Name = "IntIdMedicamentosGenericosClsTextBox"
        Me.IntIdMedicamentosGenericosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdMedicamentosGenericosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdMedicamentosGenericosClsTextBox.Size = New System.Drawing.Size(42, 20)
        Me.IntIdMedicamentosGenericosClsTextBox.TabIndex = 16
        Me.IntIdMedicamentosGenericosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrAccionClsTextBox
        '
        Me.StrAccionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMedicamentosGenericosBindingSource, "strAccion", True))
        Me.StrAccionClsTextBox.DataSource = Nothing
        Me.StrAccionClsTextBox.EnterEntreCampos = True
        Me.StrAccionClsTextBox.Location = New System.Drawing.Point(120, 129)
        Me.StrAccionClsTextBox.Name = "StrAccionClsTextBox"
        Me.StrAccionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrAccionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrAccionClsTextBox.Size = New System.Drawing.Size(468, 20)
        Me.StrAccionClsTextBox.TabIndex = 18
        Me.StrAccionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrContraindicacionesClsTextBox
        '
        Me.StrContraindicacionesClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMedicamentosGenericosBindingSource, "strContraindicaciones", True))
        Me.StrContraindicacionesClsTextBox.DataSource = Nothing
        Me.StrContraindicacionesClsTextBox.EnterEntreCampos = True
        Me.StrContraindicacionesClsTextBox.Location = New System.Drawing.Point(120, 234)
        Me.StrContraindicacionesClsTextBox.Multiline = True
        Me.StrContraindicacionesClsTextBox.Name = "StrContraindicacionesClsTextBox"
        Me.StrContraindicacionesClsTextBox.NombreCodigoF2 = Nothing
        Me.StrContraindicacionesClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrContraindicacionesClsTextBox.Size = New System.Drawing.Size(468, 74)
        Me.StrContraindicacionesClsTextBox.TabIndex = 20
        Me.StrContraindicacionesClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrdescripcionClsTextBox
        '
        Me.StrdescripcionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMedicamentosGenericosBindingSource, "strdescripcion", True))
        Me.StrdescripcionClsTextBox.DataSource = Nothing
        Me.StrdescripcionClsTextBox.EnterEntreCampos = True
        Me.StrdescripcionClsTextBox.Location = New System.Drawing.Point(120, 103)
        Me.StrdescripcionClsTextBox.Name = "StrdescripcionClsTextBox"
        Me.StrdescripcionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrdescripcionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrdescripcionClsTextBox.Size = New System.Drawing.Size(468, 20)
        Me.StrdescripcionClsTextBox.TabIndex = 22
        Me.StrdescripcionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrInteraccionesClsTextBox
        '
        Me.StrInteraccionesClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMedicamentosGenericosBindingSource, "strInteracciones", True))
        Me.StrInteraccionesClsTextBox.DataSource = Nothing
        Me.StrInteraccionesClsTextBox.EnterEntreCampos = True
        Me.StrInteraccionesClsTextBox.Location = New System.Drawing.Point(120, 155)
        Me.StrInteraccionesClsTextBox.Multiline = True
        Me.StrInteraccionesClsTextBox.Name = "StrInteraccionesClsTextBox"
        Me.StrInteraccionesClsTextBox.NombreCodigoF2 = Nothing
        Me.StrInteraccionesClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrInteraccionesClsTextBox.Size = New System.Drawing.Size(468, 73)
        Me.StrInteraccionesClsTextBox.TabIndex = 24
        Me.StrInteraccionesClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TblNombresComercialesDataGridView)
        Me.GroupBox1.Location = New System.Drawing.Point(20, 428)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(568, 250)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Nombres Comerciales"
        '
        'TblNombresComercialesDataGridView
        '
        Me.TblNombresComercialesDataGridView.AutoGenerateColumns = False
        Me.TblNombresComercialesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblNombresComercialesDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.intIdNombresComerciales, Me.strDescripcion, Me.Detalle, Me.IntIdNombresComercialesDataGridViewTextBoxColumn, Me.StrDescripcionDataGridViewTextBoxColumn, Me.IntIdMedicamentosGenericosDataGridViewTextBoxColumn, Me.IntIdTipoPresentacionComercialDataGridViewTextBoxColumn, Me.IntPorDataGridViewTextBoxColumn, Me.IntIdPresentacionDrograsDataGridViewTextBoxColumn, Me.DblConcentracionDataGridViewTextBoxColumn, Me.IntIdMedidasDrogasDataGridViewTextBoxColumn, Me.IntIdLaboratorioDataGridViewTextBoxColumn, Me.DblPrecioPublicoDataGridViewTextBoxColumn, Me.DtmFechaDataGridViewTextBoxColumn, Me.IntIdPrincipioActivoPrincipalDataGridViewTextBoxColumn, Me.IntIdPrincipioActivoAsociacionDataGridViewTextBoxColumn, Me.TblLaboratoriosfarmaceuticosDataGridViewTextBoxColumn, Me.TblMedicamentosGenericosDataGridViewTextBoxColumn, Me.TblTipoDataGridViewTextBoxColumn, Me.TblTipo1DataGridViewTextBoxColumn, Me.TblTipo2DataGridViewTextBoxColumn, Me.TblPrincipiosActivosDataGridViewTextBoxColumn, Me.TblPrincipiosActivos1DataGridViewTextBoxColumn})
        Me.TblNombresComercialesDataGridView.DataMember = "tblNombresComerciales"
        Me.TblNombresComercialesDataGridView.DataSource = Me.TblMedicamentosGenericosBindingSource
        Me.TblNombresComercialesDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblNombresComercialesDataGridView.Location = New System.Drawing.Point(3, 16)
        Me.TblNombresComercialesDataGridView.Name = "TblNombresComercialesDataGridView"
        Me.TblNombresComercialesDataGridView.Size = New System.Drawing.Size(562, 231)
        Me.TblNombresComercialesDataGridView.TabIndex = 0
        '
        'intIdNombresComerciales
        '
        Me.intIdNombresComerciales.DataPropertyName = "intIdNombresComerciales"
        Me.intIdNombresComerciales.HeaderText = "Id"
        Me.intIdNombresComerciales.Name = "intIdNombresComerciales"
        Me.intIdNombresComerciales.Width = 40
        '
        'strDescripcion
        '
        Me.strDescripcion.DataPropertyName = "strDescripcion"
        Me.strDescripcion.HeaderText = "Descripción"
        Me.strDescripcion.Name = "strDescripcion"
        Me.strDescripcion.Width = 400
        '
        'Detalle
        '
        Me.Detalle.HeaderText = "..."
        Me.Detalle.Name = "Detalle"
        Me.Detalle.Width = 30
        '
        'IntIdNombresComercialesDataGridViewTextBoxColumn
        '
        Me.IntIdNombresComercialesDataGridViewTextBoxColumn.DataPropertyName = "intIdNombresComerciales"
        Me.IntIdNombresComercialesDataGridViewTextBoxColumn.HeaderText = "intIdNombresComerciales"
        Me.IntIdNombresComercialesDataGridViewTextBoxColumn.Name = "IntIdNombresComercialesDataGridViewTextBoxColumn"
        Me.IntIdNombresComercialesDataGridViewTextBoxColumn.Visible = False
        '
        'StrDescripcionDataGridViewTextBoxColumn
        '
        Me.StrDescripcionDataGridViewTextBoxColumn.DataPropertyName = "strDescripcion"
        Me.StrDescripcionDataGridViewTextBoxColumn.HeaderText = "strDescripcion"
        Me.StrDescripcionDataGridViewTextBoxColumn.Name = "StrDescripcionDataGridViewTextBoxColumn"
        Me.StrDescripcionDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdMedicamentosGenericosDataGridViewTextBoxColumn
        '
        Me.IntIdMedicamentosGenericosDataGridViewTextBoxColumn.DataPropertyName = "intIdMedicamentosGenericos"
        Me.IntIdMedicamentosGenericosDataGridViewTextBoxColumn.HeaderText = "intIdMedicamentosGenericos"
        Me.IntIdMedicamentosGenericosDataGridViewTextBoxColumn.Name = "IntIdMedicamentosGenericosDataGridViewTextBoxColumn"
        Me.IntIdMedicamentosGenericosDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdTipoPresentacionComercialDataGridViewTextBoxColumn
        '
        Me.IntIdTipoPresentacionComercialDataGridViewTextBoxColumn.DataPropertyName = "intIdTipoPresentacionComercial"
        Me.IntIdTipoPresentacionComercialDataGridViewTextBoxColumn.HeaderText = "intIdTipoPresentacionComercial"
        Me.IntIdTipoPresentacionComercialDataGridViewTextBoxColumn.Name = "IntIdTipoPresentacionComercialDataGridViewTextBoxColumn"
        Me.IntIdTipoPresentacionComercialDataGridViewTextBoxColumn.Visible = False
        '
        'IntPorDataGridViewTextBoxColumn
        '
        Me.IntPorDataGridViewTextBoxColumn.DataPropertyName = "intPor"
        Me.IntPorDataGridViewTextBoxColumn.HeaderText = "intPor"
        Me.IntPorDataGridViewTextBoxColumn.Name = "IntPorDataGridViewTextBoxColumn"
        Me.IntPorDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdPresentacionDrograsDataGridViewTextBoxColumn
        '
        Me.IntIdPresentacionDrograsDataGridViewTextBoxColumn.DataPropertyName = "intIdPresentacionDrogras"
        Me.IntIdPresentacionDrograsDataGridViewTextBoxColumn.HeaderText = "intIdPresentacionDrogras"
        Me.IntIdPresentacionDrograsDataGridViewTextBoxColumn.Name = "IntIdPresentacionDrograsDataGridViewTextBoxColumn"
        Me.IntIdPresentacionDrograsDataGridViewTextBoxColumn.Visible = False
        '
        'DblConcentracionDataGridViewTextBoxColumn
        '
        Me.DblConcentracionDataGridViewTextBoxColumn.DataPropertyName = "dblConcentracion"
        Me.DblConcentracionDataGridViewTextBoxColumn.HeaderText = "dblConcentracion"
        Me.DblConcentracionDataGridViewTextBoxColumn.Name = "DblConcentracionDataGridViewTextBoxColumn"
        Me.DblConcentracionDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdMedidasDrogasDataGridViewTextBoxColumn
        '
        Me.IntIdMedidasDrogasDataGridViewTextBoxColumn.DataPropertyName = "intIdMedidasDrogas"
        Me.IntIdMedidasDrogasDataGridViewTextBoxColumn.HeaderText = "intIdMedidasDrogas"
        Me.IntIdMedidasDrogasDataGridViewTextBoxColumn.Name = "IntIdMedidasDrogasDataGridViewTextBoxColumn"
        Me.IntIdMedidasDrogasDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdLaboratorioDataGridViewTextBoxColumn
        '
        Me.IntIdLaboratorioDataGridViewTextBoxColumn.DataPropertyName = "intIdLaboratorio"
        Me.IntIdLaboratorioDataGridViewTextBoxColumn.HeaderText = "intIdLaboratorio"
        Me.IntIdLaboratorioDataGridViewTextBoxColumn.Name = "IntIdLaboratorioDataGridViewTextBoxColumn"
        Me.IntIdLaboratorioDataGridViewTextBoxColumn.Visible = False
        '
        'DblPrecioPublicoDataGridViewTextBoxColumn
        '
        Me.DblPrecioPublicoDataGridViewTextBoxColumn.DataPropertyName = "dblPrecioPublico"
        Me.DblPrecioPublicoDataGridViewTextBoxColumn.HeaderText = "dblPrecioPublico"
        Me.DblPrecioPublicoDataGridViewTextBoxColumn.Name = "DblPrecioPublicoDataGridViewTextBoxColumn"
        Me.DblPrecioPublicoDataGridViewTextBoxColumn.Visible = False
        '
        'DtmFechaDataGridViewTextBoxColumn
        '
        Me.DtmFechaDataGridViewTextBoxColumn.DataPropertyName = "dtmFecha"
        Me.DtmFechaDataGridViewTextBoxColumn.HeaderText = "dtmFecha"
        Me.DtmFechaDataGridViewTextBoxColumn.Name = "DtmFechaDataGridViewTextBoxColumn"
        Me.DtmFechaDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdPrincipioActivoPrincipalDataGridViewTextBoxColumn
        '
        Me.IntIdPrincipioActivoPrincipalDataGridViewTextBoxColumn.DataPropertyName = "intIdPrincipioActivoPrincipal"
        Me.IntIdPrincipioActivoPrincipalDataGridViewTextBoxColumn.HeaderText = "intIdPrincipioActivoPrincipal"
        Me.IntIdPrincipioActivoPrincipalDataGridViewTextBoxColumn.Name = "IntIdPrincipioActivoPrincipalDataGridViewTextBoxColumn"
        Me.IntIdPrincipioActivoPrincipalDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdPrincipioActivoAsociacionDataGridViewTextBoxColumn
        '
        Me.IntIdPrincipioActivoAsociacionDataGridViewTextBoxColumn.DataPropertyName = "intIdPrincipioActivoAsociacion"
        Me.IntIdPrincipioActivoAsociacionDataGridViewTextBoxColumn.HeaderText = "intIdPrincipioActivoAsociacion"
        Me.IntIdPrincipioActivoAsociacionDataGridViewTextBoxColumn.Name = "IntIdPrincipioActivoAsociacionDataGridViewTextBoxColumn"
        Me.IntIdPrincipioActivoAsociacionDataGridViewTextBoxColumn.Visible = False
        '
        'TblLaboratoriosfarmaceuticosDataGridViewTextBoxColumn
        '
        Me.TblLaboratoriosfarmaceuticosDataGridViewTextBoxColumn.DataPropertyName = "tblLaboratoriosfarmaceuticos"
        Me.TblLaboratoriosfarmaceuticosDataGridViewTextBoxColumn.HeaderText = "tblLaboratoriosfarmaceuticos"
        Me.TblLaboratoriosfarmaceuticosDataGridViewTextBoxColumn.Name = "TblLaboratoriosfarmaceuticosDataGridViewTextBoxColumn"
        Me.TblLaboratoriosfarmaceuticosDataGridViewTextBoxColumn.Visible = False
        '
        'TblMedicamentosGenericosDataGridViewTextBoxColumn
        '
        Me.TblMedicamentosGenericosDataGridViewTextBoxColumn.DataPropertyName = "tblMedicamentosGenericos"
        Me.TblMedicamentosGenericosDataGridViewTextBoxColumn.HeaderText = "tblMedicamentosGenericos"
        Me.TblMedicamentosGenericosDataGridViewTextBoxColumn.Name = "TblMedicamentosGenericosDataGridViewTextBoxColumn"
        Me.TblMedicamentosGenericosDataGridViewTextBoxColumn.Visible = False
        '
        'TblTipoDataGridViewTextBoxColumn
        '
        Me.TblTipoDataGridViewTextBoxColumn.DataPropertyName = "tblTipo"
        Me.TblTipoDataGridViewTextBoxColumn.HeaderText = "tblTipo"
        Me.TblTipoDataGridViewTextBoxColumn.Name = "TblTipoDataGridViewTextBoxColumn"
        Me.TblTipoDataGridViewTextBoxColumn.Visible = False
        '
        'TblTipo1DataGridViewTextBoxColumn
        '
        Me.TblTipo1DataGridViewTextBoxColumn.DataPropertyName = "tblTipo1"
        Me.TblTipo1DataGridViewTextBoxColumn.HeaderText = "tblTipo1"
        Me.TblTipo1DataGridViewTextBoxColumn.Name = "TblTipo1DataGridViewTextBoxColumn"
        Me.TblTipo1DataGridViewTextBoxColumn.Visible = False
        '
        'TblTipo2DataGridViewTextBoxColumn
        '
        Me.TblTipo2DataGridViewTextBoxColumn.DataPropertyName = "tblTipo2"
        Me.TblTipo2DataGridViewTextBoxColumn.HeaderText = "tblTipo2"
        Me.TblTipo2DataGridViewTextBoxColumn.Name = "TblTipo2DataGridViewTextBoxColumn"
        Me.TblTipo2DataGridViewTextBoxColumn.Visible = False
        '
        'TblPrincipiosActivosDataGridViewTextBoxColumn
        '
        Me.TblPrincipiosActivosDataGridViewTextBoxColumn.DataPropertyName = "tblPrincipiosActivos"
        Me.TblPrincipiosActivosDataGridViewTextBoxColumn.HeaderText = "tblPrincipiosActivos"
        Me.TblPrincipiosActivosDataGridViewTextBoxColumn.Name = "TblPrincipiosActivosDataGridViewTextBoxColumn"
        Me.TblPrincipiosActivosDataGridViewTextBoxColumn.Visible = False
        '
        'TblPrincipiosActivos1DataGridViewTextBoxColumn
        '
        Me.TblPrincipiosActivos1DataGridViewTextBoxColumn.DataPropertyName = "tblPrincipiosActivos1"
        Me.TblPrincipiosActivos1DataGridViewTextBoxColumn.HeaderText = "tblPrincipiosActivos1"
        Me.TblPrincipiosActivos1DataGridViewTextBoxColumn.Name = "TblPrincipiosActivos1DataGridViewTextBoxColumn"
        Me.TblPrincipiosActivos1DataGridViewTextBoxColumn.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(DblDosificacionMediaLabel)
        Me.GroupBox2.Controls.Add(Me.IntIdFrecuenciaDosificacionClsComboBox)
        Me.GroupBox2.Controls.Add(IntIdFrecuenciaDosificacionLabel)
        Me.GroupBox2.Controls.Add(Me.IntIdDosificacionClsComboBox)
        Me.GroupBox2.Controls.Add(DblDosificacionmayorLabel)
        Me.GroupBox2.Controls.Add(IntIdDosificacionLabel)
        Me.GroupBox2.Controls.Add(Me.DblDosificacionmayorClsTextBox)
        Me.GroupBox2.Controls.Add(Me.DblDosificacionPediatricaClsTextBox)
        Me.GroupBox2.Controls.Add(DblDosificacionPediatricaLabel)
        Me.GroupBox2.Controls.Add(Me.DblDosificacionMediaClsTextBox)
        Me.GroupBox2.Controls.Add(Me.DblDosificacionMinimaClsTextBox)
        Me.GroupBox2.Controls.Add(DblDosificacionMinimaLabel)
        Me.GroupBox2.Location = New System.Drawing.Point(20, 314)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(568, 106)
        Me.GroupBox2.TabIndex = 26
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Dosificación"
        '
        'FrmGenericos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(609, 699)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(StrInteraccionesLabel)
        Me.Controls.Add(Me.StrInteraccionesClsTextBox)
        Me.Controls.Add(IntIdMedicamentosLabel)
        Me.Controls.Add(Me.IntIdMedicamentosClsComboBox)
        Me.Controls.Add(IntIdMedicamentosGenericosLabel)
        Me.Controls.Add(Me.IntIdMedicamentosGenericosClsTextBox)
        Me.Controls.Add(StrAccionLabel)
        Me.Controls.Add(Me.StrAccionClsTextBox)
        Me.Controls.Add(StrContraindicacionesLabel)
        Me.Controls.Add(Me.StrContraindicacionesClsTextBox)
        Me.Controls.Add(StrdescripcionLabel)
        Me.Controls.Add(Me.StrdescripcionClsTextBox)
        Me.Controls.Add(Me.TblMedicamentosGenericosBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmGenericos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Genericos"
        CType(Me.TblMedicamentosGenericosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblMedicamentosGenericosBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblMedicamentosGenericosBindingNavigator.ResumeLayout(False)
        Me.TblMedicamentosGenericosBindingNavigator.PerformLayout()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblMedicamentosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.TblNombresComercialesDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblMedicamentosGenericosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblMedicamentosGenericosBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblMedicamentosGenericosBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents DblDosificacionmayorClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DblDosificacionMediaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DblDosificacionMinimaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DblDosificacionPediatricaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdDosificacionClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdFrecuenciaDosificacionClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdMedicamentosClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdMedicamentosGenericosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrAccionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrContraindicacionesClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrdescripcionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblMedicamentosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StrInteraccionesClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TblNombresComercialesDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents intIdNombresComerciales As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents strDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Detalle As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents IntIdNombresComercialesDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrDescripcionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdMedicamentosGenericosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdTipoPresentacionComercialDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntPorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdPresentacionDrograsDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DblConcentracionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdMedidasDrogasDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdLaboratorioDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DblPrecioPublicoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DtmFechaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdPrincipioActivoPrincipalDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdPrincipioActivoAsociacionDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblLaboratoriosfarmaceuticosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblMedicamentosGenericosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblTipoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblTipo1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblTipo2DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblPrincipiosActivosDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblPrincipiosActivos1DataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
