﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmItemRevision
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmItemRevision))
        Dim IntIdItemRevisionLabel As System.Windows.Forms.Label
        Dim StrNombreItemLabel As System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.Tabla = New System.Windows.Forms.TabPage
        Me.Detalle = New System.Windows.Forms.TabPage
        Me.TblItemRevisionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblItemRevisionBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.TblItemRevisionBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.TblItemRevisionDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.IntIdItemRevisionTextBox = New System.Windows.Forms.TextBox
        Me.StrNombreItemClsTextBox = New ClsUtilidades.ClsTextBox
        IntIdItemRevisionLabel = New System.Windows.Forms.Label
        StrNombreItemLabel = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.Tabla.SuspendLayout()
        Me.Detalle.SuspendLayout()
        CType(Me.TblItemRevisionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblItemRevisionBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblItemRevisionBindingNavigator.SuspendLayout()
        CType(Me.TblItemRevisionDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.Tabla)
        Me.TabControl1.Controls.Add(Me.Detalle)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(572, 299)
        Me.TabControl1.TabIndex = 0
        '
        'Tabla
        '
        Me.Tabla.Controls.Add(Me.TblItemRevisionDataGridView)
        Me.Tabla.Location = New System.Drawing.Point(4, 22)
        Me.Tabla.Name = "Tabla"
        Me.Tabla.Padding = New System.Windows.Forms.Padding(3)
        Me.Tabla.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Tabla.Size = New System.Drawing.Size(564, 273)
        Me.Tabla.TabIndex = 0
        Me.Tabla.Text = "Tabla"
        Me.Tabla.UseVisualStyleBackColor = True
        '
        'Detalle
        '
        Me.Detalle.Controls.Add(IntIdItemRevisionLabel)
        Me.Detalle.Controls.Add(Me.IntIdItemRevisionTextBox)
        Me.Detalle.Controls.Add(StrNombreItemLabel)
        Me.Detalle.Controls.Add(Me.StrNombreItemClsTextBox)
        Me.Detalle.Location = New System.Drawing.Point(4, 22)
        Me.Detalle.Name = "Detalle"
        Me.Detalle.Padding = New System.Windows.Forms.Padding(3)
        Me.Detalle.Size = New System.Drawing.Size(564, 273)
        Me.Detalle.TabIndex = 1
        Me.Detalle.Text = "Detalle"
        Me.Detalle.UseVisualStyleBackColor = True
        '
        'TblItemRevisionBindingSource
        '
        Me.TblItemRevisionBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblItemRevision)
        '
        'TblItemRevisionBindingNavigator
        '
        Me.TblItemRevisionBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblItemRevisionBindingNavigator.BindingSource = Me.TblItemRevisionBindingSource
        Me.TblItemRevisionBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblItemRevisionBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblItemRevisionBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblItemRevisionBindingNavigatorSaveItem})
        Me.TblItemRevisionBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblItemRevisionBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblItemRevisionBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblItemRevisionBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblItemRevisionBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblItemRevisionBindingNavigator.Name = "TblItemRevisionBindingNavigator"
        Me.TblItemRevisionBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblItemRevisionBindingNavigator.Size = New System.Drawing.Size(572, 25)
        Me.TblItemRevisionBindingNavigator.TabIndex = 1
        Me.TblItemRevisionBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(38, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'TblItemRevisionBindingNavigatorSaveItem
        '
        Me.TblItemRevisionBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblItemRevisionBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblItemRevisionBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblItemRevisionBindingNavigatorSaveItem.Name = "TblItemRevisionBindingNavigatorSaveItem"
        Me.TblItemRevisionBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblItemRevisionBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'TblItemRevisionDataGridView
        '
        Me.TblItemRevisionDataGridView.AllowUserToAddRows = False
        Me.TblItemRevisionDataGridView.AllowUserToDeleteRows = False
        Me.TblItemRevisionDataGridView.AutoGenerateColumns = False
        Me.TblItemRevisionDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblItemRevisionDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.TblItemRevisionDataGridView.DataSource = Me.TblItemRevisionBindingSource
        Me.TblItemRevisionDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblItemRevisionDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblItemRevisionDataGridView.Name = "TblItemRevisionDataGridView"
        Me.TblItemRevisionDataGridView.ReadOnly = True
        Me.TblItemRevisionDataGridView.Size = New System.Drawing.Size(558, 267)
        Me.TblItemRevisionDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdItemRevision"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strNombreItem"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nombre Item"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 400
        '
        'IntIdItemRevisionLabel
        '
        IntIdItemRevisionLabel.AutoSize = True
        IntIdItemRevisionLabel.Location = New System.Drawing.Point(25, 30)
        IntIdItemRevisionLabel.Name = "IntIdItemRevisionLabel"
        IntIdItemRevisionLabel.Size = New System.Drawing.Size(19, 13)
        IntIdItemRevisionLabel.TabIndex = 0
        IntIdItemRevisionLabel.Text = "Id:"
        '
        'IntIdItemRevisionTextBox
        '
        Me.IntIdItemRevisionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblItemRevisionBindingSource, "intIdItemRevision", True))
        Me.IntIdItemRevisionTextBox.Enabled = False
        Me.IntIdItemRevisionTextBox.Location = New System.Drawing.Point(96, 27)
        Me.IntIdItemRevisionTextBox.Name = "IntIdItemRevisionTextBox"
        Me.IntIdItemRevisionTextBox.Size = New System.Drawing.Size(56, 20)
        Me.IntIdItemRevisionTextBox.TabIndex = 1
        '
        'StrNombreItemLabel
        '
        StrNombreItemLabel.AutoSize = True
        StrNombreItemLabel.Location = New System.Drawing.Point(25, 56)
        StrNombreItemLabel.Name = "StrNombreItemLabel"
        StrNombreItemLabel.Size = New System.Drawing.Size(70, 13)
        StrNombreItemLabel.TabIndex = 2
        StrNombreItemLabel.Text = "Nombre Item:"
        '
        'StrNombreItemClsTextBox
        '
        Me.StrNombreItemClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblItemRevisionBindingSource, "strNombreItem", True))
        Me.StrNombreItemClsTextBox.DataSource = Nothing
        Me.StrNombreItemClsTextBox.Location = New System.Drawing.Point(96, 53)
        Me.StrNombreItemClsTextBox.Name = "StrNombreItemClsTextBox"
        Me.StrNombreItemClsTextBox.NombreCodigoF2 = Nothing
        Me.StrNombreItemClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrNombreItemClsTextBox.Size = New System.Drawing.Size(423, 20)
        Me.StrNombreItemClsTextBox.TabIndex = 3
        Me.StrNombreItemClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'FrmItemRevision
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(572, 324)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblItemRevisionBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmItemRevision"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Item Revisión"
        Me.TabControl1.ResumeLayout(False)
        Me.Tabla.ResumeLayout(False)
        Me.Detalle.ResumeLayout(False)
        Me.Detalle.PerformLayout()
        CType(Me.TblItemRevisionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblItemRevisionBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblItemRevisionBindingNavigator.ResumeLayout(False)
        Me.TblItemRevisionBindingNavigator.PerformLayout()
        CType(Me.TblItemRevisionDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents Tabla As System.Windows.Forms.TabPage
    Friend WithEvents TblItemRevisionDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblItemRevisionBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Detalle As System.Windows.Forms.TabPage
    Friend WithEvents IntIdItemRevisionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrNombreItemClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblItemRevisionBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblItemRevisionBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
End Class
