﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmIPS
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Dim IntIdEPSLabel As System.Windows.Forms.Label
    Dim lblNombre As System.Windows.Forms.Label
    Dim lblNit As System.Windows.Forms.Label
    Dim lblReperesentanteLegal As System.Windows.Forms.Label
    Dim lblCCRepresentanteLegal As System.Windows.Forms.Label
    Dim lblDireccion As System.Windows.Forms.Label
    Dim lblTelefono As System.Windows.Forms.Label
    Dim lblEmail As System.Windows.Forms.Label
    Dim lblSitioWeb As System.Windows.Forms.Label
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmIPS))
    Me.TabControl1 = New System.Windows.Forms.TabControl()
    Me.TabPage1 = New System.Windows.Forms.TabPage()
    Me.gvIPS = New System.Windows.Forms.DataGridView()
    Me.TabPage2 = New System.Windows.Forms.TabPage()
    Me.txtSitioWeb = New ClsUtilidades.ClsTextBox()
    Me.txtEmailContacto = New ClsUtilidades.ClsTextBox()
    Me.txtTelefono = New ClsUtilidades.ClsTextBox()
    Me.txtDireccion = New ClsUtilidades.ClsTextBox()
    Me.txtNitRepresentanteLegal = New ClsUtilidades.ClsTextBox()
    Me.txtRepresentanteLEgal = New ClsUtilidades.ClsTextBox()
    Me.txtNit = New ClsUtilidades.ClsTextBox()
    Me.txtIdIPS = New ClsUtilidades.ClsTextBox()
    Me.txtNombre = New ClsUtilidades.ClsTextBox()
    Me.gvIPSBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
    Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
    Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
    Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
    Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
    Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
    Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
    Me.gvIPSBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
    IntIdEPSLabel = New System.Windows.Forms.Label()
    lblNombre = New System.Windows.Forms.Label()
    lblNit = New System.Windows.Forms.Label()
    lblReperesentanteLegal = New System.Windows.Forms.Label()
    lblCCRepresentanteLegal = New System.Windows.Forms.Label()
    lblDireccion = New System.Windows.Forms.Label()
    lblTelefono = New System.Windows.Forms.Label()
    lblEmail = New System.Windows.Forms.Label()
    lblSitioWeb = New System.Windows.Forms.Label()
    Me.TabControl1.SuspendLayout()
    Me.TabPage1.SuspendLayout()
    CType(Me.gvIPS, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.TabPage2.SuspendLayout()
    CType(Me.gvIPSBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.gvIPSBindingNavigator.SuspendLayout()
    Me.SuspendLayout()
    '
    'IntIdEPSLabel
    '
    IntIdEPSLabel.AutoSize = True
    IntIdEPSLabel.Location = New System.Drawing.Point(38, 33)
    IntIdEPSLabel.Name = "IntIdEPSLabel"
    IntIdEPSLabel.Size = New System.Drawing.Size(19, 13)
    IntIdEPSLabel.TabIndex = 0
    IntIdEPSLabel.Text = "Id:"
    '
    'lblNombre
    '
    lblNombre.AutoSize = True
    lblNombre.Location = New System.Drawing.Point(36, 59)
    lblNombre.Name = "lblNombre"
    lblNombre.Size = New System.Drawing.Size(47, 13)
    lblNombre.TabIndex = 4
    lblNombre.Text = "Nombre:"
    '
    'lblNit
    '
    lblNit.AutoSize = True
    lblNit.Location = New System.Drawing.Point(38, 85)
    lblNit.Name = "lblNit"
    lblNit.Size = New System.Drawing.Size(23, 13)
    lblNit.TabIndex = 6
    lblNit.Text = "Nit:"
    '
    'lblReperesentanteLegal
    '
    lblReperesentanteLegal.AutoSize = True
    lblReperesentanteLegal.Location = New System.Drawing.Point(38, 112)
    lblReperesentanteLegal.Name = "lblReperesentanteLegal"
    lblReperesentanteLegal.Size = New System.Drawing.Size(105, 13)
    lblReperesentanteLegal.TabIndex = 8
    lblReperesentanteLegal.Text = "Representante legal:"
    '
    'lblCCRepresentanteLegal
    '
    lblCCRepresentanteLegal.AutoSize = True
    lblCCRepresentanteLegal.Location = New System.Drawing.Point(36, 142)
    lblCCRepresentanteLegal.Name = "lblCCRepresentanteLegal"
    lblCCRepresentanteLegal.Size = New System.Drawing.Size(116, 13)
    lblCCRepresentanteLegal.TabIndex = 10
    lblCCRepresentanteLegal.Text = "Nit representante legal:"
    '
    'lblDireccion
    '
    lblDireccion.AutoSize = True
    lblDireccion.Location = New System.Drawing.Point(36, 169)
    lblDireccion.Name = "lblDireccion"
    lblDireccion.Size = New System.Drawing.Size(55, 13)
    lblDireccion.TabIndex = 12
    lblDireccion.Text = "Dirección:"
    '
    'lblTelefono
    '
    lblTelefono.AutoSize = True
    lblTelefono.Location = New System.Drawing.Point(36, 195)
    lblTelefono.Name = "lblTelefono"
    lblTelefono.Size = New System.Drawing.Size(52, 13)
    lblTelefono.TabIndex = 14
    lblTelefono.Text = "Teléfono:"
    '
    'lblEmail
    '
    lblEmail.AutoSize = True
    lblEmail.Location = New System.Drawing.Point(38, 221)
    lblEmail.Name = "lblEmail"
    lblEmail.Size = New System.Drawing.Size(80, 13)
    lblEmail.TabIndex = 16
    lblEmail.Text = "Email contacto:"
    '
    'lblSitioWeb
    '
    lblSitioWeb.AutoSize = True
    lblSitioWeb.Location = New System.Drawing.Point(36, 248)
    lblSitioWeb.Name = "lblSitioWeb"
    lblSitioWeb.Size = New System.Drawing.Size(53, 13)
    lblSitioWeb.TabIndex = 18
    lblSitioWeb.Text = "Sitio web:"
    '
    'TabControl1
    '
    Me.TabControl1.Controls.Add(Me.TabPage1)
    Me.TabControl1.Controls.Add(Me.TabPage2)
    Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.TabControl1.Location = New System.Drawing.Point(0, 25)
    Me.TabControl1.Name = "TabControl1"
    Me.TabControl1.SelectedIndex = 0
    Me.TabControl1.Size = New System.Drawing.Size(653, 362)
    Me.TabControl1.TabIndex = 1
    '
    'TabPage1
    '
    Me.TabPage1.AutoScroll = True
    Me.TabPage1.Controls.Add(Me.gvIPS)
    Me.TabPage1.Location = New System.Drawing.Point(4, 22)
    Me.TabPage1.Name = "TabPage1"
    Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
    Me.TabPage1.Size = New System.Drawing.Size(645, 336)
    Me.TabPage1.TabIndex = 0
    Me.TabPage1.Text = "Tabla"
    Me.TabPage1.UseVisualStyleBackColor = True
    '
    'gvIPS
    '
    Me.gvIPS.AllowUserToAddRows = False
    Me.gvIPS.AllowUserToDeleteRows = False
    Me.gvIPS.AllowUserToOrderColumns = True
    Me.gvIPS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
    Me.gvIPS.Dock = System.Windows.Forms.DockStyle.Fill
    Me.gvIPS.Location = New System.Drawing.Point(3, 3)
    Me.gvIPS.Name = "gvIPS"
    Me.gvIPS.ReadOnly = True
    Me.gvIPS.Size = New System.Drawing.Size(639, 330)
    Me.gvIPS.TabIndex = 0
    '
    'TabPage2
    '
    Me.TabPage2.AutoScroll = True
    Me.TabPage2.Controls.Add(lblSitioWeb)
    Me.TabPage2.Controls.Add(Me.txtSitioWeb)
    Me.TabPage2.Controls.Add(lblEmail)
    Me.TabPage2.Controls.Add(Me.txtEmailContacto)
    Me.TabPage2.Controls.Add(lblTelefono)
    Me.TabPage2.Controls.Add(Me.txtTelefono)
    Me.TabPage2.Controls.Add(lblDireccion)
    Me.TabPage2.Controls.Add(Me.txtDireccion)
    Me.TabPage2.Controls.Add(lblCCRepresentanteLegal)
    Me.TabPage2.Controls.Add(Me.txtNitRepresentanteLegal)
    Me.TabPage2.Controls.Add(lblReperesentanteLegal)
    Me.TabPage2.Controls.Add(Me.txtRepresentanteLEgal)
    Me.TabPage2.Controls.Add(lblNit)
    Me.TabPage2.Controls.Add(Me.txtNit)
    Me.TabPage2.Controls.Add(IntIdEPSLabel)
    Me.TabPage2.Controls.Add(Me.txtIdIPS)
    Me.TabPage2.Controls.Add(lblNombre)
    Me.TabPage2.Controls.Add(Me.txtNombre)
    Me.TabPage2.Location = New System.Drawing.Point(4, 22)
    Me.TabPage2.Name = "TabPage2"
    Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
    Me.TabPage2.Size = New System.Drawing.Size(645, 336)
    Me.TabPage2.TabIndex = 1
    Me.TabPage2.Text = "Detalle"
    Me.TabPage2.UseVisualStyleBackColor = True
    '
    'txtSitioWeb
    '
    Me.txtSitioWeb.DataSource = Nothing
    Me.txtSitioWeb.EnterEntreCampos = True
    Me.txtSitioWeb.Location = New System.Drawing.Point(160, 245)
    Me.txtSitioWeb.Name = "txtSitioWeb"
    Me.txtSitioWeb.NombreCodigoF2 = Nothing
    Me.txtSitioWeb.NombreDescripcionF2 = Nothing
    Me.txtSitioWeb.Size = New System.Drawing.Size(292, 20)
    Me.txtSitioWeb.TabIndex = 17
    Me.txtSitioWeb.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'txtEmailContacto
    '
    Me.txtEmailContacto.DataSource = Nothing
    Me.txtEmailContacto.EnterEntreCampos = True
    Me.txtEmailContacto.Location = New System.Drawing.Point(160, 218)
    Me.txtEmailContacto.Name = "txtEmailContacto"
    Me.txtEmailContacto.NombreCodigoF2 = Nothing
    Me.txtEmailContacto.NombreDescripcionF2 = Nothing
    Me.txtEmailContacto.Size = New System.Drawing.Size(292, 20)
    Me.txtEmailContacto.TabIndex = 15
    Me.txtEmailContacto.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'txtTelefono
    '
    Me.txtTelefono.DataSource = Nothing
    Me.txtTelefono.EnterEntreCampos = True
    Me.txtTelefono.Location = New System.Drawing.Point(160, 192)
    Me.txtTelefono.Name = "txtTelefono"
    Me.txtTelefono.NombreCodigoF2 = Nothing
    Me.txtTelefono.NombreDescripcionF2 = Nothing
    Me.txtTelefono.Size = New System.Drawing.Size(292, 20)
    Me.txtTelefono.TabIndex = 13
    Me.txtTelefono.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'txtDireccion
    '
    Me.txtDireccion.DataSource = Nothing
    Me.txtDireccion.EnterEntreCampos = True
    Me.txtDireccion.Location = New System.Drawing.Point(160, 166)
    Me.txtDireccion.Name = "txtDireccion"
    Me.txtDireccion.NombreCodigoF2 = Nothing
    Me.txtDireccion.NombreDescripcionF2 = Nothing
    Me.txtDireccion.Size = New System.Drawing.Size(292, 20)
    Me.txtDireccion.TabIndex = 11
    Me.txtDireccion.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'txtNitRepresentanteLegal
    '
    Me.txtNitRepresentanteLegal.DataSource = Nothing
    Me.txtNitRepresentanteLegal.EnterEntreCampos = True
    Me.txtNitRepresentanteLegal.Location = New System.Drawing.Point(160, 138)
    Me.txtNitRepresentanteLegal.Name = "txtNitRepresentanteLegal"
    Me.txtNitRepresentanteLegal.NombreCodigoF2 = Nothing
    Me.txtNitRepresentanteLegal.NombreDescripcionF2 = Nothing
    Me.txtNitRepresentanteLegal.Size = New System.Drawing.Size(292, 20)
    Me.txtNitRepresentanteLegal.TabIndex = 9
    Me.txtNitRepresentanteLegal.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'txtRepresentanteLEgal
    '
    Me.txtRepresentanteLEgal.DataSource = Nothing
    Me.txtRepresentanteLEgal.EnterEntreCampos = True
    Me.txtRepresentanteLEgal.Location = New System.Drawing.Point(160, 109)
    Me.txtRepresentanteLEgal.Name = "txtRepresentanteLEgal"
    Me.txtRepresentanteLEgal.NombreCodigoF2 = Nothing
    Me.txtRepresentanteLEgal.NombreDescripcionF2 = Nothing
    Me.txtRepresentanteLEgal.Size = New System.Drawing.Size(292, 20)
    Me.txtRepresentanteLEgal.TabIndex = 7
    Me.txtRepresentanteLEgal.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'txtNit
    '
    Me.txtNit.DataSource = Nothing
    Me.txtNit.EnterEntreCampos = True
    Me.txtNit.Location = New System.Drawing.Point(160, 82)
    Me.txtNit.Name = "txtNit"
    Me.txtNit.NombreCodigoF2 = Nothing
    Me.txtNit.NombreDescripcionF2 = Nothing
    Me.txtNit.Size = New System.Drawing.Size(292, 20)
    Me.txtNit.TabIndex = 5
    Me.txtNit.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'txtIdIPS
    '
    Me.txtIdIPS.DataSource = Nothing
    Me.txtIdIPS.Enabled = False
    Me.txtIdIPS.EnterEntreCampos = True
    Me.txtIdIPS.Location = New System.Drawing.Point(160, 30)
    Me.txtIdIPS.Name = "txtIdIPS"
    Me.txtIdIPS.NombreCodigoF2 = Nothing
    Me.txtIdIPS.NombreDescripcionF2 = Nothing
    Me.txtIdIPS.Size = New System.Drawing.Size(44, 20)
    Me.txtIdIPS.TabIndex = 0
    Me.txtIdIPS.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'txtNombre
    '
    Me.txtNombre.DataSource = Nothing
    Me.txtNombre.EnterEntreCampos = True
    Me.txtNombre.Location = New System.Drawing.Point(160, 56)
    Me.txtNombre.Name = "txtNombre"
    Me.txtNombre.NombreCodigoF2 = Nothing
    Me.txtNombre.NombreDescripcionF2 = Nothing
    Me.txtNombre.Size = New System.Drawing.Size(292, 20)
    Me.txtNombre.TabIndex = 1
    Me.txtNombre.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
    '
    'gvIPSBindingNavigator
    '
    Me.gvIPSBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
    Me.gvIPSBindingNavigator.CountItem = Me.BindingNavigatorCountItem
    Me.gvIPSBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
    Me.gvIPSBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.gvIPSBindingNavigatorSaveItem})
    Me.gvIPSBindingNavigator.Location = New System.Drawing.Point(0, 0)
    Me.gvIPSBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
    Me.gvIPSBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
    Me.gvIPSBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
    Me.gvIPSBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
    Me.gvIPSBindingNavigator.Name = "gvIPSBindingNavigator"
    Me.gvIPSBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
    Me.gvIPSBindingNavigator.Size = New System.Drawing.Size(653, 25)
    Me.gvIPSBindingNavigator.TabIndex = 2
    Me.gvIPSBindingNavigator.Text = "BindingNavigator1"
    '
    'BindingNavigatorAddNewItem
    '
    Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
    Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorAddNewItem.Text = "Add new"
    '
    'BindingNavigatorCountItem
    '
    Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
    Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
    Me.BindingNavigatorCountItem.Text = "of {0}"
    Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
    '
    'BindingNavigatorDeleteItem
    '
    Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
    Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorDeleteItem.Text = "Delete"
    '
    'BindingNavigatorMoveFirstItem
    '
    Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
    Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorMoveFirstItem.Text = "Move first"
    '
    'BindingNavigatorMovePreviousItem
    '
    Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
    Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
    '
    'BindingNavigatorSeparator
    '
    Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
    Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
    '
    'BindingNavigatorPositionItem
    '
    Me.BindingNavigatorPositionItem.AccessibleName = "Position"
    Me.BindingNavigatorPositionItem.AutoSize = False
    Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
    Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
    Me.BindingNavigatorPositionItem.Text = "0"
    Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
    '
    'BindingNavigatorSeparator1
    '
    Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
    Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
    '
    'BindingNavigatorMoveNextItem
    '
    Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
    Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorMoveNextItem.Text = "Move next"
    '
    'BindingNavigatorMoveLastItem
    '
    Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
    Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
    Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
    Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
    Me.BindingNavigatorMoveLastItem.Text = "Move last"
    '
    'BindingNavigatorSeparator2
    '
    Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
    Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
    '
    'gvIPSBindingNavigatorSaveItem
    '
    Me.gvIPSBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.gvIPSBindingNavigatorSaveItem.Image = CType(resources.GetObject("gvIPSBindingNavigatorSaveItem.Image"), System.Drawing.Image)
    Me.gvIPSBindingNavigatorSaveItem.Name = "gvIPSBindingNavigatorSaveItem"
    Me.gvIPSBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
    Me.gvIPSBindingNavigatorSaveItem.Text = "Save Data"
    '
    'FrmIPS
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(653, 387)
    Me.Controls.Add(Me.TabControl1)
    Me.Controls.Add(Me.gvIPSBindingNavigator)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Name = "FrmIPS"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "IPS"
    Me.TabControl1.ResumeLayout(False)
    Me.TabPage1.ResumeLayout(False)
    CType(Me.gvIPS, System.ComponentModel.ISupportInitialize).EndInit()
    Me.TabPage2.ResumeLayout(False)
    Me.TabPage2.PerformLayout()
    CType(Me.gvIPSBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
    Me.gvIPSBindingNavigator.ResumeLayout(False)
    Me.gvIPSBindingNavigator.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Public WithEvents TabControl1 As System.Windows.Forms.TabControl
  Public WithEvents TabPage1 As System.Windows.Forms.TabPage
  Friend WithEvents gvIPS As System.Windows.Forms.DataGridView
  Public WithEvents TabPage2 As System.Windows.Forms.TabPage
  Friend WithEvents gvIPSBindingNavigator As System.Windows.Forms.BindingNavigator
  Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
  Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
  Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents gvIPSBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
  Friend WithEvents txtIdIPS As ClsUtilidades.ClsTextBox
  Friend WithEvents txtNombre As ClsUtilidades.ClsTextBox
  Friend WithEvents txtNitRepresentanteLegal As ClsUtilidades.ClsTextBox
  Friend WithEvents txtRepresentanteLEgal As ClsUtilidades.ClsTextBox
  Friend WithEvents txtNit As ClsUtilidades.ClsTextBox
  Friend WithEvents txtTelefono As ClsUtilidades.ClsTextBox
  Friend WithEvents txtDireccion As ClsUtilidades.ClsTextBox
  Friend WithEvents txtSitioWeb As ClsUtilidades.ClsTextBox
  Friend WithEvents txtEmailContacto As ClsUtilidades.ClsTextBox
End Class
