﻿Public Class FrmComerciales
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mIntIdComercial As Integer

    Public Sub New(ByVal pdc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext, ByVal pIntIdComercial As Integer)
        Try
            ' Llamada necesaria para el Diseñador de Windows Forms.
            InitializeComponent()

            ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
            dc = pdc
            mIntIdComercial = pIntIdComercial
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmComerciales_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim tblComerciales = (From g In dc.tblNombresComerciales Where g.intIdNombresComerciales = mIntIdComercial Select g)
            TblNombresComercialesBindingSource.DataSource = tblComerciales

            TblMedicamentosGenericosBindingSource.DataSource = dc.tblMedicamentosGenericos
            TblPrincipiosActivosBindingSource.DataSource = dc.tblPrincipiosActivos
            TblPrincipiosActivosBindingSource1.DataSource = dc.tblPrincipiosActivos

            Dim tblPresentacionDrogas = From t In dc.tblTipos Where t.strTipo = "PRESENTACION_DROGAS" Select t
            TblTipoBindingSource1.DataSource = tblPresentacionDrogas

            Dim tblMedidasDrogas = From t In dc.tblTipos Where t.strTipo = "MEDIDAS_DROGAS" Select t
            TblTipoBindingSource2.DataSource = tblMedidasDrogas

            Dim tblPresentacionComercial = From t In dc.tblTipos Where t.strTipo = "P_COMERCIAL" Select t
            TblTipoBindingSource.DataSource = tblPresentacionComercial

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblNombresComercialesBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblNombresComercialesBindingNavigatorSaveItem.Click
        Try
            TblNombresComercialesBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class