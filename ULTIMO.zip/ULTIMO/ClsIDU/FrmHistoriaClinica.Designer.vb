﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmHistoriaClinica
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmHistoriaClinica))
        Me.PanelBotones = New System.Windows.Forms.Panel()
        Me.btnAP = New System.Windows.Forms.Button()
        Me.btnEvolucion = New System.Windows.Forms.Button()
        Me.btnTratamiento = New System.Windows.Forms.Button()
        Me.btnDC = New System.Windows.Forms.Button()
        Me.btnEP = New System.Windows.Forms.Button()
        Me.btnEF = New System.Windows.Forms.Button()
        Me.btnHabitos = New System.Windows.Forms.Button()
        Me.btnAE = New System.Windows.Forms.Button()
        Me.btnAG = New System.Windows.Forms.Button()
        Me.btnAF = New System.Windows.Forms.Button()
        Me.btnRS = New System.Windows.Forms.Button()
        Me.btnMC = New System.Windows.Forms.Button()
        Me.PanelMotivosConsulta = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnFinalizar = New System.Windows.Forms.Button()
        Me.btnSiguiente = New System.Windows.Forms.Button()
        Me.btnAnterior = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.FechaVisitaClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtNombre = New ClsUtilidades.ClsTextBox()
        Me.txtCedula = New ClsUtilidades.ClsTextBox()
        Me.PanelBotones.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelBotones
        '
        Me.PanelBotones.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelBotones.Controls.Add(Me.btnAP)
        Me.PanelBotones.Controls.Add(Me.btnEvolucion)
        Me.PanelBotones.Controls.Add(Me.btnTratamiento)
        Me.PanelBotones.Controls.Add(Me.btnDC)
        Me.PanelBotones.Controls.Add(Me.btnEP)
        Me.PanelBotones.Controls.Add(Me.btnEF)
        Me.PanelBotones.Controls.Add(Me.btnHabitos)
        Me.PanelBotones.Controls.Add(Me.btnAE)
        Me.PanelBotones.Controls.Add(Me.btnAG)
        Me.PanelBotones.Controls.Add(Me.btnAF)
        Me.PanelBotones.Controls.Add(Me.btnRS)
        Me.PanelBotones.Controls.Add(Me.btnMC)
        Me.PanelBotones.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelBotones.Location = New System.Drawing.Point(0, 57)
        Me.PanelBotones.Name = "PanelBotones"
        Me.PanelBotones.Size = New System.Drawing.Size(188, 521)
        Me.PanelBotones.TabIndex = 0
        '
        'btnAP
        '
        Me.btnAP.Location = New System.Drawing.Point(5, 80)
        Me.btnAP.Name = "btnAP"
        Me.btnAP.Size = New System.Drawing.Size(172, 23)
        Me.btnAP.TabIndex = 2
        Me.btnAP.Tag = "AP"
        Me.btnAP.Text = "Antecedentes Personales"
        Me.btnAP.UseVisualStyleBackColor = True
        '
        'btnEvolucion
        '
        Me.btnEvolucion.Location = New System.Drawing.Point(3, 332)
        Me.btnEvolucion.Name = "btnEvolucion"
        Me.btnEvolucion.Size = New System.Drawing.Size(172, 23)
        Me.btnEvolucion.TabIndex = 11
        Me.btnEvolucion.Tag = "EV"
        Me.btnEvolucion.Text = "Evolución"
        Me.btnEvolucion.UseVisualStyleBackColor = True
        '
        'btnTratamiento
        '
        Me.btnTratamiento.Location = New System.Drawing.Point(5, 304)
        Me.btnTratamiento.Name = "btnTratamiento"
        Me.btnTratamiento.Size = New System.Drawing.Size(172, 23)
        Me.btnTratamiento.TabIndex = 10
        Me.btnTratamiento.Tag = "TM"
        Me.btnTratamiento.Text = "Tratamiento"
        Me.btnTratamiento.UseVisualStyleBackColor = True
        '
        'btnDC
        '
        Me.btnDC.Location = New System.Drawing.Point(5, 276)
        Me.btnDC.Name = "btnDC"
        Me.btnDC.Size = New System.Drawing.Size(172, 23)
        Me.btnDC.TabIndex = 9
        Me.btnDC.Tag = "DC"
        Me.btnDC.Text = "Diagnóstico y Conducta"
        Me.btnDC.UseVisualStyleBackColor = True
        '
        'btnEP
        '
        Me.btnEP.Location = New System.Drawing.Point(5, 248)
        Me.btnEP.Name = "btnEP"
        Me.btnEP.Size = New System.Drawing.Size(172, 23)
        Me.btnEP.TabIndex = 8
        Me.btnEP.Tag = "EP"
        Me.btnEP.Text = "Examenes Paracíclicos"
        Me.btnEP.UseVisualStyleBackColor = True
        '
        'btnEF
        '
        Me.btnEF.Location = New System.Drawing.Point(5, 220)
        Me.btnEF.Name = "btnEF"
        Me.btnEF.Size = New System.Drawing.Size(172, 23)
        Me.btnEF.TabIndex = 7
        Me.btnEF.Tag = "EF"
        Me.btnEF.Text = "Examen Físico"
        Me.btnEF.UseVisualStyleBackColor = True
        '
        'btnHabitos
        '
        Me.btnHabitos.Location = New System.Drawing.Point(5, 192)
        Me.btnHabitos.Name = "btnHabitos"
        Me.btnHabitos.Size = New System.Drawing.Size(172, 23)
        Me.btnHabitos.TabIndex = 6
        Me.btnHabitos.Tag = "HB"
        Me.btnHabitos.Text = "Hábitos"
        Me.btnHabitos.UseVisualStyleBackColor = True
        '
        'btnAE
        '
        Me.btnAE.Location = New System.Drawing.Point(5, 164)
        Me.btnAE.Name = "btnAE"
        Me.btnAE.Size = New System.Drawing.Size(172, 23)
        Me.btnAE.TabIndex = 5
        Me.btnAE.Tag = "ASE"
        Me.btnAE.Text = "Antecedentes Socio-Económicos"
        Me.btnAE.UseVisualStyleBackColor = True
        '
        'btnAG
        '
        Me.btnAG.Location = New System.Drawing.Point(5, 136)
        Me.btnAG.Name = "btnAG"
        Me.btnAG.Size = New System.Drawing.Size(172, 23)
        Me.btnAG.TabIndex = 4
        Me.btnAG.Tag = "AGO"
        Me.btnAG.Text = "Antecedentes Gineco Obstétricos"
        Me.btnAG.UseVisualStyleBackColor = True
        '
        'btnAF
        '
        Me.btnAF.Location = New System.Drawing.Point(5, 108)
        Me.btnAF.Name = "btnAF"
        Me.btnAF.Size = New System.Drawing.Size(172, 23)
        Me.btnAF.TabIndex = 3
        Me.btnAF.Tag = "AF"
        Me.btnAF.Text = "Antecedentes Familiares"
        Me.btnAF.UseVisualStyleBackColor = True
        '
        'btnRS
        '
        Me.btnRS.Location = New System.Drawing.Point(5, 52)
        Me.btnRS.Name = "btnRS"
        Me.btnRS.Size = New System.Drawing.Size(172, 23)
        Me.btnRS.TabIndex = 1
        Me.btnRS.Tag = "RS"
        Me.btnRS.Text = "Revisión de Sistemas"
        Me.btnRS.UseVisualStyleBackColor = True
        '
        'btnMC
        '
        Me.btnMC.Location = New System.Drawing.Point(5, 24)
        Me.btnMC.Name = "btnMC"
        Me.btnMC.Size = New System.Drawing.Size(172, 23)
        Me.btnMC.TabIndex = 0
        Me.btnMC.Tag = "MC"
        Me.btnMC.Text = "Motivos de Consulta"
        Me.btnMC.UseVisualStyleBackColor = True
        '
        'PanelMotivosConsulta
        '
        Me.PanelMotivosConsulta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PanelMotivosConsulta.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelMotivosConsulta.Location = New System.Drawing.Point(188, 57)
        Me.PanelMotivosConsulta.Name = "PanelMotivosConsulta"
        Me.PanelMotivosConsulta.Size = New System.Drawing.Size(787, 468)
        Me.PanelMotivosConsulta.TabIndex = 1
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.btnFinalizar)
        Me.Panel3.Controls.Add(Me.btnSiguiente)
        Me.Panel3.Controls.Add(Me.btnAnterior)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(188, 525)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(787, 53)
        Me.Panel3.TabIndex = 2
        '
        'btnFinalizar
        '
        Me.btnFinalizar.Location = New System.Drawing.Point(428, 17)
        Me.btnFinalizar.Name = "btnFinalizar"
        Me.btnFinalizar.Size = New System.Drawing.Size(75, 23)
        Me.btnFinalizar.TabIndex = 2
        Me.btnFinalizar.Text = "Finalizar"
        Me.btnFinalizar.UseVisualStyleBackColor = True
        '
        'btnSiguiente
        '
        Me.btnSiguiente.Location = New System.Drawing.Point(347, 17)
        Me.btnSiguiente.Name = "btnSiguiente"
        Me.btnSiguiente.Size = New System.Drawing.Size(75, 23)
        Me.btnSiguiente.TabIndex = 1
        Me.btnSiguiente.Text = "Siguiente>>"
        Me.btnSiguiente.UseVisualStyleBackColor = True
        '
        'btnAnterior
        '
        Me.btnAnterior.Location = New System.Drawing.Point(266, 17)
        Me.btnAnterior.Name = "btnAnterior"
        Me.btnAnterior.Size = New System.Drawing.Size(75, 23)
        Me.btnAnterior.TabIndex = 0
        Me.btnAnterior.Text = "<<Anterior"
        Me.btnAnterior.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.Label4)
        Me.Panel4.Controls.Add(Me.FechaVisitaClsTextBox)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Controls.Add(Me.txtNombre)
        Me.Panel4.Controls.Add(Me.txtCedula)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(975, 57)
        Me.Panel4.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(590, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Fecha Visita: "
        '
        'FechaVisitaClsTextBox
        '
        Me.FechaVisitaClsTextBox.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.FechaVisitaClsTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.FechaVisitaClsTextBox.DataSource = Nothing
        Me.FechaVisitaClsTextBox.Enabled = False
        Me.FechaVisitaClsTextBox.EnterEntreCampos = True
        Me.FechaVisitaClsTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FechaVisitaClsTextBox.Location = New System.Drawing.Point(662, 18)
        Me.FechaVisitaClsTextBox.Name = "FechaVisitaClsTextBox"
        Me.FechaVisitaClsTextBox.NombreCodigoF2 = Nothing
        Me.FechaVisitaClsTextBox.NombreDescripcionF2 = Nothing
        Me.FechaVisitaClsTextBox.Size = New System.Drawing.Size(106, 20)
        Me.FechaVisitaClsTextBox.TabIndex = 8
        Me.FechaVisitaClsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.FechaVisitaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Paciente: "
        '
        'txtNombre
        '
        Me.txtNombre.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNombre.DataSource = Nothing
        Me.txtNombre.Enabled = False
        Me.txtNombre.EnterEntreCampos = True
        Me.txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNombre.Location = New System.Drawing.Point(187, 18)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.NombreCodigoF2 = Nothing
        Me.txtNombre.NombreDescripcionF2 = Nothing
        Me.txtNombre.Size = New System.Drawing.Size(361, 20)
        Me.txtNombre.TabIndex = 6
        Me.txtNombre.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'txtCedula
        '
        Me.txtCedula.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.txtCedula.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCedula.DataSource = Nothing
        Me.txtCedula.Enabled = False
        Me.txtCedula.EnterEntreCampos = True
        Me.txtCedula.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCedula.Location = New System.Drawing.Point(75, 18)
        Me.txtCedula.Name = "txtCedula"
        Me.txtCedula.NombreCodigoF2 = Nothing
        Me.txtCedula.NombreDescripcionF2 = Nothing
        Me.txtCedula.Size = New System.Drawing.Size(106, 20)
        Me.txtCedula.TabIndex = 5
        Me.txtCedula.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtCedula.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'FrmHistoriaClinica
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(975, 578)
        Me.Controls.Add(Me.PanelMotivosConsulta)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.PanelBotones)
        Me.Controls.Add(Me.Panel4)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Name = "FrmHistoriaClinica"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Historia Clínica"
        Me.PanelBotones.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents PanelBotones As System.Windows.Forms.Panel
    Friend WithEvents PanelMotivosConsulta As System.Windows.Forms.Panel
    Friend WithEvents btnAF As System.Windows.Forms.Button
    Friend WithEvents btnRS As System.Windows.Forms.Button
    Friend WithEvents btnMC As System.Windows.Forms.Button
    Friend WithEvents btnAE As System.Windows.Forms.Button
    Friend WithEvents btnAG As System.Windows.Forms.Button
    Friend WithEvents btnHabitos As System.Windows.Forms.Button
    Friend WithEvents btnTratamiento As System.Windows.Forms.Button
    Friend WithEvents btnDC As System.Windows.Forms.Button
    Friend WithEvents btnEP As System.Windows.Forms.Button
    Friend WithEvents btnEF As System.Windows.Forms.Button
    Friend WithEvents btnEvolucion As System.Windows.Forms.Button
    Friend WithEvents btnFinalizar As System.Windows.Forms.Button
    Friend WithEvents btnSiguiente As System.Windows.Forms.Button
    Friend WithEvents btnAnterior As System.Windows.Forms.Button
    Friend WithEvents btnAP As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtNombre As ClsUtilidades.ClsTextBox
    Friend WithEvents txtCedula As ClsUtilidades.ClsTextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents FechaVisitaClsTextBox As ClsUtilidades.ClsTextBox
End Class
