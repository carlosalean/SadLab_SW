﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPrincipiosActivos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IntIdPrincipiosActivosLabel As System.Windows.Forms.Label
        Dim StrDescripcionLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmPrincipiosActivos))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TblPrincipiosActivosDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TblPrincipiosActivosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.IntIdPrincipiosActivosTextBox = New System.Windows.Forms.TextBox
        Me.StrDescripcionClsTextBox = New ClsUtilidades.ClsTextBox
        Me.TblPrincipiosActivosBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.TblPrincipiosActivosBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        IntIdPrincipiosActivosLabel = New System.Windows.Forms.Label
        StrDescripcionLabel = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblPrincipiosActivosDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblPrincipiosActivosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblPrincipiosActivosBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblPrincipiosActivosBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntIdPrincipiosActivosLabel
        '
        IntIdPrincipiosActivosLabel.AutoSize = True
        IntIdPrincipiosActivosLabel.Location = New System.Drawing.Point(21, 36)
        IntIdPrincipiosActivosLabel.Name = "IntIdPrincipiosActivosLabel"
        IntIdPrincipiosActivosLabel.Size = New System.Drawing.Size(19, 13)
        IntIdPrincipiosActivosLabel.TabIndex = 0
        IntIdPrincipiosActivosLabel.Text = "Id:"
        '
        'StrDescripcionLabel
        '
        StrDescripcionLabel.AutoSize = True
        StrDescripcionLabel.Location = New System.Drawing.Point(21, 62)
        StrDescripcionLabel.Name = "StrDescripcionLabel"
        StrDescripcionLabel.Size = New System.Drawing.Size(66, 13)
        StrDescripcionLabel.TabIndex = 2
        StrDescripcionLabel.Text = "Descripción:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(446, 241)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.Controls.Add(Me.TblPrincipiosActivosDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(438, 215)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblPrincipiosActivosDataGridView
        '
        Me.TblPrincipiosActivosDataGridView.AllowUserToAddRows = False
        Me.TblPrincipiosActivosDataGridView.AllowUserToDeleteRows = False
        Me.TblPrincipiosActivosDataGridView.AutoGenerateColumns = False
        Me.TblPrincipiosActivosDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblPrincipiosActivosDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.TblPrincipiosActivosDataGridView.DataSource = Me.TblPrincipiosActivosBindingSource
        Me.TblPrincipiosActivosDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblPrincipiosActivosDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblPrincipiosActivosDataGridView.Name = "TblPrincipiosActivosDataGridView"
        Me.TblPrincipiosActivosDataGridView.ReadOnly = True
        Me.TblPrincipiosActivosDataGridView.Size = New System.Drawing.Size(432, 209)
        Me.TblPrincipiosActivosDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdPrincipiosActivos"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 80
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strDescripcion"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Descripción"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 280
        '
        'TblPrincipiosActivosBindingSource
        '
        Me.TblPrincipiosActivosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblPrincipiosActivos)
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(IntIdPrincipiosActivosLabel)
        Me.TabPage2.Controls.Add(Me.IntIdPrincipiosActivosTextBox)
        Me.TabPage2.Controls.Add(StrDescripcionLabel)
        Me.TabPage2.Controls.Add(Me.StrDescripcionClsTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(438, 215)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'IntIdPrincipiosActivosTextBox
        '
        Me.IntIdPrincipiosActivosTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPrincipiosActivosBindingSource, "intIdPrincipiosActivos", True))
        Me.IntIdPrincipiosActivosTextBox.Location = New System.Drawing.Point(97, 33)
        Me.IntIdPrincipiosActivosTextBox.Name = "IntIdPrincipiosActivosTextBox"
        Me.IntIdPrincipiosActivosTextBox.Size = New System.Drawing.Size(60, 20)
        Me.IntIdPrincipiosActivosTextBox.TabIndex = 1
        '
        'StrDescripcionClsTextBox
        '
        Me.StrDescripcionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblPrincipiosActivosBindingSource, "strDescripcion", True))
        Me.StrDescripcionClsTextBox.DataSource = Nothing
        Me.StrDescripcionClsTextBox.Location = New System.Drawing.Point(97, 59)
        Me.StrDescripcionClsTextBox.Name = "StrDescripcionClsTextBox"
        Me.StrDescripcionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcionClsTextBox.Size = New System.Drawing.Size(291, 20)
        Me.StrDescripcionClsTextBox.TabIndex = 3
        Me.StrDescripcionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblPrincipiosActivosBindingNavigator
        '
        Me.TblPrincipiosActivosBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblPrincipiosActivosBindingNavigator.BindingSource = Me.TblPrincipiosActivosBindingSource
        Me.TblPrincipiosActivosBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblPrincipiosActivosBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblPrincipiosActivosBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblPrincipiosActivosBindingNavigatorSaveItem})
        Me.TblPrincipiosActivosBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblPrincipiosActivosBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblPrincipiosActivosBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblPrincipiosActivosBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblPrincipiosActivosBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblPrincipiosActivosBindingNavigator.Name = "TblPrincipiosActivosBindingNavigator"
        Me.TblPrincipiosActivosBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblPrincipiosActivosBindingNavigator.Size = New System.Drawing.Size(446, 25)
        Me.TblPrincipiosActivosBindingNavigator.TabIndex = 2
        Me.TblPrincipiosActivosBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(38, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblPrincipiosActivosBindingNavigatorSaveItem
        '
        Me.TblPrincipiosActivosBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblPrincipiosActivosBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblPrincipiosActivosBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblPrincipiosActivosBindingNavigatorSaveItem.Name = "TblPrincipiosActivosBindingNavigatorSaveItem"
        Me.TblPrincipiosActivosBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblPrincipiosActivosBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'FrmPrincipiosActivos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(446, 266)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblPrincipiosActivosBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmPrincipiosActivos"
        Me.Text = "Principios Activos"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblPrincipiosActivosDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblPrincipiosActivosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblPrincipiosActivosBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblPrincipiosActivosBindingNavigator.ResumeLayout(False)
        Me.TblPrincipiosActivosBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents TabControl1 As System.Windows.Forms.TabControl
    Public WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TblPrincipiosActivosDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblPrincipiosActivosBindingSource As System.Windows.Forms.BindingSource
    Public WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblPrincipiosActivosBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblPrincipiosActivosBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdPrincipiosActivosTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrDescripcionClsTextBox As ClsUtilidades.ClsTextBox
End Class
