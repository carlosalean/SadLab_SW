﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFrecuenciaMedicamentos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmFrecuenciaMedicamentos))
        Dim IntIdFrecuenciaMedicamentosLabel As System.Windows.Forms.Label
        Dim StrDescripcionLabel As System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.TblFrecuenciaMedicamentosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblFrecuenciaMedicamentosBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.TblFrecuenciaMedicamentosBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.TblFrecuenciaMedicamentosDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.IntIdFrecuenciaMedicamentosClsTextBox = New ClsUtilidades.ClsTextBox
        Me.StrDescripcionClsTextBox = New ClsUtilidades.ClsTextBox
        IntIdFrecuenciaMedicamentosLabel = New System.Windows.Forms.Label
        StrDescripcionLabel = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblFrecuenciaMedicamentosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblFrecuenciaMedicamentosBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblFrecuenciaMedicamentosBindingNavigator.SuspendLayout()
        CType(Me.TblFrecuenciaMedicamentosDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(487, 197)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.Controls.Add(Me.TblFrecuenciaMedicamentosDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(479, 171)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(IntIdFrecuenciaMedicamentosLabel)
        Me.TabPage2.Controls.Add(Me.IntIdFrecuenciaMedicamentosClsTextBox)
        Me.TabPage2.Controls.Add(StrDescripcionLabel)
        Me.TabPage2.Controls.Add(Me.StrDescripcionClsTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(479, 171)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TblFrecuenciaMedicamentosBindingSource
        '
        Me.TblFrecuenciaMedicamentosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblFrecuenciaMedicamentos)
        '
        'TblFrecuenciaMedicamentosBindingNavigator
        '
        Me.TblFrecuenciaMedicamentosBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblFrecuenciaMedicamentosBindingNavigator.BindingSource = Me.TblFrecuenciaMedicamentosBindingSource
        Me.TblFrecuenciaMedicamentosBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblFrecuenciaMedicamentosBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblFrecuenciaMedicamentosBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblFrecuenciaMedicamentosBindingNavigatorSaveItem})
        Me.TblFrecuenciaMedicamentosBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblFrecuenciaMedicamentosBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblFrecuenciaMedicamentosBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblFrecuenciaMedicamentosBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblFrecuenciaMedicamentosBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblFrecuenciaMedicamentosBindingNavigator.Name = "TblFrecuenciaMedicamentosBindingNavigator"
        Me.TblFrecuenciaMedicamentosBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblFrecuenciaMedicamentosBindingNavigator.Size = New System.Drawing.Size(487, 25)
        Me.TblFrecuenciaMedicamentosBindingNavigator.TabIndex = 1
        Me.TblFrecuenciaMedicamentosBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(38, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'TblFrecuenciaMedicamentosBindingNavigatorSaveItem
        '
        Me.TblFrecuenciaMedicamentosBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblFrecuenciaMedicamentosBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblFrecuenciaMedicamentosBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblFrecuenciaMedicamentosBindingNavigatorSaveItem.Name = "TblFrecuenciaMedicamentosBindingNavigatorSaveItem"
        Me.TblFrecuenciaMedicamentosBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblFrecuenciaMedicamentosBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'TblFrecuenciaMedicamentosDataGridView
        '
        Me.TblFrecuenciaMedicamentosDataGridView.AllowUserToAddRows = False
        Me.TblFrecuenciaMedicamentosDataGridView.AllowUserToDeleteRows = False
        Me.TblFrecuenciaMedicamentosDataGridView.AutoGenerateColumns = False
        Me.TblFrecuenciaMedicamentosDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblFrecuenciaMedicamentosDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.TblFrecuenciaMedicamentosDataGridView.DataSource = Me.TblFrecuenciaMedicamentosBindingSource
        Me.TblFrecuenciaMedicamentosDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblFrecuenciaMedicamentosDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblFrecuenciaMedicamentosDataGridView.Name = "TblFrecuenciaMedicamentosDataGridView"
        Me.TblFrecuenciaMedicamentosDataGridView.ReadOnly = True
        Me.TblFrecuenciaMedicamentosDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TblFrecuenciaMedicamentosDataGridView.Size = New System.Drawing.Size(473, 165)
        Me.TblFrecuenciaMedicamentosDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdFrecuenciaMedicamentos"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strDescripcion"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Descripcion"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 330
        '
        'IntIdFrecuenciaMedicamentosLabel
        '
        IntIdFrecuenciaMedicamentosLabel.AutoSize = True
        IntIdFrecuenciaMedicamentosLabel.Location = New System.Drawing.Point(21, 24)
        IntIdFrecuenciaMedicamentosLabel.Name = "IntIdFrecuenciaMedicamentosLabel"
        IntIdFrecuenciaMedicamentosLabel.Size = New System.Drawing.Size(22, 13)
        IntIdFrecuenciaMedicamentosLabel.TabIndex = 0
        IntIdFrecuenciaMedicamentosLabel.Text = "Id :"
        '
        'IntIdFrecuenciaMedicamentosClsTextBox
        '
        Me.IntIdFrecuenciaMedicamentosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblFrecuenciaMedicamentosBindingSource, "intIdFrecuenciaMedicamentos", True))
        Me.IntIdFrecuenciaMedicamentosClsTextBox.DataSource = Nothing
        Me.IntIdFrecuenciaMedicamentosClsTextBox.Enabled = False
        Me.IntIdFrecuenciaMedicamentosClsTextBox.Location = New System.Drawing.Point(92, 21)
        Me.IntIdFrecuenciaMedicamentosClsTextBox.Name = "IntIdFrecuenciaMedicamentosClsTextBox"
        Me.IntIdFrecuenciaMedicamentosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdFrecuenciaMedicamentosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdFrecuenciaMedicamentosClsTextBox.Size = New System.Drawing.Size(60, 20)
        Me.IntIdFrecuenciaMedicamentosClsTextBox.TabIndex = 1
        Me.IntIdFrecuenciaMedicamentosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrDescripcionLabel
        '
        StrDescripcionLabel.AutoSize = True
        StrDescripcionLabel.Location = New System.Drawing.Point(21, 50)
        StrDescripcionLabel.Name = "StrDescripcionLabel"
        StrDescripcionLabel.Size = New System.Drawing.Size(69, 13)
        StrDescripcionLabel.TabIndex = 2
        StrDescripcionLabel.Text = "Descripcion :"
        '
        'StrDescripcionClsTextBox
        '
        Me.StrDescripcionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblFrecuenciaMedicamentosBindingSource, "strDescripcion", True))
        Me.StrDescripcionClsTextBox.DataSource = Nothing
        Me.StrDescripcionClsTextBox.Location = New System.Drawing.Point(92, 47)
        Me.StrDescripcionClsTextBox.Name = "StrDescripcionClsTextBox"
        Me.StrDescripcionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcionClsTextBox.Size = New System.Drawing.Size(342, 20)
        Me.StrDescripcionClsTextBox.TabIndex = 3
        Me.StrDescripcionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'FrmFrecuenciaMedicamentos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(487, 222)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblFrecuenciaMedicamentosBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmFrecuenciaMedicamentos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Frecuencia Medicamentos"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblFrecuenciaMedicamentosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblFrecuenciaMedicamentosBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblFrecuenciaMedicamentosBindingNavigator.ResumeLayout(False)
        Me.TblFrecuenciaMedicamentosBindingNavigator.PerformLayout()
        CType(Me.TblFrecuenciaMedicamentosDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblFrecuenciaMedicamentosDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblFrecuenciaMedicamentosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblFrecuenciaMedicamentosBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblFrecuenciaMedicamentosBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdFrecuenciaMedicamentosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrDescripcionClsTextBox As ClsUtilidades.ClsTextBox
End Class
