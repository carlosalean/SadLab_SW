﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDatosPrestadores
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim BitRealizaConsultasLabel As System.Windows.Forms.Label
        Dim IntIDConsecutivoLabel As System.Windows.Forms.Label
        Dim IntIdPrestadoresLabel As System.Windows.Forms.Label
        Dim StrCodigoPrestadorServicioLabel As System.Windows.Forms.Label
        Dim StrNroDeIDLabel As System.Windows.Forms.Label
        Dim StrRazonSocialLabel As System.Windows.Forms.Label
        Dim StrDireccionLabel As System.Windows.Forms.Label
        Dim StrTelefonoLabel As System.Windows.Forms.Label
        Dim StrResponsabilidadesLabel As System.Windows.Forms.Label
        Dim StrResolucionLabel As System.Windows.Forms.Label
        Dim StrLineaFinalFacturaLabel As System.Windows.Forms.Label
        Dim IntIdConsecutivoFacturaLabel As System.Windows.Forms.Label
        Dim StrTitulosLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmDatosPrestadores))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TblDatosPrestadoreDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.TblDatosPrestadoreBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.StrTitulosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdConsecutivoFacturaClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrLineaFinalFacturaClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrResolucionClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrResponsabilidadesClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrTelefonoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrDireccionClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntCodigoVerificacionClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrTipoDeIDClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.BitRealizaConsultasClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.IntIDConsecutivoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdPrestadoresClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrCodigoPrestadorServicioClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrNroDeIDClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrRazonSocialClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.TblDatosPrestadoreBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblDatosPrestadoreBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        BitRealizaConsultasLabel = New System.Windows.Forms.Label()
        IntIDConsecutivoLabel = New System.Windows.Forms.Label()
        IntIdPrestadoresLabel = New System.Windows.Forms.Label()
        StrCodigoPrestadorServicioLabel = New System.Windows.Forms.Label()
        StrNroDeIDLabel = New System.Windows.Forms.Label()
        StrRazonSocialLabel = New System.Windows.Forms.Label()
        StrDireccionLabel = New System.Windows.Forms.Label()
        StrTelefonoLabel = New System.Windows.Forms.Label()
        StrResponsabilidadesLabel = New System.Windows.Forms.Label()
        StrResolucionLabel = New System.Windows.Forms.Label()
        StrLineaFinalFacturaLabel = New System.Windows.Forms.Label()
        IntIdConsecutivoFacturaLabel = New System.Windows.Forms.Label()
        StrTitulosLabel = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblDatosPrestadoreDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDatosPrestadoreBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblDatosPrestadoreBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblDatosPrestadoreBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'BitRealizaConsultasLabel
        '
        BitRealizaConsultasLabel.AutoSize = True
        BitRealizaConsultasLabel.Location = New System.Drawing.Point(18, 147)
        BitRealizaConsultasLabel.Name = "BitRealizaConsultasLabel"
        BitRealizaConsultasLabel.Size = New System.Drawing.Size(94, 13)
        BitRealizaConsultasLabel.TabIndex = 0
        BitRealizaConsultasLabel.Text = "Realiza Consultas:"
        '
        'IntIDConsecutivoLabel
        '
        IntIDConsecutivoLabel.AutoSize = True
        IntIDConsecutivoLabel.Location = New System.Drawing.Point(18, 120)
        IntIDConsecutivoLabel.Name = "IntIDConsecutivoLabel"
        IntIDConsecutivoLabel.Size = New System.Drawing.Size(97, 13)
        IntIDConsecutivoLabel.TabIndex = 2
        IntIDConsecutivoLabel.Text = "Consecutivo RIPS:"
        '
        'IntIdPrestadoresLabel
        '
        IntIdPrestadoresLabel.AutoSize = True
        IntIdPrestadoresLabel.Location = New System.Drawing.Point(18, 15)
        IntIdPrestadoresLabel.Name = "IntIdPrestadoresLabel"
        IntIdPrestadoresLabel.Size = New System.Drawing.Size(19, 13)
        IntIdPrestadoresLabel.TabIndex = 4
        IntIdPrestadoresLabel.Text = "Id:"
        '
        'StrCodigoPrestadorServicioLabel
        '
        StrCodigoPrestadorServicioLabel.AutoSize = True
        StrCodigoPrestadorServicioLabel.Location = New System.Drawing.Point(18, 94)
        StrCodigoPrestadorServicioLabel.Name = "StrCodigoPrestadorServicioLabel"
        StrCodigoPrestadorServicioLabel.Size = New System.Drawing.Size(43, 13)
        StrCodigoPrestadorServicioLabel.TabIndex = 6
        StrCodigoPrestadorServicioLabel.Text = "Codigo:"
        '
        'StrNroDeIDLabel
        '
        StrNroDeIDLabel.AutoSize = True
        StrNroDeIDLabel.Location = New System.Drawing.Point(18, 41)
        StrNroDeIDLabel.Name = "StrNroDeIDLabel"
        StrNroDeIDLabel.Size = New System.Drawing.Size(110, 13)
        StrNroDeIDLabel.TabIndex = 8
        StrNroDeIDLabel.Text = "Nro De Identificación:"
        '
        'StrRazonSocialLabel
        '
        StrRazonSocialLabel.AutoSize = True
        StrRazonSocialLabel.Location = New System.Drawing.Point(18, 68)
        StrRazonSocialLabel.Name = "StrRazonSocialLabel"
        StrRazonSocialLabel.Size = New System.Drawing.Size(73, 13)
        StrRazonSocialLabel.TabIndex = 10
        StrRazonSocialLabel.Text = "Razon Social:"
        '
        'StrDireccionLabel
        '
        StrDireccionLabel.AutoSize = True
        StrDireccionLabel.Location = New System.Drawing.Point(18, 175)
        StrDireccionLabel.Name = "StrDireccionLabel"
        StrDireccionLabel.Size = New System.Drawing.Size(55, 13)
        StrDireccionLabel.TabIndex = 14
        StrDireccionLabel.Text = "Dirección:"
        '
        'StrTelefonoLabel
        '
        StrTelefonoLabel.AutoSize = True
        StrTelefonoLabel.Location = New System.Drawing.Point(18, 201)
        StrTelefonoLabel.Name = "StrTelefonoLabel"
        StrTelefonoLabel.Size = New System.Drawing.Size(52, 13)
        StrTelefonoLabel.TabIndex = 16
        StrTelefonoLabel.Text = "Teléfono:"
        '
        'StrResponsabilidadesLabel
        '
        StrResponsabilidadesLabel.AutoSize = True
        StrResponsabilidadesLabel.Location = New System.Drawing.Point(18, 310)
        StrResponsabilidadesLabel.Name = "StrResponsabilidadesLabel"
        StrResponsabilidadesLabel.Size = New System.Drawing.Size(99, 13)
        StrResponsabilidadesLabel.TabIndex = 18
        StrResponsabilidadesLabel.Text = "Responsabilidades:"
        '
        'StrResolucionLabel
        '
        StrResolucionLabel.AutoSize = True
        StrResolucionLabel.Location = New System.Drawing.Point(18, 227)
        StrResolucionLabel.Name = "StrResolucionLabel"
        StrResolucionLabel.Size = New System.Drawing.Size(63, 13)
        StrResolucionLabel.TabIndex = 22
        StrResolucionLabel.Text = "Resolución:"
        '
        'StrLineaFinalFacturaLabel
        '
        StrLineaFinalFacturaLabel.AutoSize = True
        StrLineaFinalFacturaLabel.Location = New System.Drawing.Point(18, 254)
        StrLineaFinalFacturaLabel.Name = "StrLineaFinalFacturaLabel"
        StrLineaFinalFacturaLabel.Size = New System.Drawing.Size(100, 13)
        StrLineaFinalFacturaLabel.TabIndex = 24
        StrLineaFinalFacturaLabel.Text = "Linea Final Factura:"
        '
        'IntIdConsecutivoFacturaLabel
        '
        IntIdConsecutivoFacturaLabel.AutoSize = True
        IntIdConsecutivoFacturaLabel.Location = New System.Drawing.Point(18, 279)
        IntIdConsecutivoFacturaLabel.Name = "IntIdConsecutivoFacturaLabel"
        IntIdConsecutivoFacturaLabel.Size = New System.Drawing.Size(108, 13)
        IntIdConsecutivoFacturaLabel.TabIndex = 26
        IntIdConsecutivoFacturaLabel.Text = "Consecutivo Factura:"
        '
        'StrTitulosLabel
        '
        StrTitulosLabel.AutoSize = True
        StrTitulosLabel.Location = New System.Drawing.Point(18, 401)
        StrTitulosLabel.Name = "StrTitulosLabel"
        StrTitulosLabel.Size = New System.Drawing.Size(41, 13)
        StrTitulosLabel.TabIndex = 26
        StrTitulosLabel.Text = "Titulos:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(590, 485)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.Controls.Add(Me.TblDatosPrestadoreDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(582, 459)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblDatosPrestadoreDataGridView
        '
        Me.TblDatosPrestadoreDataGridView.AllowUserToAddRows = False
        Me.TblDatosPrestadoreDataGridView.AllowUserToDeleteRows = False
        Me.TblDatosPrestadoreDataGridView.AutoGenerateColumns = False
        Me.TblDatosPrestadoreDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblDatosPrestadoreDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7})
        Me.TblDatosPrestadoreDataGridView.DataSource = Me.TblDatosPrestadoreBindingSource
        Me.TblDatosPrestadoreDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblDatosPrestadoreDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblDatosPrestadoreDataGridView.Name = "TblDatosPrestadoreDataGridView"
        Me.TblDatosPrestadoreDataGridView.ReadOnly = True
        Me.TblDatosPrestadoreDataGridView.Size = New System.Drawing.Size(576, 453)
        Me.TblDatosPrestadoreDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdPrestadores"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strCodigoPrestadorServicio"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Codigo "
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 80
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "strRazonSocial"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Razon Social"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 250
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "strNroDeID"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Nro De Identificación"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 150
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "strTipoDeID"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Tipo"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Width = 80
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "intIDConsecutivo"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Consecutivo"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "bitRealizaConsultas"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Realiza Consultas"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn7.Width = 120
        '
        'TblDatosPrestadoreBindingSource
        '
        Me.TblDatosPrestadoreBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDatosPrestadores)
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.Controls.Add(StrTitulosLabel)
        Me.TabPage2.Controls.Add(Me.StrTitulosClsTextBox)
        Me.TabPage2.Controls.Add(IntIdConsecutivoFacturaLabel)
        Me.TabPage2.Controls.Add(Me.IntIdConsecutivoFacturaClsTextBox)
        Me.TabPage2.Controls.Add(StrLineaFinalFacturaLabel)
        Me.TabPage2.Controls.Add(Me.StrLineaFinalFacturaClsTextBox)
        Me.TabPage2.Controls.Add(StrResolucionLabel)
        Me.TabPage2.Controls.Add(Me.StrResolucionClsTextBox)
        Me.TabPage2.Controls.Add(StrResponsabilidadesLabel)
        Me.TabPage2.Controls.Add(Me.StrResponsabilidadesClsTextBox)
        Me.TabPage2.Controls.Add(StrTelefonoLabel)
        Me.TabPage2.Controls.Add(Me.StrTelefonoClsTextBox)
        Me.TabPage2.Controls.Add(StrDireccionLabel)
        Me.TabPage2.Controls.Add(Me.StrDireccionClsTextBox)
        Me.TabPage2.Controls.Add(Me.IntCodigoVerificacionClsTextBox)
        Me.TabPage2.Controls.Add(Me.StrTipoDeIDClsComboBox)
        Me.TabPage2.Controls.Add(BitRealizaConsultasLabel)
        Me.TabPage2.Controls.Add(Me.BitRealizaConsultasClsCheckBox)
        Me.TabPage2.Controls.Add(IntIDConsecutivoLabel)
        Me.TabPage2.Controls.Add(Me.IntIDConsecutivoClsTextBox)
        Me.TabPage2.Controls.Add(IntIdPrestadoresLabel)
        Me.TabPage2.Controls.Add(Me.IntIdPrestadoresClsTextBox)
        Me.TabPage2.Controls.Add(StrCodigoPrestadorServicioLabel)
        Me.TabPage2.Controls.Add(Me.StrCodigoPrestadorServicioClsTextBox)
        Me.TabPage2.Controls.Add(StrNroDeIDLabel)
        Me.TabPage2.Controls.Add(Me.StrNroDeIDClsTextBox)
        Me.TabPage2.Controls.Add(StrRazonSocialLabel)
        Me.TabPage2.Controls.Add(Me.StrRazonSocialClsTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(582, 459)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'StrTitulosClsTextBox
        '
        Me.StrTitulosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "strTitulos", True))
        Me.StrTitulosClsTextBox.DataSource = Nothing
        Me.StrTitulosClsTextBox.EnterEntreCampos = True
        Me.StrTitulosClsTextBox.Location = New System.Drawing.Point(130, 401)
        Me.StrTitulosClsTextBox.Multiline = True
        Me.StrTitulosClsTextBox.Name = "StrTitulosClsTextBox"
        Me.StrTitulosClsTextBox.NombreCodigoF2 = Nothing
        Me.StrTitulosClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrTitulosClsTextBox.Size = New System.Drawing.Size(313, 50)
        Me.StrTitulosClsTextBox.TabIndex = 27
        Me.StrTitulosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdConsecutivoFacturaClsTextBox
        '
        Me.IntIdConsecutivoFacturaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "intIdConsecutivoFactura", True))
        Me.IntIdConsecutivoFacturaClsTextBox.DataSource = Nothing
        Me.IntIdConsecutivoFacturaClsTextBox.EnterEntreCampos = True
        Me.IntIdConsecutivoFacturaClsTextBox.Location = New System.Drawing.Point(130, 276)
        Me.IntIdConsecutivoFacturaClsTextBox.Name = "IntIdConsecutivoFacturaClsTextBox"
        Me.IntIdConsecutivoFacturaClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdConsecutivoFacturaClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdConsecutivoFacturaClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.IntIdConsecutivoFacturaClsTextBox.TabIndex = 12
        Me.IntIdConsecutivoFacturaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'StrLineaFinalFacturaClsTextBox
        '
        Me.StrLineaFinalFacturaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "strLineaFinalFactura", True))
        Me.StrLineaFinalFacturaClsTextBox.DataSource = Nothing
        Me.StrLineaFinalFacturaClsTextBox.EnterEntreCampos = True
        Me.StrLineaFinalFacturaClsTextBox.Location = New System.Drawing.Point(130, 250)
        Me.StrLineaFinalFacturaClsTextBox.Name = "StrLineaFinalFacturaClsTextBox"
        Me.StrLineaFinalFacturaClsTextBox.NombreCodigoF2 = Nothing
        Me.StrLineaFinalFacturaClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrLineaFinalFacturaClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrLineaFinalFacturaClsTextBox.TabIndex = 11
        Me.StrLineaFinalFacturaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrResolucionClsTextBox
        '
        Me.StrResolucionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "strResolucion", True))
        Me.StrResolucionClsTextBox.DataSource = Nothing
        Me.StrResolucionClsTextBox.EnterEntreCampos = True
        Me.StrResolucionClsTextBox.Location = New System.Drawing.Point(130, 224)
        Me.StrResolucionClsTextBox.Name = "StrResolucionClsTextBox"
        Me.StrResolucionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrResolucionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrResolucionClsTextBox.Size = New System.Drawing.Size(281, 20)
        Me.StrResolucionClsTextBox.TabIndex = 10
        Me.StrResolucionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrResponsabilidadesClsTextBox
        '
        Me.StrResponsabilidadesClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "strResponsabilidades", True))
        Me.StrResponsabilidadesClsTextBox.DataSource = Nothing
        Me.StrResponsabilidadesClsTextBox.EnterEntreCampos = True
        Me.StrResponsabilidadesClsTextBox.Location = New System.Drawing.Point(130, 310)
        Me.StrResponsabilidadesClsTextBox.Multiline = True
        Me.StrResponsabilidadesClsTextBox.Name = "StrResponsabilidadesClsTextBox"
        Me.StrResponsabilidadesClsTextBox.NombreCodigoF2 = Nothing
        Me.StrResponsabilidadesClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrResponsabilidadesClsTextBox.Size = New System.Drawing.Size(313, 85)
        Me.StrResponsabilidadesClsTextBox.TabIndex = 13
        Me.StrResponsabilidadesClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrTelefonoClsTextBox
        '
        Me.StrTelefonoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "StrTelefono", True))
        Me.StrTelefonoClsTextBox.DataSource = Nothing
        Me.StrTelefonoClsTextBox.EnterEntreCampos = True
        Me.StrTelefonoClsTextBox.Location = New System.Drawing.Point(130, 198)
        Me.StrTelefonoClsTextBox.Name = "StrTelefonoClsTextBox"
        Me.StrTelefonoClsTextBox.NombreCodigoF2 = Nothing
        Me.StrTelefonoClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrTelefonoClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrTelefonoClsTextBox.TabIndex = 9
        Me.StrTelefonoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrDireccionClsTextBox
        '
        Me.StrDireccionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "strDireccion", True))
        Me.StrDireccionClsTextBox.DataSource = Nothing
        Me.StrDireccionClsTextBox.EnterEntreCampos = True
        Me.StrDireccionClsTextBox.Location = New System.Drawing.Point(130, 172)
        Me.StrDireccionClsTextBox.Name = "StrDireccionClsTextBox"
        Me.StrDireccionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDireccionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDireccionClsTextBox.Size = New System.Drawing.Size(281, 20)
        Me.StrDireccionClsTextBox.TabIndex = 8
        Me.StrDireccionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntCodigoVerificacionClsTextBox
        '
        Me.IntCodigoVerificacionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "intCodigoVerificacion", True))
        Me.IntCodigoVerificacionClsTextBox.DataSource = Nothing
        Me.IntCodigoVerificacionClsTextBox.EnterEntreCampos = True
        Me.IntCodigoVerificacionClsTextBox.Location = New System.Drawing.Point(240, 38)
        Me.IntCodigoVerificacionClsTextBox.Name = "IntCodigoVerificacionClsTextBox"
        Me.IntCodigoVerificacionClsTextBox.NombreCodigoF2 = Nothing
        Me.IntCodigoVerificacionClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntCodigoVerificacionClsTextBox.Size = New System.Drawing.Size(31, 20)
        Me.IntCodigoVerificacionClsTextBox.TabIndex = 2
        Me.IntCodigoVerificacionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrTipoDeIDClsComboBox
        '
        Me.StrTipoDeIDClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedItem", Me.TblDatosPrestadoreBindingSource, "strTipoDeID", True))
        Me.StrTipoDeIDClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.StrTipoDeIDClsComboBox.FormattingEnabled = True
        Me.StrTipoDeIDClsComboBox.Items.AddRange(New Object() {"CC", "NI"})
        Me.StrTipoDeIDClsComboBox.Location = New System.Drawing.Point(277, 37)
        Me.StrTipoDeIDClsComboBox.Name = "StrTipoDeIDClsComboBox"
        Me.StrTipoDeIDClsComboBox.Size = New System.Drawing.Size(69, 21)
        Me.StrTipoDeIDClsComboBox.TabIndex = 3
        '
        'BitRealizaConsultasClsCheckBox
        '
        Me.BitRealizaConsultasClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblDatosPrestadoreBindingSource, "bitRealizaConsultas", True))
        Me.BitRealizaConsultasClsCheckBox.Location = New System.Drawing.Point(130, 143)
        Me.BitRealizaConsultasClsCheckBox.Name = "BitRealizaConsultasClsCheckBox"
        Me.BitRealizaConsultasClsCheckBox.Size = New System.Drawing.Size(16, 24)
        Me.BitRealizaConsultasClsCheckBox.TabIndex = 7
        Me.BitRealizaConsultasClsCheckBox.UseVisualStyleBackColor = True
        '
        'IntIDConsecutivoClsTextBox
        '
        Me.IntIDConsecutivoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "intIDConsecutivo", True))
        Me.IntIDConsecutivoClsTextBox.DataSource = Nothing
        Me.IntIDConsecutivoClsTextBox.EnterEntreCampos = True
        Me.IntIDConsecutivoClsTextBox.Location = New System.Drawing.Point(130, 117)
        Me.IntIDConsecutivoClsTextBox.Name = "IntIDConsecutivoClsTextBox"
        Me.IntIDConsecutivoClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIDConsecutivoClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIDConsecutivoClsTextBox.Size = New System.Drawing.Size(104, 20)
        Me.IntIDConsecutivoClsTextBox.TabIndex = 6
        Me.IntIDConsecutivoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdPrestadoresClsTextBox
        '
        Me.IntIdPrestadoresClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "intIdPrestadores", True))
        Me.IntIdPrestadoresClsTextBox.DataSource = Nothing
        Me.IntIdPrestadoresClsTextBox.Enabled = False
        Me.IntIdPrestadoresClsTextBox.EnterEntreCampos = True
        Me.IntIdPrestadoresClsTextBox.Location = New System.Drawing.Point(130, 12)
        Me.IntIdPrestadoresClsTextBox.Name = "IntIdPrestadoresClsTextBox"
        Me.IntIdPrestadoresClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdPrestadoresClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdPrestadoresClsTextBox.Size = New System.Drawing.Size(33, 20)
        Me.IntIdPrestadoresClsTextBox.TabIndex = 0
        Me.IntIdPrestadoresClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrCodigoPrestadorServicioClsTextBox
        '
        Me.StrCodigoPrestadorServicioClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "strCodigoPrestadorServicio", True))
        Me.StrCodigoPrestadorServicioClsTextBox.DataSource = Nothing
        Me.StrCodigoPrestadorServicioClsTextBox.EnterEntreCampos = True
        Me.StrCodigoPrestadorServicioClsTextBox.Location = New System.Drawing.Point(130, 91)
        Me.StrCodigoPrestadorServicioClsTextBox.Name = "StrCodigoPrestadorServicioClsTextBox"
        Me.StrCodigoPrestadorServicioClsTextBox.NombreCodigoF2 = Nothing
        Me.StrCodigoPrestadorServicioClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrCodigoPrestadorServicioClsTextBox.Size = New System.Drawing.Size(104, 20)
        Me.StrCodigoPrestadorServicioClsTextBox.TabIndex = 5
        Me.StrCodigoPrestadorServicioClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrNroDeIDClsTextBox
        '
        Me.StrNroDeIDClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "strNroDeID", True))
        Me.StrNroDeIDClsTextBox.DataSource = Nothing
        Me.StrNroDeIDClsTextBox.EnterEntreCampos = True
        Me.StrNroDeIDClsTextBox.Location = New System.Drawing.Point(130, 38)
        Me.StrNroDeIDClsTextBox.Name = "StrNroDeIDClsTextBox"
        Me.StrNroDeIDClsTextBox.NombreCodigoF2 = Nothing
        Me.StrNroDeIDClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrNroDeIDClsTextBox.Size = New System.Drawing.Size(104, 20)
        Me.StrNroDeIDClsTextBox.TabIndex = 1
        Me.StrNroDeIDClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrRazonSocialClsTextBox
        '
        Me.StrRazonSocialClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDatosPrestadoreBindingSource, "strRazonSocial", True))
        Me.StrRazonSocialClsTextBox.DataSource = Nothing
        Me.StrRazonSocialClsTextBox.EnterEntreCampos = True
        Me.StrRazonSocialClsTextBox.Location = New System.Drawing.Point(130, 65)
        Me.StrRazonSocialClsTextBox.Name = "StrRazonSocialClsTextBox"
        Me.StrRazonSocialClsTextBox.NombreCodigoF2 = Nothing
        Me.StrRazonSocialClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrRazonSocialClsTextBox.Size = New System.Drawing.Size(313, 20)
        Me.StrRazonSocialClsTextBox.TabIndex = 4
        Me.StrRazonSocialClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblDatosPrestadoreBindingNavigator
        '
        Me.TblDatosPrestadoreBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblDatosPrestadoreBindingNavigator.BindingSource = Me.TblDatosPrestadoreBindingSource
        Me.TblDatosPrestadoreBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblDatosPrestadoreBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblDatosPrestadoreBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblDatosPrestadoreBindingNavigatorSaveItem})
        Me.TblDatosPrestadoreBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblDatosPrestadoreBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblDatosPrestadoreBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblDatosPrestadoreBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblDatosPrestadoreBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblDatosPrestadoreBindingNavigator.Name = "TblDatosPrestadoreBindingNavigator"
        Me.TblDatosPrestadoreBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblDatosPrestadoreBindingNavigator.Size = New System.Drawing.Size(590, 25)
        Me.TblDatosPrestadoreBindingNavigator.TabIndex = 1
        Me.TblDatosPrestadoreBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblDatosPrestadoreBindingNavigatorSaveItem
        '
        Me.TblDatosPrestadoreBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblDatosPrestadoreBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblDatosPrestadoreBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblDatosPrestadoreBindingNavigatorSaveItem.Name = "TblDatosPrestadoreBindingNavigatorSaveItem"
        Me.TblDatosPrestadoreBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblDatosPrestadoreBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'FrmDatosPrestadores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(590, 510)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblDatosPrestadoreBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmDatosPrestadores"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Datos Prestadores"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblDatosPrestadoreDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDatosPrestadoreBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblDatosPrestadoreBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblDatosPrestadoreBindingNavigator.ResumeLayout(False)
        Me.TblDatosPrestadoreBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblDatosPrestadoreDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblDatosPrestadoreBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDatosPrestadoreBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblDatosPrestadoreBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents StrTipoDeIDClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents BitRealizaConsultasClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents IntIDConsecutivoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdPrestadoresClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrCodigoPrestadorServicioClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNroDeIDClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrRazonSocialClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents IntCodigoVerificacionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrTelefonoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrDireccionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrResponsabilidadesClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrLineaFinalFacturaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrResolucionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdConsecutivoFacturaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrTitulosClsTextBox As ClsUtilidades.ClsTextBox
End Class
