﻿Imports System.Windows.Forms

Public Class uscAntecedentesGinecoObstetricos
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mIdentificacion As String
    Private _btn As Windows.Forms.Button
    Private mclsUtilidadesHC As clsUtilidadesHC
    Private _IdUsuario As String
    Private mNuevo As Boolean

    Public Sub New()
        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()
        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
    End Sub

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mIdentificacion() As String
        Get
            Return _mIdentificacion
        End Get
        Set(ByVal value As String)
            _mIdentificacion = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub cargarDatosTabAG()
        Try
            Dim mconsulta = (From p In dc.tblAntecedentesGinecoObstetricos Where p.strNroIdentificacion = mIdentificacion Select p.bitModoTexto, p.strHcTextoGinecoObst)
            If mconsulta.Count > 0 Then
                For Each c In mconsulta
                    If c.bitModoTexto = True Then
                        StrHcTextoGinecoObstTextBox.Dock = DockStyle.Fill
                        StrHcTextoGinecoObstTextBox.BringToFront()
                        StrHcTextoGinecoObstTextBox.Multiline = True
                        StrHcTextoGinecoObstTextBox.Visible = True
                        prCargarDatosAntecedentesGinecoObstetricos()
                    Else
                        prCargarDatosAntecedentesGinecoObstetricos()
                        Exit For
                    End If
                Next
            Else
                mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
                If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
                    StrHcTextoGinecoObstTextBox.Dock = DockStyle.Fill
                    StrHcTextoGinecoObstTextBox.BringToFront()
                    StrHcTextoGinecoObstTextBox.Multiline = True
                    StrHcTextoGinecoObstTextBox.Visible = True
                    prCargarDatosAntecedentesGinecoObstetricos()
                Else
                    prCargarDatosAntecedentesGinecoObstetricos()
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub prCargarDatosAntecedentesGinecoObstetricos()
        Try
            Dim mConsultaTipos = (From t In dc.tblTipos Where t.strTipo = "TIPO_CICLO" Select t)
            TblTipoBindingSource.DataSource = mConsultaTipos

            Dim mconsulta = (From p In dc.tblAntecedentesGinecoObstetricos Where p.strNroIdentificacion = mIdentificacion Select p)
            If mconsulta.Count > 0 Then
                TblAntecedentesGinecoObstetricosBindingSource.DataSource = mconsulta
                mNuevo = False
            Else
                TblAntecedentesGinecoObstetricosBindingSource.AddNew()
                mNuevo = True
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblEPBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblEPBindingNavigatorSaveItem.Click
        prGuardar()
    End Sub

    Private Sub uscAntecedentesGinecoObstetricos_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        prGuardar()
    End Sub

    Public Sub prGuardar() Implements IAbandonarUC.prGuardar

        Try
            If TblAntecedentesGinecoObstetricosBindingSource.Position < 0 Then
                Exit Sub
            End If

            If TblAntecedentesGinecoObstetricosBindingSource.Position = 0 Then
                TblAntecedentesGinecoObstetricosBindingSource.Item(TblAntecedentesGinecoObstetricosBindingSource.Position).strHcTextoGinecoObst = StrHcTextoGinecoObstTextBox.Text
                TblAntecedentesGinecoObstetricosBindingSource.Item(TblAntecedentesGinecoObstetricosBindingSource.Position).strNroIdentificacion = mIdentificacion
                If StrHcTextoGinecoObstTextBox.Dock = DockStyle.Fill Then
                    TblAntecedentesGinecoObstetricosBindingSource.Item(TblAntecedentesGinecoObstetricosBindingSource.Position).bitModoTexto = True
                Else
                    TblAntecedentesGinecoObstetricosBindingSource.Item(TblAntecedentesGinecoObstetricosBindingSource.Position).bitModoTexto = False
                End If
                TblAntecedentesGinecoObstetricosBindingSource.EndEdit()
                If mNuevo = True Then
                    dc.tblAntecedentesGinecoObstetricos.InsertOnSubmit(TblAntecedentesGinecoObstetricosBindingSource.Item(TblAntecedentesGinecoObstetricosBindingSource.Position))
                End If
                dc.SubmitChanges()
                mNuevo = False
            End If
            TblAntecedentesGinecoObstetricosBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
End Class
