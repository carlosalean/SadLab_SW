﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmRegistroSalida
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IntIdCitaLabel As System.Windows.Forms.Label
        Dim IntIdPacienteLabel As System.Windows.Forms.Label
        Dim IntIdServicioLabel As System.Windows.Forms.Label
        Dim NumValorUnitarioLabel As System.Windows.Forms.Label
        Dim IntNroServiciosLabel As System.Windows.Forms.Label
        Dim NumValorDescuentoLabel As System.Windows.Forms.Label
        Dim StrNroOrdenLabel As System.Windows.Forms.Label
        Dim StrCodAtencionLabel As System.Windows.Forms.Label
        Dim DtmFechaAutorizacionLabel As System.Windows.Forms.Label
        Dim IntIdProcedimientoLabel As System.Windows.Forms.Label
        Dim IntIdDiagnosticoPrevioLabel As System.Windows.Forms.Label
        Dim IntIdDiagnosticoPosteriorLabel As System.Windows.Forms.Label
        Dim IntIdComplicacionLabel As System.Windows.Forms.Label
        Dim IntIdClaseProcedimientoLabel As System.Windows.Forms.Label
        Dim IntFormaRealizaActoQLabel As System.Windows.Forms.Label
        Dim IntIdPersonalAtiendeLabel As System.Windows.Forms.Label
        Dim IntTipoProcedimientoLabel As System.Windows.Forms.Label
        Dim StrCondicionPacienteLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmRegistroSalida))
        Me.NumValorCoopagoLabel = New System.Windows.Forms.Label()
        Me.StrNroIdPacienteTextBox = New ClsUtilidades.ClsTextBox()
        Me.TblCitaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TextBoxNombre = New ClsUtilidades.ClsTextBox()
        Me.IntIdCitaTextBox = New ClsUtilidades.ClsTextBox()
        Me.VerificationControl = New DPFP.Gui.Verification.VerificationControl()
        Me.TblEmpeadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdServicioClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblServicioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.NumValorUnitarioClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntNroServiciosClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.NumValorCoopagoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.NumValorDescuentoClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrNroOrdenClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrCodAtencionClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.DtmFechaAutorizacionClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.IntIdProcedimientoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblProcedimientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdDiagnosticoPrevioClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblDisgnosticoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdDiagnosticoPosteriorClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblDisgnosticoPosBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdComplicacionClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblComplicacionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdClaseProcedimientoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblClaseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntFormaRealizaActoQClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblFormaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntIdPersonalAtiendeClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblAtiendeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntTipoProcedimientoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StrCondicionPacienteClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.ClsComboBox1 = New ClsUtilidades.ClsComboBox()
        Me.ClsComboBox2 = New ClsUtilidades.ClsComboBox()
        Me.ClsComboBox3 = New ClsUtilidades.ClsComboBox()
        Me.NoRegistraHuellaCheckBox = New System.Windows.Forms.CheckBox()
        Me.TblCitaBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TblCitaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnPago = New System.Windows.Forms.ToolStripButton()
        Me.btnHabilitarCoopago = New System.Windows.Forms.Button()
        IntIdCitaLabel = New System.Windows.Forms.Label()
        IntIdPacienteLabel = New System.Windows.Forms.Label()
        IntIdServicioLabel = New System.Windows.Forms.Label()
        NumValorUnitarioLabel = New System.Windows.Forms.Label()
        IntNroServiciosLabel = New System.Windows.Forms.Label()
        NumValorDescuentoLabel = New System.Windows.Forms.Label()
        StrNroOrdenLabel = New System.Windows.Forms.Label()
        StrCodAtencionLabel = New System.Windows.Forms.Label()
        DtmFechaAutorizacionLabel = New System.Windows.Forms.Label()
        IntIdProcedimientoLabel = New System.Windows.Forms.Label()
        IntIdDiagnosticoPrevioLabel = New System.Windows.Forms.Label()
        IntIdDiagnosticoPosteriorLabel = New System.Windows.Forms.Label()
        IntIdComplicacionLabel = New System.Windows.Forms.Label()
        IntIdClaseProcedimientoLabel = New System.Windows.Forms.Label()
        IntFormaRealizaActoQLabel = New System.Windows.Forms.Label()
        IntIdPersonalAtiendeLabel = New System.Windows.Forms.Label()
        IntTipoProcedimientoLabel = New System.Windows.Forms.Label()
        StrCondicionPacienteLabel = New System.Windows.Forms.Label()
        CType(Me.TblCitaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblServicioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDisgnosticoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDisgnosticoPosBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblComplicacionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblClaseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblFormaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblAtiendeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCitaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCitaBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntIdCitaLabel
        '
        IntIdCitaLabel.AutoSize = True
        IntIdCitaLabel.Location = New System.Drawing.Point(11, 44)
        IntIdCitaLabel.Name = "IntIdCitaLabel"
        IntIdCitaLabel.Size = New System.Drawing.Size(19, 13)
        IntIdCitaLabel.TabIndex = 28
        IntIdCitaLabel.Text = "Id:"
        '
        'IntIdPacienteLabel
        '
        IntIdPacienteLabel.AutoSize = True
        IntIdPacienteLabel.Location = New System.Drawing.Point(11, 70)
        IntIdPacienteLabel.Name = "IntIdPacienteLabel"
        IntIdPacienteLabel.Size = New System.Drawing.Size(52, 13)
        IntIdPacienteLabel.TabIndex = 29
        IntIdPacienteLabel.Text = "Paciente:"
        '
        'IntIdServicioLabel
        '
        IntIdServicioLabel.AutoSize = True
        IntIdServicioLabel.Location = New System.Drawing.Point(15, 181)
        IntIdServicioLabel.Name = "IntIdServicioLabel"
        IntIdServicioLabel.Size = New System.Drawing.Size(48, 13)
        IntIdServicioLabel.TabIndex = 41
        IntIdServicioLabel.Text = "Servicio:"
        '
        'NumValorUnitarioLabel
        '
        NumValorUnitarioLabel.AutoSize = True
        NumValorUnitarioLabel.Location = New System.Drawing.Point(13, 205)
        NumValorUnitarioLabel.Name = "NumValorUnitarioLabel"
        NumValorUnitarioLabel.Size = New System.Drawing.Size(73, 13)
        NumValorUnitarioLabel.TabIndex = 42
        NumValorUnitarioLabel.Text = "Valor Unitario:"
        NumValorUnitarioLabel.Visible = False
        '
        'IntNroServiciosLabel
        '
        IntNroServiciosLabel.AutoSize = True
        IntNroServiciosLabel.Location = New System.Drawing.Point(227, 208)
        IntNroServiciosLabel.Name = "IntNroServiciosLabel"
        IntNroServiciosLabel.Size = New System.Drawing.Size(73, 13)
        IntNroServiciosLabel.TabIndex = 43
        IntNroServiciosLabel.Text = "Nro Servicios:"
        IntNroServiciosLabel.Visible = False
        '
        'NumValorDescuentoLabel
        '
        NumValorDescuentoLabel.AutoSize = True
        NumValorDescuentoLabel.Location = New System.Drawing.Point(12, 234)
        NumValorDescuentoLabel.Name = "NumValorDescuentoLabel"
        NumValorDescuentoLabel.Size = New System.Drawing.Size(89, 13)
        NumValorDescuentoLabel.TabIndex = 45
        NumValorDescuentoLabel.Text = "Valor Descuento:"
        NumValorDescuentoLabel.Visible = False
        '
        'StrNroOrdenLabel
        '
        StrNroOrdenLabel.AutoSize = True
        StrNroOrdenLabel.Location = New System.Drawing.Point(12, 122)
        StrNroOrdenLabel.Name = "StrNroOrdenLabel"
        StrNroOrdenLabel.Size = New System.Drawing.Size(88, 13)
        StrNroOrdenLabel.TabIndex = 47
        StrNroOrdenLabel.Text = "Nro Autorización:"
        '
        'StrCodAtencionLabel
        '
        StrCodAtencionLabel.AutoSize = True
        StrCodAtencionLabel.Location = New System.Drawing.Point(227, 234)
        StrCodAtencionLabel.Name = "StrCodAtencionLabel"
        StrCodAtencionLabel.Size = New System.Drawing.Size(74, 13)
        StrCodAtencionLabel.TabIndex = 48
        StrCodAtencionLabel.Text = "Cod Atención:"
        StrCodAtencionLabel.Visible = False
        '
        'DtmFechaAutorizacionLabel
        '
        DtmFechaAutorizacionLabel.AutoSize = True
        DtmFechaAutorizacionLabel.Location = New System.Drawing.Point(12, 260)
        DtmFechaAutorizacionLabel.Name = "DtmFechaAutorizacionLabel"
        DtmFechaAutorizacionLabel.Size = New System.Drawing.Size(101, 13)
        DtmFechaAutorizacionLabel.TabIndex = 49
        DtmFechaAutorizacionLabel.Text = "Fecha Autorizacion:"
        DtmFechaAutorizacionLabel.Visible = False
        AddHandler DtmFechaAutorizacionLabel.Click, AddressOf Me.DtmFechaAutorizacionLabel_Click
        '
        'IntIdProcedimientoLabel
        '
        IntIdProcedimientoLabel.AutoSize = True
        IntIdProcedimientoLabel.Location = New System.Drawing.Point(12, 286)
        IntIdProcedimientoLabel.Name = "IntIdProcedimientoLabel"
        IntIdProcedimientoLabel.Size = New System.Drawing.Size(77, 13)
        IntIdProcedimientoLabel.TabIndex = 50
        IntIdProcedimientoLabel.Text = "Procedimiento:"
        IntIdProcedimientoLabel.Visible = False
        '
        'IntIdDiagnosticoPrevioLabel
        '
        IntIdDiagnosticoPrevioLabel.AutoSize = True
        IntIdDiagnosticoPrevioLabel.Location = New System.Drawing.Point(12, 313)
        IntIdDiagnosticoPrevioLabel.Name = "IntIdDiagnosticoPrevioLabel"
        IntIdDiagnosticoPrevioLabel.Size = New System.Drawing.Size(99, 13)
        IntIdDiagnosticoPrevioLabel.TabIndex = 51
        IntIdDiagnosticoPrevioLabel.Text = "Diagnostico Previo:"
        IntIdDiagnosticoPrevioLabel.Visible = False
        '
        'IntIdDiagnosticoPosteriorLabel
        '
        IntIdDiagnosticoPosteriorLabel.AutoSize = True
        IntIdDiagnosticoPosteriorLabel.Location = New System.Drawing.Point(12, 340)
        IntIdDiagnosticoPosteriorLabel.Name = "IntIdDiagnosticoPosteriorLabel"
        IntIdDiagnosticoPosteriorLabel.Size = New System.Drawing.Size(90, 13)
        IntIdDiagnosticoPosteriorLabel.TabIndex = 52
        IntIdDiagnosticoPosteriorLabel.Text = "Diagnostico Post:"
        IntIdDiagnosticoPosteriorLabel.Visible = False
        '
        'IntIdComplicacionLabel
        '
        IntIdComplicacionLabel.AutoSize = True
        IntIdComplicacionLabel.Location = New System.Drawing.Point(12, 367)
        IntIdComplicacionLabel.Name = "IntIdComplicacionLabel"
        IntIdComplicacionLabel.Size = New System.Drawing.Size(73, 13)
        IntIdComplicacionLabel.TabIndex = 53
        IntIdComplicacionLabel.Text = "Complicacion:"
        IntIdComplicacionLabel.Visible = False
        '
        'IntIdClaseProcedimientoLabel
        '
        IntIdClaseProcedimientoLabel.AutoSize = True
        IntIdClaseProcedimientoLabel.Location = New System.Drawing.Point(13, 394)
        IntIdClaseProcedimientoLabel.Name = "IntIdClaseProcedimientoLabel"
        IntIdClaseProcedimientoLabel.Size = New System.Drawing.Size(106, 13)
        IntIdClaseProcedimientoLabel.TabIndex = 54
        IntIdClaseProcedimientoLabel.Text = "Clase Procedimiento:"
        IntIdClaseProcedimientoLabel.Visible = False
        '
        'IntFormaRealizaActoQLabel
        '
        IntFormaRealizaActoQLabel.AutoSize = True
        IntFormaRealizaActoQLabel.Location = New System.Drawing.Point(272, 397)
        IntFormaRealizaActoQLabel.Name = "IntFormaRealizaActoQLabel"
        IntFormaRealizaActoQLabel.Size = New System.Drawing.Size(153, 13)
        IntFormaRealizaActoQLabel.TabIndex = 55
        IntFormaRealizaActoQLabel.Text = "Forma Realiza Acto Quirurgico:"
        IntFormaRealizaActoQLabel.Visible = False
        '
        'IntIdPersonalAtiendeLabel
        '
        IntIdPersonalAtiendeLabel.AutoSize = True
        IntIdPersonalAtiendeLabel.Location = New System.Drawing.Point(12, 421)
        IntIdPersonalAtiendeLabel.Name = "IntIdPersonalAtiendeLabel"
        IntIdPersonalAtiendeLabel.Size = New System.Drawing.Size(90, 13)
        IntIdPersonalAtiendeLabel.TabIndex = 56
        IntIdPersonalAtiendeLabel.Text = "Personal Atiende:"
        IntIdPersonalAtiendeLabel.Visible = False
        '
        'IntTipoProcedimientoLabel
        '
        IntTipoProcedimientoLabel.AutoSize = True
        IntTipoProcedimientoLabel.Location = New System.Drawing.Point(272, 424)
        IntTipoProcedimientoLabel.Name = "IntTipoProcedimientoLabel"
        IntTipoProcedimientoLabel.Size = New System.Drawing.Size(101, 13)
        IntTipoProcedimientoLabel.TabIndex = 57
        IntTipoProcedimientoLabel.Text = "Tipo Procedimiento:"
        IntTipoProcedimientoLabel.Visible = False
        '
        'StrCondicionPacienteLabel
        '
        StrCondicionPacienteLabel.AutoSize = True
        StrCondicionPacienteLabel.Location = New System.Drawing.Point(12, 448)
        StrCondicionPacienteLabel.Name = "StrCondicionPacienteLabel"
        StrCondicionPacienteLabel.Size = New System.Drawing.Size(102, 13)
        StrCondicionPacienteLabel.TabIndex = 58
        StrCondicionPacienteLabel.Text = "Condicion Paciente:"
        StrCondicionPacienteLabel.Visible = False
        '
        'NumValorCoopagoLabel
        '
        Me.NumValorCoopagoLabel.AutoSize = True
        Me.NumValorCoopagoLabel.Location = New System.Drawing.Point(12, 96)
        Me.NumValorCoopagoLabel.Name = "NumValorCoopagoLabel"
        Me.NumValorCoopagoLabel.Size = New System.Drawing.Size(80, 13)
        Me.NumValorCoopagoLabel.TabIndex = 44
        Me.NumValorCoopagoLabel.Text = "Valor Coopago:"
        '
        'StrNroIdPacienteTextBox
        '
        Me.StrNroIdPacienteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strNroIdPaciente", True))
        Me.StrNroIdPacienteTextBox.DataSource = Nothing
        Me.StrNroIdPacienteTextBox.EnterEntreCampos = True
        Me.StrNroIdPacienteTextBox.Location = New System.Drawing.Point(120, 67)
        Me.StrNroIdPacienteTextBox.Name = "StrNroIdPacienteTextBox"
        Me.StrNroIdPacienteTextBox.NombreCodigoF2 = Nothing
        Me.StrNroIdPacienteTextBox.NombreDescripcionF2 = Nothing
        Me.StrNroIdPacienteTextBox.Size = New System.Drawing.Size(135, 20)
        Me.StrNroIdPacienteTextBox.TabIndex = 1
        Me.StrNroIdPacienteTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblCitaBindingSource
        '
        Me.TblCitaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCita)
        '
        'TextBoxNombre
        '
        Me.TextBoxNombre.DataSource = Nothing
        Me.TextBoxNombre.Enabled = False
        Me.TextBoxNombre.EnterEntreCampos = True
        Me.TextBoxNombre.Location = New System.Drawing.Point(261, 67)
        Me.TextBoxNombre.Name = "TextBoxNombre"
        Me.TextBoxNombre.NombreCodigoF2 = Nothing
        Me.TextBoxNombre.NombreDescripcionF2 = Nothing
        Me.TextBoxNombre.Size = New System.Drawing.Size(346, 20)
        Me.TextBoxNombre.TabIndex = 2
        Me.TextBoxNombre.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdCitaTextBox
        '
        Me.IntIdCitaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "intIdCita", True))
        Me.IntIdCitaTextBox.DataSource = Nothing
        Me.IntIdCitaTextBox.Enabled = False
        Me.IntIdCitaTextBox.EnterEntreCampos = True
        Me.IntIdCitaTextBox.Location = New System.Drawing.Point(120, 41)
        Me.IntIdCitaTextBox.Name = "IntIdCitaTextBox"
        Me.IntIdCitaTextBox.NombreCodigoF2 = Nothing
        Me.IntIdCitaTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdCitaTextBox.Size = New System.Drawing.Size(47, 20)
        Me.IntIdCitaTextBox.TabIndex = 0
        Me.IntIdCitaTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'VerificationControl
        '
        Me.VerificationControl.Active = True
        Me.VerificationControl.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.VerificationControl.Location = New System.Drawing.Point(525, 91)
        Me.VerificationControl.Name = "VerificationControl"
        Me.VerificationControl.ReaderSerialNumber = "00000000-0000-0000-0000-000000000000"
        Me.VerificationControl.Size = New System.Drawing.Size(66, 75)
        Me.VerificationControl.TabIndex = 41
        '
        'TblEmpeadoBindingSource
        '
        Me.TblEmpeadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEmpeados)
        '
        'IntIdServicioClsComboBox
        '
        Me.IntIdServicioClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdServicioClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdServicioClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdServicio", True))
        Me.IntIdServicioClsComboBox.DataSource = Me.TblServicioBindingSource
        Me.IntIdServicioClsComboBox.DisplayMember = "strNombre"
        Me.IntIdServicioClsComboBox.FormattingEnabled = True
        Me.IntIdServicioClsComboBox.Location = New System.Drawing.Point(120, 178)
        Me.IntIdServicioClsComboBox.Name = "IntIdServicioClsComboBox"
        Me.IntIdServicioClsComboBox.Size = New System.Drawing.Size(487, 21)
        Me.IntIdServicioClsComboBox.TabIndex = 3
        Me.IntIdServicioClsComboBox.ValueMember = "intIdServicios"
        '
        'TblServicioBindingSource
        '
        Me.TblServicioBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblServicio)
        Me.TblServicioBindingSource.Sort = "strNombre"
        '
        'NumValorUnitarioClsTextBox
        '
        Me.NumValorUnitarioClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "numValorUnitario", True))
        Me.NumValorUnitarioClsTextBox.DataSource = Nothing
        Me.NumValorUnitarioClsTextBox.EnterEntreCampos = True
        Me.NumValorUnitarioClsTextBox.Location = New System.Drawing.Point(120, 205)
        Me.NumValorUnitarioClsTextBox.Name = "NumValorUnitarioClsTextBox"
        Me.NumValorUnitarioClsTextBox.NombreCodigoF2 = Nothing
        Me.NumValorUnitarioClsTextBox.NombreDescripcionF2 = Nothing
        Me.NumValorUnitarioClsTextBox.ReadOnly = True
        Me.NumValorUnitarioClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.NumValorUnitarioClsTextBox.TabIndex = 4
        Me.NumValorUnitarioClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.NumValorUnitarioClsTextBox.Visible = False
        '
        'IntNroServiciosClsTextBox
        '
        Me.IntNroServiciosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "intNroServicios", True))
        Me.IntNroServiciosClsTextBox.DataSource = Nothing
        Me.IntNroServiciosClsTextBox.EnterEntreCampos = True
        Me.IntNroServiciosClsTextBox.Location = New System.Drawing.Point(306, 205)
        Me.IntNroServiciosClsTextBox.Name = "IntNroServiciosClsTextBox"
        Me.IntNroServiciosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntNroServiciosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntNroServiciosClsTextBox.ReadOnly = True
        Me.IntNroServiciosClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.IntNroServiciosClsTextBox.TabIndex = 5
        Me.IntNroServiciosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.IntNroServiciosClsTextBox.Visible = False
        '
        'NumValorCoopagoClsTextBox
        '
        Me.NumValorCoopagoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "numValorCoopago", True))
        Me.NumValorCoopagoClsTextBox.DataSource = Nothing
        Me.NumValorCoopagoClsTextBox.EnterEntreCampos = True
        Me.NumValorCoopagoClsTextBox.Location = New System.Drawing.Point(120, 93)
        Me.NumValorCoopagoClsTextBox.Name = "NumValorCoopagoClsTextBox"
        Me.NumValorCoopagoClsTextBox.NombreCodigoF2 = Nothing
        Me.NumValorCoopagoClsTextBox.NombreDescripcionF2 = Nothing
        Me.NumValorCoopagoClsTextBox.ReadOnly = True
        Me.NumValorCoopagoClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.NumValorCoopagoClsTextBox.TabIndex = 3
        Me.NumValorCoopagoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'NumValorDescuentoClsTextBox
        '
        Me.NumValorDescuentoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "numValorDescuento", True))
        Me.NumValorDescuentoClsTextBox.DataSource = Nothing
        Me.NumValorDescuentoClsTextBox.EnterEntreCampos = True
        Me.NumValorDescuentoClsTextBox.Location = New System.Drawing.Point(120, 231)
        Me.NumValorDescuentoClsTextBox.Name = "NumValorDescuentoClsTextBox"
        Me.NumValorDescuentoClsTextBox.NombreCodigoF2 = Nothing
        Me.NumValorDescuentoClsTextBox.NombreDescripcionF2 = Nothing
        Me.NumValorDescuentoClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.NumValorDescuentoClsTextBox.TabIndex = 7
        Me.NumValorDescuentoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.NumValorDescuentoClsTextBox.Visible = False
        '
        'StrNroOrdenClsTextBox
        '
        Me.StrNroOrdenClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strNroOrden", True))
        Me.StrNroOrdenClsTextBox.DataSource = Nothing
        Me.StrNroOrdenClsTextBox.EnterEntreCampos = True
        Me.StrNroOrdenClsTextBox.Location = New System.Drawing.Point(120, 119)
        Me.StrNroOrdenClsTextBox.Name = "StrNroOrdenClsTextBox"
        Me.StrNroOrdenClsTextBox.NombreCodigoF2 = Nothing
        Me.StrNroOrdenClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrNroOrdenClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrNroOrdenClsTextBox.TabIndex = 4
        Me.StrNroOrdenClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrCodAtencionClsTextBox
        '
        Me.StrCodAtencionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strCodAtencion", True))
        Me.StrCodAtencionClsTextBox.DataSource = Nothing
        Me.StrCodAtencionClsTextBox.EnterEntreCampos = True
        Me.StrCodAtencionClsTextBox.Location = New System.Drawing.Point(306, 231)
        Me.StrCodAtencionClsTextBox.Name = "StrCodAtencionClsTextBox"
        Me.StrCodAtencionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrCodAtencionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrCodAtencionClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrCodAtencionClsTextBox.TabIndex = 11
        Me.StrCodAtencionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.StrCodAtencionClsTextBox.Visible = False
        '
        'DtmFechaAutorizacionClsDateTimePicker
        '
        Me.DtmFechaAutorizacionClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblCitaBindingSource, "dtmFechaAutorizacion", True))
        Me.DtmFechaAutorizacionClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaAutorizacionClsDateTimePicker.Location = New System.Drawing.Point(120, 257)
        Me.DtmFechaAutorizacionClsDateTimePicker.Name = "DtmFechaAutorizacionClsDateTimePicker"
        Me.DtmFechaAutorizacionClsDateTimePicker.Size = New System.Drawing.Size(101, 20)
        Me.DtmFechaAutorizacionClsDateTimePicker.TabIndex = 10
        Me.DtmFechaAutorizacionClsDateTimePicker.Visible = False
        '
        'IntIdProcedimientoClsComboBox
        '
        Me.IntIdProcedimientoClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdProcedimientoClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdProcedimientoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdProcedimiento", True))
        Me.IntIdProcedimientoClsComboBox.DataSource = Me.TblProcedimientoBindingSource
        Me.IntIdProcedimientoClsComboBox.DisplayMember = "strNombre"
        Me.IntIdProcedimientoClsComboBox.FormattingEnabled = True
        Me.IntIdProcedimientoClsComboBox.Location = New System.Drawing.Point(120, 283)
        Me.IntIdProcedimientoClsComboBox.Name = "IntIdProcedimientoClsComboBox"
        Me.IntIdProcedimientoClsComboBox.Size = New System.Drawing.Size(487, 21)
        Me.IntIdProcedimientoClsComboBox.TabIndex = 12
        Me.IntIdProcedimientoClsComboBox.ValueMember = "intIdProcedimientos"
        Me.IntIdProcedimientoClsComboBox.Visible = False
        '
        'TblProcedimientoBindingSource
        '
        Me.TblProcedimientoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        Me.TblProcedimientoBindingSource.Sort = "strNombre"
        '
        'IntIdDiagnosticoPrevioClsComboBox
        '
        Me.IntIdDiagnosticoPrevioClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdDiagnosticoPrevioClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdDiagnosticoPrevioClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoPrevio", True))
        Me.IntIdDiagnosticoPrevioClsComboBox.DataSource = Me.TblDisgnosticoBindingSource
        Me.IntIdDiagnosticoPrevioClsComboBox.DisplayMember = "strNombre"
        Me.IntIdDiagnosticoPrevioClsComboBox.FormattingEnabled = True
        Me.IntIdDiagnosticoPrevioClsComboBox.Location = New System.Drawing.Point(191, 310)
        Me.IntIdDiagnosticoPrevioClsComboBox.Name = "IntIdDiagnosticoPrevioClsComboBox"
        Me.IntIdDiagnosticoPrevioClsComboBox.Size = New System.Drawing.Size(416, 21)
        Me.IntIdDiagnosticoPrevioClsComboBox.TabIndex = 21
        Me.IntIdDiagnosticoPrevioClsComboBox.ValueMember = "intIdDiagnostico"
        Me.IntIdDiagnosticoPrevioClsComboBox.Visible = False
        '
        'TblDisgnosticoBindingSource
        '
        Me.TblDisgnosticoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
        '
        'IntIdDiagnosticoPosteriorClsComboBox
        '
        Me.IntIdDiagnosticoPosteriorClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdDiagnosticoPosteriorClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdDiagnosticoPosteriorClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoPosterior", True))
        Me.IntIdDiagnosticoPosteriorClsComboBox.DataSource = Me.TblDisgnosticoPosBindingSource
        Me.IntIdDiagnosticoPosteriorClsComboBox.DisplayMember = "strNombre"
        Me.IntIdDiagnosticoPosteriorClsComboBox.FormattingEnabled = True
        Me.IntIdDiagnosticoPosteriorClsComboBox.Location = New System.Drawing.Point(191, 337)
        Me.IntIdDiagnosticoPosteriorClsComboBox.Name = "IntIdDiagnosticoPosteriorClsComboBox"
        Me.IntIdDiagnosticoPosteriorClsComboBox.Size = New System.Drawing.Size(416, 21)
        Me.IntIdDiagnosticoPosteriorClsComboBox.TabIndex = 22
        Me.IntIdDiagnosticoPosteriorClsComboBox.ValueMember = "intIdDiagnostico"
        Me.IntIdDiagnosticoPosteriorClsComboBox.Visible = False
        '
        'TblDisgnosticoPosBindingSource
        '
        Me.TblDisgnosticoPosBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
        '
        'IntIdComplicacionClsComboBox
        '
        Me.IntIdComplicacionClsComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.IntIdComplicacionClsComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.IntIdComplicacionClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdComplicacion", True))
        Me.IntIdComplicacionClsComboBox.DataSource = Me.TblComplicacionBindingSource
        Me.IntIdComplicacionClsComboBox.DisplayMember = "strNombre"
        Me.IntIdComplicacionClsComboBox.FormattingEnabled = True
        Me.IntIdComplicacionClsComboBox.Location = New System.Drawing.Point(191, 364)
        Me.IntIdComplicacionClsComboBox.Name = "IntIdComplicacionClsComboBox"
        Me.IntIdComplicacionClsComboBox.Size = New System.Drawing.Size(416, 21)
        Me.IntIdComplicacionClsComboBox.TabIndex = 23
        Me.IntIdComplicacionClsComboBox.ValueMember = "intIdDiagnostico"
        Me.IntIdComplicacionClsComboBox.Visible = False
        '
        'TblComplicacionBindingSource
        '
        Me.TblComplicacionBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
        '
        'IntIdClaseProcedimientoClsComboBox
        '
        Me.IntIdClaseProcedimientoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdClaseProcedimiento", True))
        Me.IntIdClaseProcedimientoClsComboBox.DataSource = Me.TblClaseBindingSource
        Me.IntIdClaseProcedimientoClsComboBox.DisplayMember = "strValor"
        Me.IntIdClaseProcedimientoClsComboBox.FormattingEnabled = True
        Me.IntIdClaseProcedimientoClsComboBox.Location = New System.Drawing.Point(120, 391)
        Me.IntIdClaseProcedimientoClsComboBox.Name = "IntIdClaseProcedimientoClsComboBox"
        Me.IntIdClaseProcedimientoClsComboBox.Size = New System.Drawing.Size(146, 21)
        Me.IntIdClaseProcedimientoClsComboBox.TabIndex = 16
        Me.IntIdClaseProcedimientoClsComboBox.ValueMember = "intIdTipo"
        Me.IntIdClaseProcedimientoClsComboBox.Visible = False
        '
        'TblClaseBindingSource
        '
        Me.TblClaseBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntFormaRealizaActoQClsComboBox
        '
        Me.IntFormaRealizaActoQClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intFormaRealizaActoQ", True))
        Me.IntFormaRealizaActoQClsComboBox.DataSource = Me.TblFormaBindingSource
        Me.IntFormaRealizaActoQClsComboBox.DisplayMember = "strValor"
        Me.IntFormaRealizaActoQClsComboBox.FormattingEnabled = True
        Me.IntFormaRealizaActoQClsComboBox.Location = New System.Drawing.Point(431, 394)
        Me.IntFormaRealizaActoQClsComboBox.Name = "IntFormaRealizaActoQClsComboBox"
        Me.IntFormaRealizaActoQClsComboBox.Size = New System.Drawing.Size(175, 21)
        Me.IntFormaRealizaActoQClsComboBox.TabIndex = 18
        Me.IntFormaRealizaActoQClsComboBox.ValueMember = "intIdTipo"
        Me.IntFormaRealizaActoQClsComboBox.Visible = False
        '
        'TblFormaBindingSource
        '
        Me.TblFormaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntIdPersonalAtiendeClsComboBox
        '
        Me.IntIdPersonalAtiendeClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdPersonalAtiende", True))
        Me.IntIdPersonalAtiendeClsComboBox.DataSource = Me.TblAtiendeBindingSource
        Me.IntIdPersonalAtiendeClsComboBox.DisplayMember = "strValor"
        Me.IntIdPersonalAtiendeClsComboBox.FormattingEnabled = True
        Me.IntIdPersonalAtiendeClsComboBox.Location = New System.Drawing.Point(120, 418)
        Me.IntIdPersonalAtiendeClsComboBox.Name = "IntIdPersonalAtiendeClsComboBox"
        Me.IntIdPersonalAtiendeClsComboBox.Size = New System.Drawing.Size(146, 21)
        Me.IntIdPersonalAtiendeClsComboBox.TabIndex = 17
        Me.IntIdPersonalAtiendeClsComboBox.ValueMember = "intIdTipo"
        Me.IntIdPersonalAtiendeClsComboBox.Visible = False
        '
        'TblAtiendeBindingSource
        '
        Me.TblAtiendeBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntTipoProcedimientoClsComboBox
        '
        Me.IntTipoProcedimientoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intTipoProcedimiento", True))
        Me.IntTipoProcedimientoClsComboBox.DataSource = Me.TblTipoBindingSource
        Me.IntTipoProcedimientoClsComboBox.DisplayMember = "strValor"
        Me.IntTipoProcedimientoClsComboBox.FormattingEnabled = True
        Me.IntTipoProcedimientoClsComboBox.Location = New System.Drawing.Point(379, 421)
        Me.IntTipoProcedimientoClsComboBox.Name = "IntTipoProcedimientoClsComboBox"
        Me.IntTipoProcedimientoClsComboBox.Size = New System.Drawing.Size(227, 21)
        Me.IntTipoProcedimientoClsComboBox.TabIndex = 19
        Me.IntTipoProcedimientoClsComboBox.ValueMember = "intIdTipo"
        Me.IntTipoProcedimientoClsComboBox.Visible = False
        '
        'TblTipoBindingSource
        '
        Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'StrCondicionPacienteClsTextBox
        '
        Me.StrCondicionPacienteClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitaBindingSource, "strCondicionPaciente", True))
        Me.StrCondicionPacienteClsTextBox.DataSource = Nothing
        Me.StrCondicionPacienteClsTextBox.EnterEntreCampos = True
        Me.StrCondicionPacienteClsTextBox.Location = New System.Drawing.Point(120, 445)
        Me.StrCondicionPacienteClsTextBox.Multiline = True
        Me.StrCondicionPacienteClsTextBox.Name = "StrCondicionPacienteClsTextBox"
        Me.StrCondicionPacienteClsTextBox.NombreCodigoF2 = Nothing
        Me.StrCondicionPacienteClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrCondicionPacienteClsTextBox.Size = New System.Drawing.Size(487, 93)
        Me.StrCondicionPacienteClsTextBox.TabIndex = 20
        Me.StrCondicionPacienteClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.StrCondicionPacienteClsTextBox.Visible = False
        '
        'ClsComboBox1
        '
        Me.ClsComboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ClsComboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ClsComboBox1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoPrevio", True))
        Me.ClsComboBox1.DataSource = Me.TblDisgnosticoBindingSource
        Me.ClsComboBox1.DisplayMember = "strCodigo"
        Me.ClsComboBox1.FormattingEnabled = True
        Me.ClsComboBox1.Location = New System.Drawing.Point(120, 310)
        Me.ClsComboBox1.Name = "ClsComboBox1"
        Me.ClsComboBox1.Size = New System.Drawing.Size(69, 21)
        Me.ClsComboBox1.TabIndex = 13
        Me.ClsComboBox1.ValueMember = "intIdDiagnostico"
        Me.ClsComboBox1.Visible = False
        '
        'ClsComboBox2
        '
        Me.ClsComboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ClsComboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ClsComboBox2.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdDiagnosticoPosterior", True))
        Me.ClsComboBox2.DataSource = Me.TblDisgnosticoPosBindingSource
        Me.ClsComboBox2.DisplayMember = "strCodigo"
        Me.ClsComboBox2.FormattingEnabled = True
        Me.ClsComboBox2.Location = New System.Drawing.Point(120, 337)
        Me.ClsComboBox2.Name = "ClsComboBox2"
        Me.ClsComboBox2.Size = New System.Drawing.Size(69, 21)
        Me.ClsComboBox2.TabIndex = 14
        Me.ClsComboBox2.ValueMember = "intIdDiagnostico"
        Me.ClsComboBox2.Visible = False
        '
        'ClsComboBox3
        '
        Me.ClsComboBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ClsComboBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ClsComboBox3.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitaBindingSource, "intIdComplicacion", True))
        Me.ClsComboBox3.DataSource = Me.TblComplicacionBindingSource
        Me.ClsComboBox3.DisplayMember = "strCodigo"
        Me.ClsComboBox3.FormattingEnabled = True
        Me.ClsComboBox3.Location = New System.Drawing.Point(120, 364)
        Me.ClsComboBox3.Name = "ClsComboBox3"
        Me.ClsComboBox3.Size = New System.Drawing.Size(69, 21)
        Me.ClsComboBox3.TabIndex = 15
        Me.ClsComboBox3.ValueMember = "intIdDiagnostico"
        Me.ClsComboBox3.Visible = False
        '
        'NoRegistraHuellaCheckBox
        '
        Me.NoRegistraHuellaCheckBox.AutoSize = True
        Me.NoRegistraHuellaCheckBox.Enabled = False
        Me.NoRegistraHuellaCheckBox.Location = New System.Drawing.Point(525, 149)
        Me.NoRegistraHuellaCheckBox.Name = "NoRegistraHuellaCheckBox"
        Me.NoRegistraHuellaCheckBox.Size = New System.Drawing.Size(82, 17)
        Me.NoRegistraHuellaCheckBox.TabIndex = 24
        Me.NoRegistraHuellaCheckBox.Text = "No Registra"
        Me.NoRegistraHuellaCheckBox.UseVisualStyleBackColor = True
        '
        'TblCitaBindingNavigatorSaveItem
        '
        Me.TblCitaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblCitaBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblCitaBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblCitaBindingNavigatorSaveItem.Name = "TblCitaBindingNavigatorSaveItem"
        Me.TblCitaBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblCitaBindingNavigatorSaveItem.Text = "Save Data"
        '
        'TblCitaBindingNavigator
        '
        Me.TblCitaBindingNavigator.AddNewItem = Nothing
        Me.TblCitaBindingNavigator.BindingSource = Me.TblCitaBindingSource
        Me.TblCitaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblCitaBindingNavigator.DeleteItem = Nothing
        Me.TblCitaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorSeparator1, Me.TblCitaBindingNavigatorSaveItem, Me.ToolStripSeparator1, Me.btnPago})
        Me.TblCitaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCitaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblCitaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblCitaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblCitaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblCitaBindingNavigator.Name = "TblCitaBindingNavigator"
        Me.TblCitaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblCitaBindingNavigator.Size = New System.Drawing.Size(625, 25)
        Me.TblCitaBindingNavigator.TabIndex = 27
        Me.TblCitaBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'btnPago
        '
        Me.btnPago.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.btnPago.Image = Global.ClsIDU.My.Resources.Resources.money
        Me.btnPago.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnPago.Name = "btnPago"
        Me.btnPago.Size = New System.Drawing.Size(23, 22)
        Me.btnPago.Text = "ToolStripButton1"
        Me.btnPago.ToolTipText = "Pagos"
        '
        'btnHabilitarCoopago
        '
        Me.btnHabilitarCoopago.Location = New System.Drawing.Point(581, 122)
        Me.btnHabilitarCoopago.Name = "btnHabilitarCoopago"
        Me.btnHabilitarCoopago.Size = New System.Drawing.Size(26, 24)
        Me.btnHabilitarCoopago.TabIndex = 59
        Me.btnHabilitarCoopago.Text = "H"
        Me.btnHabilitarCoopago.UseVisualStyleBackColor = True
        '
        'FrmRegistroSalida
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(625, 171)
        Me.Controls.Add(Me.btnHabilitarCoopago)
        Me.Controls.Add(Me.NoRegistraHuellaCheckBox)
        Me.Controls.Add(Me.ClsComboBox3)
        Me.Controls.Add(Me.ClsComboBox2)
        Me.Controls.Add(Me.ClsComboBox1)
        Me.Controls.Add(StrCondicionPacienteLabel)
        Me.Controls.Add(Me.StrCondicionPacienteClsTextBox)
        Me.Controls.Add(IntTipoProcedimientoLabel)
        Me.Controls.Add(Me.IntTipoProcedimientoClsComboBox)
        Me.Controls.Add(IntIdPersonalAtiendeLabel)
        Me.Controls.Add(Me.IntIdPersonalAtiendeClsComboBox)
        Me.Controls.Add(IntFormaRealizaActoQLabel)
        Me.Controls.Add(Me.IntFormaRealizaActoQClsComboBox)
        Me.Controls.Add(IntIdClaseProcedimientoLabel)
        Me.Controls.Add(Me.IntIdClaseProcedimientoClsComboBox)
        Me.Controls.Add(IntIdComplicacionLabel)
        Me.Controls.Add(Me.IntIdComplicacionClsComboBox)
        Me.Controls.Add(IntIdDiagnosticoPosteriorLabel)
        Me.Controls.Add(Me.IntIdDiagnosticoPosteriorClsComboBox)
        Me.Controls.Add(IntIdDiagnosticoPrevioLabel)
        Me.Controls.Add(Me.IntIdDiagnosticoPrevioClsComboBox)
        Me.Controls.Add(IntIdProcedimientoLabel)
        Me.Controls.Add(Me.IntIdProcedimientoClsComboBox)
        Me.Controls.Add(DtmFechaAutorizacionLabel)
        Me.Controls.Add(Me.DtmFechaAutorizacionClsDateTimePicker)
        Me.Controls.Add(StrCodAtencionLabel)
        Me.Controls.Add(Me.StrCodAtencionClsTextBox)
        Me.Controls.Add(StrNroOrdenLabel)
        Me.Controls.Add(Me.StrNroOrdenClsTextBox)
        Me.Controls.Add(NumValorDescuentoLabel)
        Me.Controls.Add(Me.NumValorDescuentoClsTextBox)
        Me.Controls.Add(Me.NumValorCoopagoLabel)
        Me.Controls.Add(Me.NumValorCoopagoClsTextBox)
        Me.Controls.Add(IntNroServiciosLabel)
        Me.Controls.Add(Me.IntNroServiciosClsTextBox)
        Me.Controls.Add(NumValorUnitarioLabel)
        Me.Controls.Add(Me.NumValorUnitarioClsTextBox)
        Me.Controls.Add(IntIdServicioLabel)
        Me.Controls.Add(Me.IntIdServicioClsComboBox)
        Me.Controls.Add(Me.VerificationControl)
        Me.Controls.Add(Me.StrNroIdPacienteTextBox)
        Me.Controls.Add(Me.TextBoxNombre)
        Me.Controls.Add(IntIdCitaLabel)
        Me.Controls.Add(Me.IntIdCitaTextBox)
        Me.Controls.Add(IntIdPacienteLabel)
        Me.Controls.Add(Me.TblCitaBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmRegistroSalida"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Registro de Salida de Paciente"
        CType(Me.TblCitaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblServicioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDisgnosticoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDisgnosticoPosBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblComplicacionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblClaseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblFormaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblAtiendeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCitaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCitaBindingNavigator.ResumeLayout(False)
        Me.TblCitaBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents StrNroIdPacienteTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblEmpeadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TextBoxNombre As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdCitaTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents VerificationControl As DPFP.Gui.Verification.VerificationControl
    Friend WithEvents IntIdServicioClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents NumValorUnitarioClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntNroServiciosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents NumValorCoopagoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents NumValorDescuentoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNroOrdenClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrCodAtencionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DtmFechaAutorizacionClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntIdProcedimientoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoPrevioClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdDiagnosticoPosteriorClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdComplicacionClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdClaseProcedimientoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntFormaRealizaActoQClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdPersonalAtiendeClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntTipoProcedimientoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents StrCondicionPacienteClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblServicioBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblProcedimientoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDisgnosticoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDisgnosticoPosBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblComplicacionBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblClaseBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblFormaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblAtiendeBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ClsComboBox1 As ClsUtilidades.ClsComboBox
    Friend WithEvents ClsComboBox2 As ClsUtilidades.ClsComboBox
    Friend WithEvents ClsComboBox3 As ClsUtilidades.ClsComboBox
    Friend WithEvents NoRegistraHuellaCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TblCitaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCitaBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblCitaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnPago As System.Windows.Forms.ToolStripButton
    Friend WithEvents NumValorCoopagoLabel As System.Windows.Forms.Label
    Friend WithEvents btnHabilitarCoopago As System.Windows.Forms.Button
End Class
