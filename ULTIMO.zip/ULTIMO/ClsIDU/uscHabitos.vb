﻿Imports System.Windows.Forms

Public Class uscHabitos
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mIdentificacion As String
    Private _btn As Windows.Forms.Button
    Private mclsUtilidadesHC As clsUtilidadesHC
    Private _IdUsuario As String
    Private mNuevo As Boolean
    Public Sub New()

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mIdentificacion() As String
        Get
            Return _mIdentificacion
        End Get
        Set(ByVal value As String)
            _mIdentificacion = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub cargarDatosTabHabitos()
        'Try
        '    mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
        '    If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
        '        StrHcTextoHabitosTextBox.Dock = DockStyle.Fill
        '        StrHcTextoHabitosTextBox.BringToFront()
        '        StrHcTextoHabitosTextBox.Visible = True
        '        StrHcTextoHabitosTextBox.Multiline = True
        '        prCargarHabitos()
        '    Else
        '        prCargarHabitos()
        '    End If
        'Catch ex As Exception
        '    ClsError.ClsError.PrMostrarError(ex)
        'End Try
        Try
            Dim mconsulta = (From p In dc.tblHabitosHC Where p.strNroIdentificacion = mIdentificacion Select p.bitModoTexto, p.strHcTextoHabitos)
            If mconsulta.Count > 0 Then
                For Each c In mconsulta
                    If c.bitModoTexto = True Then
                        StrHcTextoHabitosTextBox.Dock = DockStyle.Fill
                        StrHcTextoHabitosTextBox.BringToFront()
                        StrHcTextoHabitosTextBox.Multiline = True
                        StrHcTextoHabitosTextBox.Visible = True
                        prCargarHabitos()
                    Else
                        prCargarHabitos()
                        Exit For
                    End If
                Next
            Else
                mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
                If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
                    StrHcTextoHabitosTextBox.Dock = DockStyle.Fill
                    StrHcTextoHabitosTextBox.BringToFront()
                    StrHcTextoHabitosTextBox.Multiline = True
                    StrHcTextoHabitosTextBox.Visible = True
                    prCargarHabitos()
                Else
                    prCargarHabitos()
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub prCargarHabitos()
        Try
            TblTipoActividadBindingSource.DataSource = (From a In dc.tblTipos Where a.strTipo = "ACTIVIDAD_FISICA" Select a)
            TblTipoEjercicioBindingSource.DataSource = (From e In dc.tblTipos Where e.strTipo = "EJERCICIOS" Select e)
            TblTipoClaseLicorBindingSource.DataSource = (From l In dc.tblTipos Where l.strTipo = "LICORES" Select l)

            Dim mConsulta = (From h In dc.tblHabitosHC Where h.strNroIdentificacion = mIdentificacion)

            If mConsulta.Count > 0 Then
                TblHabitosHCBindingSource.DataSource = mConsulta
                mNuevo = False
            Else
                TblHabitosHCBindingSource.AddNew()
                mNuevo = True
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblEPBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblEPBindingNavigatorSaveItem.Click
        prGuardar()
    End Sub

    Private Sub uscHabitos_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        prGuardar()
    End Sub

    Public Sub prGuardar() Implements IAbandonarUC.prGuardar
        Try
            If TblHabitosHCBindingSource.Position = 0 Then
                TblHabitosHCBindingSource.Item(TblHabitosHCBindingSource.Position).strHcTextoHabitos = StrHcTextoHabitosTextBox.Text
                TblHabitosHCBindingSource.Item(TblHabitosHCBindingSource.Position).strNroIdentificacion = mIdentificacion

                If StrHcTextoHabitosTextBox.Dock = DockStyle.Fill Then
                    TblHabitosHCBindingSource.Item(TblHabitosHCBindingSource.Position).bitModoTexto = True
                Else
                    TblHabitosHCBindingSource.Item(TblHabitosHCBindingSource.Position).bitModoTexto = False
                End If

                TblHabitosHCBindingSource.EndEdit()
                If mNuevo = True Then
                    dc.tblHabitosHC.InsertOnSubmit(TblHabitosHCBindingSource.Item(TblHabitosHCBindingSource.Position))
                End If

                dc.SubmitChanges()
                mNuevo = False
            End If
            TblHabitosHCBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub
   
    Private Sub BitPerteneceAsociacionesClsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BitPerteneceAsociacionesClsCheckBox.CheckedChanged
        If BitPerteneceAsociacionesClsCheckBox.Checked Then
            StrAsociacionesClsTextBox.ReadOnly = False
        Else
            StrAsociacionesClsTextBox.ReadOnly = True
        End If
    End Sub

    Private Sub BitConsumeLicorClsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BitConsumeLicorClsCheckBox.CheckedChanged
        If BitConsumeLicorClsCheckBox.Checked Then
            GroupBoxLicor.Enabled = True
            'IntidClaseLicorClsComboBox.Enabled = True
            'IntcantidadTragosClsTextBox.ReadOnly = False
            'IntFrecuenciaLicorClsTextBox.ReadOnly = False
        Else
            GroupBoxLicor.Enabled = False
            'IntidClaseLicorClsComboBox.Enabled = False
            'IntcantidadTragosClsTextBox.ReadOnly = True
            'IntFrecuenciaLicorClsTextBox.ReadOnly = True
        End If
    End Sub

    Private Sub BitFumaUltimosSeisMesesClsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BitFumaUltimosSeisMesesClsCheckBox.CheckedChanged

        If BitFumaUltimosSeisMesesClsCheckBox.Checked Then
            GroupBoxFuma.Enabled = True
            'IntCigarrillosPorDiaClsTextBox.ReadOnly = False
            'IntAnosFumadosClsTextBox.ReadOnly = False
            'DblPaquetesAnoClsTextBox.ReadOnly = False
        Else
            GroupBoxFuma.Enabled = False
            'IntCigarrillosPorDiaClsTextBox.ReadOnly = True
            'IntAnosFumadosClsTextBox.ReadOnly = True
            'DblPaquetesAnoClsTextBox.ReadOnly = True
        End If
    End Sub

    Private Sub BitComsumePsicoactivosClsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BitComsumePsicoactivosClsCheckBox.CheckedChanged

        If BitComsumePsicoactivosClsCheckBox.Checked Then
            StrClasePsicoactivosClsTextBox.ReadOnly = False
        Else
            StrClasePsicoactivosClsTextBox.ReadOnly = True
        End If
    End Sub

    Private Sub BitHipnoticosParaDormirClsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BitHipnoticosParaDormirClsCheckBox.CheckedChanged
        If BitHipnoticosParaDormirClsCheckBox.Checked Then
            StrClaseHipnoticosClsTextBox.ReadOnly = False
        Else
            StrClaseHipnoticosClsTextBox.ReadOnly = True
        End If
    End Sub
   
    Private Sub IntCigarrillosPorDiaClsTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntCigarrillosPorDiaClsTextBox.TextChanged, DblPaquetesAnoClsTextBox.TextChanged
        Try
            If Not IntCigarrillosPorDiaClsTextBox.Text = Nothing Then
                DblPaquetesAnoClsTextBox.Text = (CType(IntCigarrillosPorDiaClsTextBox.Text, Integer) * 360) / 20
            Else
                DblPaquetesAnoClsTextBox.Text = Nothing
            End If
        Catch ex As Exception

        End Try
    End Sub

    
End Class
