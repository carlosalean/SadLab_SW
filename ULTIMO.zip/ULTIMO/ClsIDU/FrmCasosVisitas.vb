﻿Imports System.Data.Linq
Imports System.Windows.Forms

Public Class FrmCasosVisitas
    Dim mstrStringConection As String
    Dim midusuario As String
    'Dim mCedula As String
    'Dim mNombre As String
    Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

    Sub New(ByVal strStringConection As String, ByVal mCedulaPaciente As String, ByVal mNombrePaciente As String, ByVal mPermisosHC As ClsUtilidades.ClsPermisos.ClsHistoriasClinicas, ByVal idUsuario As String)
        Try
            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            mstrStringConection = strStringConection
            txtCedula.Text = mCedulaPaciente
            txtNombre.Text = mNombrePaciente
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            midusuario = idUsuario

            If Not mPermisosHC Is Nothing Then
                btnHistoriaClinica.Enabled = mPermisosHC.Ver
                'Or mPermisosHC.Crear Or mPermisosHC.Modificar
                ContextMenuStrip.Items("CrearOModificarHistoriaClinicaToolStripMenuItem").Enabled = mPermisosHC.Crear Or mPermisosHC.Modificar
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmCasosVisitas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            ToolStripComboBoxEstadoCita.SelectedIndex = 0
            TblMotivosConsultaBindingSource.DataSource = dc.tblMotivosConsulta
            prBuscar()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub prBuscar()
        Try
            Dim ConsultaCitas = dc.usp_ConsultarCasosVisitas(ToolStripComboBoxEstadoCita.SelectedIndex, txtCedula.Text)
            'If ConsultaCitas.Count = 0 Then
            '    MsgBox("No se encontraron citas para este paciente")
            '    Exit Sub
            'End If

            TblCitasBindingSource.DataSource = ConsultaCitas

            Dim mintIdCita As Integer = TblCitasBindingSource.Item(TblCitasBindingSource.Position).intIdCita
            Dim mCitasMotivosConsulta = (From Cm In dc.tblCitasMotivosConsulta Where Cm.intIdCita = mintIdCita Select Cm)
            TblCitasMotivosConsultaBindingSource.DataSource = mCitasMotivosConsulta

        Catch ex As ArgumentOutOfRangeException
            'ClsError.ClsError.PrMostrarError(New System.Exception("No se encontraron citas" & " " & ToolStripComboBoxEstadoCita.Text & " " & "para el paciente"))
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub ToolStripComboBoxEstadoCita_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripComboBoxEstadoCita.SelectedIndexChanged
        Try
            prBuscar()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Public Function ValidadGrid() As Boolean
        Try
            ValidadGrid = True
            With TblCitasMotivosConsultaDataGridViewMotivosConsulta

                For fila1 As Integer = 0 To .Rows.Count - 1
                    For fila2 As Integer = fila1 + 1 To .Rows.Count - 1
                        If .Item(0, fila1).Value = .Item(0, fila2).Value Then
                            MsgBox("No se permite grabar varias veces el mismo motivo de consulta")
                            ValidadGrid = False
                            Exit Function
                        End If
                    Next
                Next
            End With

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Function

    Public Sub RecorrerGrid()
        Try
            If dc.usp_EliminartblCitasMotivosConsulta(TblCitasBindingSource.Item(TblCitasBindingSource.Position).intIdCita) = 0 Then
                Dim intIdMotivoConsulta As Integer
                With TblCitasMotivosConsultaDataGridViewMotivosConsulta
                    For fila As Integer = 0 To .Rows.Count - 1
                        intIdMotivoConsulta = .Item(0, fila).Value
                        If intIdMotivoConsulta <> Nothing Then
                            dc.usp_InsertartblCitasMotivosConsulta(TblCitasBindingSource.Item(TblCitasBindingSource.Position).intIdCita, intIdMotivoConsulta)
                        End If
                    Next
                End With
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub TblCitasBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblCitasBindingNavigatorSaveItem.Click
        Try
            If ValidadGrid() = True Then
                RecorrerGrid()
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblCitasMotivosConsultaDataGridView1_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblCitasMotivosConsultaDataGridViewMotivosConsulta.DataError
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TblCitasBindingSource_PositionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblCitasBindingSource.PositionChanged
        Try
            Dim mintIdCita As Integer = TblCitasBindingSource.Item(TblCitasBindingSource.Position).intIdCita
            Dim mCitasMotivosConsulta = (From Cm In dc.tblCitasMotivosConsulta Where Cm.intIdCita = mintIdCita Select Cm)
            TblCitasMotivosConsultaBindingSource.DataSource = mCitasMotivosConsulta

        Catch ex As ArgumentOutOfRangeException
            ClsError.ClsError.PrMostrarError(New System.Exception("No se encontraron citas" & " " & ToolStripComboBoxEstadoCita.Text & " " & "para el paciente"))
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub TblCitasDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblCitasDataGridView.DataError
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnHistoriaClinica_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHistoriaClinica.Click
        'If txtCedula.Text <> Nothing Then
        '    If Application.OpenForms("FrmVerHistoriaClinica") Is Nothing Then
        '        Dim mFrmVerHistoriaClinica As New ClsReportes.FrmVerHistoriaClinica(mstrStringConection, txtCedula.Text, txtNombre.Text)
        '        mFrmVerHistoriaClinica.MdiParent = Me.MdiParent
        '        mFrmVerHistoriaClinica.Show()
        '    Else
        '        Application.OpenForms("FrmVerHistoriaClinica").BringToFront()
        '    End If
        'Else
        '    MsgBox("Debe seleccionar un paciente", MsgBoxStyle.Information, "")
        'End If

    End Sub


   

    Private Sub CrearOModificarHistoriaClinicaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrearOModificarHistoriaClinicaToolStripMenuItem.Click
        Try
            Dim idcita = TblCitasBindingSource.Item(TblCitasBindingSource.Position).intIdCita
            'Dim existeCita = (From p In dc.tblHistoriasClinicas Where p.intIdCita = idcita).Count

            'If existeCita = 0 Then
            'dc.usp_InsertarHistoriaClinica(idcita)
            If Application.OpenForms("FrmHistoriaClinica") Is Nothing Then
                Dim mDate As Date = (From p In dc.tblCita Where p.intIdCita.Equals(idcita) Select p.dtmFecha).Single
                Dim mFrmHistoriaClinica As New ClsIDU.FrmHistoriaClinica(mstrStringConection, midusuario, idcita, txtCedula.Text, txtNombre.Text, mDate)
                mFrmHistoriaClinica.MdiParent = Me.MdiParent
                mFrmHistoriaClinica.Show()
            Else
                Application.OpenForms("FrmHistoriaClinica").BringToFront()
            End If
            'End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub
End Class