﻿Imports System.Windows.Forms

Public Class uscExamenesFisicos
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mHC As Integer
    Private _btn As Windows.Forms.Button
    Private _IdUsuario As String

    Private mCambiarNodo As Boolean = True
    Private mNodoSel As TreeNode
    Private mclsUtilidadesHC As clsUtilidadesHC

    Public Sub New()

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mHC() As Integer
        Get
            Return _mHC
        End Get
        Set(ByVal value As Integer)
            _mHC = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub CargarItemExamenesFisicosHC()
        Try
            Dim mconsulta = (From p In dc.tblExamenFisicoHC Where p.intIdHC = mHC Select p.strValorTexto, p.bitModoTexto)
            If mconsulta.Count > 0 Then
                For Each c In mconsulta
                    If c.bitModoTexto = True Then
                        ObservacionesClsTextBox.Dock = DockStyle.Fill
                        ObservacionesClsTextBox.BringToFront()
                        ObservacionesClsTextBox.ReadOnly = False
                        ObservacionesClsTextBox.Text = c.strValorTexto
                    Else
                        PrCargarDatosExamenFisico()
                        Exit For
                    End If
                Next
            Else
                mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
                If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
                    ObservacionesClsTextBox.Dock = DockStyle.Fill
                    ObservacionesClsTextBox.BringToFront()
                    ObservacionesClsTextBox.ReadOnly = False
                Else
                    PrCargarDatosExamenFisico()
                End If
            End If
        Catch ex As Exception
            ' ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub PrCargarDatosExamenFisico()
        Try
            If TreeViewExamenesFisicos.Nodes.Count = 0 Then
                Dim mClsllenarTreeview As New ClsLlenarTreeViewSintomasSignosLab()
                mClsllenarTreeview.PrllenarTreeView(1, dc, TreeViewExamenesFisicos)  'PrllenarTreeView()
            End If
            TreeViewExamenesFisicos.HideSelection = False
            Dim tblExamenFisicoHC = (From r In dc.tblExamenFisicoHC Where r.intIdHC = mHC Select r)
            For Each mtblExamenFisicoHC In tblExamenFisicoHC
                For Each mNodo As TreeNode In TreeViewExamenesFisicos.Nodes
                    If mNodo.Nodes.Count > 0 Then
                        If FnBuscarHijos(mtblExamenFisicoHC.intIdSintSigLab, mNodo) Then
                            mNodo.Expand()
                        End If
                    Else
                        If mNodo.Tag = mtblExamenFisicoHC.intIdSintSigLab Then
                            mNodo.ImageIndex = 3
                            mNodo.SelectedImageIndex = 3
                        Else
                            If mNodo.ImageIndex <> 3 Then
                                mNodo.ImageIndex = 1
                                mNodo.SelectedImageIndex = 1
                            End If
                        End If
                    End If
                Next
            Next
        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Function FnBuscarHijos(ByVal pintIdSintSigLab As Integer, ByVal pNodo As TreeNode)
        Dim mBuscarHijos As Boolean = False
        For Each mNodo As TreeNode In pNodo.Nodes
            If mNodo.Nodes.Count > 0 Then
                If FnBuscarHijos(pintIdSintSigLab, mNodo) Then
                    mNodo.Expand()
                    mBuscarHijos = True
                End If
            Else
                If mNodo.Tag = pintIdSintSigLab Then
                    mNodo.ImageIndex = 3
                    mNodo.SelectedImageIndex = 3
                    mBuscarHijos = True
                Else
                    If mNodo.ImageIndex <> 3 Then
                        mNodo.ImageIndex = 1
                        mNodo.SelectedImageIndex = 1
                    End If
                End If
            End If
        Next
        FnBuscarHijos = mBuscarHijos
    End Function

    Private Sub bitValorBoolSiRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bitValorBoolSiRadioButton.CheckedChanged, bitValorBoolNoRadioButton.CheckedChanged
        Try
            If TreeViewExamenesFisicos.SelectedNode.Nodes.Count = 0 And mCambiarNodo Then
                TreeViewExamenesFisicos.SelectedNode.ImageIndex = 3
                TreeViewExamenesFisicos.SelectedNode.SelectedImageIndex = 3
                mNodoSel = TreeViewExamenesFisicos.SelectedNode
                ObservacionesClsTextBox.ReadOnly = False
                'btnGuardar.Enabled = True
            End If
        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Try
            If TreeViewExamenesFisicos.SelectedNode.Nodes.Count = 0 Then
                TreeViewExamenesFisicos.SelectedNode.ImageIndex = 1
                TreeViewExamenesFisicos.SelectedNode.SelectedImageIndex = 1
                ObservacionesClsTextBox.ReadOnly = True
                mCambiarNodo = False
                bitValorBoolSiRadioButton.Checked = False
                bitValorBoolNoRadioButton.Checked = False
                mCambiarNodo = True
                mNodoSel = Nothing
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub btnRevisar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRevisar.Click
        PrCargarDatosExamenFisico()
    End Sub

    Private Sub TreeViewExamenesFisicos_NodeMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles TreeViewExamenesFisicos.NodeMouseClick
        Try
            txtTitulo.Text = TreeViewExamenesFisicos.SelectedNode.Text
            'btnGuardar.Enabled = False
            Dim mTag As Integer
            mTag = e.Node.Tag
            If e.Node.ImageIndex = 3 Then
                Dim tblRevisionExamenFisico = dc.usp_ConsultarRegtblExamenFisico(mHC, mTag) '(From r In dc.tblExamenFisicoHC Where r.intIdHC = mHC And r.intIdSintSigLab = mTag Select r)
                For Each mtblRevisionExamenFisico In tblRevisionExamenFisico
                    ObservacionesClsTextBox.Text = mtblRevisionExamenFisico.strValorTexto
                    ValorNumClsTextBox.Text = mtblRevisionExamenFisico.numValorNum
                    mCambiarNodo = False
                    If mtblRevisionExamenFisico.bitValorBool Then
                        bitValorBoolSiRadioButton.Checked = True
                        bitValorBoolNoRadioButton.Checked = False
                    Else
                        bitValorBoolSiRadioButton.Checked = False
                        bitValorBoolNoRadioButton.Checked = True
                    End If
                    mCambiarNodo = True
                Next
            Else
                If mNodoSel Is Nothing Then
                    'Dim mtipo As Integer = (From s In dc.tblSintomasSignosLaboratorios Where s.intID = mTag Select s.intTipoDato).Single
                    'Select Case mtipo
                    '    Case 0
                    '        Panel2.Enabled = False
                    '        btnBorrar.Enabled = False
                    '        ValorNumClsTextBox.ReadOnly = True
                    '    Case 1
                    '        Panel2.Enabled = True
                    '        btnBorrar.Enabled = True
                    '        ValorNumClsTextBox.ReadOnly = True
                    '    Case 1
                    '        Panel2.Enabled = False
                    '        btnBorrar.Enabled = False
                    '        ValorNumClsTextBox.ReadOnly = False
                    '    Case 2
                    '        ObservacionesClsTextBox.ReadOnly = False
                    'End Select

                    ObservacionesClsTextBox.Text = ""
                    ValorNumClsTextBox.Text = 0
                    mCambiarNodo = False
                    bitValorBoolSiRadioButton.Checked = False
                    bitValorBoolNoRadioButton.Checked = False
                    mCambiarNodo = True
                End If
            End If


        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TreeViewExamenesFisicos_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeViewExamenesFisicos.AfterSelect
        prActualizarExamenesFisicos()
    End Sub

    Private Sub btnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGuardar.Click
        prActualizarExamenesFisicos()
        'btnGuardar.Enabled = False
    End Sub

    Private Sub btnExpandir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExpandir.Click
        TreeViewExamenesFisicos.ExpandAll()
    End Sub

    Private Sub btnContraer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnContraer.Click
        TreeViewExamenesFisicos.CollapseAll()
    End Sub

    Private Sub prActualizarExamenesFisicos()
        Try
            If Not mNodoSel Is Nothing Then
                Dim mValor As Decimal
                If IsNumeric(ValorNumClsTextBox.Text) Then
                    mValor = Decimal.Parse(ValorNumClsTextBox.Text)
                Else
                    mValor = 0
                End If
                dc.usp_ActualizarExamenesFisicosHC(mNodoSel.Tag, mValor, bitValorBoolSiRadioButton.Checked, ObservacionesClsTextBox.Text, mHC, 0)
                mNodoSel = Nothing
            End If
        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub uscExamenesFisicos_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        Try
            PrGuardar()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Public Sub PrGuardar() Implements IAbandonarUC.prGuardar
        Try
            If ObservacionesClsTextBox.Dock = DockStyle.Fill Then
                Dim mValor As Decimal
                If IsNumeric(ValorNumClsTextBox.Text) Then
                    mValor = Decimal.Parse(ValorNumClsTextBox.Text)
                Else
                    mValor = 0
                End If
                dc.usp_ActualizarExamenesFisicosHC(Nothing, mValor, bitValorBoolSiRadioButton.Checked, ObservacionesClsTextBox.Text, mHC, True)
            End If
        Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

End Class
