﻿Public Class FrmRegistrarDatosFacturacion
  Dim mstrStringConection As String
  Dim DataContext As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
  Dim mHabilitarCoopago As Boolean = False
  Dim mstrIntIdUsuario As String
  Dim nIdSedeParam As Integer
    Dim mDatosCargados As Boolean = False

    Sub New(ByVal strStringConection As String, ByVal pHabilitarCoopago As Boolean, ByVal strIntIdUsuario As String, ByVal nIdSede As Integer)
    Try
      ' This call is required by the Windows Form Designer.
      InitializeComponent()

      ' Add any initialization after the InitializeComponent() call.
      mstrStringConection = strStringConection
      'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
      'mHabilitarCoopago = pHabilitarCoopago
      mstrIntIdUsuario = strIntIdUsuario
      nIdSedeParam = nIdSede
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub FrmRegistroSalida_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Try
      Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
      DataContext = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

            TextBoxNombre.Text = ""
      NumValorCoopagoClsTextBox.Enabled = mHabilitarCoopago
            ''Modificación 20160812, Alejandro Torres Monsalve, alejo.torres9301@gmail.com
            ''Descripción: Se cambia el origen de datos de la tabla citas para que haga el cálculo del valor con base en la tabla de tarifas
            'Dim FacturacionBl As ReglasNegocio.Facturacion = New ReglasNegocio.Facturacion()
            'Dim dtDatos As DataTable = FacturacionBl.ConsultarDatosFacturacionPaciente(nIdSedeParam)
            'If Not dtDatos Is Nothing And dtDatos.Rows.Count > 0 Then
            '  TblCitaBindingSource.DataSource = dtDatos
            'Else
            '  TblCitaBindingSource.DataSource = dc.tblCita
            'End If

            'Fin modificación 20160812

        Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TblCitaBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblCitaBindingNavigatorSaveItem.Click
    Dim mintPRestador As Integer = 0

    Try
            If TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Cancelada").ReturnValue Then
                MsgBox("La cita se encuentra cancelada y no puede ser facturada..", MsgBoxStyle.Information)
                StrNroIdPacienteTextBox.Focus()
                Exit Sub
            End If

            If Not String.IsNullOrWhiteSpace(IntNroServiciosClsTextBox.Text) Then
        If Convert.ToInt32(IntNroServiciosClsTextBox.Text) <= 0 Then
          MsgBox("El número de servicios es cero (0)", MsgBoxStyle.Information)
          Exit Sub
        End If
      Else
        MsgBox("El campo número de servicios esta vacío", MsgBoxStyle.Information)
        Exit Sub
      End If
      Try
        mintPRestador = ClsComboBoxPrestador.SelectedValue  'TblDatosPrestadoresBindingSource.Item(TblDatosPrestadoresBindingSource.Position).intIdPrestadores
      Catch ex As Exception
        mintPRestador = 0
      End Try
      If mintPRestador = 0 Then
        MsgBox("Debe seleccionar el prestador del servicio..", MsgBoxStyle.Information)
        ClsComboBoxPrestador.Focus()
        Exit Sub
      End If
            If StrNroIdPacienteTextBox.Text.Trim.Length > 0 Then
                If TblCitaBindingSource.Item(TblCitaBindingSource.Position).strNroIdPaciente = StrNroIdPacienteTextBox.Text Then
                    TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdEstadoCita = DataContext.usp_SeleccionarTipo("ESTADO_CITA", "Facturada").ReturnValue
                    'Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
                    Dim mResultado As Integer
                    mResultado = DataContext.usp_FacturaEps(TblCitaBindingSource.Item(TblCitaBindingSource.Position).StrNroFactura, TblCitaBindingSource.Item(TblCitaBindingSource.Position).StrNroIdPaciente, mintPRestador, TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProfesional)

                    If mResultado = 0 Then
                        MsgBox("Los datos no han sido actualizados las EPS son diferentes", MsgBoxStyle.Information)
                    Else
                        Try
                            Dim mStrNroFactura As String = TblCitaBindingSource.Item(TblCitaBindingSource.Position).StrNroFactura
                            Dim mintIdCodigoPrestador As Integer = TblEmpeadoBindingSource.Item(TblEmpeadoBindingSource.Position).intIdCodigoPrestador
                            If mStrNroFactura.Trim.Length > 0 Then
                                Dim mFacturas = (From p In DataContext.tblFacturacions Where p.bitImpresa = True And p.strNroFactura = mStrNroFactura And p.intIdPrestador = mintIdCodigoPrestador Select p)
                                If mFacturas.Count > 0 Then
                                    MsgBox("No se pueden adicionar mas citas a esta factura ya que se encuentra cerrada..", MsgBoxStyle.Information, "Registrar datos de facturación")
                                    Exit Sub
                                End If
                            End If
                        Catch ex As Exception

                        End Try

                        TblCitaBindingSource.EndEdit()
                        DataContext.SubmitChanges()
                        MsgBox("Los datos han sido actualizados", MsgBoxStyle.Information)
                    End If
                    NumValorCoopagoClsTextBox.Enabled = False
                Else
                    MsgBox("El numero de identificación del paciente es diferente al de la cita que desea modificar..")
                End If
            Else
                MsgBox("Debe digitar una cedula..")
            End If



            '      'Modificación 20160818, Alejandro Torres Monsalve, alejo.torres9301@gmail.com
            '      'Se cambia la forma de actualizar los datos de la cita, se hace el llamado al metodo que se encuentra en las reglas de negocio
            '      Dim nValorUnitario As Decimal
            '      Dim nCantidadServicios As Integer
            '      Dim nIdServicio As Integer = 0
            '      Dim nIdDiagnostiscoPrevio As Integer = 0
            '      Dim nIdDiagnostiscoPosterior As Integer = 0
            '      Dim nIdComplicacion As Integer = 0
            '      Dim nIdClaseProcedimiento As Integer = 0
            '      Dim nIdFormaRealizaActoQ As Integer = 0
            '      Dim nIdPersonalAtiende As Integer = 0
            '      Dim nIdTipoProcedimiento As Integer = 0
            '      Dim sCondicionPaciente As String = String.Empty
            '      Dim sCodAtencion As String = String.Empty
            '      Dim dFechaAutorizacion As Date
            '      Dim nIdDiagnostiscoPrincipal As Integer = 0
            '      Dim nIdDiagnostiscoRelacionadoN1 As Integer = 0
            '      Dim nIdDiagnostiscoRelacionadoN2 As Integer = 0
            '      Dim nIdDiagnostiscoRelacionadoN3 As Integer = 0

            '      If Not String.IsNullOrWhiteSpace(NumValorUnitarioClsTextBox.Text) Then
            '        nValorUnitario = Convert.ToDecimal(NumValorUnitarioClsTextBox.Text)
            '      End If
            '      If Not String.IsNullOrWhiteSpace(IntNroServiciosClsTextBox.Text) Then
            '        nCantidadServicios = Convert.ToInt32(IntNroServiciosClsTextBox.Text)
            '      End If
            '      If Not IntIdServicioClsComboBox.SelectedValue = Nothing Then
            '        nIdServicio = Convert.ToInt32(IntIdServicioClsComboBox.SelectedValue)
            '      End If
            '      If Not IntIdDiagnosticoPrevioClsComboBox.SelectedValue = Nothing Then
            '        nIdDiagnostiscoPrevio = Convert.ToInt32(IntIdDiagnosticoPrevioClsComboBox.SelectedValue)
            '      End If
            '      If Not IntIdDiagnosticoPosteriorClsComboBox.SelectedValue = Nothing Then
            '        nIdDiagnostiscoPosterior = Convert.ToInt32(IntIdDiagnosticoPosteriorClsComboBox.SelectedValue)
            '      End If
            '      If Not IntIdComplicacionClsComboBox.SelectedValue = Nothing Then
            '        nIdComplicacion = Convert.ToInt32(IntIdComplicacionClsComboBox.SelectedValue)
            '      End If
            '      If Not IntIdClaseProcedimientoClsComboBox.SelectedValue = Nothing Then
            '        nIdClaseProcedimiento = Convert.ToInt32(IntIdClaseProcedimientoClsComboBox.SelectedValue)
            '      End If
            '      If Not IntFormaRealizaActoQClsComboBox.SelectedValue = Nothing Then
            '        nIdFormaRealizaActoQ = Convert.ToInt32(IntFormaRealizaActoQClsComboBox.SelectedValue)
            '      End If
            '      If Not IntIdPersonalAtiendeClsComboBox.SelectedValue = Nothing Then
            '        nIdPersonalAtiende = Convert.ToInt32(IntIdPersonalAtiendeClsComboBox.SelectedValue)
            '      End If
            '      If Not IntTipoProcedimientoClsComboBox.SelectedValue = Nothing Then
            '        nIdTipoProcedimiento = Convert.ToInt32(IntTipoProcedimientoClsComboBox.SelectedValue)
            '      End If
            '      If Not String.IsNullOrWhiteSpace(StrCondicionPacienteClsTextBox.Text) Then
            '        sCondicionPaciente = StrCondicionPacienteClsTextBox.Text
            '      End If
            '      If Not String.IsNullOrWhiteSpace(StrCodAtencionClsTextBox.Text) Then
            '        sCodAtencion = StrCodAtencionClsTextBox.Text
            '      End If
            '      If Not DtmFechaAutorizacionClsDateTimePicker.Value = Nothing Then
            '        dFechaAutorizacion = DtmFechaAutorizacionClsDateTimePicker.Value
            '      End If
            '      If Not IntIdDiagNosticoPrincipalClsComboBox.SelectedValue = Nothing Then
            '        nIdDiagnostiscoPrincipal = Convert.ToInt32(IntIdDiagNosticoPrincipalClsComboBox.SelectedValue)
            '      End If
            '      If Not IntIdDiagnosticoRelacionadoN1ClsComboBox.SelectedValue = Nothing Then
            '        nIdDiagnostiscoRelacionadoN1 = Convert.ToInt32(IntIdDiagnosticoRelacionadoN1ClsComboBox.SelectedValue)
            '      End If
            '      If Not IntIdDiagnosticoRelacionadoN2ClsComboBox.SelectedValue = Nothing Then
            '        nIdDiagnostiscoRelacionadoN2 = Convert.ToInt32(IntIdDiagnosticoRelacionadoN2ClsComboBox.SelectedValue)
            '      End If
            '      If Not IntIdDiagnosticoRelacionadoN3ClsComboBox.SelectedValue = Nothing Then
            '        nIdDiagnostiscoRelacionadoN3 = Convert.ToInt32(IntIdDiagnosticoRelacionadoN3ClsComboBox.SelectedValue)
            '      End If
            '      Dim FacturacionBl As ReglasNegocio.Facturacion = New ReglasNegocio.Facturacion()
            '      Dim bActualizar As Boolean = FacturacionBl.ActualizarCita(nIdCita, sNroPacienteId, nEstadoCita, sNroFactura, nValorUnitario, nCantidadServicios _
            '                                                                , StrNroOrdenClsTextBox.Text, nIdServicio, nIdDiagnostiscoPrevio, nIdDiagnostiscoPosterior _
            '                                                                , nIdComplicacion, nIdClaseProcedimiento, nIdFormaRealizaActoQ, nIdPersonalAtiende, nIdTipoProcedimiento _
            '                                                                , sCondicionPaciente, sCodAtencion, dFechaAutorizacion, nIdDiagnostiscoPrincipal, nIdDiagnostiscoRelacionadoN1 _
            '                                                                , nIdDiagnostiscoRelacionadoN2, nIdDiagnostiscoRelacionadoN3, nIdPrestador)
            '      If bActualizar Then


            '        Dim dtDatos As DataTable = FacturacionBl.ConsultarDatosFacturacionPaciente(nIdSedeParam, sNroPacienteId)
            '        If Not dtDatos Is Nothing And dtDatos.Rows.Count > 0 Then
            '          TblCitaBindingSource.DataSource = dtDatos
            '        Else
            '          TblCitaBindingSource.DataSource = DataContext.tblCita
            '        End If

            '        Dim nPosicion As Integer = TblCitaBindingSource.Find("intIdCita", nIdCita)
            '        TblCitaBindingSource.Position = nPosicion

            '        TblCitaBindingSource_PositionChanged(Nothing, Nothing)

            '        MsgBox("Los datos han sido actualizados", MsgBoxStyle.Information)
            '      Else
            '        MsgBox("Los datos no han sido actualizados, por favor intente más tarde", MsgBoxStyle.Exclamation)
            '      End If
            '    End If
            '    NumValorCoopagoClsTextBox.Enabled = False
            '  Else
            '    MsgBox("El numero de identificación del paciente es diferente al de la cita que desea modificar..")
            '  End If
            'Else
            '  MsgBox("Debe digitar una cedula..")
            'End If
        Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub StrNroIdPacienteTextBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrNroIdPacienteTextBox.Leave
    Try
            'Dim dc2 = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            If StrNroIdPacienteTextBox.Text.Length = 0 Then
                Exit Sub
            End If

            Dim mNroId As String = StrNroIdPacienteTextBox.Text
            If Not String.IsNullOrWhiteSpace(mNroId) Then
                Dim mNombre As String
                If (From p In DataContext.tblPacientes Where
                            p.strNroIdentificacion = mNroId Select p.strPrimerNombre).Any() Then
                    mNombre = (From p In DataContext.tblPacientes Where
                            p.strNroIdentificacion = mNroId Select p.strPrimerNombre & " " & IIf(p.strSegundoNombre Is Nothing, "", p.strSegundoNombre) & " " & p.strPrimerApellido & " " & IIf(p.strSegundoApellido Is Nothing, "", p.strSegundoApellido)).Single

                    TextBoxNombre.Text = mNombre.ToString
                Else
                    MsgBox("La cédula ingresada no está registrada en el sistema, puede ser que haya sido mal digitada por favor verifique con el nombre y apellido del paciente en el listado de pacientes", MsgBoxStyle.Information)
                    Exit Sub
                End If
            End If
            Dim mCita = (From c In DataContext.tblCita Where c.strNroIdPaciente = mNroId Select c)
            If mCita.Count = 0 Then
                MsgBox("El paciente no tiene citas para facturar..", MsgBoxStyle.Information)
            Else

                If Not mDatosCargados Then
                    mDatosCargados = True
                    TblEmpeadoBindingSource.DataSource = DataContext.tblEmpeados
                    TblProcedimientoBindingSource.DataSource = DataContext.tblProcedimiento
                    TblDisgnosticoBindingSource.DataSource = DataContext.tblDisgnostico
                    TblDisgnosticoPosBindingSource.DataSource = DataContext.tblDisgnostico

                    TblDisgnosticoPrincipalBindingSource.DataSource = DataContext.tblDisgnostico
                    TblDisgnosticoRe1BindingSource.DataSource = DataContext.tblDisgnostico
                    TblDisgnosticoRe2BindingSource.DataSource = DataContext.tblDisgnostico
                    TblDisgnosticoRe3BindingSource.DataSource = DataContext.tblDisgnostico

                    TblDatosPrestadoresBindingSource.DataSource = DataContext.tblDatosPrestadores

                    TblComplicacionBindingSource.DataSource = DataContext.tblDisgnostico
                    TblServicioBindingSource.DataSource = DataContext.tblServicios
                    Dim Estado = (From p In DataContext.tblTipos
                                  Where p.strTipo = "ESTADO_CITA")
                    TblTipoEstadoBindingSource.DataSource = Estado

                    Dim mTblClase = (From p In DataContext.tblTipos
                                     Where p.strTipo = "CLASE_PROCEDIMIENTO")
                    TblClaseBindingSource.DataSource = mTblClase

                    Dim mTblAtiende = (From p In DataContext.tblTipos
                                       Where p.strTipo = "PERSONA_ATIENDE")
                    TblAtiendeBindingSource.DataSource = mTblAtiende

                    Dim mTblForma = (From p In DataContext.tblTipos
                                     Where p.strTipo = "FORMA_REALIZA")
                    TblFormaBindingSource.DataSource = mTblForma

                    Dim mTblTipo = (From p In DataContext.tblTipos
                                    Where p.strTipo = "TIPO_PROCED")
                    TblTipoBindingSource.DataSource = mTblTipo

                End If

                TblCitaBindingSource.DataSource = mCita
                TblCitaBindingSource.Position = 0

            End If

            'Modificacion 20160822, Alejandro Torres Monsalve, alejo.torres9301@gmail.com
            'Se buscan los datos de las citas del paciente
            'Dim FacturacionBl As ReglasNegocio.Facturacion = New ReglasNegocio.Facturacion()
            'Dim dtDatos As DataTable = FacturacionBl.ConsultarDatosFacturacionPaciente(nIdSedeParam, mNroId)

            '      If dtDatos.Rows.Count = 0 Then
            '  MsgBox("El paciente no tiene citas para facturar..", MsgBoxStyle.Information)
            'Else
            '  TblCitaBindingSource.DataSource = dtDatos
            '  TblCitaBindingSource.Position = 0

            '  TblCitaBindingSource_PositionChanged(Nothing, Nothing)
            'End If
            ''Fin modificación 20160822
            NumValorCoopagoClsTextBox.Enabled = False

    Catch ex As Exception
      TextBoxNombre.Text = ""
      StrNroIdPacienteTextBox.Text = ""
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub btnHabilitarCoopago_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHabilitarCoopago.Click
    Try
      Dim mClaveIngreso
      Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario)
      If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then

        Dim mDlgClaveSuperUsuario As New DlgClaveSuperUsuario()
        If mDlgClaveSuperUsuario.ShowDialog = Windows.Forms.DialogResult.OK Then
          Dim mClaveSuper = DataContext.usp_ClaveSuperUsuario(mValidaHuella.mstrIntIdUsuario)
          mClaveIngreso = mDlgClaveSuperUsuario.strClave
                    If mClaveSuper(0).strClaveSuperUsuario = mClaveIngreso Then
                        NumValorCoopagoClsTextBox.Enabled = True
                        mHabilitarCoopago = NumValorCoopagoClsTextBox.Enabled
                    Else
                        MsgBox("La clave es incorrecta..")
          End If
        End If
      End If

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        Try
            If Not String.IsNullOrWhiteSpace(ClsComboBoxPrestador.SelectedValue) Then
                If MsgBox("Se adicionará un nuevo consecutivo de facturación. ¿Está seguro que desea realizar esta operación.?", MsgBoxStyle.YesNoCancel, "Adicionar Consecutivo de Facturación") = MsgBoxResult.Yes Then
                    Dim mIntConsecutivo As Integer
                    'Dim intProfesional As Integer = TblCitaBindingSource.Item(TblCitaBindingSource.Position).intIdProfesional
                    'mIntConsecutivo = (From c In DataContext.tblDatosPrestadores Join p In DataContext.tblEmpeados On c.intIdPrestadores Equals p.intIdCodigoPrestador Where p.intIdCodigoEmpleado = intProfesional Select c.intIdConsecutivoFactura).Single
                    Dim intIdPrestador = Integer.Parse(ClsComboBoxPrestador.SelectedValue.ToString())
                    Dim FacturacionBl As ReglasNegocio.Facturacion = New ReglasNegocio.Facturacion()

                    'Dim mConsecutivo = DataContext.usp_AsignarConsecutivoFacturacionPrestadores(intIdPrestador)
                    mIntConsecutivo = FacturacionBl.ReadUpdateConsecutivoFactPrestador(intIdPrestador)

                    If mIntConsecutivo = 0 Then
                        MsgBox("El prestador del servicio no tiene configurado el consecutivo electronico de facturación", MsgBoxStyle.Information, "Adicionar Consecutivo de Facturación")
                    Else
                        MsgBox("El consecutivo asignado es: " & mIntConsecutivo.ToString, MsgBoxStyle.Information, "Adicionar Consecutivo de Facturación")
                        StrNroFacturaClsTextBox.Text = mIntConsecutivo.ToString
                    End If
                End If
            Else
                MsgBox("Debe seleccionar un prestador del servicio", MsgBoxStyle.Information, "Adicionar Consecutivo de Facturación")
            End If
        Catch ex As Exception
            MsgBox("El prestador del servicio no tiene configurado el consecutivo electronico de facturación", MsgBoxStyle.Information, "Adicionar Consecutivo de Facturación")
        End Try
    End Sub

  Private Sub TblCitaBindingSource_PositionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblCitaBindingSource.PositionChanged
    Try
            If TblCitaBindingSource.Item(TblCitaBindingSource.Position).bitCerrada Then
                PanelPRincipal.Enabled = False
                GroupBox2.Enabled = False
            Else
                PanelPRincipal.Enabled = True
                GroupBox2.Enabled = True
            End If

            If CBool(DirectCast(TblCitaBindingSource.Item(TblCitaBindingSource.Position), System.Data.DataRowView).Row.ItemArray(45)) Then
                PanelPRincipal.Enabled = False
                GroupBox2.Enabled = False
            Else
                PanelPRincipal.Enabled = True
        GroupBox2.Enabled = True
      End If
      Dim mIntEmpleado As Integer
      mIntEmpleado = DirectCast(TblCitaBindingSource.Item(TblCitaBindingSource.Position), System.Data.DataRowView).Row.ItemArray(3)
    Catch ex As Exception

    End Try
  End Sub

  Private Sub StrNroFacturaClsTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrNroFacturaClsTextBox.TextChanged
    Try
      'TblCitaBindingSource.Item(TblCitaBindingSource.Position).StrNroFactura = StrNroFacturaClsTextBox.Text
    Catch ex As Exception

    End Try
  End Sub
End Class