﻿Public Class FrmDatosPrestadores
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Sub New(ByVal strStringConection As String)
        Try

            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub
    Private Sub TblDatosPrestadoreBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblDatosPrestadoreBindingNavigatorSaveItem.Click
        Try
            TblDatosPrestadoreBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmDatosPrestadores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            'Fuente de datos 
            TblDatosPrestadoreBindingSource.DataSource = dc.tblDatosPrestadores
            'TblEmpeadosBindingSource.DataSource = dc.tblEmpeados
            'IntIdCodigoEmpleadoComboBox.DataSource = TblEmpeadosBindingSource
            'IntIdCodigoEmpleadoComboBox.DisplayMember = "strNombreEmpleado"
            'IntIdCodigoEmpleadoComboBox.ValueMember = "intIdCodigoEmpleado"
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub
End Class