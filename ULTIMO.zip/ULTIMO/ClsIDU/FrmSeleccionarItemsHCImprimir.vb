﻿Imports System.Drawing
Imports System.Windows.Forms

'Fecha: 2016-05-14
'Descripcion cambio: Creación del formulario, se crea el formulario que se va a utilizar para seleccionar los items de la HC que se deseen imprimir, solo sera visible
'                    para las citas que tengan HC creada, a las que no tienen se le inhabilitara desde el listado de citas.
'Autor: Alejandro Torres Monsalve

Public Class FrmSeleccionarItemsHCImprimir
  Dim mstrStringConection As String
  Dim DataContext As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
  Dim mstrIntIdUsuario As Integer
  Dim mBuscar As Boolean
  Dim mintIdSede As Integer
  Dim mPermisosHC As ClsUtilidades.ClsPermisos.ClsHistoriasClinicas
  Dim SeleccionarColumn As Integer = 0
  Private IsSelectedAllRecords As Boolean

  Private _MostrarPantalla As Boolean = False
  Public Property MostrarPantalla() As Boolean
    Get
      Return _MostrarPantalla
    End Get
    Set(ByVal value As Boolean)
      _MostrarPantalla = value
    End Set
  End Property

#Region "Constructor"
  ''' <summary>
  ''' Contructor que inicializa el formulario, carga el listado de items según la cita que se le envie para que el usuario decida que items imprimir
  ''' </summary>
  ''' <param name="pstrStringConection"></param>
  ''' <param name="NroIdPaciente"></param>
  ''' <param name="mIdUsuario"></param>
  Public Sub New(ByVal pstrStringConection As String, ByVal NroIdPaciente As String, ByVal mIdUsuario As String)
    ' This call is required by the designer.
    InitializeComponent()
    ' Se carga el listado de itmes de la HC disponibles para imprimir
    '----------------------------------------------------------------------------------------------------------------------------------------------------------
    Try
      DataContext = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(pstrStringConection)
      mstrStringConection = pstrStringConection
      'Se buscan todas las citas del paciente que tenga HC
      Dim ltDatos = DataContext.usp_ConsultarCitasSeleccionImpresion(NroIdPaciente).ToList()
      If Not ltDatos Is Nothing And ltDatos.ToList().Count > 0 Then
        'Se agregan las columnas al grid
        dgvItemsImpresion.Columns.Clear()

        dgvItemsImpresion.DataSource = ltDatos
        dgvItemsImpresion.Columns(0).Visible = False
        dgvItemsImpresion.Columns(1).Visible = False
        FormatoColumnaListado(2, 150, "Fecha cita", DataGridViewContentAlignment.MiddleCenter)
        FormatoColumnaListado(3, 200, "Profesional", DataGridViewContentAlignment.MiddleLeft)
        FormatoColumnaListado(4, 440, "Procedimiento", DataGridViewContentAlignment.MiddleLeft)

        Dim chkColumnSeleccionar As DataGridViewCheckBoxColumn = New DataGridViewCheckBoxColumn()
        chkColumnSeleccionar.HeaderText = ""
        chkColumnSeleccionar.Name = "Seleccionar"
        chkColumnSeleccionar.SortMode = DataGridViewColumnSortMode.NotSortable
        chkColumnSeleccionar.Width = 20
        chkColumnSeleccionar.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgvItemsImpresion.Columns.Insert(0, chkColumnSeleccionar)

        Dim btnColumn = New DataGridViewButtonColumn()
        btnColumn.HeaderText = "Ver detalle"
        btnColumn.ReadOnly = True
        btnColumn.Name = "VerDetalle"
        btnColumn.Text = "Ver"
        btnColumn.UseColumnTextForButtonValue = True
        btnColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
        btnColumn.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        dgvItemsImpresion.Columns.Insert(6, btnColumn)

        dgvItemsImpresion.RowHeadersVisible = False
        'Se agrega el checkbox para seleccionar o deseleccionar todos los registros
        AgregarSeleccionTodos()
        ' ==== Fin agregar columnas al gridview
        MostrarPantalla = True
      Else
        MessageBox.Show("No hay registros de historia clínica para este paciente.", "Aviso", MessageBoxButtons.OK)
        MostrarPantalla = False
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

#End Region

#Region "Metodos privados y eventos"

#Region "Listado"

  ''' <summary>
  ''' Metodo que le de faormato a la columna del datagridview
  ''' </summary>
  ''' <param name="nIndex">Especifica el numero de columna a la que se le va a dar formato</param>
  ''' <param name="nWidth">Especifica el ancho que va a a tener la columna</param>
  ''' <param name="sHeader">Especifica el texto de encabezado que va a tener al columna</param>
  Private Sub FormatoColumnaListado(ByVal nIndex As Integer, ByVal nWidth As Integer, ByVal sHeader As String, ByVal vAlineacion As DataGridViewContentAlignment)
    dgvItemsImpresion.Columns(nIndex).Width = nWidth
    dgvItemsImpresion.Columns(nIndex).HeaderText = sHeader
    dgvItemsImpresion.Columns(nIndex).DefaultCellStyle.Alignment = vAlineacion
  End Sub

  Private Sub AgregarSeleccionTodos()
    Dim chkSeleccionarTodos As New CheckBox
    chkSeleccionarTodos.Name = "SeleccionarTodos"
    chkSeleccionarTodos.Size = New Size(14, 14)

    'Coloca el checkbox centrado en el encabezado
    chkSeleccionarTodos.Location = New System.Drawing.Point(5, 5)
    chkSeleccionarTodos.BackColor = Color.White
    dgvItemsImpresion.Controls.Add(chkSeleccionarTodos)

    'Evento que se dispara con el clic en el checbox seleccionar todos
    AddHandler chkSeleccionarTodos.Click, AddressOf HeaderCheckBox_Click

    'Cuando cambie el valor de alguno de los checkbox del listado debe cambiar la seleccion del checkbox seleccionar todos
    AddHandler dgvItemsImpresion.CellValueChanged, AddressOf dgvItemsImpresion_CellChecked

    'Garantiza que el cambio de seleccion no provoque ningun error
    AddHandler dgvItemsImpresion.CurrentCellDirtyStateChanged, AddressOf dgvItemsImpresion_CurrentCellDirtyStateChanged
  End Sub

  'Evento que se dispara con el clic en el checbox seleccionar todos
  Private Sub HeaderCheckBox_Click(ByVal sender As Object, ByVal e As EventArgs)
    IsSelectedAllRecords = True

    Dim chkSeleccionarTodos As CheckBox
    chkSeleccionarTodos = DirectCast(sender, CheckBox)
    Dim dgvPadre As DataGridView = chkSeleccionarTodos.Parent

    For Each row As DataGridViewRow In dgvPadre.Rows
      row.Cells(0).Value = chkSeleccionarTodos.Checked
    Next

    dgvPadre.EndEdit()

    IsSelectedAllRecords = False
  End Sub

  'Cuando cambie el valor de alguno de los checkbox del listado debe cambiar la seleccion del checkbox seleccionar todos
  Private Sub dgvItemsImpresion_CellChecked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)
    Dim dgvItmesImprimir As DataGridView = DirectCast(sender, DataGridView)
    If Not IsSelectedAllRecords Then
      If dgvItmesImprimir.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = False Then
        'Cuando algun checkbox es deseleccionado el checkbox de la cabecera se debe deseleccionar
        DirectCast(dgvItmesImprimir.Controls.Item("SeleccionarTodos"), CheckBox).Checked = False
      Else
        'Cuando algun checkbox del listado es seleccionado se hace una busqueda verificando que todos esten seleccionado, si es el caso se marca como seleccionado
        'el checkbox de la cabecera
        Dim isAllChecked As Boolean = True
        For Each row As DataGridViewRow In dgvItmesImprimir.Rows
          If row.Cells(0).Value = False Then
            isAllChecked = False
            Exit For
          End If
        Next
        DirectCast(dgvItmesImprimir.Controls.Item("SeleccionarTodos"), CheckBox).Checked = isAllChecked
      End If
    End If
  End Sub

  'Garantiza que el cambio de seleccion de celda no provoque ningun error
  Private Sub dgvItemsImpresion_CurrentCellDirtyStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Dim dgvItmesImprimir As DataGridView = DirectCast(sender, DataGridView)
    If TypeOf dgvItmesImprimir.CurrentCell Is DataGridViewCheckBoxCell Then
      dgvItmesImprimir.CommitEdit(DataGridViewDataErrorContexts.Commit)
    End If
  End Sub

#End Region

#Region "Imprimir"

  Private Function ValidarSeleccion() As String
    Dim sRetorno As String = String.Empty
    Dim nCount As Integer = 0
    'Se valida que listado tenga registros, si no tiene se muestra el mensaje, si tiene se recorre buscando que por lo menos 1 registro haya sido marcado para imprimir
    If dgvItemsImpresion.RowCount > 0 Then
      'Se recorre el listado para verificar que items han sido seleccionados para imprimir
      For Each drFila As DataGridViewRow In dgvItemsImpresion.Rows
        If CBool(drFila.Cells("Seleccionar").Value) Then
          nCount = nCount + 1
        End If
      Next

      If nCount = 0 Then
        sRetorno = "No se ha seleccionado ningún registro para ser impreso, por favor verifique."
      End If
    Else
      sRetorno = "El listado no tiene ningún registro."
    End If
    Return sRetorno
  End Function

  Private Sub btnImprimir_Click(sender As Object, e As EventArgs) Handles btnImprimir.Click
    Try
      Dim sError As String = ValidarSeleccion()
      If String.IsNullOrWhiteSpace(sError) Then
        'Si en la validaciones no presenta ningún error, se recorre el el listado y se sacan los códigos de las citas y de las historias clinicas y se almacenan en esta
        'variable
        Dim arrCodigosCitasHC(dgvItemsImpresion.RowCount - 1, 1) As Integer
        Dim nRow As Integer = 0
        'arrCodigosCitasHC(0, 0) = 398970
        'arrCodigosCitasHC(0, 1) = 9051
        For Each dr As DataGridViewRow In dgvItemsImpresion.Rows
          If CBool(dr.Cells("Seleccionar").Value) Then
            arrCodigosCitasHC(nRow, 0) = Convert.ToInt32(dr.Cells("CodigoCita").Value)
            arrCodigosCitasHC(nRow, 1) = Convert.ToInt32(dr.Cells("CodigoHC").Value)
          Else 'Si no se selecciono el registro del listado se agrega en el array con el valor de -1 para excluirlos en el proceso de generacion del pdf
            arrCodigosCitasHC(nRow, 0) = -1
            arrCodigosCitasHC(nRow, 1) = -1
          End If
          nRow = nRow + 1
        Next
        'Instancia del form en el que se debe de visualizar el archivo creado
        If Application.OpenForms("FrmItemsHCImprimir") Is Nothing Then
          Dim mFrmItemsHCImprimir = New ClsReportes.FrmItemsHCImprimir(mstrStringConection, arrCodigosCitasHC)
          mFrmItemsHCImprimir.Show()
        Else
          Application.OpenForms("FrmItemsHCImprimir").BringToFront()
        End If
      Else
        ClsError.ClsError.PrMostrarError(New Exception(sError))
      End If
    Catch ex As Exception
      'MsgBox(String.Format("Error al imprimir los registros seleccionados. Error: {0}, InnerExeption: {1}", ex.Message, ex.InnerException))
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub dgvItemsImpresion_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvItemsImpresion.CellClick
    Try
      If e.ColumnIndex = 1 Then
        'Instancia del form en el que se debe de visualizar el archivo creado
        If Application.OpenForms("FrmItemsHCImprimir") Is Nothing Then

          Dim arrCodigosCitasHC(0, 1) As Integer '= {{Convert.ToInt32(dgvItemsImpresion.Rows(e.RowIndex).Cells("CodigoCita").Value), Convert.ToInt32(dgvItemsImpresion.Rows(e.RowIndex).Cells("CodigoHC").Value)}}
          arrCodigosCitasHC(0, 0) = Convert.ToInt32(dgvItemsImpresion.Rows(e.RowIndex).Cells("CodigoCita").Value)
          arrCodigosCitasHC(0, 1) = Convert.ToInt32(dgvItemsImpresion.Rows(e.RowIndex).Cells("CodigoHC").Value)
          Dim mFrmItemsHCImprimir = New ClsReportes.FrmItemsHCImprimir(mstrStringConection, arrCodigosCitasHC)
          mFrmItemsHCImprimir.Show()
        Else
          Application.OpenForms("FrmItemsHCImprimir").BringToFront()
        End If
      End If
    Catch ex As Exception

    End Try
  End Sub

#End Region

#End Region

End Class