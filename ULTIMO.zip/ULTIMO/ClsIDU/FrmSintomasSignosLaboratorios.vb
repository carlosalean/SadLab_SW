﻿Imports System.Windows.Forms

Public Class FrmSintomasSignosLaboratorios
    Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    'Dim dataSetArbol As System.Data.DataSet
    'Dim tablaArbol As DataTable
    Dim NodoPadre As Integer
    Dim Ingreso As Boolean
    Dim Guardar As Boolean
    Dim estado As String = "N"
    Dim mClsllenarTreeview As New ClsLlenarTreeViewSintomasSignosLab()

    Sub New(ByVal strStringConection As String)
        Try
            ' Llamada necesaria para el Diseñador de Windows Forms.
            InitializeComponent()
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    'Private Sub CrearNodosDelPadre(ByVal indicePadre As Integer, ByVal nodePadre As TreeNode)

    '    Dim dataViewHijos As DataView

    '    ' Crear un DataView con los Nodos que dependen del Nodo padre pasado como parámetro.
    '    dataViewHijos = New DataView(dataSetArbol.Tables("TablaArbol"))
    '    dataViewHijos.RowFilter = dataSetArbol.Tables("TablaArbol").Columns("intIdPadre").ColumnName + " = " + indicePadre.ToString()

    '    ' Agregar al TreeView los nodos Hijos que se han obtenido en el DataView.
    '    For Each dataRowCurrent As DataRowView In dataViewHijos

    '        Dim nuevoNodo As New TreeNode
    '        nuevoNodo.Text = dataRowCurrent("strDescripcion").ToString().Trim()
    '        nuevoNodo.Name = dataRowCurrent("intIdSintomasSignosLaboratorios").ToString


    '        If dataRowCurrent("intTipoDato").ToString.Length > 0 Then
    '            nuevoNodo.ImageIndex = 1
    '            nuevoNodo.SelectedImageIndex = 1
    '        Else
    '            nuevoNodo.ImageIndex = 0
    '            nuevoNodo.SelectedImageIndex = 0
    '        End If

    '        ' si el parámetro nodoPadre es nulo es porque es la primera llamada, son los Nodos
    '        ' del primer nivel que no dependen de otro nodo.
    '        If nodePadre Is Nothing Then
    '            nuevoNodo.Tag = "P"
    '            TreeView.Nodes.Add(nuevoNodo)
    '        Else
    '            ' se añade el nuevo nodo al nodo padre.
    '            nodePadre.Nodes.Add(nuevoNodo)
    '        End If

    '        ' Llamada recurrente al mismo método para agregar los Hijos del Nodo recién agregado.
    '        CrearNodosDelPadre(Int32.Parse(dataRowCurrent("intIdSintomasSignosLaboratorios").ToString()), nuevoNodo)
    '    Next dataRowCurrent

    'End Sub
    'Private Sub PrllenarTreeView()
    '    Try
    '        'Dim mRes As New List(Of Object)
    '        Dim mConsulta = dc.usp_ConsultarSintomasSignosLab(ComboBoxTipo.SelectedIndex)
    '        For Each mR In mConsulta
    '            Dim nuevoNodo As New TreeNode
    '            nuevoNodo.Text = mR.strDescripcion
    '            nuevoNodo.Name = mR.intIdSintomasSignosLaboratorios
    '            nuevoNodo.Tag = "P"
    '            PrLlenarHijos(mR, nuevoNodo)
    '            TreeView.Nodes.Add(nuevoNodo)
    '        Next
    '        'CrearNodosDelPadre(0, Nothing)
    '    Catch ex As Exception
    '        ClsError.ClsError.PrMostrarError(ex)
    '    End Try
    'End Sub

    'Private Sub PrLlenarHijos(ByVal mHijo As Object, ByRef mNodoPadre As TreeNode)
    '    Try
    '        Dim mConsulta = dc.usp_ConsultarSintomasSignosLabHijos(ComboBoxTipo.SelectedIndex, mHijo.intIdSintomasSignosLaboratorios)
    '        For Each mR In mConsulta
    '            Dim nuevoNodo As New TreeNode
    '            nuevoNodo.Text = mR.strDescripcion
    '            nuevoNodo.Name = mR.intIdSintomasSignosLaboratorios
    '            If mR.intTipoDato Is Nothing Or mR.intTipoDato = -1 Then
    '                nuevoNodo.ImageIndex = 0
    '                nuevoNodo.SelectedImageIndex = 0
    '            Else
    '                nuevoNodo.ImageIndex = 1
    '                nuevoNodo.SelectedImageIndex = 1
    '            End If
    '            PrLlenarHijos(mR, nuevoNodo)
    '            mNodoPadre.Nodes.Add(nuevoNodo)
    '        Next
    '    Catch ex As Exception
    '        ClsError.ClsError.PrMostrarError(ex)
    '    End Try
    'End Sub
    'Private Sub CrearDataSet()
    '    Try
    '        Dim mRes As New List(Of Object)
    '        Dim mConsulta = dc.usp_ConsultarSintomasSignosLab(ComboBoxTipo.SelectedIndex)
    '        Dim cont As Integer = 0

    '        For Each mR In mConsulta
    '            mRes.Add(mR)
    '        Next

    '        If mRes.Count = 0 Then
    '            MsgBox("No se encontraron registros para la consulta", MsgBoxStyle.Information, "")
    '            TreeView.Nodes.Clear()
    '            Exit Sub
    '        End If

    '        dataSetArbol = New DataSet("DataSetArbol")

    '        tablaArbol = dataSetArbol.Tables.Add("TablaArbol")
    '        tablaArbol.Columns.Add("intIdSintomasSignosLaboratorios", GetType(Integer))
    '        tablaArbol.Columns.Add("strDescripcion", GetType(String))
    '        tablaArbol.Columns.Add("intIdPadre", GetType(Integer))
    '        tablaArbol.Columns.Add("intTipoDato", GetType(Integer))

    '        While cont < mRes.Count
    '            InsertarDataRow(mRes.Item(cont).intIdSintomasSignosLaboratorios, _
    '                            mRes.Item(cont).strDescripcion, mRes.Item(cont).intIdPadre, mRes.Item(cont).intTipoDato)

    '            cont += 1
    '        End While

    '        CrearNodosDelPadre(0, Nothing)

    '    Catch ex As Exception
    '        ClsError.ClsError.PrMostrarError(ex)
    '    End Try

    'End Sub

    'Private Sub InsertarDataRow(ByVal intIdSintomasSignosLaboratorios As Integer, _
    '                            ByVal strDescripcion As String, ByVal IdentificadorPadre As Integer, ByVal intTipoDato As Integer)

    '    Dim nuevaFila As DataRow
    '    nuevaFila = dataSetArbol.Tables("TablaArbol").NewRow()
    '    nuevaFila("intIdSintomasSignosLaboratorios") = intIdSintomasSignosLaboratorios
    '    nuevaFila("strDescripcion") = strDescripcion
    '    nuevaFila("intIdPadre") = IdentificadorPadre
    '    nuevaFila("intTipoDato") = intTipoDato
    '    dataSetArbol.Tables("TablaArbol").Rows.Add(nuevaFila)

    'End Sub

    Private Sub Habilitar(ByVal valor As Boolean)
        If valor = False Then
            txtNombreNodo.Enabled = False
            cmbTipoCampo.Enabled = False
            cmbTipoDato.Enabled = False
            NumericUpDownInicial.Enabled = False
            NumericUpDownFinal.Enabled = False
            ClsCheckBox.Enabled = False
        Else
            txtNombreNodo.Enabled = True
            cmbTipoCampo.Enabled = True
            'cmbTipoDato.Enabled = True
            'NumericUpDownInicial.Enabled = True
            'NumericUpDownFinal.Enabled = True
            'ClsCheckBox.Enabled = True
        End If
    End Sub

    Private Sub limpiar()
        txtNombreNodo.Text = Nothing
        cmbTipoDato.SelectedIndex = -1
        cmbTipoCampo.SelectedIndex = -1
        NumericUpDownInicial.Value = Nothing
        NumericUpDownFinal.Value = Nothing
        ClsCheckBox.Checked = False
        Label7.Text = "No"
        'txtNombreNodo.Enabled = True
        'cmbTipoCampo.Enabled = True
    End Sub

    Private Function Validar() As Boolean
        Try
            If txtNombreNodo.TextLength = 0 Then
                MsgBox("No ha ingresado la descripción", MsgBoxStyle.Information, "")
                Validar = False
                Exit Function
            End If

            If TreeView.SelectedNode Is Nothing Then
                Label8.Text = "No hay directorio seleccionado "
                MsgBox("No ha seleccionado un elemento", MsgBoxStyle.Information, "")
                Validar = False
                Exit Function
            End If

            If cmbTipoCampo.SelectedIndex = 0 Then
                TreeView.SelectedNode.Nodes.Add(txtNombreNodo.Text)
                TreeView.SelectedNode.Expand()
            Else
                TreeView.SelectedNode.Nodes.Add(txtNombreNodo.Text)
                TreeView.SelectedNode.Expand()
            End If
            Validar = True

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Function

    Private Sub FrmSintomasSignosLaboratorios_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Ingreso = True
        ComboBoxTipo.SelectedIndex = 0
        'CrearDataSet()
        mClsllenarTreeview.PrllenarTreeView(ComboBoxTipo.SelectedIndex, dc, TreeView)  'PrllenarTreeView()
    End Sub

    Private Sub TreeView_NodeMouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles TreeView.NodeMouseDoubleClick
        Try
            If estado = "G" Or estado = "E" Then
                Exit Sub
            End If

            limpiar()
            Dim mRes As New List(Of Object)
            Dim mConsulta = dc.usp_ConsultartblSintomasSignosLaboratorios(NodoPadre)

            For Each mR In mConsulta
                mRes.Add(mR)
            Next

            If mRes.Count = 0 Then
                txtNombreNodo.Enabled = False
                cmbTipoCampo.Enabled = False
                Exit Sub
            ElseIf mRes.Item(0).intTipoDato = Nothing Then
                txtNombreNodo.Enabled = False
                cmbTipoCampo.Enabled = False
                Exit Sub
            Else
                txtNombreNodo.Text = mRes.Item(0).strDescripcion
                cmbTipoCampo.SelectedIndex = 1
                cmbTipoDato.SelectedIndex = mRes.Item(0).intTipoDato
                NumericUpDownInicial.Value = mRes.Item(0).intRangoInicial
                NumericUpDownFinal.Value = mRes.Item(0).intRangoFinal
                ClsCheckBox.Checked = mRes.Item(0).boolValorDefecto
                Habilitar(False)
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
        'TreeView.SelectedNode.Expand()

    End Sub

    Private Sub txtNombreNodo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNombreNodo.TextChanged
        If estado = "E" Then
            Exit Sub
        End If

        If txtNombreNodo.TextLength = 0 Then
            cmbTipoCampo.SelectedIndex = -1
        Else
            cmbTipoCampo.SelectedIndex = 0
        End If
    End Sub

    Private Sub cmbTipoCampo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbTipoCampo.SelectedIndexChanged

        If cmbTipoCampo.SelectedIndex = 1 Then
            cmbTipoDato.Enabled = True
            cmbTipoDato.SelectedIndex = 0
        Else
            cmbTipoDato.Enabled = False
            cmbTipoDato.SelectedIndex = -1
            NumericUpDownInicial.Text = 0
            NumericUpDownFinal.Text = 0
            NumericUpDownInicial.Enabled = False
            NumericUpDownFinal.Enabled = False
        End If

    End Sub

    Private Sub cmbTipoDato_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbTipoDato.SelectedIndexChanged

        If cmbTipoDato.SelectedIndex = 2 Then
            NumericUpDownInicial.Enabled = True
            NumericUpDownFinal.Enabled = True
        Else
            NumericUpDownInicial.Enabled = False
            NumericUpDownFinal.Enabled = False
            NumericUpDownInicial.Value = Nothing
            NumericUpDownFinal.Value = Nothing
        End If

        If cmbTipoDato.SelectedIndex = 1 Then
            ClsCheckBox.Enabled = True
        Else
            ClsCheckBox.Enabled = False
        End If

    End Sub

    Private Sub ComboBoxTipo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBoxTipo.SelectedIndexChanged
        If Ingreso = True Then
            Ingreso = False
            Exit Sub
        Else
            'CrearDataSet()
            TreeView.Nodes.Clear()
            mClsllenarTreeview.PrllenarTreeView(ComboBoxTipo.SelectedIndex, dc, TreeView)  'PrllenarTreeView()

        End If
    End Sub

    Private Sub TreeView_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles TreeView.AfterSelect
        If TreeView.SelectedNode Is Nothing Then
            Label8.Text = "No hay directorio seleccionado "
        Else
            NodoPadre = TreeView.SelectedNode.Name
            Label8.Text = "Esta ubicado en el directorio: " & TreeView.SelectedNode.Text
        End If
    End Sub

    Private Sub ClsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClsCheckBox.CheckedChanged
        If ClsCheckBox.Checked Then
            Me.Label7.Text = "(Si)"
        Else
            Me.Label7.Text = "(No)"
        End If
    End Sub

    Private Sub TreeView_NodeMouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles TreeView.NodeMouseClick
        Try
            If estado = "G" Or estado = "E" Then
                Exit Sub
            End If

            limpiar()
            Dim mRes As New List(Of Object)
            Dim mConsulta = dc.usp_ConsultartblSintomasSignosLaboratorios(NodoPadre)

            For Each mR In mConsulta
                mRes.Add(mR)
            Next

            If mRes.Count = 0 Then
                txtNombreNodo.Enabled = False
                cmbTipoCampo.Enabled = False
                Exit Sub
            ElseIf mRes.Item(0).intTipoDato = Nothing Then
                txtNombreNodo.Enabled = False
                cmbTipoCampo.Enabled = False
                Exit Sub
            Else
                txtNombreNodo.Text = mRes.Item(0).strDescripcion
                cmbTipoCampo.SelectedIndex = 1
                cmbTipoDato.SelectedIndex = mRes.Item(0).intTipoDato
                NumericUpDownInicial.Value = mRes.Item(0).intRangoInicial
                NumericUpDownFinal.Value = mRes.Item(0).intRangoFinal
                ClsCheckBox.Checked = mRes.Item(0).boolValorDefecto
                Habilitar(False)
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
        'TreeView.SelectedNode.Expand()
        ' limpiar()
    End Sub

    Private Sub btnNuevo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNuevo.Click

        Try
            btnNuevo.Enabled = False
            btnModificar.Enabled = False
            btnBorrar.Enabled = False
            btnGuardar.Enabled = True
            btnCancelar.Enabled = True
            estado = "G"
            limpiar()
            Guardar = True
            Habilitar(True)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub btnGuardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGuardar.Click
        Try
            If Validar() = True Then

                If Guardar = True And estado = "G" Then

                    If dc.usp_InsertartblSintomasSignosLaboratorios(txtNombreNodo.Text, NodoPadre, cmbTipoDato.SelectedIndex, NumericUpDownInicial.Value, NumericUpDownFinal.Value, ClsCheckBox.Checked, ComboBoxTipo.SelectedIndex) = 0 Then
                        TreeView.Nodes.Clear()
                        'CrearDataSet()
                        mClsllenarTreeview.PrllenarTreeView(ComboBoxTipo.SelectedIndex, dc, TreeView)  'PrllenarTreeView()
                    End If

                    btnNuevo.Enabled = True
                    btnBorrar.Enabled = True
                    btnGuardar.Enabled = False
                    btnCancelar.Enabled = False
                    btnModificar.Enabled = True
                    Guardar = False
                    estado = "N"
                    Habilitar(False)
                Else
                    If dc.usp_ActualizartblSintomasSignosLaboratorios(NodoPadre, txtNombreNodo.Text, cmbTipoDato.SelectedIndex, NumericUpDownInicial.Value, NumericUpDownFinal.Value, ClsCheckBox.Checked) = 0 Then
                        TreeView.Nodes.Clear()
                        'CrearDataSet()
                        mClsllenarTreeview.PrllenarTreeView(ComboBoxTipo.SelectedIndex, dc, TreeView)  'PrllenarTreeView()
                    End If

                    btnNuevo.Enabled = True
                    btnBorrar.Enabled = True
                    btnGuardar.Enabled = False
                    btnCancelar.Enabled = False
                    btnModificar.Enabled = True
                    Guardar = False
                    estado = "N"
                    Habilitar(False)
                End If
            Else
                ' MsgBox("Faltan datos por ingresar", MsgBoxStyle.Information, "")
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub btnBorrar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBorrar.Click
        Try
            If TreeView.SelectedNode Is Nothing Then
                MsgBox("seleccione un elemento a eliminar", MsgBoxStyle.Information, "")
                TreeView_Leave(sender, e)
                Exit Sub
            End If

            If TreeView.SelectedNode.Tag = "P" Then
                MsgBox("Opción de nivel superior, no puede eliminarse", MsgBoxStyle.Information, "")
                Exit Sub
            Else
                Dim ret As Integer = MessageBox.Show("Esta seguro de Borrar " & TreeView.SelectedNode.Text, " ", MessageBoxButtons.OKCancel)
                If ret = 1 Then
                    If dc.usp_EliminartblSintomasSignosLaboratorios(NodoPadre) = 0 Then
                        TreeView.Nodes.Clear()
                        'CrearDataSet()
                        mClsllenarTreeview.PrllenarTreeView(ComboBoxTipo.SelectedIndex, dc, TreeView)  'PrllenarTreeView()
                    End If
                Else
                    Exit Sub
                End If

            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

        'TreeView.Nodes.Remove(TreeView.SelectedNode)
    End Sub

    Private Sub btnCancelar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        'TreeView.Nodes.Remove(TreeView.SelectedNode)
        TreeView.Nodes.Clear()
        'CrearDataSet()
        mClsllenarTreeview.PrllenarTreeView(ComboBoxTipo.SelectedIndex, dc, TreeView)  'PrllenarTreeView()
        btnNuevo.Enabled = True
        btnBorrar.Enabled = True
        btnModificar.Enabled = True
        btnGuardar.Enabled = False
        btnCancelar.Enabled = False
        limpiar()
        Habilitar(False)
        estado = "N"
    End Sub

    Private Sub btnLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLimpiar.Click
        Me.Close()
        'limpiar()
    End Sub

    Private Sub btnModificar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnModificar.Click
        Try
            If TreeView.SelectedNode Is Nothing Then
                MsgBox("Seleccione un elemento a modificar", MsgBoxStyle.Information, "")
                TreeView_Leave(sender, e)
                Exit Sub
            End If

            If cmbTipoCampo.SelectedIndex = 1 And cmbTipoDato.SelectedIndex >= 0 Then
                cmbTipoDato.Enabled = True
                txtNombreNodo.Enabled = True
                estado = "E"
                Guardar = True

                btnNuevo.Enabled = False
                btnModificar.Enabled = False
                btnBorrar.Enabled = True
                btnGuardar.Enabled = True
                btnCancelar.Enabled = True
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub PrintRecursive(ByVal n As TreeNode)
        'System.Diagnostics.Debug.WriteLine(n.Text)
        'MessageBox.Show(n.Text)
        Dim aNode As TreeNode
        For Each aNode In n.Nodes
            aNode.Expand()
            PrintRecursive(aNode)
        Next
    End Sub

    ' Call the procedure using the top nodes of the treeview.
    Private Sub CallRecursive(ByVal aTreeView As TreeView)
        Dim n As TreeNode
        For Each n In aTreeView.Nodes
            PrintRecursive(n)
        Next
    End Sub

    Private Sub btnExpandir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExpandir.Click
        TreeView.ExpandAll()
        'CallRecursive(TreeView)

    End Sub

    Private Sub btnContraer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnContraer.Click
        TreeView.CollapseAll()
    End Sub

    Private Sub TreeView_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TreeView.Leave
        If TreeView.SelectedNode Is Nothing Then
            Label8.Text = "No hay directorio seleccionado "
        Else
            NodoPadre = TreeView.SelectedNode.Name
            Label8.Text = "Esta ubicado en el directorio: " & TreeView.SelectedNode.Text
        End If
    End Sub
End Class