﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uscHabitos
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IntCigarrillosPorDiaLabel As System.Windows.Forms.Label
        Dim IntAnosFumadosLabel As System.Windows.Forms.Label
        Dim DblPaquetesAnoLabel As System.Windows.Forms.Label
        Dim IntidClaseLicorLabel As System.Windows.Forms.Label
        Dim IntcantidadTragosLabel As System.Windows.Forms.Label
        Dim IntFrecuenciaLicorLabel As System.Windows.Forms.Label
        Dim BitComsumePsicoactivosLabel As System.Windows.Forms.Label
        Dim BitConsumeLicorLabel As System.Windows.Forms.Label
        Dim BitFumaUltimosSeisMesesLabel As System.Windows.Forms.Label
        Dim BitHipnoticosParaDormirLabel As System.Windows.Forms.Label
        Dim BitPerteneceAsociacionesLabel As System.Windows.Forms.Label
        Dim DtmFechaLabel As System.Windows.Forms.Label
        Dim IntDuracionLabel As System.Windows.Forms.Label
        Dim IntFrecuenciaLabel As System.Windows.Forms.Label
        Dim IntidActividadLabel As System.Windows.Forms.Label
        Dim IntidEjercicioLabel As System.Windows.Forms.Label
        Dim IntidHabitosLabel As System.Windows.Forms.Label
        Dim StrAsociacionesLabel As System.Windows.Forms.Label
        Dim StrClaseHipnoticosLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uscHabitos))
        Me.TblHabitosHCBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label10 = New System.Windows.Forms.Label
        Me.GroupBoxFuma = New System.Windows.Forms.GroupBox
        Me.IntCigarrillosPorDiaClsTextBox = New ClsUtilidades.ClsTextBox
        Me.IntAnosFumadosClsTextBox = New ClsUtilidades.ClsTextBox
        Me.DblPaquetesAnoClsTextBox = New ClsUtilidades.ClsTextBox
        Me.GroupBoxLicor = New System.Windows.Forms.GroupBox
        Me.IntidClaseLicorClsComboBox = New ClsUtilidades.ClsComboBox
        Me.TblTipoClaseLicorBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntcantidadTragosClsTextBox = New ClsUtilidades.ClsTextBox
        Me.IntFrecuenciaLicorClsTextBox = New ClsUtilidades.ClsTextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.BitComsumePsicoactivosClsCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitConsumeLicorClsCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitFumaUltimosSeisMesesClsCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitHipnoticosParaDormirClsCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitPerteneceAsociacionesClsCheckBox = New ClsUtilidades.ClsCheckBox
        Me.DtmFechaClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker
        Me.IntDuracionClsTextBox = New ClsUtilidades.ClsTextBox
        Me.IntFrecuenciaClsTextBox = New ClsUtilidades.ClsTextBox
        Me.IntidActividadClsComboBox = New ClsUtilidades.ClsComboBox
        Me.TblTipoActividadBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntidEjercicioClsComboBox = New ClsUtilidades.ClsComboBox
        Me.TblTipoEjercicioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntidHabitosClsTextBox = New ClsUtilidades.ClsTextBox
        Me.TblCitasMotivosConsultaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.TblEPBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.StrHcTextoHabitosTextBox = New System.Windows.Forms.TextBox
        Me.StrAsociacionesClsTextBox = New System.Windows.Forms.TextBox
        Me.StrClasePsicoactivosClsTextBox = New System.Windows.Forms.TextBox
        Me.StrClaseHipnoticosClsTextBox = New System.Windows.Forms.TextBox
        IntCigarrillosPorDiaLabel = New System.Windows.Forms.Label
        IntAnosFumadosLabel = New System.Windows.Forms.Label
        DblPaquetesAnoLabel = New System.Windows.Forms.Label
        IntidClaseLicorLabel = New System.Windows.Forms.Label
        IntcantidadTragosLabel = New System.Windows.Forms.Label
        IntFrecuenciaLicorLabel = New System.Windows.Forms.Label
        BitComsumePsicoactivosLabel = New System.Windows.Forms.Label
        BitConsumeLicorLabel = New System.Windows.Forms.Label
        BitFumaUltimosSeisMesesLabel = New System.Windows.Forms.Label
        BitHipnoticosParaDormirLabel = New System.Windows.Forms.Label
        BitPerteneceAsociacionesLabel = New System.Windows.Forms.Label
        DtmFechaLabel = New System.Windows.Forms.Label
        IntDuracionLabel = New System.Windows.Forms.Label
        IntFrecuenciaLabel = New System.Windows.Forms.Label
        IntidActividadLabel = New System.Windows.Forms.Label
        IntidEjercicioLabel = New System.Windows.Forms.Label
        IntidHabitosLabel = New System.Windows.Forms.Label
        StrAsociacionesLabel = New System.Windows.Forms.Label
        StrClaseHipnoticosLabel = New System.Windows.Forms.Label
        CType(Me.TblHabitosHCBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBoxFuma.SuspendLayout()
        Me.GroupBoxLicor.SuspendLayout()
        CType(Me.TblTipoClaseLicorBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoActividadBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoEjercicioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCitasMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCitasMotivosConsultaBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntCigarrillosPorDiaLabel
        '
        IntCigarrillosPorDiaLabel.AutoSize = True
        IntCigarrillosPorDiaLabel.Location = New System.Drawing.Point(7, 16)
        IntCigarrillosPorDiaLabel.Name = "IntCigarrillosPorDiaLabel"
        IntCigarrillosPorDiaLabel.Size = New System.Drawing.Size(92, 13)
        IntCigarrillosPorDiaLabel.TabIndex = 18
        IntCigarrillosPorDiaLabel.Text = "Cigarrillos Por Dia:"
        '
        'IntAnosFumadosLabel
        '
        IntAnosFumadosLabel.AutoSize = True
        IntAnosFumadosLabel.Location = New System.Drawing.Point(164, 16)
        IntAnosFumadosLabel.Name = "IntAnosFumadosLabel"
        IntAnosFumadosLabel.Size = New System.Drawing.Size(80, 13)
        IntAnosFumadosLabel.TabIndex = 14
        IntAnosFumadosLabel.Text = "Años Fumados:"
        '
        'DblPaquetesAnoLabel
        '
        DblPaquetesAnoLabel.AutoSize = True
        DblPaquetesAnoLabel.Location = New System.Drawing.Point(344, 16)
        DblPaquetesAnoLabel.Name = "DblPaquetesAnoLabel"
        DblPaquetesAnoLabel.Size = New System.Drawing.Size(77, 13)
        DblPaquetesAnoLabel.TabIndex = 10
        DblPaquetesAnoLabel.Text = "Paquetes Año:"
        '
        'IntidClaseLicorLabel
        '
        IntidClaseLicorLabel.AutoSize = True
        IntidClaseLicorLabel.Location = New System.Drawing.Point(2, 18)
        IntidClaseLicorLabel.Name = "IntidClaseLicorLabel"
        IntidClaseLicorLabel.Size = New System.Drawing.Size(62, 13)
        IntidClaseLicorLabel.TabIndex = 28
        IntidClaseLicorLabel.Text = "Clase Licor:"
        '
        'IntcantidadTragosLabel
        '
        IntcantidadTragosLabel.AutoSize = True
        IntcantidadTragosLabel.Location = New System.Drawing.Point(185, 19)
        IntcantidadTragosLabel.Name = "IntcantidadTragosLabel"
        IntcantidadTragosLabel.Size = New System.Drawing.Size(88, 13)
        IntcantidadTragosLabel.TabIndex = 16
        IntcantidadTragosLabel.Text = "Cantidad Tragos:"
        '
        'IntFrecuenciaLicorLabel
        '
        IntFrecuenciaLicorLabel.AutoSize = True
        IntFrecuenciaLicorLabel.Location = New System.Drawing.Point(334, 17)
        IntFrecuenciaLicorLabel.Name = "IntFrecuenciaLicorLabel"
        IntFrecuenciaLicorLabel.Size = New System.Drawing.Size(87, 13)
        IntFrecuenciaLicorLabel.TabIndex = 24
        IntFrecuenciaLicorLabel.Text = "Frecuencia días:"
        '
        'BitComsumePsicoactivosLabel
        '
        BitComsumePsicoactivosLabel.AutoSize = True
        BitComsumePsicoactivosLabel.Location = New System.Drawing.Point(9, 316)
        BitComsumePsicoactivosLabel.Name = "BitComsumePsicoactivosLabel"
        BitComsumePsicoactivosLabel.Size = New System.Drawing.Size(119, 13)
        BitComsumePsicoactivosLabel.TabIndex = 53
        BitComsumePsicoactivosLabel.Text = "Comsume Psicoactivos:"
        '
        'BitConsumeLicorLabel
        '
        BitConsumeLicorLabel.AutoSize = True
        BitConsumeLicorLabel.Location = New System.Drawing.Point(9, 207)
        BitConsumeLicorLabel.Name = "BitConsumeLicorLabel"
        BitConsumeLicorLabel.Size = New System.Drawing.Size(80, 13)
        BitConsumeLicorLabel.TabIndex = 55
        BitConsumeLicorLabel.Text = "Consume Licor:"
        '
        'BitFumaUltimosSeisMesesLabel
        '
        BitFumaUltimosSeisMesesLabel.AutoSize = True
        BitFumaUltimosSeisMesesLabel.Location = New System.Drawing.Point(9, 249)
        BitFumaUltimosSeisMesesLabel.Name = "BitFumaUltimosSeisMesesLabel"
        BitFumaUltimosSeisMesesLabel.Size = New System.Drawing.Size(159, 13)
        BitFumaUltimosSeisMesesLabel.TabIndex = 57
        BitFumaUltimosSeisMesesLabel.Text = "Ha Fumado los últimos 6 Meses:"
        '
        'BitHipnoticosParaDormirLabel
        '
        BitHipnoticosParaDormirLabel.AutoSize = True
        BitHipnoticosParaDormirLabel.Location = New System.Drawing.Point(9, 386)
        BitHipnoticosParaDormirLabel.Name = "BitHipnoticosParaDormirLabel"
        BitHipnoticosParaDormirLabel.Size = New System.Drawing.Size(163, 13)
        BitHipnoticosParaDormirLabel.TabIndex = 59
        BitHipnoticosParaDormirLabel.Text = "Necesita Hipnoticos Para Dormir:"
        '
        'BitPerteneceAsociacionesLabel
        '
        BitPerteneceAsociacionesLabel.AutoSize = True
        BitPerteneceAsociacionesLabel.Location = New System.Drawing.Point(9, 147)
        BitPerteneceAsociacionesLabel.Name = "BitPerteneceAsociacionesLabel"
        BitPerteneceAsociacionesLabel.Size = New System.Drawing.Size(125, 13)
        BitPerteneceAsociacionesLabel.TabIndex = 61
        BitPerteneceAsociacionesLabel.Text = "Pertenece Asociaciones:"
        '
        'DtmFechaLabel
        '
        DtmFechaLabel.AutoSize = True
        DtmFechaLabel.Location = New System.Drawing.Point(9, 52)
        DtmFechaLabel.Name = "DtmFechaLabel"
        DtmFechaLabel.Size = New System.Drawing.Size(40, 13)
        DtmFechaLabel.TabIndex = 63
        DtmFechaLabel.Text = "Fecha:"
        '
        'IntDuracionLabel
        '
        IntDuracionLabel.AutoSize = True
        IntDuracionLabel.Location = New System.Drawing.Point(583, 91)
        IntDuracionLabel.Name = "IntDuracionLabel"
        IntDuracionLabel.Size = New System.Drawing.Size(53, 13)
        IntDuracionLabel.TabIndex = 65
        IntDuracionLabel.Text = "Duración:"
        '
        'IntFrecuenciaLabel
        '
        IntFrecuenciaLabel.AutoSize = True
        IntFrecuenciaLabel.Location = New System.Drawing.Point(443, 92)
        IntFrecuenciaLabel.Name = "IntFrecuenciaLabel"
        IntFrecuenciaLabel.Size = New System.Drawing.Size(66, 13)
        IntFrecuenciaLabel.TabIndex = 67
        IntFrecuenciaLabel.Text = "Frecuencia: "
        '
        'IntidActividadLabel
        '
        IntidActividadLabel.AutoSize = True
        IntidActividadLabel.Location = New System.Drawing.Point(9, 92)
        IntidActividadLabel.Name = "IntidActividadLabel"
        IntidActividadLabel.Size = New System.Drawing.Size(54, 13)
        IntidActividadLabel.TabIndex = 69
        IntidActividadLabel.Text = "Actividad:"
        '
        'IntidEjercicioLabel
        '
        IntidEjercicioLabel.AutoSize = True
        IntidEjercicioLabel.Location = New System.Drawing.Point(232, 92)
        IntidEjercicioLabel.Name = "IntidEjercicioLabel"
        IntidEjercicioLabel.Size = New System.Drawing.Size(50, 13)
        IntidEjercicioLabel.TabIndex = 71
        IntidEjercicioLabel.Text = "Ejercicio:"
        '
        'IntidHabitosLabel
        '
        IntidHabitosLabel.AutoSize = True
        IntidHabitosLabel.Location = New System.Drawing.Point(181, 52)
        IntidHabitosLabel.Name = "IntidHabitosLabel"
        IntidHabitosLabel.Size = New System.Drawing.Size(18, 13)
        IntidHabitosLabel.TabIndex = 73
        IntidHabitosLabel.Text = "id:"
        IntidHabitosLabel.Visible = False
        '
        'StrAsociacionesLabel
        '
        StrAsociacionesLabel.AutoSize = True
        StrAsociacionesLabel.Location = New System.Drawing.Point(192, 124)
        StrAsociacionesLabel.Name = "StrAsociacionesLabel"
        StrAsociacionesLabel.Size = New System.Drawing.Size(131, 13)
        StrAsociacionesLabel.TabIndex = 75
        StrAsociacionesLabel.Text = "Enumere las Asociaciones"
        '
        'StrClaseHipnoticosLabel
        '
        StrClaseHipnoticosLabel.AutoSize = True
        StrClaseHipnoticosLabel.Location = New System.Drawing.Point(192, 352)
        StrClaseHipnoticosLabel.Name = "StrClaseHipnoticosLabel"
        StrClaseHipnoticosLabel.Size = New System.Drawing.Size(89, 13)
        StrClaseHipnoticosLabel.TabIndex = 77
        StrClaseHipnoticosLabel.Text = "Clase Hipnóticos:"
        '
        'TblHabitosHCBindingSource
        '
        Me.TblHabitosHCBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblHabitosHC)
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(192, 282)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(111, 13)
        Me.Label10.TabIndex = 85
        Me.Label10.Text = "Clase de Psicoactivos"
        '
        'GroupBoxFuma
        '
        Me.GroupBoxFuma.Controls.Add(IntCigarrillosPorDiaLabel)
        Me.GroupBoxFuma.Controls.Add(Me.IntCigarrillosPorDiaClsTextBox)
        Me.GroupBoxFuma.Controls.Add(IntAnosFumadosLabel)
        Me.GroupBoxFuma.Controls.Add(Me.IntAnosFumadosClsTextBox)
        Me.GroupBoxFuma.Controls.Add(DblPaquetesAnoLabel)
        Me.GroupBoxFuma.Controls.Add(Me.DblPaquetesAnoClsTextBox)
        Me.GroupBoxFuma.Enabled = False
        Me.GroupBoxFuma.Location = New System.Drawing.Point(195, 235)
        Me.GroupBoxFuma.Name = "GroupBoxFuma"
        Me.GroupBoxFuma.Size = New System.Drawing.Size(498, 40)
        Me.GroupBoxFuma.TabIndex = 84
        Me.GroupBoxFuma.TabStop = False
        '
        'IntCigarrillosPorDiaClsTextBox
        '
        Me.IntCigarrillosPorDiaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "intCigarrillosPorDia", True))
        Me.IntCigarrillosPorDiaClsTextBox.DataSource = Nothing
        Me.IntCigarrillosPorDiaClsTextBox.Location = New System.Drawing.Point(105, 13)
        Me.IntCigarrillosPorDiaClsTextBox.Name = "IntCigarrillosPorDiaClsTextBox"
        Me.IntCigarrillosPorDiaClsTextBox.NombreCodigoF2 = Nothing
        Me.IntCigarrillosPorDiaClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntCigarrillosPorDiaClsTextBox.Size = New System.Drawing.Size(51, 20)
        Me.IntCigarrillosPorDiaClsTextBox.TabIndex = 19
        Me.IntCigarrillosPorDiaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'IntAnosFumadosClsTextBox
        '
        Me.IntAnosFumadosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "intAnosFumados", True))
        Me.IntAnosFumadosClsTextBox.DataSource = Nothing
        Me.IntAnosFumadosClsTextBox.Location = New System.Drawing.Point(247, 13)
        Me.IntAnosFumadosClsTextBox.Name = "IntAnosFumadosClsTextBox"
        Me.IntAnosFumadosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntAnosFumadosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntAnosFumadosClsTextBox.Size = New System.Drawing.Size(52, 20)
        Me.IntAnosFumadosClsTextBox.TabIndex = 15
        Me.IntAnosFumadosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'DblPaquetesAnoClsTextBox
        '
        Me.DblPaquetesAnoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "dblPaquetesAno", True))
        Me.DblPaquetesAnoClsTextBox.DataSource = Nothing
        Me.DblPaquetesAnoClsTextBox.Location = New System.Drawing.Point(427, 13)
        Me.DblPaquetesAnoClsTextBox.Name = "DblPaquetesAnoClsTextBox"
        Me.DblPaquetesAnoClsTextBox.NombreCodigoF2 = Nothing
        Me.DblPaquetesAnoClsTextBox.NombreDescripcionF2 = Nothing
        Me.DblPaquetesAnoClsTextBox.ReadOnly = True
        Me.DblPaquetesAnoClsTextBox.Size = New System.Drawing.Size(59, 20)
        Me.DblPaquetesAnoClsTextBox.TabIndex = 11
        Me.DblPaquetesAnoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'GroupBoxLicor
        '
        Me.GroupBoxLicor.Controls.Add(IntidClaseLicorLabel)
        Me.GroupBoxLicor.Controls.Add(Me.IntidClaseLicorClsComboBox)
        Me.GroupBoxLicor.Controls.Add(IntcantidadTragosLabel)
        Me.GroupBoxLicor.Controls.Add(Me.IntcantidadTragosClsTextBox)
        Me.GroupBoxLicor.Controls.Add(IntFrecuenciaLicorLabel)
        Me.GroupBoxLicor.Controls.Add(Me.IntFrecuenciaLicorClsTextBox)
        Me.GroupBoxLicor.Enabled = False
        Me.GroupBoxLicor.Location = New System.Drawing.Point(195, 192)
        Me.GroupBoxLicor.Name = "GroupBoxLicor"
        Me.GroupBoxLicor.Size = New System.Drawing.Size(498, 43)
        Me.GroupBoxLicor.TabIndex = 83
        Me.GroupBoxLicor.TabStop = False
        '
        'IntidClaseLicorClsComboBox
        '
        Me.IntidClaseLicorClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblHabitosHCBindingSource, "intidClaseLicor", True))
        Me.IntidClaseLicorClsComboBox.DataSource = Me.TblTipoClaseLicorBindingSource
        Me.IntidClaseLicorClsComboBox.DisplayMember = "strValor"
        Me.IntidClaseLicorClsComboBox.FormattingEnabled = True
        Me.IntidClaseLicorClsComboBox.Location = New System.Drawing.Point(70, 14)
        Me.IntidClaseLicorClsComboBox.Name = "IntidClaseLicorClsComboBox"
        Me.IntidClaseLicorClsComboBox.Size = New System.Drawing.Size(109, 21)
        Me.IntidClaseLicorClsComboBox.TabIndex = 29
        Me.IntidClaseLicorClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoClaseLicorBindingSource
        '
        Me.TblTipoClaseLicorBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntcantidadTragosClsTextBox
        '
        Me.IntcantidadTragosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "intcantidadTragos", True))
        Me.IntcantidadTragosClsTextBox.DataSource = Nothing
        Me.IntcantidadTragosClsTextBox.Location = New System.Drawing.Point(277, 15)
        Me.IntcantidadTragosClsTextBox.Name = "IntcantidadTragosClsTextBox"
        Me.IntcantidadTragosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntcantidadTragosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntcantidadTragosClsTextBox.Size = New System.Drawing.Size(51, 20)
        Me.IntcantidadTragosClsTextBox.TabIndex = 17
        Me.IntcantidadTragosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'IntFrecuenciaLicorClsTextBox
        '
        Me.IntFrecuenciaLicorClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "intFrecuenciaLicor", True))
        Me.IntFrecuenciaLicorClsTextBox.DataSource = Nothing
        Me.IntFrecuenciaLicorClsTextBox.Location = New System.Drawing.Point(427, 14)
        Me.IntFrecuenciaLicorClsTextBox.Name = "IntFrecuenciaLicorClsTextBox"
        Me.IntFrecuenciaLicorClsTextBox.NombreCodigoF2 = Nothing
        Me.IntFrecuenciaLicorClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntFrecuenciaLicorClsTextBox.Size = New System.Drawing.Size(62, 20)
        Me.IntFrecuenciaLicorClsTextBox.TabIndex = 25
        Me.IntFrecuenciaLicorClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(645, 72)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(44, 13)
        Me.Label9.TabIndex = 82
        Me.Label9.Text = "Minutos"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(515, 73)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 13)
        Me.Label8.TabIndex = 81
        Me.Label8.Text = "Semanal"
        '
        'BitComsumePsicoactivosClsCheckBox
        '
        Me.BitComsumePsicoactivosClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblHabitosHCBindingSource, "bitComsumePsicoactivos", True))
        Me.BitComsumePsicoactivosClsCheckBox.Location = New System.Drawing.Point(172, 310)
        Me.BitComsumePsicoactivosClsCheckBox.Name = "BitComsumePsicoactivosClsCheckBox"
        Me.BitComsumePsicoactivosClsCheckBox.Size = New System.Drawing.Size(17, 24)
        Me.BitComsumePsicoactivosClsCheckBox.TabIndex = 54
        Me.BitComsumePsicoactivosClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitConsumeLicorClsCheckBox
        '
        Me.BitConsumeLicorClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblHabitosHCBindingSource, "bitConsumeLicor", True))
        Me.BitConsumeLicorClsCheckBox.Location = New System.Drawing.Point(172, 202)
        Me.BitConsumeLicorClsCheckBox.Name = "BitConsumeLicorClsCheckBox"
        Me.BitConsumeLicorClsCheckBox.Size = New System.Drawing.Size(17, 24)
        Me.BitConsumeLicorClsCheckBox.TabIndex = 56
        Me.BitConsumeLicorClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitFumaUltimosSeisMesesClsCheckBox
        '
        Me.BitFumaUltimosSeisMesesClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblHabitosHCBindingSource, "bitFumaUltimosSeisMeses", True))
        Me.BitFumaUltimosSeisMesesClsCheckBox.Location = New System.Drawing.Point(172, 243)
        Me.BitFumaUltimosSeisMesesClsCheckBox.Name = "BitFumaUltimosSeisMesesClsCheckBox"
        Me.BitFumaUltimosSeisMesesClsCheckBox.Size = New System.Drawing.Size(19, 24)
        Me.BitFumaUltimosSeisMesesClsCheckBox.TabIndex = 58
        Me.BitFumaUltimosSeisMesesClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitHipnoticosParaDormirClsCheckBox
        '
        Me.BitHipnoticosParaDormirClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblHabitosHCBindingSource, "bitHipnoticosParaDormir", True))
        Me.BitHipnoticosParaDormirClsCheckBox.Location = New System.Drawing.Point(172, 381)
        Me.BitHipnoticosParaDormirClsCheckBox.Name = "BitHipnoticosParaDormirClsCheckBox"
        Me.BitHipnoticosParaDormirClsCheckBox.Size = New System.Drawing.Size(17, 24)
        Me.BitHipnoticosParaDormirClsCheckBox.TabIndex = 60
        Me.BitHipnoticosParaDormirClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitPerteneceAsociacionesClsCheckBox
        '
        Me.BitPerteneceAsociacionesClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblHabitosHCBindingSource, "bitPerteneceAsociaciones", True))
        Me.BitPerteneceAsociacionesClsCheckBox.Location = New System.Drawing.Point(172, 142)
        Me.BitPerteneceAsociacionesClsCheckBox.Name = "BitPerteneceAsociacionesClsCheckBox"
        Me.BitPerteneceAsociacionesClsCheckBox.Size = New System.Drawing.Size(17, 24)
        Me.BitPerteneceAsociacionesClsCheckBox.TabIndex = 62
        Me.BitPerteneceAsociacionesClsCheckBox.UseVisualStyleBackColor = True
        '
        'DtmFechaClsDateTimePicker
        '
        Me.DtmFechaClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblHabitosHCBindingSource, "dtmFecha", True))
        Me.DtmFechaClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaClsDateTimePicker.Location = New System.Drawing.Point(72, 48)
        Me.DtmFechaClsDateTimePicker.Name = "DtmFechaClsDateTimePicker"
        Me.DtmFechaClsDateTimePicker.Size = New System.Drawing.Size(92, 20)
        Me.DtmFechaClsDateTimePicker.TabIndex = 64
        '
        'IntDuracionClsTextBox
        '
        Me.IntDuracionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "intDuracion", True))
        Me.IntDuracionClsTextBox.DataSource = Nothing
        Me.IntDuracionClsTextBox.Location = New System.Drawing.Point(642, 88)
        Me.IntDuracionClsTextBox.Name = "IntDuracionClsTextBox"
        Me.IntDuracionClsTextBox.NombreCodigoF2 = Nothing
        Me.IntDuracionClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntDuracionClsTextBox.Size = New System.Drawing.Size(51, 20)
        Me.IntDuracionClsTextBox.TabIndex = 66
        Me.IntDuracionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'IntFrecuenciaClsTextBox
        '
        Me.IntFrecuenciaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "intFrecuencia", True))
        Me.IntFrecuenciaClsTextBox.DataSource = Nothing
        Me.IntFrecuenciaClsTextBox.Location = New System.Drawing.Point(514, 89)
        Me.IntFrecuenciaClsTextBox.Name = "IntFrecuenciaClsTextBox"
        Me.IntFrecuenciaClsTextBox.NombreCodigoF2 = Nothing
        Me.IntFrecuenciaClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntFrecuenciaClsTextBox.Size = New System.Drawing.Size(51, 20)
        Me.IntFrecuenciaClsTextBox.TabIndex = 68
        Me.IntFrecuenciaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Entero
        '
        'IntidActividadClsComboBox
        '
        Me.IntidActividadClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblHabitosHCBindingSource, "intidActividad", True))
        Me.IntidActividadClsComboBox.DataSource = Me.TblTipoActividadBindingSource
        Me.IntidActividadClsComboBox.DisplayMember = "strValor"
        Me.IntidActividadClsComboBox.FormattingEnabled = True
        Me.IntidActividadClsComboBox.Location = New System.Drawing.Point(72, 88)
        Me.IntidActividadClsComboBox.Name = "IntidActividadClsComboBox"
        Me.IntidActividadClsComboBox.Size = New System.Drawing.Size(144, 21)
        Me.IntidActividadClsComboBox.TabIndex = 70
        Me.IntidActividadClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoActividadBindingSource
        '
        Me.TblTipoActividadBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntidEjercicioClsComboBox
        '
        Me.IntidEjercicioClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblHabitosHCBindingSource, "intidEjercicio", True))
        Me.IntidEjercicioClsComboBox.DataSource = Me.TblTipoEjercicioBindingSource
        Me.IntidEjercicioClsComboBox.DisplayMember = "strValor"
        Me.IntidEjercicioClsComboBox.FormattingEnabled = True
        Me.IntidEjercicioClsComboBox.Location = New System.Drawing.Point(285, 88)
        Me.IntidEjercicioClsComboBox.Name = "IntidEjercicioClsComboBox"
        Me.IntidEjercicioClsComboBox.Size = New System.Drawing.Size(144, 21)
        Me.IntidEjercicioClsComboBox.TabIndex = 72
        Me.IntidEjercicioClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoEjercicioBindingSource
        '
        Me.TblTipoEjercicioBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntidHabitosClsTextBox
        '
        Me.IntidHabitosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "intidHabitos", True))
        Me.IntidHabitosClsTextBox.DataSource = Nothing
        Me.IntidHabitosClsTextBox.Location = New System.Drawing.Point(205, 49)
        Me.IntidHabitosClsTextBox.Name = "IntidHabitosClsTextBox"
        Me.IntidHabitosClsTextBox.NombreCodigoF2 = Nothing
        Me.IntidHabitosClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntidHabitosClsTextBox.Size = New System.Drawing.Size(62, 20)
        Me.IntidHabitosClsTextBox.TabIndex = 74
        Me.IntidHabitosClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.IntidHabitosClsTextBox.Visible = False
        '
        'TblCitasMotivosConsultaBindingNavigator
        '
        Me.TblCitasMotivosConsultaBindingNavigator.AddNewItem = Nothing
        Me.TblCitasMotivosConsultaBindingNavigator.BindingSource = Me.TblHabitosHCBindingSource
        Me.TblCitasMotivosConsultaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblCitasMotivosConsultaBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblCitasMotivosConsultaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorDeleteItem, Me.TblEPBindingNavigatorSaveItem})
        Me.TblCitasMotivosConsultaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCitasMotivosConsultaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblCitasMotivosConsultaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblCitasMotivosConsultaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblCitasMotivosConsultaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblCitasMotivosConsultaBindingNavigator.Name = "TblCitasMotivosConsultaBindingNavigator"
        Me.TblCitasMotivosConsultaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblCitasMotivosConsultaBindingNavigator.Size = New System.Drawing.Size(713, 25)
        Me.TblCitasMotivosConsultaBindingNavigator.TabIndex = 88
        Me.TblCitasMotivosConsultaBindingNavigator.Text = "BindingNavigator"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(38, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblEPBindingNavigatorSaveItem
        '
        Me.TblEPBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblEPBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblEPBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblEPBindingNavigatorSaveItem.Name = "TblEPBindingNavigatorSaveItem"
        Me.TblEPBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblEPBindingNavigatorSaveItem.Text = "Save Data"
        '
        'StrHcTextoHabitosTextBox
        '
        Me.StrHcTextoHabitosTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "strHcTextoHabitos", True))
        Me.StrHcTextoHabitosTextBox.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StrHcTextoHabitosTextBox.Location = New System.Drawing.Point(629, 43)
        Me.StrHcTextoHabitosTextBox.Name = "StrHcTextoHabitosTextBox"
        Me.StrHcTextoHabitosTextBox.Size = New System.Drawing.Size(60, 26)
        Me.StrHcTextoHabitosTextBox.TabIndex = 89
        Me.StrHcTextoHabitosTextBox.Visible = False
        '
        'StrAsociacionesClsTextBox
        '
        Me.StrAsociacionesClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "strAsociaciones", True))
        Me.StrAsociacionesClsTextBox.Location = New System.Drawing.Point(196, 140)
        Me.StrAsociacionesClsTextBox.Multiline = True
        Me.StrAsociacionesClsTextBox.Name = "StrAsociacionesClsTextBox"
        Me.StrAsociacionesClsTextBox.ReadOnly = True
        Me.StrAsociacionesClsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.StrAsociacionesClsTextBox.Size = New System.Drawing.Size(497, 52)
        Me.StrAsociacionesClsTextBox.TabIndex = 90
        '
        'StrClasePsicoactivosClsTextBox
        '
        Me.StrClasePsicoactivosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "strClasePsicoactivos", True))
        Me.StrClasePsicoactivosClsTextBox.Location = New System.Drawing.Point(195, 297)
        Me.StrClasePsicoactivosClsTextBox.Multiline = True
        Me.StrClasePsicoactivosClsTextBox.Name = "StrClasePsicoactivosClsTextBox"
        Me.StrClasePsicoactivosClsTextBox.ReadOnly = True
        Me.StrClasePsicoactivosClsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.StrClasePsicoactivosClsTextBox.Size = New System.Drawing.Size(497, 52)
        Me.StrClasePsicoactivosClsTextBox.TabIndex = 91
        '
        'StrClaseHipnoticosClsTextBox
        '
        Me.StrClaseHipnoticosClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblHabitosHCBindingSource, "strClaseHipnoticos", True))
        Me.StrClaseHipnoticosClsTextBox.Location = New System.Drawing.Point(195, 366)
        Me.StrClaseHipnoticosClsTextBox.Multiline = True
        Me.StrClaseHipnoticosClsTextBox.Name = "StrClaseHipnoticosClsTextBox"
        Me.StrClaseHipnoticosClsTextBox.ReadOnly = True
        Me.StrClaseHipnoticosClsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.StrClaseHipnoticosClsTextBox.Size = New System.Drawing.Size(497, 52)
        Me.StrClaseHipnoticosClsTextBox.TabIndex = 92
        '
        'uscHabitos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.StrClaseHipnoticosClsTextBox)
        Me.Controls.Add(Me.StrClasePsicoactivosClsTextBox)
        Me.Controls.Add(Me.StrAsociacionesClsTextBox)
        Me.Controls.Add(Me.StrHcTextoHabitosTextBox)
        Me.Controls.Add(Me.TblCitasMotivosConsultaBindingNavigator)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.GroupBoxFuma)
        Me.Controls.Add(Me.GroupBoxLicor)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(BitComsumePsicoactivosLabel)
        Me.Controls.Add(BitConsumeLicorLabel)
        Me.Controls.Add(BitFumaUltimosSeisMesesLabel)
        Me.Controls.Add(BitHipnoticosParaDormirLabel)
        Me.Controls.Add(BitPerteneceAsociacionesLabel)
        Me.Controls.Add(DtmFechaLabel)
        Me.Controls.Add(IntDuracionLabel)
        Me.Controls.Add(IntFrecuenciaLabel)
        Me.Controls.Add(IntidActividadLabel)
        Me.Controls.Add(IntidEjercicioLabel)
        Me.Controls.Add(IntidHabitosLabel)
        Me.Controls.Add(StrAsociacionesLabel)
        Me.Controls.Add(StrClaseHipnoticosLabel)
        Me.Controls.Add(Me.BitComsumePsicoactivosClsCheckBox)
        Me.Controls.Add(Me.BitConsumeLicorClsCheckBox)
        Me.Controls.Add(Me.BitFumaUltimosSeisMesesClsCheckBox)
        Me.Controls.Add(Me.BitHipnoticosParaDormirClsCheckBox)
        Me.Controls.Add(Me.BitPerteneceAsociacionesClsCheckBox)
        Me.Controls.Add(Me.DtmFechaClsDateTimePicker)
        Me.Controls.Add(Me.IntDuracionClsTextBox)
        Me.Controls.Add(Me.IntFrecuenciaClsTextBox)
        Me.Controls.Add(Me.IntidActividadClsComboBox)
        Me.Controls.Add(Me.IntidEjercicioClsComboBox)
        Me.Controls.Add(Me.IntidHabitosClsTextBox)
        Me.Name = "uscHabitos"
        Me.Size = New System.Drawing.Size(713, 438)
        CType(Me.TblHabitosHCBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBoxFuma.ResumeLayout(False)
        Me.GroupBoxFuma.PerformLayout()
        Me.GroupBoxLicor.ResumeLayout(False)
        Me.GroupBoxLicor.PerformLayout()
        CType(Me.TblTipoClaseLicorBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoActividadBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoEjercicioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCitasMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCitasMotivosConsultaBindingNavigator.ResumeLayout(False)
        Me.TblCitasMotivosConsultaBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblHabitosHCBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents GroupBoxFuma As System.Windows.Forms.GroupBox
    Friend WithEvents IntCigarrillosPorDiaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntAnosFumadosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DblPaquetesAnoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents GroupBoxLicor As System.Windows.Forms.GroupBox
    Friend WithEvents IntidClaseLicorClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntcantidadTragosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntFrecuenciaLicorClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents BitComsumePsicoactivosClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitConsumeLicorClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitFumaUltimosSeisMesesClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitHipnoticosParaDormirClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitPerteneceAsociacionesClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents DtmFechaClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntDuracionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntFrecuenciaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntidActividadClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntidEjercicioClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntidHabitosClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TblCitasMotivosConsultaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblEPBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblTipoClaseLicorBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoActividadBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoEjercicioBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StrHcTextoHabitosTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrAsociacionesClsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrClasePsicoactivosClsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrClaseHipnoticosClsTextBox As System.Windows.Forms.TextBox

End Class
