﻿Imports System.Windows.Forms

Public Class uscTratamiento
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mHC As Integer
    Private _btn As Windows.Forms.Button
    Private mclsUtilidadesHC As clsUtilidadesHC
    Private _IdUsuario As String
    Private mNuevo As Boolean
    Private _mstrStringConection As String
    Private _mCita As Integer

    Public Sub New()

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub



    Public Property mstrStringConection() As String
        Get
            Return _mstrStringConection
        End Get
        Set(ByVal value As String)
            _mstrStringConection = value
        End Set
    End Property

    Public Property mCita() As Integer
        Get
            Return _mCita
        End Get
        Set(ByVal value As Integer)
            _mCita = value
        End Set
    End Property
    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mHC() As Integer
        Get
            Return _mHC
        End Get
        Set(ByVal value As Integer)
            _mHC = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub cargarDatosTabTratamiento()
        'Try
        '    mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
        '    If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
        '        StrTratamientoTextoTextBox.Dock = DockStyle.Fill
        '        StrTratamientoTextoTextBox.BringToFront()
        '        StrTratamientoTextoTextBox.Visible = True
        '        StrTratamientoTextoTextBox.Multiline = True
        '        prCargarDatostratamiento()
        '    Else
        '        prCargarDatostratamiento()
        '    End If
        'Catch ex As Exception
        '    ClsError.ClsError.PrMostrarError(ex)
        'End Try

        Try
            Dim mconsulta = (From p In dc.tblDiagnosticoConductaHC Where p.intidHC = mHC Select p.bitModoTexto, p.strDiagnosticoConductaTextoHC)
            If mconsulta.Count > 0 Then
                For Each c In mconsulta
                    If c.bitModoTexto = True Then
                        StrTratamientoTextoTextBox.Dock = DockStyle.Fill
                        StrTratamientoTextoTextBox.BringToFront()
                        StrTratamientoTextoTextBox.Multiline = True
                        StrTratamientoTextoTextBox.Visible = True
                        prCargarDatostratamiento()
                    Else
                        prCargarDatostratamiento()
                        Exit For
                    End If
                Next
            Else
                mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
                If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
                    StrTratamientoTextoTextBox.Dock = DockStyle.Fill
                    StrTratamientoTextoTextBox.BringToFront()
                    StrTratamientoTextoTextBox.Multiline = True
                    StrTratamientoTextoTextBox.Visible = True
                    prCargarDatostratamiento()
                Else
                    prCargarDatostratamiento()
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub prCargarDatostratamiento()
        Try
            TblMedicamentosGenericosBindingSource.DataSource = dc.tblMedicamentosGenericos
            Dim mMedidas = (From p In dc.tblTipos Where p.strTipo = "MEDIDAS_DROGAS" Select p)
            TblTipoBindingSource.DataSource = mMedidas

            Dim mFrecuencia = (From f In dc.tblTipos Where f.strTipo = "FRECUENCIA" Select f)
            TblTipoBindingSource1.DataSource = mFrecuencia

            Dim mconsultaTipo = (From t In dc.tblTratamientoHC Where t.intidHC = mHC Select t)
            TblTratamientoHCBindingSource.DataSource = mconsultaTipo

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub TblTratamientoHCBindingSource_AddingNew(ByVal sender As System.Object, ByVal e As System.ComponentModel.AddingNewEventArgs) Handles TblTratamientoHCBindingSource.AddingNew
        'Try
        '    If sender.Position.ToString >= 0 Then
        '        sender.Item(sender.Position).dtmFecha = FormatDateTime(Now, DateFormat.ShortDate)
        '    End If
        'Catch ex As Exception
        '    ClsError.ClsError.PrMostrarError(ex)
        'End Try
    End Sub

    'Private Sub TblTratamientoHCDataGridView_CellValueChanged(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles TblTratamientoHCDataGridView.CellValueChanged
    '    Try
    '        If e.ColumnIndex = 0 Then
    '            'TblTratamientoHCDataGridView.Rows(e.RowIndex).Cells(0).Value = 60
    '            'TblNombresComercialesDataGridView.Rows(e.RowIndex).Cells(0).Value()
    '        End If
    '    Catch ex As Exception
    '        ClsError.ClsError.PrMostrarError(ex)
    '    End Try

    'End Sub

    Private Sub TblTratamientoHCDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblTratamientoHCDataGridView.DataError
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TblTratamientoHCBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblTratamientoHCBindingNavigatorSaveItem.Click
        prGuardar()
    End Sub

    Private Sub uscTratamiento_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        prGuardar()
    End Sub

    Private Sub prGuardar() Implements IAbandonarUC.prGuardar
        Try
            If mNuevo = True Then
                TblTratamientoHCBindingSource.Item(TblTratamientoHCBindingSource.Position).strTratamientoTexto = StrTratamientoTextoTextBox.Text
                TblTratamientoHCBindingSource.Item(TblTratamientoHCBindingSource.Position).dtmFecha = FormatDateTime(Now, DateFormat.ShortDate)
                TblTratamientoHCBindingSource.Item(TblTratamientoHCBindingSource.Position).intidHC = mHC
                If StrTratamientoTextoTextBox.Dock = DockStyle.Fill Then
                    TblTratamientoHCBindingSource.Item(TblTratamientoHCBindingSource.Position).bitModoTexto = True
                Else
                    TblTratamientoHCBindingSource.Item(TblTratamientoHCBindingSource.Position).bitModoTexto = False
                End If
                TblTratamientoHCBindingSource.EndEdit()
                dc.SubmitChanges()
                mNuevo = False
            Else
                TblTratamientoHCBindingSource.EndEdit()
                dc.SubmitChanges()
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        mNuevo = True
    End Sub

    Private Sub ToolStripButtonImprimir_Click(sender As Object, e As EventArgs) Handles ToolStripButtonImprimir.Click
        If Application.OpenForms("FrmAnexosHC") Is Nothing Then
            Dim mFrmresumenHC = New ClsReportes.FrmAnexosHC(Me.mstrStringConection, Me.mCita, Me.mHC, 2)
            mFrmresumenHC.Show()
        Else
            Application.OpenForms("FrmAnexosHC").BringToFront()
        End If
    End Sub
End Class
