﻿Imports System.Windows.Forms

Public Class FrmIPS

  Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
  Dim bLimpiarCampos As Boolean = False

  Sub New(ByVal strStringConection As String)
    Try

      ' This call is required by the Windows Form Designer.
      InitializeComponent()

      ' Add any initialization after the InitializeComponent() call.
      dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
    bLimpiarCampos = True
    ''LimpiarCampos()
    TabControl1.SelectTab(1)
  End Sub

  Private Sub FrmEPS_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Try
      'gvIPS.DataSource = dc.SP_IPSAdmin(3, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing).ReturnValue
      'Caragr columnas al data gridview
      If gvIPS.Columns.Count = 0 Then
        gvIPS.Columns.Add(AgregarColumnasGrid("nIdIPS", "Id", "Id", 100))
        gvIPS.Columns.Add(AgregarColumnasGrid("sNombre", "Nombre", "Nombre", 250))
        gvIPS.Columns.Add(AgregarColumnasGrid("sNit", "Nit", "Nit", 100))
        gvIPS.Columns.Add(AgregarColumnasGrid("sRepresentanteLegal", "Representante legal", "RepresentanteLegal", 250))
        gvIPS.Columns.Add(AgregarColumnasGrid("sNitCcRepresentanteLegal", "Nit representante legal", "NitRepresentanteLegal", 250))
        gvIPS.Columns.Add(AgregarColumnasGrid("sDireccion", "Dirección", "Direccion", 100))
        gvIPS.Columns.Add(AgregarColumnasGrid("sTelefono", "Teléfono", "Telefono", 100))
        gvIPS.Columns.Add(AgregarColumnasGrid("sEmailContacto", "Email", "Email", 150))
        gvIPS.Columns.Add(AgregarColumnasGrid("sSitioWeb", "Sito web", "SitioWeb", 150))
      End If

      gvIPS.DataSource = dc.SP_ConsultarIPS(Nothing)
      If gvIPS.RowCount = 0 Then
        gvIPS.Visible = False
      Else
        gvIPS.Visible = True
      End If
      gvIPS.RowHeadersVisible = False

      BindingNavigatorAddNewItem.Enabled = True

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TblEPBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles gvIPSBindingNavigatorSaveItem.Click
    Try
      Dim sErrores As String = ValidarCampos()

      Dim nOpcionSp As Integer = 1
      Dim nIdIPS? As Integer = Nothing

      If Not String.IsNullOrWhiteSpace(sErrores) Then
        ClsError.ClsError.PrMostrarError(New Exception(sErrores))
      Else

        If Not String.IsNullOrWhiteSpace(txtIdIPS.Text) Then
          nOpcionSp = 4
          nIdIPS = Convert.ToInt32(txtIdIPS.Text)
        End If

        gvIPS.EndEdit()
        txtIdIPS.Text = Convert.ToString(dc.SP_IPSAdmin(nOpcionSp, nIdIPS, txtNombre.Text, txtNit.Text, txtRepresentanteLEgal.Text, txtNitRepresentanteLegal.Text, txtDireccion.Text, txtTelefono.Text, txtEmailContacto.Text, txtSitioWeb.Text).ReturnValue)

        Select Case nOpcionSp
          Case 1
            MostrarMensaje("El registro se creó correctamente")
          Case 4
            MostrarMensaje("El registro se actualizó correctamente")
        End Select
        bLimpiarCampos = True
        'LimpiarCampos()
        TabControl1.SelectTab(0)
        FrmEPS_Load(Nothing, Nothing)
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TblTarifasDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs)
    Try
      'Error
    Catch ex As Exception
      'Error
    End Try
  End Sub

  Private Sub TblEPBindingSource_CurrentChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      'TblEPBindingSource.Item(TblEPBindingSource.Position).intIdEPS()
      'tbl()
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TblTarifaDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs)
    Try
      'Error
    Catch ex As Exception
      'Error
    End Try
  End Sub

  Private Function ValidarCampos() As String
    Dim sErrores As String = String.Empty

    If String.IsNullOrWhiteSpace(txtNombre.Text) Then
      sErrores = "El nombre es requerido"
    End If

    If String.IsNullOrWhiteSpace(txtRepresentanteLEgal.Text) Then
      If String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If

      sErrores += "El representante legal es requerido"
    End If

    If String.IsNullOrWhiteSpace(txtNitRepresentanteLegal.Text) Then
      If String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If
      sErrores += "El nit del representante legal es requerido"
    End If

    Return sErrores
  End Function

  Private Function AgregarColumnasGrid(ByVal sCampo As String, ByVal sHeader As String, ByVal sName As String, ByVal nWidth As Integer) As DataGridViewTextBoxColumn
    Dim dgvCol As New DataGridViewTextBoxColumn

    dgvCol.DataPropertyName = sCampo
    dgvCol.HeaderText = sHeader
    dgvCol.Selected = False
    dgvCol.Name = sName
    dgvCol.Width = nWidth
    dgvCol.SortMode = DataGridViewColumnSortMode.NotSortable

    Return dgvCol
  End Function

  Private Sub TabControl1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles TabControl1.SelectedIndexChanged
    If bLimpiarCampos Then
      LimpiarCampos()

      BindingNavigatorDeleteItem.Enabled = True
    End If
  End Sub

  Private Sub selectedCellsButton_Click( _
    ByVal sender As Object, ByVal e As System.EventArgs) _
    Handles gvIPS.Click

    If Not gvIPS.CurrentCell Is Nothing Then
      Dim selectedCellCount As Integer = _
        gvIPS.GetCellCount(DataGridViewElementStates.Selected)

      Dim o As Object = gvIPS.GetCellCount(DataGridViewElementStates.Selected).GetType()

      If selectedCellCount > 0 Then

        txtIdIPS.Text = Convert.ToString(gvIPS.Item("Id", gvIPS.CurrentRow.Index).Value)
        txtNombre.Text = Convert.ToString(gvIPS.Item("Nombre", gvIPS.CurrentRow.Index).Value)
        txtNit.Text = Convert.ToString(gvIPS.Item("Nit", gvIPS.CurrentRow.Index).Value)
        txtRepresentanteLEgal.Text = Convert.ToString(gvIPS.Item("RepresentanteLegal", gvIPS.CurrentRow.Index).Value)
        txtNitRepresentanteLegal.Text = Convert.ToString(gvIPS.Item("NitRepresentanteLegal", gvIPS.CurrentRow.Index).Value)
        txtDireccion.Text = Convert.ToString(gvIPS.Item("Direccion", gvIPS.CurrentRow.Index).Value)
        txtTelefono.Text = Convert.ToString(gvIPS.Item("Telefono", gvIPS.CurrentRow.Index).Value)
        txtEmailContacto.Text = Convert.ToString(gvIPS.Item("Email", gvIPS.CurrentRow.Index).Value)
        txtSitioWeb.Text = Convert.ToString(gvIPS.Item("SitioWeb", gvIPS.CurrentRow.Index).Value)
        bLimpiarCampos = False
        TabControl1.SelectTab(TabControl1.TabCount - 1)
        
        BindingNavigatorDeleteItem.Enabled = True

      End If
    End If

  End Sub

  Private Sub LimpiarCampos()
    txtIdIPS.Text = String.Empty
    txtNombre.Text = String.Empty
    txtNit.Text = String.Empty
    txtRepresentanteLEgal.Text = String.Empty
    txtNitRepresentanteLegal.Text = String.Empty
    txtDireccion.Text = String.Empty
    txtTelefono.Text = String.Empty
    txtEmailContacto.Text = String.Empty
    txtSitioWeb.Text = String.Empty
  End Sub

  Private Sub BindingNavigatorDeleteItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorDeleteItem.Click
    Try
      Dim nIdIPS As Integer = Convert.ToInt32(gvIPS.Item("Id", gvIPS.CurrentRow.Index).Value)

      Dim oRetorno As Object = dc.SP_IPSAdmin(5, nIdIPS, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing).ReturnValue

      Select Case oRetorno
        Case "5"
          MostrarMensaje("El registro se eliminó correctamente")
        Case Else
          MostrarMensaje(oRetorno)
      End Select

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    Finally
      bLimpiarCampos = True
      'LimpiarCampos()
      TabControl1.SelectTab(0)

      FrmEPS_Load(Nothing, Nothing)
    End Try
  End Sub

  Private Sub MostrarMensaje(ByVal sMensaje As String)
    MessageBox.Show(sMensaje, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly, False)
  End Sub

End Class