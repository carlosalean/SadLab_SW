﻿Imports System.Windows.Forms

Public Class uscAntecedentesSocioEconomicos
    Implements IAbandonarUC

    Private _dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Private _mIdentificacion As String
    Private _btn As Windows.Forms.Button
    Private mclsUtilidadesHC As clsUtilidadesHC
    Private _IdUsuario As String
    Private mNuevo As Boolean

    Public Sub New()

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().

    End Sub

    Public Property dc() As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
        Get
            Return _dc
        End Get
        Set(ByVal value As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext)
            _dc = value
        End Set
    End Property

    Public Property mIdentificacion() As String
        Get
            Return _mIdentificacion
        End Get
        Set(ByVal value As String)
            _mIdentificacion = value
        End Set
    End Property

    Public Property Boton() As Windows.Forms.Button
        Get
            Return _btn
        End Get
        Set(ByVal value As Windows.Forms.Button)
            _btn = value
        End Set
    End Property

    Public Property IdUsuario() As String
        Get
            Return _IdUsuario
        End Get
        Set(ByVal value As String)
            _IdUsuario = value
        End Set
    End Property

    Public Sub cargarDatosTabASE()
        Try
            Dim mconsulta = (From p In dc.tblAntecedentesSocioEconomicosHC Where p.strNroIdentificacion = mIdentificacion Select p.bitModoTexto, p.strHcAntEconomicos)
            If mconsulta.Count > 0 Then
                For Each c In mconsulta
                    If c.bitModoTexto = True Then
                        StrHcAntEconomicosTextBox.Dock = DockStyle.Fill
                        StrHcAntEconomicosTextBox.BringToFront()
                        StrHcAntEconomicosTextBox.Multiline = True
                        StrHcAntEconomicosTextBox.Visible = True
                        prCargarDatosAntecedentesSocioEconomicos()
                    Else
                        prCargarDatosAntecedentesSocioEconomicos()
                        Exit For
                    End If
                Next
            Else
                mclsUtilidadesHC = New clsUtilidadesHC(dc, IdUsuario)
                If mclsUtilidadesHC.consultarModoTextoItems(Boton) = True Then
                    StrHcAntEconomicosTextBox.Dock = DockStyle.Fill
                    StrHcAntEconomicosTextBox.BringToFront()
                    StrHcAntEconomicosTextBox.Multiline = True
                    StrHcAntEconomicosTextBox.Visible = True
                    prCargarDatosAntecedentesSocioEconomicos()
                Else
                    prCargarDatosAntecedentesSocioEconomicos()
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub prCargarDatosAntecedentesSocioEconomicos()
        Try
            'Cargar ocupaciones 
            TblOcupacionesBindingSource.DataSource = dc.tblOcupaciones

            'Cargar Escolaridad
            TblTipoEscolaridadBindingSource.DataSource = dc.usp_ConsultarEscolaridad()

            'Cargar tipo empleado
            TblTipoEmpleoBindingSource.DataSource = dc.usp_ConsultarEmpleo

            'Cargar ingresos
            TblTipoIngresosBindingSource.DataSource = dc.usp_ConsultarIngresosPropios

            'Cargar ingresos familiares
            TblTipoIngresosFamiliaresBindingSource.DataSource = dc.usp_ConsultarIngresosPropios

            'Cargar Sostiene la familia
            TblTipoSostieneFamiliaBindingSource.DataSource = dc.usp_ConsultarSostieneFamilia

            'Cargar vive
            TblTipoViveBindingSource.DataSource = dc.usp_ConsultarVive

            'Cargar tipo vivienda
            TblTipoViviendaBindingSource.DataSource = dc.usp_ConsultarTipoVivienda

            'Cargar ubicacion vivienda
            TblTipoUbicacionViviendaBindingSource.DataSource = dc.usp_ConsultarUbicacionVivienda

            'Cargar estrato
            TblTipoEstratoBindingSource.DataSource = dc.usp_ConsultarEstratos

            'Cargar tipo acabados
            TblTipoAcabadosBindingSource.DataSource = dc.usp_ConsultarAcabadosVivienda

            Dim mAntecedentes = (From E In dc.tblAntecedentesSocioEconomicosHC Where E.strNroIdentificacion = mIdentificacion Select E)

            If mAntecedentes.Count > 0 Then
                TblAntecedentesSocioEconomicosHCBindingSource.DataSource = mAntecedentes '(From E In dc.tblAntecedentesSocioEconomicosHC Where E.intidHC = mHC Select E)
                mNuevo = False
            Else
                TblAntecedentesSocioEconomicosHCBindingSource.AddNew()
                mNuevo = True
            End If

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub uscAntecedentesSocioEconomicos_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Leave
        prGuardar()
    End Sub

    Private Sub TblEPBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblEPBindingNavigatorSaveItem.Click
        prGuardar()
    End Sub

    Public Sub prGuardar() Implements IAbandonarUC.prGuardar

        Try
            If TblAntecedentesSocioEconomicosHCBindingSource.Position = 0 Then
                TblAntecedentesSocioEconomicosHCBindingSource.Item(TblAntecedentesSocioEconomicosHCBindingSource.Position).strHcAntEconomicos = StrHcAntEconomicosTextBox.Text
                TblAntecedentesSocioEconomicosHCBindingSource.Item(TblAntecedentesSocioEconomicosHCBindingSource.Position).strNroIdentificacion = mIdentificacion

                If StrHcAntEconomicosTextBox.Dock = DockStyle.Fill Then
                    TblAntecedentesSocioEconomicosHCBindingSource.Item(TblAntecedentesSocioEconomicosHCBindingSource.Position).bitModoTexto = True
                Else
                    TblAntecedentesSocioEconomicosHCBindingSource.Item(TblAntecedentesSocioEconomicosHCBindingSource.Position).bitModoTexto = False
                End If
                TblAntecedentesSocioEconomicosHCBindingSource.EndEdit()
                If mNuevo = True Then
                    dc.tblAntecedentesSocioEconomicosHC.InsertOnSubmit(TblAntecedentesSocioEconomicosHCBindingSource.Item(TblAntecedentesSocioEconomicosHCBindingSource.Position))
                End If
                mNuevo = False
                dc.SubmitChanges()
            End If
            TblAntecedentesSocioEconomicosHCBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

End Class
