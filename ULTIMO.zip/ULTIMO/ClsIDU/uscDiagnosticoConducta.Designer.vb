﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uscDiagnosticoConducta
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DtmFechaLabel As System.Windows.Forms.Label
        Dim IntidDiagnosticoLabel As System.Windows.Forms.Label
        Dim StrComplicacionesLabel As System.Windows.Forms.Label
        Dim IntidProcedimientoTerLabel As System.Windows.Forms.Label
        Dim IntidProcedimientoSecLabel As System.Windows.Forms.Label
        Dim IntidProcedimientoPpalLabel As System.Windows.Forms.Label
        Dim BitProcedimientoLabel As System.Windows.Forms.Label
        Dim BitMedidasGeneralesLabel As System.Windows.Forms.Label
        Dim BitTtoNoFarmacologicoLabel As System.Windows.Forms.Label
        Dim BitTtoFarmacologicoLabel As System.Windows.Forms.Label
        Dim BitExamenesLaboratorioLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uscDiagnosticoConducta))
        Me.TblCitasMotivosConsultaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.TblDiagnosticoConductaHCBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblEPBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TblDisgnosticoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblProcedimientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblProcedimientoBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblProcedimientoBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.DtmFechaClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker()
        Me.IntidDiagnosticoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.StrDiagnosticoConductaTextoHCClsTextBox = New System.Windows.Forms.TextBox()
        Me.StrComplicacionesClsTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntidProcedimientoTerClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.IntidProcedimientoSecClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.IntidProcedimientoPpalClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.BitProcedimientoClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.BitMedidasGeneralesClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.BitTtoNoFarmacologicoClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.BitTtoFarmacologicoClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.BitExamenesLaboratorioClsCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BitPresuntivoRadioButton = New System.Windows.Forms.RadioButton()
        Me.BitConfirmadoRadioButton = New System.Windows.Forms.RadioButton()
        Me.ToolStripButtonImprimir = New System.Windows.Forms.ToolStripButton()
        DtmFechaLabel = New System.Windows.Forms.Label()
        IntidDiagnosticoLabel = New System.Windows.Forms.Label()
        StrComplicacionesLabel = New System.Windows.Forms.Label()
        IntidProcedimientoTerLabel = New System.Windows.Forms.Label()
        IntidProcedimientoSecLabel = New System.Windows.Forms.Label()
        IntidProcedimientoPpalLabel = New System.Windows.Forms.Label()
        BitProcedimientoLabel = New System.Windows.Forms.Label()
        BitMedidasGeneralesLabel = New System.Windows.Forms.Label()
        BitTtoNoFarmacologicoLabel = New System.Windows.Forms.Label()
        BitTtoFarmacologicoLabel = New System.Windows.Forms.Label()
        BitExamenesLaboratorioLabel = New System.Windows.Forms.Label()
        CType(Me.TblCitasMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCitasMotivosConsultaBindingNavigator.SuspendLayout()
        CType(Me.TblDiagnosticoConductaHCBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDisgnosticoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProcedimientoBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProcedimientoBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DtmFechaLabel
        '
        DtmFechaLabel.AutoSize = True
        DtmFechaLabel.Location = New System.Drawing.Point(17, 29)
        DtmFechaLabel.Name = "DtmFechaLabel"
        DtmFechaLabel.Size = New System.Drawing.Size(40, 13)
        DtmFechaLabel.TabIndex = 116
        DtmFechaLabel.Text = "Fecha:"
        '
        'IntidDiagnosticoLabel
        '
        IntidDiagnosticoLabel.AutoSize = True
        IntidDiagnosticoLabel.Location = New System.Drawing.Point(15, 54)
        IntidDiagnosticoLabel.Name = "IntidDiagnosticoLabel"
        IntidDiagnosticoLabel.Size = New System.Drawing.Size(66, 13)
        IntidDiagnosticoLabel.TabIndex = 114
        IntidDiagnosticoLabel.Text = "Diagnostico:"
        '
        'StrComplicacionesLabel
        '
        StrComplicacionesLabel.AutoSize = True
        StrComplicacionesLabel.Location = New System.Drawing.Point(15, 306)
        StrComplicacionesLabel.Name = "StrComplicacionesLabel"
        StrComplicacionesLabel.Size = New System.Drawing.Size(84, 13)
        StrComplicacionesLabel.TabIndex = 111
        StrComplicacionesLabel.Text = "Complicaciones:"
        '
        'IntidProcedimientoTerLabel
        '
        IntidProcedimientoTerLabel.AutoSize = True
        IntidProcedimientoTerLabel.Location = New System.Drawing.Point(12, 252)
        IntidProcedimientoTerLabel.Name = "IntidProcedimientoTerLabel"
        IntidProcedimientoTerLabel.Size = New System.Drawing.Size(103, 13)
        IntidProcedimientoTerLabel.TabIndex = 110
        IntidProcedimientoTerLabel.Text = "Procedimiento 3ario:"
        '
        'IntidProcedimientoSecLabel
        '
        IntidProcedimientoSecLabel.AutoSize = True
        IntidProcedimientoSecLabel.Location = New System.Drawing.Point(13, 225)
        IntidProcedimientoSecLabel.Name = "IntidProcedimientoSecLabel"
        IntidProcedimientoSecLabel.Size = New System.Drawing.Size(103, 13)
        IntidProcedimientoSecLabel.TabIndex = 107
        IntidProcedimientoSecLabel.Text = "Procedimiento 2ario:"
        '
        'IntidProcedimientoPpalLabel
        '
        IntidProcedimientoPpalLabel.AutoSize = True
        IntidProcedimientoPpalLabel.Location = New System.Drawing.Point(12, 198)
        IntidProcedimientoPpalLabel.Name = "IntidProcedimientoPpalLabel"
        IntidProcedimientoPpalLabel.Size = New System.Drawing.Size(101, 13)
        IntidProcedimientoPpalLabel.TabIndex = 105
        IntidProcedimientoPpalLabel.Text = "Procedimiento Ppal:"
        '
        'BitProcedimientoLabel
        '
        BitProcedimientoLabel.AutoSize = True
        BitProcedimientoLabel.Location = New System.Drawing.Point(387, 16)
        BitProcedimientoLabel.Name = "BitProcedimientoLabel"
        BitProcedimientoLabel.Size = New System.Drawing.Size(77, 13)
        BitProcedimientoLabel.TabIndex = 8
        BitProcedimientoLabel.Text = "Procedimiento:"
        '
        'BitMedidasGeneralesLabel
        '
        BitMedidasGeneralesLabel.AutoSize = True
        BitMedidasGeneralesLabel.Location = New System.Drawing.Point(204, 46)
        BitMedidasGeneralesLabel.Name = "BitMedidasGeneralesLabel"
        BitMedidasGeneralesLabel.Size = New System.Drawing.Size(101, 13)
        BitMedidasGeneralesLabel.TabIndex = 6
        BitMedidasGeneralesLabel.Text = "Medidas Generales:"
        '
        'BitTtoNoFarmacologicoLabel
        '
        BitTtoNoFarmacologicoLabel.AutoSize = True
        BitTtoNoFarmacologicoLabel.Location = New System.Drawing.Point(204, 16)
        BitTtoNoFarmacologicoLabel.Name = "BitTtoNoFarmacologicoLabel"
        BitTtoNoFarmacologicoLabel.Size = New System.Drawing.Size(115, 13)
        BitTtoNoFarmacologicoLabel.TabIndex = 4
        BitTtoNoFarmacologicoLabel.Text = "Tto No Farmacológico:"
        '
        'BitTtoFarmacologicoLabel
        '
        BitTtoFarmacologicoLabel.AutoSize = True
        BitTtoFarmacologicoLabel.Location = New System.Drawing.Point(8, 46)
        BitTtoFarmacologicoLabel.Name = "BitTtoFarmacologicoLabel"
        BitTtoFarmacologicoLabel.Size = New System.Drawing.Size(98, 13)
        BitTtoFarmacologicoLabel.TabIndex = 2
        BitTtoFarmacologicoLabel.Text = "Tto Farmacológico:"
        '
        'BitExamenesLaboratorioLabel
        '
        BitExamenesLaboratorioLabel.AutoSize = True
        BitExamenesLaboratorioLabel.Location = New System.Drawing.Point(8, 16)
        BitExamenesLaboratorioLabel.Name = "BitExamenesLaboratorioLabel"
        BitExamenesLaboratorioLabel.Size = New System.Drawing.Size(130, 13)
        BitExamenesLaboratorioLabel.TabIndex = 0
        BitExamenesLaboratorioLabel.Text = "Examenes de Laboratorio:"
        '
        'TblCitasMotivosConsultaBindingNavigator
        '
        Me.TblCitasMotivosConsultaBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblCitasMotivosConsultaBindingNavigator.BindingSource = Me.TblDiagnosticoConductaHCBindingSource
        Me.TblCitasMotivosConsultaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblCitasMotivosConsultaBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblCitasMotivosConsultaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblEPBindingNavigatorSaveItem, Me.ToolStripButtonImprimir})
        Me.TblCitasMotivosConsultaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCitasMotivosConsultaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblCitasMotivosConsultaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblCitasMotivosConsultaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblCitasMotivosConsultaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblCitasMotivosConsultaBindingNavigator.Name = "TblCitasMotivosConsultaBindingNavigator"
        Me.TblCitasMotivosConsultaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblCitasMotivosConsultaBindingNavigator.Size = New System.Drawing.Size(653, 25)
        Me.TblCitasMotivosConsultaBindingNavigator.TabIndex = 87
        Me.TblCitasMotivosConsultaBindingNavigator.Text = "BindingNavigator"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'TblDiagnosticoConductaHCBindingSource
        '
        Me.TblDiagnosticoConductaHCBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDiagnosticoConductaHC)
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblEPBindingNavigatorSaveItem
        '
        Me.TblEPBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblEPBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblEPBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblEPBindingNavigatorSaveItem.Name = "TblEPBindingNavigatorSaveItem"
        Me.TblEPBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblEPBindingNavigatorSaveItem.Text = "Save Data"
        '
        'TblDisgnosticoBindingSource
        '
        Me.TblDisgnosticoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDisgnostico)
        '
        'TblProcedimientoBindingSource
        '
        Me.TblProcedimientoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        '
        'TblProcedimientoBindingSource1
        '
        Me.TblProcedimientoBindingSource1.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        '
        'TblProcedimientoBindingSource2
        '
        Me.TblProcedimientoBindingSource2.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(DtmFechaLabel)
        Me.Panel1.Controls.Add(Me.DtmFechaClsDateTimePicker)
        Me.Panel1.Controls.Add(IntidDiagnosticoLabel)
        Me.Panel1.Controls.Add(Me.IntidDiagnosticoClsComboBox)
        Me.Panel1.Controls.Add(Me.StrDiagnosticoConductaTextoHCClsTextBox)
        Me.Panel1.Controls.Add(StrComplicacionesLabel)
        Me.Panel1.Controls.Add(Me.StrComplicacionesClsTextBox)
        Me.Panel1.Controls.Add(IntidProcedimientoTerLabel)
        Me.Panel1.Controls.Add(Me.IntidProcedimientoTerClsComboBox)
        Me.Panel1.Controls.Add(IntidProcedimientoSecLabel)
        Me.Panel1.Controls.Add(Me.IntidProcedimientoSecClsComboBox)
        Me.Panel1.Controls.Add(IntidProcedimientoPpalLabel)
        Me.Panel1.Controls.Add(Me.IntidProcedimientoPpalClsComboBox)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 25)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(653, 436)
        Me.Panel1.TabIndex = 88
        '
        'DtmFechaClsDateTimePicker
        '
        Me.DtmFechaClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblDiagnosticoConductaHCBindingSource, "dtmFecha", True))
        Me.DtmFechaClsDateTimePicker.Enabled = False
        Me.DtmFechaClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaClsDateTimePicker.Location = New System.Drawing.Point(124, 25)
        Me.DtmFechaClsDateTimePicker.Name = "DtmFechaClsDateTimePicker"
        Me.DtmFechaClsDateTimePicker.Size = New System.Drawing.Size(85, 20)
        Me.DtmFechaClsDateTimePicker.TabIndex = 118
        '
        'IntidDiagnosticoClsComboBox
        '
        Me.IntidDiagnosticoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblDiagnosticoConductaHCBindingSource, "intidDiagnostico", True))
        Me.IntidDiagnosticoClsComboBox.DataSource = Me.TblDisgnosticoBindingSource
        Me.IntidDiagnosticoClsComboBox.DisplayMember = "strNombre"
        Me.IntidDiagnosticoClsComboBox.FormattingEnabled = True
        Me.IntidDiagnosticoClsComboBox.Location = New System.Drawing.Point(124, 51)
        Me.IntidDiagnosticoClsComboBox.Name = "IntidDiagnosticoClsComboBox"
        Me.IntidDiagnosticoClsComboBox.Size = New System.Drawing.Size(507, 21)
        Me.IntidDiagnosticoClsComboBox.TabIndex = 117
        Me.IntidDiagnosticoClsComboBox.ValueMember = "intIdDiagnostico"
        '
        'StrDiagnosticoConductaTextoHCClsTextBox
        '
        Me.StrDiagnosticoConductaTextoHCClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDiagnosticoConductaHCBindingSource, "strDiagnosticoConductaTextoHC", True))
        Me.StrDiagnosticoConductaTextoHCClsTextBox.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StrDiagnosticoConductaTextoHCClsTextBox.Location = New System.Drawing.Point(531, 81)
        Me.StrDiagnosticoConductaTextoHCClsTextBox.Multiline = True
        Me.StrDiagnosticoConductaTextoHCClsTextBox.Name = "StrDiagnosticoConductaTextoHCClsTextBox"
        Me.StrDiagnosticoConductaTextoHCClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrDiagnosticoConductaTextoHCClsTextBox.TabIndex = 115
        Me.StrDiagnosticoConductaTextoHCClsTextBox.Visible = False
        '
        'StrComplicacionesClsTextBox
        '
        Me.StrComplicacionesClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblDiagnosticoConductaHCBindingSource, "strComplicaciones", True))
        Me.StrComplicacionesClsTextBox.DataSource = Nothing
        Me.StrComplicacionesClsTextBox.EnterEntreCampos = False
        Me.StrComplicacionesClsTextBox.Location = New System.Drawing.Point(124, 276)
        Me.StrComplicacionesClsTextBox.Multiline = True
        Me.StrComplicacionesClsTextBox.Name = "StrComplicacionesClsTextBox"
        Me.StrComplicacionesClsTextBox.NombreCodigoF2 = Nothing
        Me.StrComplicacionesClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrComplicacionesClsTextBox.Size = New System.Drawing.Size(507, 73)
        Me.StrComplicacionesClsTextBox.TabIndex = 113
        Me.StrComplicacionesClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntidProcedimientoTerClsComboBox
        '
        Me.IntidProcedimientoTerClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblDiagnosticoConductaHCBindingSource, "intidProcedimientoTer", True))
        Me.IntidProcedimientoTerClsComboBox.DataSource = Me.TblProcedimientoBindingSource2
        Me.IntidProcedimientoTerClsComboBox.DisplayMember = "strDescripcion"
        Me.IntidProcedimientoTerClsComboBox.FormattingEnabled = True
        Me.IntidProcedimientoTerClsComboBox.Location = New System.Drawing.Point(124, 249)
        Me.IntidProcedimientoTerClsComboBox.Name = "IntidProcedimientoTerClsComboBox"
        Me.IntidProcedimientoTerClsComboBox.Size = New System.Drawing.Size(507, 21)
        Me.IntidProcedimientoTerClsComboBox.TabIndex = 112
        Me.IntidProcedimientoTerClsComboBox.ValueMember = "intIdProcedimientos"
        '
        'IntidProcedimientoSecClsComboBox
        '
        Me.IntidProcedimientoSecClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblDiagnosticoConductaHCBindingSource, "intidProcedimientoSec", True))
        Me.IntidProcedimientoSecClsComboBox.DataSource = Me.TblProcedimientoBindingSource1
        Me.IntidProcedimientoSecClsComboBox.DisplayMember = "strDescripcion"
        Me.IntidProcedimientoSecClsComboBox.FormattingEnabled = True
        Me.IntidProcedimientoSecClsComboBox.Location = New System.Drawing.Point(124, 222)
        Me.IntidProcedimientoSecClsComboBox.Name = "IntidProcedimientoSecClsComboBox"
        Me.IntidProcedimientoSecClsComboBox.Size = New System.Drawing.Size(507, 21)
        Me.IntidProcedimientoSecClsComboBox.TabIndex = 109
        Me.IntidProcedimientoSecClsComboBox.ValueMember = "intIdProcedimientos"
        '
        'IntidProcedimientoPpalClsComboBox
        '
        Me.IntidProcedimientoPpalClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblDiagnosticoConductaHCBindingSource, "intidProcedimientoPpal", True))
        Me.IntidProcedimientoPpalClsComboBox.DataSource = Me.TblProcedimientoBindingSource
        Me.IntidProcedimientoPpalClsComboBox.DisplayMember = "strDescripcion"
        Me.IntidProcedimientoPpalClsComboBox.FormattingEnabled = True
        Me.IntidProcedimientoPpalClsComboBox.Location = New System.Drawing.Point(124, 195)
        Me.IntidProcedimientoPpalClsComboBox.Name = "IntidProcedimientoPpalClsComboBox"
        Me.IntidProcedimientoPpalClsComboBox.Size = New System.Drawing.Size(507, 21)
        Me.IntidProcedimientoPpalClsComboBox.TabIndex = 108
        Me.IntidProcedimientoPpalClsComboBox.ValueMember = "intIdProcedimientos"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(BitProcedimientoLabel)
        Me.GroupBox2.Controls.Add(Me.BitProcedimientoClsCheckBox)
        Me.GroupBox2.Controls.Add(BitMedidasGeneralesLabel)
        Me.GroupBox2.Controls.Add(Me.BitMedidasGeneralesClsCheckBox)
        Me.GroupBox2.Controls.Add(BitTtoNoFarmacologicoLabel)
        Me.GroupBox2.Controls.Add(Me.BitTtoNoFarmacologicoClsCheckBox)
        Me.GroupBox2.Controls.Add(BitTtoFarmacologicoLabel)
        Me.GroupBox2.Controls.Add(Me.BitTtoFarmacologicoClsCheckBox)
        Me.GroupBox2.Controls.Add(BitExamenesLaboratorioLabel)
        Me.GroupBox2.Controls.Add(Me.BitExamenesLaboratorioClsCheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(124, 112)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(507, 77)
        Me.GroupBox2.TabIndex = 106
        Me.GroupBox2.TabStop = False
        '
        'BitProcedimientoClsCheckBox
        '
        Me.BitProcedimientoClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblDiagnosticoConductaHCBindingSource, "bitProcedimiento", True))
        Me.BitProcedimientoClsCheckBox.Location = New System.Drawing.Point(470, 11)
        Me.BitProcedimientoClsCheckBox.Name = "BitProcedimientoClsCheckBox"
        Me.BitProcedimientoClsCheckBox.Size = New System.Drawing.Size(16, 24)
        Me.BitProcedimientoClsCheckBox.TabIndex = 9
        Me.BitProcedimientoClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitMedidasGeneralesClsCheckBox
        '
        Me.BitMedidasGeneralesClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblDiagnosticoConductaHCBindingSource, "bitMedidasGenerales", True))
        Me.BitMedidasGeneralesClsCheckBox.Location = New System.Drawing.Point(325, 41)
        Me.BitMedidasGeneralesClsCheckBox.Name = "BitMedidasGeneralesClsCheckBox"
        Me.BitMedidasGeneralesClsCheckBox.Size = New System.Drawing.Size(17, 24)
        Me.BitMedidasGeneralesClsCheckBox.TabIndex = 7
        Me.BitMedidasGeneralesClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitTtoNoFarmacologicoClsCheckBox
        '
        Me.BitTtoNoFarmacologicoClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblDiagnosticoConductaHCBindingSource, "bitTtoNoFarmacologico", True))
        Me.BitTtoNoFarmacologicoClsCheckBox.Location = New System.Drawing.Point(325, 11)
        Me.BitTtoNoFarmacologicoClsCheckBox.Name = "BitTtoNoFarmacologicoClsCheckBox"
        Me.BitTtoNoFarmacologicoClsCheckBox.Size = New System.Drawing.Size(17, 24)
        Me.BitTtoNoFarmacologicoClsCheckBox.TabIndex = 5
        Me.BitTtoNoFarmacologicoClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitTtoFarmacologicoClsCheckBox
        '
        Me.BitTtoFarmacologicoClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblDiagnosticoConductaHCBindingSource, "bitTtoFarmacologico", True))
        Me.BitTtoFarmacologicoClsCheckBox.Location = New System.Drawing.Point(143, 40)
        Me.BitTtoFarmacologicoClsCheckBox.Name = "BitTtoFarmacologicoClsCheckBox"
        Me.BitTtoFarmacologicoClsCheckBox.Size = New System.Drawing.Size(19, 24)
        Me.BitTtoFarmacologicoClsCheckBox.TabIndex = 3
        Me.BitTtoFarmacologicoClsCheckBox.UseVisualStyleBackColor = True
        '
        'BitExamenesLaboratorioClsCheckBox
        '
        Me.BitExamenesLaboratorioClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblDiagnosticoConductaHCBindingSource, "bitExamenesLaboratorio", True))
        Me.BitExamenesLaboratorioClsCheckBox.Location = New System.Drawing.Point(143, 11)
        Me.BitExamenesLaboratorioClsCheckBox.Name = "BitExamenesLaboratorioClsCheckBox"
        Me.BitExamenesLaboratorioClsCheckBox.Size = New System.Drawing.Size(16, 24)
        Me.BitExamenesLaboratorioClsCheckBox.TabIndex = 1
        Me.BitExamenesLaboratorioClsCheckBox.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 144)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 13)
        Me.Label2.TabIndex = 104
        Me.Label2.Text = "Tipo de conducta:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 86)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 13)
        Me.Label1.TabIndex = 103
        Me.Label1.Text = "Tipo de Diagnóstico:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BitPresuntivoRadioButton)
        Me.GroupBox1.Controls.Add(Me.BitConfirmadoRadioButton)
        Me.GroupBox1.Location = New System.Drawing.Point(124, 73)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(190, 39)
        Me.GroupBox1.TabIndex = 102
        Me.GroupBox1.TabStop = False
        '
        'BitPresuntivoRadioButton
        '
        Me.BitPresuntivoRadioButton.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.TblDiagnosticoConductaHCBindingSource, "bitPresuntivo", True))
        Me.BitPresuntivoRadioButton.Location = New System.Drawing.Point(8, 9)
        Me.BitPresuntivoRadioButton.Name = "BitPresuntivoRadioButton"
        Me.BitPresuntivoRadioButton.Size = New System.Drawing.Size(79, 24)
        Me.BitPresuntivoRadioButton.TabIndex = 3
        Me.BitPresuntivoRadioButton.TabStop = True
        Me.BitPresuntivoRadioButton.Text = "Presuntivo"
        Me.BitPresuntivoRadioButton.UseVisualStyleBackColor = True
        '
        'BitConfirmadoRadioButton
        '
        Me.BitConfirmadoRadioButton.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.TblDiagnosticoConductaHCBindingSource, "bitConfirmado", True))
        Me.BitConfirmadoRadioButton.Location = New System.Drawing.Point(104, 9)
        Me.BitConfirmadoRadioButton.Name = "BitConfirmadoRadioButton"
        Me.BitConfirmadoRadioButton.Size = New System.Drawing.Size(79, 24)
        Me.BitConfirmadoRadioButton.TabIndex = 1
        Me.BitConfirmadoRadioButton.TabStop = True
        Me.BitConfirmadoRadioButton.Text = "Confirmado"
        Me.BitConfirmadoRadioButton.UseVisualStyleBackColor = True
        '
        'ToolStripButtonImprimir
        '
        Me.ToolStripButtonImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButtonImprimir.Image = CType(resources.GetObject("ToolStripButtonImprimir.Image"), System.Drawing.Image)
        Me.ToolStripButtonImprimir.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButtonImprimir.Name = "ToolStripButtonImprimir"
        Me.ToolStripButtonImprimir.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButtonImprimir.Text = "Imprimir"
        '
        'uscDiagnosticoConducta
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TblCitasMotivosConsultaBindingNavigator)
        Me.Name = "uscDiagnosticoConducta"
        Me.Size = New System.Drawing.Size(653, 461)
        CType(Me.TblCitasMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCitasMotivosConsultaBindingNavigator.ResumeLayout(False)
        Me.TblCitasMotivosConsultaBindingNavigator.PerformLayout()
        CType(Me.TblDiagnosticoConductaHCBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDisgnosticoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProcedimientoBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProcedimientoBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblCitasMotivosConsultaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblEPBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblDiagnosticoConductaHCBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblDisgnosticoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblProcedimientoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblProcedimientoBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents TblProcedimientoBindingSource2 As System.Windows.Forms.BindingSource
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DtmFechaClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntidDiagnosticoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents StrDiagnosticoConductaTextoHCClsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StrComplicacionesClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntidProcedimientoTerClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntidProcedimientoSecClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntidProcedimientoPpalClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents BitProcedimientoClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitMedidasGeneralesClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitTtoNoFarmacologicoClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitTtoFarmacologicoClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitExamenesLaboratorioClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents BitPresuntivoRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents BitConfirmadoRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ToolStripButtonImprimir As System.Windows.Forms.ToolStripButton

End Class
