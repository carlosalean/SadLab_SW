﻿Imports System.Windows.Forms

Public Class DialogCierreCaja
    Dim mstrStringConection As String
    Dim mstrIntIdUsuario As Integer
    Dim mintIdCaja As Integer
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mRes As New List(Of Object)
    Dim mList As New List(Of Object)
    Public CajaCerrada As Boolean = False
    Public mEfectivo As Integer
    Public mDiferencia As Integer

    Public Sub New(ByVal strStringConection As String, ByVal strIntIdUsuario As Integer, ByVal intIdCaja As Integer)

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()
        mstrStringConection = strIntIdUsuario
        mstrIntIdUsuario = strIntIdUsuario
        mintIdCaja = intIdCaja
        dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)

    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Try
            If ClsTextBoxEfectivo.Text = Nothing Then
                MsgBox("Debe ingresar el efectivo", MsgBoxStyle.Information, " ")
                Exit Sub
            End If

            If ClsTextBoxTotal.Text = 0 Then
                If dc.usp_CerrarCaja(mList.Item(0).intIdCuadre, 0, Convert.ToInt32(ClsTextBoxEfectivo.Text.ToString.Replace("$", "").Replace(",", "")), Integer.Parse(ClsTextBoxDiferencia.Text.ToString.Replace("$", "").Replace(",", "").Replace("(", "-").Replace(")", "").Replace(" ", "")), mintIdCaja) = 0 Then
                    MsgBox("La caja ha sido cerrada", MsgBoxStyle.Information, " ")
                    mEfectivo = ClsTextBoxEfectivo.Text
                    mDiferencia = ClsTextBoxDiferencia.Text
                    CajaCerrada = True
                End If
            Else
                If dc.usp_CerrarCaja(BindingSourcePagos.Item(BindingSourcePagos.Position).intIdCuadre, Convert.ToInt32(ClsTextBoxTotal.Text.ToString.Replace("$", "").Replace(",", "")), Convert.ToInt32(ClsTextBoxEfectivo.Text.ToString.Replace("$", "").Replace(",", "")), Integer.Parse(ClsTextBoxDiferencia.Text.ToString.Replace("$", "").Replace(",", "").Replace("(", "-").Replace(")", "").Replace(" ", "")), mintIdCaja) = 0 Then
                    MsgBox("La caja ha sido cerrada", MsgBoxStyle.Information, " ")
                    mEfectivo = ClsTextBoxEfectivo.Text
                    mDiferencia = ClsTextBoxDiferencia.Text
                    CajaCerrada = True
                End If
            End If

            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Function Sumar( _
       ByVal Dgv As Windows.Forms.DataGridView, ByVal columna As String) As Double

        Dim total As Double = 0
        Try
            For i As Integer = 0 To Dgv.RowCount - 1
                total = total + CDbl(Dgv.Item(columna, i).Value)
            Next
        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try

        Return total

    End Function

    Private Sub DialogCierreCaja_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim mConsulta = dc.usp_ConsultarPagos(mstrIntIdUsuario, mintIdCaja, 0)
            For Each mR In mConsulta
                mRes.Add(mR)
            Next

            If mRes.Count > 0 Then
                BindingSourcePagos.DataSource = mRes
                Me.ClsTextBoxUsuario.DataBindings.Add(New System.Windows.Forms.Binding("Text", BindingSourcePagos, "strNombreUsuario", True))
                Me.ClsTextBoxCaja.DataBindings.Add(New System.Windows.Forms.Binding("Text", BindingSourcePagos, "strNombreCaja"))
                ClsTextBoxBase.Text = FormatCurrency(BindingSourcePagos.Item(BindingSourcePagos.Position).numValorBase, 0)
                Me.ClsTextBoxTotal.Text = FormatCurrency(Sumar(DataGridView, "NumValorPagadoDataGridViewTextBoxColumn"), 0)
            Else
                mConsulta = dc.usp_ConsultarPagos(mstrIntIdUsuario, mintIdCaja, 1)
                For Each mR In mConsulta
                    mList.Add(mR)
                Next

                BindingSourcePagos.DataSource = mList
                ClsTextBoxBase.Text = FormatCurrency(BindingSourcePagos.Item(BindingSourcePagos.Position).numValorBase, 0)
                ClsTextBoxTotal.Text = FormatCurrency(Sumar(DataGridView, "NumValorPagadoDataGridViewTextBoxColumn"), 0)
                ClsTextBoxUsuario.Text = BindingSourcePagos.Item(BindingSourcePagos.Position).strNombreUsuario
                ClsTextBoxCaja.Text = BindingSourcePagos.Item(BindingSourcePagos.Position).strNombreCaja

            End If

            With Me.DataGridView
                .Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
                .Columns(4).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
            End With

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub ClsTextBoxEfectivo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClsTextBoxEfectivo.TextChanged
        Try
            If ClsTextBoxEfectivo.TextLength > 0 Then
                ClsTextBoxDiferencia.Text = FormatCurrency(CType(ClsTextBoxEfectivo.Text, Int32) - (CType(ClsTextBoxBase.Text, Int32) + CType(ClsTextBoxTotal.Text, Int32)), 0)

                If CType(ClsTextBoxDiferencia.Text, Int32) < 0 Then
                    ClsTextBoxDiferencia.ForeColor = Drawing.Color.Red
                Else
                    If CType(ClsTextBoxDiferencia.Text, Int32) > 0 Then
                        ClsTextBoxDiferencia.ForeColor = Drawing.Color.Green
                    Else
                        ClsTextBoxDiferencia.ForeColor = Drawing.Color.Black
                    End If
                End If
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub
End Class
