﻿Public Class FrmClaseMedicamentos
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim pStringConection As String

    Public Sub New(ByVal mStringConection As String)
        Try
            ' Llamada necesaria para el Diseñador de Windows Forms.
            InitializeComponent()

            ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mStringConection)
            pStringConection = mStringConection
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmClaseMedicamentos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TblMedicamentosBindingSource.DataSource = dc.tblMedicamentos
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblMedicamentosBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblMedicamentosBindingNavigatorSaveItem.Click
        Try
            TblMedicamentosBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblMedicamentosGenericosDataGridView_CellClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles TblMedicamentosGenericosDataGridView.CellClick
        If e.ColumnIndex = 2 Then
            Dim mFrmGenericos As New FrmGenericos(dc, TblMedicamentosGenericosDataGridView.Rows(e.RowIndex).Cells(0).Value)
            mFrmGenericos.Show()
        End If
    End Sub
End Class