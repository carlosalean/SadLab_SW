﻿Imports System.Data.Linq
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class FrmPacientes
    Public mstrStringConection As String
    Dim mDataContext As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mTemplate(3)
    Dim strIntIdUsuario As String
    Dim strPaciente As String
    Dim mstrIntIdSede As Integer
    Dim mNuevo As Boolean = True
    Dim mPermisosHC As ClsUtilidades.ClsPermisos.ClsHistoriasClinicas

    Sub New(ByVal strStringConection As String, ByVal pstrIntIdUsuario As Integer, ByVal pstrIntIdSede As Integer, ByVal pstrPaciente As String, ByVal pPermisosHC As ClsUtilidades.ClsPermisos.ClsHistoriasClinicas)
        Try

            ' This call is required by the Windows Form Designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.
            mstrStringConection = strStringConection
            strIntIdUsuario = pstrIntIdUsuario
            strPaciente = pstrPaciente
            mstrIntIdSede = pstrIntIdSede
            If Not pPermisosHC Is Nothing Then
                btnHistoriaClinica.Enabled = pPermisosHC.Ver Or pPermisosHC.Crear Or pPermisosHC.Modificar
            End If

            mPermisosHC = pPermisosHC
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmPacientes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            mDataContext = dc
            'TblPacienteBindingSource.DataSource = dc.tblPacientes
            TblDepartamentoBindingSource.DataSource = dc.tblDepartamentos
            Dim TipoDoc = (From p In dc.tblTipos _
                            Where p.strTipo = "TIPO_DOCUMENTO")
            TblTipoDocumentoBindingSource.DataSource = TipoDoc
            Dim Sexo = (From p In dc.tblTipos _
                            Where p.strTipo = "SEXO")
            TblSexoBindingSource.DataSource = Sexo

            Dim TipoUsu = (From p In dc.tblTipos _
                            Where p.strTipo = "TIPO_USUARIO")
            TblTipoUsuarioBindingSource.DataSource = TipoUsu

            Dim Estado = (From p In dc.tblTipos _
                            Where p.strTipo = "ESTADO_CIVIL")

            TblEstadoCivilBindingSource.DataSource = Estado
            Dim Zona = (From p In dc.tblTipos _
                            Where p.strTipo = "ZONA_RESIDENCIAL")
            TblZonaResidencialBindingSource.DataSource = Zona

            Dim Parentezco = (From p In dc.tblTipos _
                            Where p.strTipo = "PARENTEZCO")

            TblParentezcoBindingSource.DataSource = Parentezco

            Dim MedidaEdad = (From p In dc.tblTipos _
                            Where p.strTipo = "MEDIDA_EDAD")

            TblTipoMedidaEdadBindingSource.DataSource = MedidaEdad

            TblEPBindingSource.DataSource = dc.tblEPs

            TblDescuentoBindingSource.DataSource = dc.tblDescuentos

            SeleccionToolStripComboBox.SelectedIndex = 0
            If strPaciente.Trim.Length > 0 Then
                'TblPacienteBindingSource.DataSource = dc.tblPacientes
                TblPacienteBindingSource.AddNew()
                StrNroIdentificacionTextBox.Text = strPaciente
                StrNroIdentificacionTextBox.Focus()
                TieneHuellaCheckBox.Visible = False
                mNuevo = True
            End If
            TblProtocolosBindingSource.DataSource = dc.tblProtocolos
            mTemplate(0) = Nothing
            mTemplate(1) = Nothing
            mTemplate(2) = Nothing
            mTemplate(3) = Nothing

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblPacienteBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblPacienteBindingNavigatorSaveItem.Click
        Try
            Dim bytes As Byte() = Nothing
            Dim mTemplatetmp As DPFP.Template
            If TblPacienteBindingSource.Position > -1 Then
                If TypeOf mTemplate(0) Is DPFP.Template Then
                    mTemplatetmp = mTemplate(0)
                    mTemplatetmp.Serialize(bytes)
                    If Not bytes Is Nothing Then
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate1 = bytes
                    Else
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate1 = Nothing
                    End If
                Else
                    If Not mTemplate(0) Is Nothing Then
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate1 = mTemplate(0)
                    Else
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate1 = Nothing
                    End If
                End If
                If TypeOf mTemplate(1) Is DPFP.Template Then
                    mTemplatetmp = mTemplate(1)
                    mTemplatetmp.Serialize(bytes)
                    If Not bytes Is Nothing Then
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate2 = bytes
                    Else
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate2 = Nothing
                    End If
                Else
                    If Not mTemplate(1) Is Nothing Then
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate2 = mTemplate(1)
                    Else
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate2 = Nothing
                    End If
                End If
                If TypeOf mTemplate(2) Is DPFP.Template Then
                    mTemplatetmp = mTemplate(2)
                    mTemplatetmp.Serialize(bytes)
                    If Not bytes Is Nothing Then
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate3 = bytes
                    Else
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate3 = Nothing
                    End If
                Else
                    If Not mTemplate(2) Is Nothing Then
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate3 = mTemplate(2)
                    Else
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate3 = Nothing
                    End If
                End If
                If TypeOf mTemplate(3) Is DPFP.Template Then
                    mTemplatetmp = mTemplate(3)
                    mTemplatetmp.Serialize(bytes)
                    If Not bytes Is Nothing Then
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate4 = bytes
                    Else
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate4 = Nothing
                    End If
                Else
                    If Not mTemplate(3) Is Nothing Then
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate4 = mTemplate(3)
                    Else
                        TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate4 = Nothing
                    End If
                End If

                Dim mAccion As String = "Modificado"
                TblPacienteBindingSource.EndEdit()
                If mNuevo Then
                    mDataContext.tblPacientes.InsertOnSubmit(TblPacienteBindingSource.Item(TblPacienteBindingSource.Position))
                    mAccion = "Ingresado"
                End If
                mDataContext.SubmitChanges()
                mNuevo = False
                'mDataContext.SubmitChanges()
                MsgBox("El paciente fué " & mAccion & " con exito..")
            Else
                MsgBox("Debe seleccionar el botón adicionar nuevo...")
            End If

        Catch ex As DuplicateKeyException
            ClsError.ClsError.PrMostrarError(New System.Exception("No se permite grabar varias veces el mismo protocolo"))
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(New System.Exception("No se pudo gruardar el paciente debido al siguiente error: " & ex.Message))
        End Try
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        ' TabControl1.SelectTab(1)
        mTemplate(0) = Nothing
        mTemplate(1) = Nothing
        mTemplate(2) = Nothing
        mTemplate(3) = Nothing

        Dim tmpPac = (From P In mDataContext.tblPacientes _
                        Where P.strNroIdentificacion Is Nothing _
                        Select P)

        TblPacienteBindingSource.DataSource = tmpPac
        TieneHuellaCheckBox.Visible = False
        mNuevo = True
    End Sub


    Private Sub ButtonHuella_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonHuella.Click
        Try
            Try
                Dim mDetectar As New DlgRegistroHuella()
                If mDetectar.ShowDialog() = Windows.Forms.DialogResult.OK Then
                    Dim bytes As Byte() = Nothing
                    If Not mDetectar.Templates(0) Is Nothing Then
                        mDetectar.Templates(0).Serialize(bytes)
                        mTemplate(0) = bytes
                    End If
                    bytes = Nothing
                    If Not mDetectar.Templates(1) Is Nothing Then
                        mDetectar.Templates(1).Serialize(bytes)
                        mTemplate(1) = bytes
                    End If
                    bytes = Nothing
                    If Not mDetectar.Templates(2) Is Nothing Then
                        mDetectar.Templates(2).Serialize(bytes)
                        mTemplate(2) = bytes
                    End If
                    bytes = Nothing
                    If Not mDetectar.Templates(3) Is Nothing Then
                        mDetectar.Templates(3).Serialize(bytes)
                        mTemplate(3) = bytes
                    End If
                End If
            Catch ex As Exception
                ClsError.ClsError.PrMostrarError(ex)
            End Try
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub StrNroIdentificacionTextBox_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles StrNroIdentificacionTextBox.KeyPress
        Try
            If e.KeyChar = Chr(13) Then
                PrBuscarNuevo()
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub PrBuscarNuevo()
        Try
            mTemplate(0) = Nothing
            mTemplate(1) = Nothing
            mTemplate(2) = Nothing
            mTemplate(3) = Nothing

            Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            Dim tmpPac = (From P In dc.tblPacientes _
                                    Where P.strNroIdentificacion = StrNroIdentificacionTextBox.Text _
                                    Select P)
            If tmpPac.Count = 1 Then
                MsgBox("El paciente ya existe..")
                TblPacienteBindingSource.DataSource = tmpPac
                TblPacienteBindingSource.Position = 0
                mDataContext = dc

                'btnHistoriaClinica.Enabled = True

                TieneHuellaCheckBox.Visible = False
                TieneHuellaCheckBox.Checked = False

                'Huellas
                Dim mTemplatetmp
                Dim bytes As Byte() = Nothing

                mTemplatetmp = (From p In dc.tblPacientes Where p.strNroIdentificacion = StrNroIdentificacionTextBox.Text Select p.byTemplate1).Single
                If Not mTemplatetmp Is Nothing Then
                    bytes = mTemplatetmp.ToArray()
                    mTemplate(0) = New DPFP.Template()
                    mTemplate(0).DeSerialize(bytes)

                    TieneHuellaCheckBox.Visible = True
                    TieneHuellaCheckBox.Checked = True
                End If

                mTemplatetmp = (From p In dc.tblPacientes Where p.strNroIdentificacion = StrNroIdentificacionTextBox.Text Select p.byTemplate2).Single
                If Not mTemplatetmp Is Nothing Then
                    bytes = mTemplatetmp.ToArray()
                    mTemplate(1) = New DPFP.Template()
                    mTemplate(1).DeSerialize(bytes)

                    TieneHuellaCheckBox.Visible = True
                    TieneHuellaCheckBox.Checked = True

                End If

                mTemplatetmp = (From p In dc.tblPacientes Where p.strNroIdentificacion = StrNroIdentificacionTextBox.Text Select p.byTemplate3).Single
                If Not mTemplatetmp Is Nothing Then
                    bytes = mTemplatetmp.ToArray()
                    mTemplate(2) = New DPFP.Template()
                    mTemplate(2).DeSerialize(bytes)

                    TieneHuellaCheckBox.Visible = True
                    TieneHuellaCheckBox.Checked = True

                End If

                mTemplatetmp = (From p In dc.tblPacientes Where p.strNroIdentificacion = StrNroIdentificacionTextBox.Text Select p.byTemplate4).Single
                If Not mTemplatetmp Is Nothing Then
                    bytes = mTemplatetmp.ToArray()
                    mTemplate(3) = New DPFP.Template()
                    mTemplate(3).DeSerialize(bytes)

                    TieneHuellaCheckBox.Visible = True
                    TieneHuellaCheckBox.Checked = True

                End If
                mNuevo = False
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BusquedaToolStripTextBox_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles BusquedaToolStripTextBox.KeyUp
        Try
            If e.KeyCode = Windows.Forms.Keys.Enter Then

                Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
                mDataContext = dc
                Dim tmpPac

                If SeleccionToolStripComboBox.SelectedIndex = 0 Then
                    tmpPac = (From P In dc.tblPacientes _
                                            Where P.strNroIdentificacion = BusquedaToolStripTextBox.Text _
                                            Select P)
                End If
                If SeleccionToolStripComboBox.SelectedIndex = 1 Then
                    tmpPac = (From P In dc.tblPacientes _
                                            Where (P.strPrimerNombre & " " & P.strSegundoNombre & " " & P.strPrimerApellido & " " & P.strSegundoApellido).Contains(BusquedaToolStripTextBox.Text) _
                              Select P)
                    'Where P.strPrimerNombre.Contains(BusquedaToolStripTextBox.Text) Or _
                    'P.strSegundoNombre.Contains(BusquedaToolStripTextBox.Text) Or _
                    ' P.strPrimerApellido.Contains(BusquedaToolStripTextBox.Text) Or _                    'P.strSegundoApellido.Contains(BusquedaToolStripTextBox.Text) Or _

                End If

                If SeleccionToolStripComboBox.SelectedIndex = 2 Then
                    tmpPac = (From P In dc.tblPacientes Join Ep In dc.tblEPs On Ep.intIdEPS Equals _
                                            P.intIdEps _
                                            Where Ep.strNombre.Contains(BusquedaToolStripTextBox.Text) _
                                            Select P)
                End If

                If Not tmpPac Is Nothing Then
                    TblPacienteBindingSource.DataSource = tmpPac
                    TblPacienteBindingSource.Position = 0
                    'TabControl1.SelectTab(1)
                    mNuevo = False
                Else
                    MsgBox("No existen coincidencias..")
                End If
            End If
            TieneHuellaCheckBox.Visible = False

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub SeleccionToolStripComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SeleccionToolStripComboBox.SelectedIndexChanged
        Try
            If SeleccionToolStripComboBox.SelectedIndex = 3 Then
                TblPacienteBindingSource.DataSource = mDataContext.tblPacientes
                TieneHuellaCheckBox.Visible = False
                mNuevo = False
            End If
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub IntEdadClsTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntEdadClsTextBox.TextChanged

    End Sub

    Private Sub AsignarCitaButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AsignarCitaButton.Click
        Try
            If Windows.Forms.Application.OpenForms("FrmCita") Is Nothing Then
                Dim mFrmCitas As New FrmCita(mstrStringConection, strIntIdUsuario, mstrIntIdSede, StrNroIdentificacionTextBox.Text)
                mFrmCitas.Show()
            Else
                Windows.Forms.Application.OpenForms("FrmCita").BringToFront()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TblPacienteDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblPacienteDataGridView.DataError
        Try
            'No hace nada
        Catch ex As Exception
            'No hace nada
        End Try
    End Sub

    Private Sub TblPacienteBindingSource_PositionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblPacienteBindingSource.PositionChanged
        Try
            If Not TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate1 Is Nothing Or _
               Not TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate2 Is Nothing Or _
               Not TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate3 Is Nothing Or _
               Not TblPacienteBindingSource.Item(TblPacienteBindingSource.Position).byTemplate Is Nothing Then
                TieneHuellaCheckBox.Checked = True
            Else
                TieneHuellaCheckBox.Checked = False
            End If

        Catch ex As Exception
            'No hace nada
        End Try
    End Sub

    Private Sub TblPacientesProtocolosDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblPacientesProtocolosDataGridView.DataError
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnHistoriaClinica_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHistoriaClinica.Click
        If StrNroIdentificacionTextBox.Text <> Nothing Then

            If Application.OpenForms("FrmCasosVisitas") Is Nothing Then
                Dim mFrmCasosVisitas As New ClsIDU.FrmCasosVisitas(mstrStringConection, StrNroIdentificacionTextBox.Text, StrPrimerNombreTextBox.Text & Space(1) & StrSegundoNombreTextBox.Text & Space(1) & StrPrimerApellidoTextBox.Text & Space(1) & StrSegundoApellidoTextBox.Text, mPermisosHC, strIntIdUsuario)
                mFrmCasosVisitas.MdiParent = Me.MdiParent
                mFrmCasosVisitas.Show()
            Else
                Application.OpenForms("FrmCasosVisitas").BringToFront()
            End If
        Else
            MsgBox("Debe seleccionar un paciente", MsgBoxStyle.Information, "")
        End If
    End Sub


    Private Sub BindingNavigatorDeleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorDeleteItem.Click
        Try
            mDataContext.tblPacientes.DeleteOnSubmit(TblPacienteBindingSource.Item(TblPacienteBindingSource.Position))
            mDataContext.SubmitChanges()
            MsgBox("El registro del paciente fué eliminado con exito..")
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(New System.Exception("No se pudo eliminar el paciente debido al siguiente error: " & ex.Message))
        End Try
    End Sub

    Private Sub StrNroIdentificacionTextBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrNroIdentificacionTextBox.Leave
        'PrBuscarNuevo()
    End Sub

    Private Sub StrNroIdentificacionTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StrNroIdentificacionTextBox.TextChanged

    End Sub

    Private Sub TblTipoDocumentoBindingSource_CurrentChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblTipoDocumentoBindingSource.CurrentChanged

    End Sub
End Class