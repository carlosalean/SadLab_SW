﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCasosVisitas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCasosVisitas))
        Me.TblCitasBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.TblCitasBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblCitasBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripComboBoxEstadoCita = New System.Windows.Forms.ToolStripComboBox()
        Me.TblCitasDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.intIdEstadoCita = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.intIdProcedimiento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.intIdProfesional = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.intIdSede = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ContextMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CrearOModificarHistoriaClinicaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtCedula = New ClsUtilidades.ClsTextBox()
        Me.txtNombre = New ClsUtilidades.ClsTextBox()
        Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.TblMotivosConsultaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblCitasMotivosConsultaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnHistoriaClinica = New System.Windows.Forms.Button()
        CType(Me.TblCitasBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCitasBindingNavigator.SuspendLayout()
        CType(Me.TblCitasBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCitasDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip.SuspendLayout()
        CType(Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCitasMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TblCitasBindingNavigator
        '
        Me.TblCitasBindingNavigator.AddNewItem = Nothing
        Me.TblCitasBindingNavigator.BindingSource = Me.TblCitasBindingSource
        Me.TblCitasBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblCitasBindingNavigator.DeleteItem = Nothing
        Me.TblCitasBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.TblCitasBindingNavigatorSaveItem, Me.ToolStripSeparator1, Me.ToolStripLabel1, Me.ToolStripComboBoxEstadoCita})
        Me.TblCitasBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCitasBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblCitasBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblCitasBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblCitasBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblCitasBindingNavigator.Name = "TblCitasBindingNavigator"
        Me.TblCitasBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblCitasBindingNavigator.Size = New System.Drawing.Size(618, 25)
        Me.TblCitasBindingNavigator.TabIndex = 0
        Me.TblCitasBindingNavigator.Text = "BindingNavigator1"
        '
        'TblCitasBindingSource
        '
        Me.TblCitasBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCita)
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblCitasBindingNavigatorSaveItem
        '
        Me.TblCitasBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblCitasBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblCitasBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblCitasBindingNavigatorSaveItem.Name = "TblCitasBindingNavigatorSaveItem"
        Me.TblCitasBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblCitasBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(67, 22)
        Me.ToolStripLabel1.Text = "Estado cita:"
        '
        'ToolStripComboBoxEstadoCita
        '
        Me.ToolStripComboBoxEstadoCita.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ToolStripComboBoxEstadoCita.Items.AddRange(New Object() {"Pendientes", "Cumplidas", "Canceladas"})
        Me.ToolStripComboBoxEstadoCita.Name = "ToolStripComboBoxEstadoCita"
        Me.ToolStripComboBoxEstadoCita.Size = New System.Drawing.Size(121, 25)
        '
        'TblCitasDataGridView
        '
        Me.TblCitasDataGridView.AllowUserToAddRows = False
        Me.TblCitasDataGridView.AllowUserToDeleteRows = False
        Me.TblCitasDataGridView.AutoGenerateColumns = False
        Me.TblCitasDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblCitasDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.intIdEstadoCita, Me.intIdProcedimiento, Me.intIdProfesional, Me.intIdSede, Me.Column1})
        Me.TblCitasDataGridView.ContextMenuStrip = Me.ContextMenuStrip
        Me.TblCitasDataGridView.DataSource = Me.TblCitasBindingSource
        Me.TblCitasDataGridView.Location = New System.Drawing.Point(12, 71)
        Me.TblCitasDataGridView.Name = "TblCitasDataGridView"
        Me.TblCitasDataGridView.ReadOnly = True
        Me.TblCitasDataGridView.Size = New System.Drawing.Size(594, 171)
        Me.TblCitasDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "dtmFecha"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Fecha"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 80
        '
        'intIdEstadoCita
        '
        Me.intIdEstadoCita.DataPropertyName = "intIdEstadoCita"
        Me.intIdEstadoCita.HeaderText = "Estado Cita"
        Me.intIdEstadoCita.Name = "intIdEstadoCita"
        Me.intIdEstadoCita.ReadOnly = True
        Me.intIdEstadoCita.Width = 85
        '
        'intIdProcedimiento
        '
        Me.intIdProcedimiento.DataPropertyName = "strProcedimiento"
        Me.intIdProcedimiento.HeaderText = "Procedimiento"
        Me.intIdProcedimiento.Name = "intIdProcedimiento"
        Me.intIdProcedimiento.ReadOnly = True
        Me.intIdProcedimiento.Width = 200
        '
        'intIdProfesional
        '
        Me.intIdProfesional.DataPropertyName = "strProfesional"
        Me.intIdProfesional.HeaderText = "Profesional"
        Me.intIdProfesional.Name = "intIdProfesional"
        Me.intIdProfesional.ReadOnly = True
        Me.intIdProfesional.Width = 200
        '
        'intIdSede
        '
        Me.intIdSede.DataPropertyName = "strNombreSede"
        Me.intIdSede.HeaderText = "intIdSede"
        Me.intIdSede.Name = "intIdSede"
        Me.intIdSede.ReadOnly = True
        '
        'Column1
        '
        Me.Column1.DataPropertyName = "intIdCita"
        Me.Column1.HeaderText = "id"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Visible = False
        '
        'ContextMenuStrip
        '
        Me.ContextMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CrearOModificarHistoriaClinicaToolStripMenuItem})
        Me.ContextMenuStrip.Name = "ContextMenuStrip"
        Me.ContextMenuStrip.Size = New System.Drawing.Size(242, 26)
        '
        'CrearOModificarHistoriaClinicaToolStripMenuItem
        '
        Me.CrearOModificarHistoriaClinicaToolStripMenuItem.Name = "CrearOModificarHistoriaClinicaToolStripMenuItem"
        Me.CrearOModificarHistoriaClinicaToolStripMenuItem.Size = New System.Drawing.Size(241, 22)
        Me.CrearOModificarHistoriaClinicaToolStripMenuItem.Text = "Crear o Verificar Historia Clínica"
        '
        'txtCedula
        '
        Me.txtCedula.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.txtCedula.DataSource = Nothing
        Me.txtCedula.Enabled = False
        Me.txtCedula.EnterEntreCampos = True
        Me.txtCedula.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCedula.Location = New System.Drawing.Point(12, 45)
        Me.txtCedula.Name = "txtCedula"
        Me.txtCedula.NombreCodigoF2 = Nothing
        Me.txtCedula.NombreDescripcionF2 = Nothing
        Me.txtCedula.Size = New System.Drawing.Size(106, 20)
        Me.txtCedula.TabIndex = 3
        Me.txtCedula.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtCedula.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'txtNombre
        '
        Me.txtNombre.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.txtNombre.DataSource = Nothing
        Me.txtNombre.Enabled = False
        Me.txtNombre.EnterEntreCampos = True
        Me.txtNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNombre.Location = New System.Drawing.Point(124, 45)
        Me.txtNombre.Name = "txtNombre"
        Me.txtNombre.NombreCodigoF2 = Nothing
        Me.txtNombre.NombreDescripcionF2 = Nothing
        Me.txtNombre.Size = New System.Drawing.Size(361, 20)
        Me.txtNombre.TabIndex = 4
        Me.txtNombre.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblCitasMotivosConsultaDataGridViewMotivosConsulta
        '
        Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta.AutoGenerateColumns = False
        Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn6})
        Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta.DataSource = Me.TblCitasMotivosConsultaBindingSource
        Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta.Location = New System.Drawing.Point(12, 248)
        Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta.Name = "TblCitasMotivosConsultaDataGridViewMotivosConsulta"
        Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta.Size = New System.Drawing.Size(594, 162)
        Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta.TabIndex = 5
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "intIdMotivoConsulta"
        Me.DataGridViewTextBoxColumn6.DataSource = Me.TblMotivosConsultaBindingSource
        Me.DataGridViewTextBoxColumn6.DisplayMember = "strDescripcion"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Motivo Consulta"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn6.ValueMember = "intIdMotivoConsulta"
        Me.DataGridViewTextBoxColumn6.Width = 520
        '
        'TblMotivosConsultaBindingSource
        '
        Me.TblMotivosConsultaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblMotivosConsulta)
        '
        'TblCitasMotivosConsultaBindingSource
        '
        Me.TblCitasMotivosConsultaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCitasMotivosConsulta)
        '
        'btnHistoriaClinica
        '
        Me.btnHistoriaClinica.Location = New System.Drawing.Point(491, 42)
        Me.btnHistoriaClinica.Name = "btnHistoriaClinica"
        Me.btnHistoriaClinica.Size = New System.Drawing.Size(115, 23)
        Me.btnHistoriaClinica.TabIndex = 6
        Me.btnHistoriaClinica.Text = "Ver Historia Clínica"
        Me.btnHistoriaClinica.UseVisualStyleBackColor = True
        '
        'FrmCasosVisitas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(618, 424)
        Me.Controls.Add(Me.btnHistoriaClinica)
        Me.Controls.Add(Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta)
        Me.Controls.Add(Me.txtNombre)
        Me.Controls.Add(Me.txtCedula)
        Me.Controls.Add(Me.TblCitasDataGridView)
        Me.Controls.Add(Me.TblCitasBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FrmCasosVisitas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Casos Visitas"
        CType(Me.TblCitasBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCitasBindingNavigator.ResumeLayout(False)
        Me.TblCitasBindingNavigator.PerformLayout()
        CType(Me.TblCitasBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCitasDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip.ResumeLayout(False)
        CType(Me.TblCitasMotivosConsultaDataGridViewMotivosConsulta, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCitasMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblCitasBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCitasBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblCitasBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblCitasDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripComboBoxEstadoCita As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents txtCedula As ClsUtilidades.ClsTextBox
    Friend WithEvents txtNombre As ClsUtilidades.ClsTextBox
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblMotivosConsultaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCitasMotivosConsultaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCitasMotivosConsultaDataGridViewMotivosConsulta As System.Windows.Forms.DataGridView
    Friend WithEvents btnHistoriaClinica As System.Windows.Forms.Button
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents ContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CrearOModificarHistoriaClinicaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIdEstadoCita As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIdProcedimiento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIdProfesional As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIdSede As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
