﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uscMotivosConsulta
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IntIdLabel As System.Windows.Forms.Label
        Dim IntIdMotivoConsultaLabel As System.Windows.Forms.Label
        Dim StrDescripcionMotivoLabel As System.Windows.Forms.Label
        Dim StrDescripcionEnfermedadLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uscMotivosConsulta))
        Me.TblCitasMotivosConsultaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblMotivosConsultaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblCitasMotivosConsultaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.TblEPBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.BtnNuevoMotivo = New System.Windows.Forms.Button
        Me.IntIdClsTextBox = New ClsUtilidades.ClsTextBox
        Me.IntIdMotivoConsultaClsComboBox = New ClsUtilidades.ClsComboBox
        Me.StrDescripcionMotivoClsTextBox = New ClsUtilidades.ClsTextBox
        Me.StrDescripcionEnfermedadClsTextBox = New ClsUtilidades.ClsTextBox
        IntIdLabel = New System.Windows.Forms.Label
        IntIdMotivoConsultaLabel = New System.Windows.Forms.Label
        StrDescripcionMotivoLabel = New System.Windows.Forms.Label
        StrDescripcionEnfermedadLabel = New System.Windows.Forms.Label
        CType(Me.TblCitasMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCitasMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCitasMotivosConsultaBindingNavigator.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntIdLabel
        '
        IntIdLabel.AutoSize = True
        IntIdLabel.Location = New System.Drawing.Point(21, 21)
        IntIdLabel.Name = "IntIdLabel"
        IntIdLabel.Size = New System.Drawing.Size(19, 13)
        IntIdLabel.TabIndex = 95
        IntIdLabel.Text = "Id:"
        '
        'IntIdMotivoConsultaLabel
        '
        IntIdMotivoConsultaLabel.AutoSize = True
        IntIdMotivoConsultaLabel.Location = New System.Drawing.Point(21, 47)
        IntIdMotivoConsultaLabel.Name = "IntIdMotivoConsultaLabel"
        IntIdMotivoConsultaLabel.Size = New System.Drawing.Size(86, 13)
        IntIdMotivoConsultaLabel.TabIndex = 97
        IntIdMotivoConsultaLabel.Text = "Motivo Consulta:"
        '
        'StrDescripcionMotivoLabel
        '
        StrDescripcionMotivoLabel.AutoSize = True
        StrDescripcionMotivoLabel.Location = New System.Drawing.Point(21, 74)
        StrDescripcionMotivoLabel.Name = "StrDescripcionMotivoLabel"
        StrDescripcionMotivoLabel.Size = New System.Drawing.Size(101, 13)
        StrDescripcionMotivoLabel.TabIndex = 99
        StrDescripcionMotivoLabel.Text = "Descripcion Motivo:"
        '
        'StrDescripcionEnfermedadLabel
        '
        StrDescripcionEnfermedadLabel.AutoSize = True
        StrDescripcionEnfermedadLabel.Location = New System.Drawing.Point(21, 256)
        StrDescripcionEnfermedadLabel.Name = "StrDescripcionEnfermedadLabel"
        StrDescripcionEnfermedadLabel.Size = New System.Drawing.Size(126, 13)
        StrDescripcionEnfermedadLabel.TabIndex = 101
        StrDescripcionEnfermedadLabel.Text = "Descripcion Enfermedad:"
        '
        'TblCitasMotivosConsultaBindingSource
        '
        Me.TblCitasMotivosConsultaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCitasMotivosConsulta)
        '
        'TblMotivosConsultaBindingSource
        '
        Me.TblMotivosConsultaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblMotivosConsulta)
        '
        'TblCitasMotivosConsultaBindingNavigator
        '
        Me.TblCitasMotivosConsultaBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblCitasMotivosConsultaBindingNavigator.BindingSource = Me.TblCitasMotivosConsultaBindingSource
        Me.TblCitasMotivosConsultaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblCitasMotivosConsultaBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblCitasMotivosConsultaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblEPBindingNavigatorSaveItem})
        Me.TblCitasMotivosConsultaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCitasMotivosConsultaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblCitasMotivosConsultaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblCitasMotivosConsultaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblCitasMotivosConsultaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblCitasMotivosConsultaBindingNavigator.Name = "TblCitasMotivosConsultaBindingNavigator"
        Me.TblCitasMotivosConsultaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblCitasMotivosConsultaBindingNavigator.Size = New System.Drawing.Size(692, 25)
        Me.TblCitasMotivosConsultaBindingNavigator.TabIndex = 85
        Me.TblCitasMotivosConsultaBindingNavigator.Text = "BindingNavigator"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(36, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblEPBindingNavigatorSaveItem
        '
        Me.TblEPBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblEPBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblEPBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblEPBindingNavigatorSaveItem.Name = "TblEPBindingNavigatorSaveItem"
        Me.TblEPBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblEPBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BtnNuevoMotivo)
        Me.Panel1.Controls.Add(IntIdLabel)
        Me.Panel1.Controls.Add(Me.IntIdClsTextBox)
        Me.Panel1.Controls.Add(IntIdMotivoConsultaLabel)
        Me.Panel1.Controls.Add(Me.IntIdMotivoConsultaClsComboBox)
        Me.Panel1.Controls.Add(StrDescripcionMotivoLabel)
        Me.Panel1.Controls.Add(Me.StrDescripcionMotivoClsTextBox)
        Me.Panel1.Controls.Add(StrDescripcionEnfermedadLabel)
        Me.Panel1.Controls.Add(Me.StrDescripcionEnfermedadClsTextBox)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 25)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(692, 445)
        Me.Panel1.TabIndex = 86
        '
        'BtnNuevoMotivo
        '
        Me.BtnNuevoMotivo.Location = New System.Drawing.Point(549, 42)
        Me.BtnNuevoMotivo.Name = "BtnNuevoMotivo"
        Me.BtnNuevoMotivo.Size = New System.Drawing.Size(88, 23)
        Me.BtnNuevoMotivo.TabIndex = 103
        Me.BtnNuevoMotivo.Text = "Nuevo Motivo"
        Me.BtnNuevoMotivo.UseVisualStyleBackColor = True
        '
        'IntIdClsTextBox
        '
        Me.IntIdClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitasMotivosConsultaBindingSource, "intId", True))
        Me.IntIdClsTextBox.DataSource = Nothing
        Me.IntIdClsTextBox.Enabled = False
        Me.IntIdClsTextBox.EnterEntreCampos = True
        Me.IntIdClsTextBox.Location = New System.Drawing.Point(167, 18)
        Me.IntIdClsTextBox.Name = "IntIdClsTextBox"
        Me.IntIdClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdClsTextBox.Size = New System.Drawing.Size(51, 20)
        Me.IntIdClsTextBox.TabIndex = 96
        Me.IntIdClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdMotivoConsultaClsComboBox
        '
        Me.IntIdMotivoConsultaClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblCitasMotivosConsultaBindingSource, "intIdMotivoConsulta", True))
        Me.IntIdMotivoConsultaClsComboBox.DataSource = Me.TblMotivosConsultaBindingSource
        Me.IntIdMotivoConsultaClsComboBox.DisplayMember = "strDescripcion"
        Me.IntIdMotivoConsultaClsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.IntIdMotivoConsultaClsComboBox.FormattingEnabled = True
        Me.IntIdMotivoConsultaClsComboBox.Location = New System.Drawing.Point(167, 44)
        Me.IntIdMotivoConsultaClsComboBox.Name = "IntIdMotivoConsultaClsComboBox"
        Me.IntIdMotivoConsultaClsComboBox.Size = New System.Drawing.Size(376, 21)
        Me.IntIdMotivoConsultaClsComboBox.TabIndex = 98
        Me.IntIdMotivoConsultaClsComboBox.ValueMember = "intIdMotivoConsulta"
        '
        'StrDescripcionMotivoClsTextBox
        '
        Me.StrDescripcionMotivoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitasMotivosConsultaBindingSource, "strDescripcionMotivo", True))
        Me.StrDescripcionMotivoClsTextBox.DataSource = Nothing
        Me.StrDescripcionMotivoClsTextBox.EnterEntreCampos = False
        Me.StrDescripcionMotivoClsTextBox.Location = New System.Drawing.Point(24, 90)
        Me.StrDescripcionMotivoClsTextBox.Multiline = True
        Me.StrDescripcionMotivoClsTextBox.Name = "StrDescripcionMotivoClsTextBox"
        Me.StrDescripcionMotivoClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcionMotivoClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcionMotivoClsTextBox.Size = New System.Drawing.Size(647, 156)
        Me.StrDescripcionMotivoClsTextBox.TabIndex = 100
        Me.StrDescripcionMotivoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrDescripcionEnfermedadClsTextBox
        '
        Me.StrDescripcionEnfermedadClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCitasMotivosConsultaBindingSource, "strDescripcionEnfermedad", True))
        Me.StrDescripcionEnfermedadClsTextBox.DataSource = Nothing
        Me.StrDescripcionEnfermedadClsTextBox.EnterEntreCampos = False
        Me.StrDescripcionEnfermedadClsTextBox.Location = New System.Drawing.Point(24, 279)
        Me.StrDescripcionEnfermedadClsTextBox.Multiline = True
        Me.StrDescripcionEnfermedadClsTextBox.Name = "StrDescripcionEnfermedadClsTextBox"
        Me.StrDescripcionEnfermedadClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcionEnfermedadClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcionEnfermedadClsTextBox.Size = New System.Drawing.Size(647, 148)
        Me.StrDescripcionEnfermedadClsTextBox.TabIndex = 102
        Me.StrDescripcionEnfermedadClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'uscMotivosConsulta
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TblCitasMotivosConsultaBindingNavigator)
        Me.Name = "uscMotivosConsulta"
        Me.Size = New System.Drawing.Size(692, 470)
        CType(Me.TblCitasMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCitasMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCitasMotivosConsultaBindingNavigator.ResumeLayout(False)
        Me.TblCitasMotivosConsultaBindingNavigator.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblCitasMotivosConsultaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblMotivosConsultaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCitasMotivosConsultaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblEPBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents BtnNuevoMotivo As System.Windows.Forms.Button
    Friend WithEvents IntIdClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdMotivoConsultaClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents StrDescripcionMotivoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrDescripcionEnfermedadClsTextBox As ClsUtilidades.ClsTextBox

End Class
