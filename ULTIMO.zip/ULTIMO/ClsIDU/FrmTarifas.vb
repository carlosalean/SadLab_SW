﻿Imports System.Windows.Forms

Public Class FrmTarifas

  Public mstrStringConection As String
  Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext()

  Sub New(ByVal strStringConection As String)
    Try

      ' This call is required by the Windows Form Designer.
      InitializeComponent()

      ' Add any initialization after the InitializeComponent() call.
      'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
      mstrStringConection = strStringConection
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub FrmTarifas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Try
      dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

      'Caragr columnas al data gridview
      If TblTarifaDataGridView.Columns.Count = 0 Then
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("nIdTarifaIPSPorEPS", "Id", "Id", 100))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("IPS", "IPS", "IPS", 250))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("nIdIPS", "", "nIdIPS", 0, False))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("EPS", "EPS", "EPS", 100))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("nIdEPS", "", "nIdEPS", 0, False))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("Procedimiento", "Procedimiento", "Procedimiento", 250))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("nIdProcedimiento", "", "nIdProcedimiento", 0, False))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("Tipo", "Tipo", "Tipo", 250))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("nTipo", "", "nTipo", 0, False))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("TipoTarifa", "Tipo de tarifa", "TipoTarifa", 100))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("nIdTipoTarifa", "", "nIdTipoTarifa", 0, False))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("TarifaBase", "Tarifa base", "TarifaBase", 100))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("nIdTarifaBase", "", "nIdTarifaBase", 0, False))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("sNombreParaContabilidad", "Nombre contabilidad", "sNombreParaContabilidad", 150))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("sCodigoContabilidad", "Código para contabilidad", "sCodigoContabilidad", 150))
        TblTarifaDataGridView.Columns.Add(AgregarColumnasGrid("nValor", "Valor", "Valor", 150))

        CargarComboBox()
      End If

      'Dim dtDatos As DataTable = dc.sp_ListarTarifasIPSPorEPS()

      TblTarifaDataGridView.DataSource = dc.sp_ListarTarifasIPSPorEPS()

      If dc.TarifasIPSPorEPs.Count = 0 Then
        TblTarifaDataGridView.Visible = False
      Else
        TblTarifaDataGridView.Visible = True

      End If
      TblTarifaDataGridView.RowHeadersVisible = False

      BindingNavigatorAddNewItem.Enabled = True

      'GenerarCodigoContabilidad()

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TblTarifaBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblTarifaBindingNavigatorSaveItem.Click
    Try
      Dim sErrores As String = ValidarCampos()
      If Not String.IsNullOrWhiteSpace(sErrores) Then
        ClsError.ClsError.PrMostrarError(New Exception(sErrores))
      Else
        If dc.sp_TarifasIPSPorEPSAdmin(4, Nothing, Convert.ToInt32(cbIPS.SelectedValue), Convert.ToInt32(cbEPS.SelectedValue), Convert.ToInt32(cbProcedimiento.SelectedValue), _
                                       Nothing, Nothing, Nothing, Nothing, Nothing, Nothing) > 0 Then
          MostrarMensaje("Ya existe un registro asociado a la IPS, ESP y procedimiento seleccionado")
          Exit Sub
        End If

        Dim nOpcionSp As Integer = 1
        Dim nIdTarifaIPSPorEPS? As Integer = Nothing
        Dim sNombreContabilidad As String

        If Not String.IsNullOrWhiteSpace(txtIdTarifaIPSPorEPS.Text) Then
          nOpcionSp = 2
          nIdTarifaIPSPorEPS = Convert.ToInt32(txtIdTarifaIPSPorEPS.Text)
        End If

        sNombreContabilidad = CrearNombreContabilidad()

        TblTarifaDataGridView.EndEdit()
        txtIdTarifaIPSPorEPS.Text = Convert.ToString(dc.sp_TarifasIPSPorEPSAdmin(nOpcionSp, nIdTarifaIPSPorEPS, Convert.ToInt32(cbIPS.SelectedValue), _
                                                                                 Convert.ToInt32(cbEPS.SelectedValue), Convert.ToInt32(cbProcedimiento.SelectedValue), _
                                                                                 Convert.ToInt32(cbTipo.SelectedValue), Convert.ToInt32(cbTIpoTarifa.SelectedValue), _
                                                                                 Convert.ToInt32(cbTarifaBase.SelectedValue), sNombreContabilidad, _
                                                                                 txtCodigoContabilidad.Text, Convert.ToDecimal(txtValor.Text)))

        Select Case nOpcionSp
          Case 1
            MostrarMensaje("El registro se creó correctamente")
          Case 2
            MostrarMensaje("El registro se actualizó correctamente")
        End Select

        LimpiarCampos()
        TabControl1.SelectTab(0)
        FrmTarifas_Load(Nothing, Nothing)
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TblTarifaDataGridView_DataError(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewDataErrorEventArgs) Handles TblTarifaDataGridView.DataError
    Try
      'Error
    Catch ex As Exception
      'Error
    End Try
  End Sub

  Private Function AgregarColumnasGrid(ByVal sCampo As String, ByVal sHeader As String, ByVal sName As String, ByVal nWidth As Integer, Optional ByVal bVisible As Boolean = True) As DataGridViewTextBoxColumn
    Dim dgvCol As New DataGridViewTextBoxColumn

    dgvCol.DataPropertyName = sCampo
    dgvCol.HeaderText = sHeader
    dgvCol.Name = sName
    dgvCol.Width = nWidth
    dgvCol.Visible = bVisible

    Return dgvCol
  End Function

  Dim bEsCarga As Boolean = False

  Private Sub selectedCellsButton_Click( _
    ByVal sender As Object, ByVal e As System.EventArgs) _
    Handles TblTarifaDataGridView.Click

    Dim selectedCellCount As Integer = _
        TblTarifaDataGridView.GetCellCount(DataGridViewElementStates.Selected)

    If selectedCellCount > 0 Then

      bEsCarga = True

      txtIdTarifaIPSPorEPS.Text = Convert.ToString(TblTarifaDataGridView.Item("Id", TblTarifaDataGridView.CurrentRow.Index).Value)
      cbIPS.SelectedIndex = cbIPS.FindString(Convert.ToString(TblTarifaDataGridView.Item("IPS", TblTarifaDataGridView.CurrentRow.Index).Value))
      cbEPS.SelectedIndex = cbEPS.FindString(Convert.ToString(TblTarifaDataGridView.Item("EPS", TblTarifaDataGridView.CurrentRow.Index).Value))
      cbTipo.SelectedIndex = cbTipo.FindString(Convert.ToString(TblTarifaDataGridView.Item("Tipo", TblTarifaDataGridView.CurrentRow.Index).Value))
      cbTIpoTarifa.SelectedIndex = cbTIpoTarifa.FindString(Convert.ToString(TblTarifaDataGridView.Item("TipoTarifa", TblTarifaDataGridView.CurrentRow.Index).Value))
      cbProcedimiento.SelectedIndex = cbProcedimiento.FindString(Convert.ToString(TblTarifaDataGridView.Item("Procedimiento", TblTarifaDataGridView.CurrentRow.Index).Value))
      cbTarifaBase.SelectedIndex = cbTarifaBase.FindString(Convert.ToString(TblTarifaDataGridView.Item("TarifaBase", TblTarifaDataGridView.CurrentRow.Index).Value))
      txtCodigoContabilidad.Text = Convert.ToString(TblTarifaDataGridView.Item("sCodigoContabilidad", TblTarifaDataGridView.CurrentRow.Index).Value)
      If String.IsNullOrWhiteSpace(txtCodigoContabilidad.Text) Then
        txtCodigoContabilidad.Text = dc.sp_BuscarCodigoProcedimiento(Convert.ToInt32(cbProcedimiento.SelectedValue)).ReturnValue.ToString()
      End If

      txtValor.Text = Convert.ToString(TblTarifaDataGridView.Item("Valor", TblTarifaDataGridView.CurrentRow.Index).Value)

      TabControl1.SelectTab(1)

      BindingNavigatorDeleteItem.Enabled = True

      bEsCarga = False
    End If

  End Sub

  Private Sub LimpiarCampos()
    txtIdTarifaIPSPorEPS.Text = String.Empty
    cbIPS.SelectedValue = "0"
    cbEPS.SelectedValue = "0"
    cbTipo.SelectedValue = "0"
    cbTIpoTarifa.SelectedValue = "0"
    cbProcedimiento.SelectedValue = "0"
    cbTarifaBase.SelectedValue = "0"
    txtCodigoContabilidad.Text = String.Empty
    txtValor.Text = String.Empty

  End Sub

  Private Sub BindingNavigatorDeleteItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorDeleteItem.Click
    Try
      Dim nIdTarifaIPSEPS As Integer = Convert.ToInt32(TblTarifaDataGridView.Item("Id", TblTarifaDataGridView.CurrentRow.Index).Value)

      Dim oRetorno As Object = dc.sp_TarifasIPSPorEPSAdmin(3, nIdTarifaIPSEPS, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing)

      If Not String.IsNullOrWhiteSpace(oRetorno) Then
        MostrarMensaje("El registro se eliminó correctamente")
      End If

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    Finally

      LimpiarCampos()
      TabControl1.SelectTab(0)

      FrmTarifas_Load(Nothing, Nothing)

    End Try
  End Sub

  Private Sub MostrarMensaje(ByVal sMensaje As String)
    MessageBox.Show(sMensaje, "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly, False)
  End Sub

  Private Function ValidarCampos() As String
    Dim sErrores As String = String.Empty

    If cbIPS.SelectedValue = "0" Then
      sErrores = "La IPS es requerida"
    End If

    If cbEPS.SelectedValue = "0" Then
      If String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If

      sErrores += "La EPS es requerida"
    End If

    If cbProcedimiento.SelectedValue = "0" Then
      If String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If
      sErrores += "El procedimiento es requerido"
    End If

    If cbTipo.SelectedValue = "0" Then
      If String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If
      sErrores += "El tipo es requerido"
    End If

    If cbTipo.SelectedValue = "0" Then
      If String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If
      sErrores += "El tipo tarifa es requerido"
    End If

    If String.IsNullOrWhiteSpace(txtCodigoContabilidad.Text) Then
      If String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If
      sErrores += "El código contabilidad es requerido"
    End If

    Try

      If String.IsNullOrWhiteSpace(txtValor.Text) Then
        If String.IsNullOrWhiteSpace(sErrores) Then
          sErrores += System.Environment.NewLine
        End If
        sErrores += "El valor es requerido"
      Else
        Dim nValor As Integer = Convert.ToInt32(txtValor.Text)

        If Convert.ToInt32(txtValor.Text) <= 0 Then
          If String.IsNullOrWhiteSpace(sErrores) Then
            sErrores += System.Environment.NewLine
          End If
          sErrores += "El valor debe ser mayor a cero(0)"
        End If
      End If
    Catch ex As Exception
      If String.IsNullOrWhiteSpace(sErrores) Then
        sErrores += System.Environment.NewLine
      End If
      sErrores += "El valor debe ser numérico"
    End Try

    Return sErrores
  End Function

  'TODO: DESCOMENTAR SI ES NECESARIO, ALEJANDRO TORRES MONSALVE

  'Private Sub ToolStripButtonImportar_Click(sender As Object, e As EventArgs) Handles ToolStripButtonImportar.Click
  '  Try
  '    Dim mClsImportar As New ClsReportes.ClsImportarArchivo()
  '    Dim mDatos As New DataTable()
  '    If OpenFileDialogImportar.ShowDialog() = Windows.Forms.DialogResult.OK Then

  '      mDatos = mClsImportar.FnImportarArchivo(OpenFileDialogImportar.FileName)
  '      For Each mTabla In mDatos.Rows
  '        Dim mRegistroTarifa As New ClsBaseDatos_SadLab.tblTarifas
  '        Dim mValores = mTabla(0).Split(";"c)
  '        Dim mstrProc As String = mValores(2)
  '        Dim mProcedimiento = (From c In mDataContext.tblProcedimiento _
  '                             Where (c.strCodigoProcedimiento = mstrProc) _
  '                             Select c.intIdProcedimientos).Take(1)

  '        mRegistroTarifa.intIdEPS = mValores(0)
  '        mRegistroTarifa.intIdProcedimiento = mProcedimiento.Single
  '        mRegistroTarifa.strCodigoProcedimiento = mValores(3)
  '        mRegistroTarifa.intIdTarifaBase = mValores(4)
  '        mRegistroTarifa.intTipo = mValores(5)
  '        mRegistroTarifa.intIDTipoTarifa = mValores(6)
  '        mRegistroTarifa.numValor = mValores(7)

  '        TblTarifaBindingSource.Add(mRegistroTarifa)
  '      Next
  '      TblTarifaBindingSource.EndEdit()
  '      mDataContext.SubmitChanges()
  '    End If
  '  Catch ex As Exception

  '  End Try
  'End Sub

  Private Function CrearNombreContabilidad() As String
    Dim sRetorno As String = String.Empty

    Dim sIPS() As String = cbIPS.Text.Split(" ")
    Dim _sIPS As String
    If sIPS.Length = 1 Then
      _sIPS = sIPS(0)
    Else
      For i = 0 To sIPS.Length - 1
        _sIPS = _sIPS + sIPS(i)
      Next
    End If

    Dim sEPS() As String = cbEPS.Text.Split(" ")
    Dim _sEPS As String
    If sEPS.Length = 1 Then
      _sEPS = sEPS(0)
    Else
      For i = 0 To sEPS.Length - 1
        _sEPS = _sEPS + sEPS(i)
      Next
    End If

    Dim sProcedimiento() As String = cbProcedimiento.Text.Split(" ")
    Dim _sProcedimiento As String
    If sProcedimiento.Length = 1 Then
      _sProcedimiento = sProcedimiento(0)
    Else
      For i = 0 To sProcedimiento.Length - 1
        _sProcedimiento = _sProcedimiento + sProcedimiento(i)
      Next
    End If

    sRetorno = String.Format("{0}{1}{2}", _sIPS, _sEPS, _sProcedimiento)

    Return sRetorno
  End Function

  Private Sub CargarComboBox()
    Try
      cbIPS.DisplayMember = "sNombre"
      cbIPS.ValueMember = "nIdIPS"
      cbIPS.DataSource = dc.SP_ConsultarIPS(Nothing)

      cbEPS.DisplayMember = "strNombre"
      cbEPS.ValueMember = "intIdEPS"
      cbEPS.DataSource = dc.tblEPs

      cbProcedimiento.DisplayMember = "strNombre"
      cbProcedimiento.ValueMember = "intIdProcedimientos"
      cbProcedimiento.DataSource = dc.tblProcedimiento

      cbTipo.DisplayMember = "strValor"
      cbTipo.ValueMember = "intIdTipo"
      cbTipo.DataSource = (From p In dc.tblTipos _
          Where p.strTipo = "TIPO_TARIFA")

      cbTIpoTarifa.DisplayMember = "strNombreTipoTarifa"
      cbTIpoTarifa.ValueMember = "intIdTipoTarifa"
      cbTIpoTarifa.DataSource = dc.tblTipoTarifa

      cbTarifaBase.DisplayMember = "NombreTarifa"
      cbTarifaBase.ValueMember = "intIdTarifaBase"
      cbTarifaBase.DataSource = dc.tblTarifaBase
      'Se cargan por defecto en el item 0
      cbIPS.SelectedValue = "0"
      cbEPS.SelectedValue = "0"
      cbTipo.SelectedValue = "0"
      cbTIpoTarifa.SelectedValue = "0"
      cbProcedimiento.SelectedValue = "0"
      cbTarifaBase.SelectedValue = "0"
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
    LimpiarCampos()
    TabControl1.SelectTab(1)
  End Sub

  Private Sub cbProcedimiento_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbProcedimiento.SelectedIndexChanged
    Try
      If Not bEsCarga Then
        If Not cbProcedimiento.SelectedValue Is Nothing And Not cbProcedimiento.SelectedValue = "0" Then
          txtCodigoContabilidad.Text = dc.sp_BuscarCodigoProcedimiento(Convert.ToInt32(cbProcedimiento.SelectedValue)).ReturnValue.ToString()
        Else 'If txtCodigoContabilidad.Text.Length <= 1 Then
          txtCodigoContabilidad.Text = String.Empty
        End If
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub txtCodigoContabilidad_TextChanged(sender As Object, e As EventArgs) Handles txtCodigoContabilidad.TextChanged
    If Not bEsCarga Then
      If txtCodigoContabilidad.Text.Length >= 6 Then
        cbProcedimiento.SelectedValue = dc.sp_BuscarProcedimientoPorCodigo(txtCodigoContabilidad.Text)
      ElseIf txtCodigoContabilidad.Text.Length = 0 Then
        cbProcedimiento.SelectedValue = "0"
      End If
    End If
  End Sub
End Class