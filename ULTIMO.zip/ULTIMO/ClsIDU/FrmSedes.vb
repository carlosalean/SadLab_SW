﻿Public Class FrmSedes
    Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

    Sub New(ByVal strStringConection As String)

        ' Llamada necesaria para el Diseñador de Windows Forms.
        InitializeComponent()

        ' Agregue cualquier inicialización después de la llamada a InitializeComponent().
        dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
    End Sub

    Private Sub FrmSedes_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            TblSedesBindingSource.DataSource = dc.tblSedes
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    Private Sub TblSedesBindingNavigator_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TblSedesBindingNavigator.Click
        TabControl1.SelectTab(1)
    End Sub

    Private Sub TblSedesBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblSedesBindingNavigatorSaveItem.Click

        Try
            TblSedesBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try

    End Sub

    
End Class