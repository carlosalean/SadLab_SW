﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uscEvolucionVisita
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim StrdescripcionLabel As System.Windows.Forms.Label
        Dim IntNivelEvolucionLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uscEvolucionVisita))
        Me.TblEvolucionHCBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.TblEvolucionHCBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblEvolucionHCBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.StrdescripcionTextBox = New System.Windows.Forms.TextBox()
        Me.IntNivelEvolucionComboBox = New System.Windows.Forms.ComboBox()
        Me.ToolStripButtonImprimir = New System.Windows.Forms.ToolStripButton()
        StrdescripcionLabel = New System.Windows.Forms.Label()
        IntNivelEvolucionLabel = New System.Windows.Forms.Label()
        CType(Me.TblEvolucionHCBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblEvolucionHCBindingNavigator.SuspendLayout()
        CType(Me.TblEvolucionHCBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StrdescripcionLabel
        '
        StrdescripcionLabel.AutoSize = True
        StrdescripcionLabel.Location = New System.Drawing.Point(6, 33)
        StrdescripcionLabel.Name = "StrdescripcionLabel"
        StrdescripcionLabel.Size = New System.Drawing.Size(121, 13)
        StrdescripcionLabel.TabIndex = 5
        StrdescripcionLabel.Text = "Evoluciones de la visita:"
        '
        'IntNivelEvolucionLabel
        '
        IntNivelEvolucionLabel.AutoSize = True
        IntNivelEvolucionLabel.Location = New System.Drawing.Point(546, 37)
        IntNivelEvolucionLabel.Name = "IntNivelEvolucionLabel"
        IntNivelEvolucionLabel.Size = New System.Drawing.Size(99, 13)
        IntNivelEvolucionLabel.TabIndex = 6
        IntNivelEvolucionLabel.Text = "Nivel de Evolución:"
        '
        'TblEvolucionHCBindingNavigator
        '
        Me.TblEvolucionHCBindingNavigator.AddNewItem = Nothing
        Me.TblEvolucionHCBindingNavigator.BindingSource = Me.TblEvolucionHCBindingSource
        Me.TblEvolucionHCBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblEvolucionHCBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblEvolucionHCBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorDeleteItem, Me.TblEvolucionHCBindingNavigatorSaveItem, Me.ToolStripButtonImprimir})
        Me.TblEvolucionHCBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblEvolucionHCBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblEvolucionHCBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblEvolucionHCBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblEvolucionHCBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblEvolucionHCBindingNavigator.Name = "TblEvolucionHCBindingNavigator"
        Me.TblEvolucionHCBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblEvolucionHCBindingNavigator.Size = New System.Drawing.Size(726, 25)
        Me.TblEvolucionHCBindingNavigator.TabIndex = 0
        Me.TblEvolucionHCBindingNavigator.Text = "BindingNavigator1"
        '
        'TblEvolucionHCBindingSource
        '
        Me.TblEvolucionHCBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEvolucionHC)
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblEvolucionHCBindingNavigatorSaveItem
        '
        Me.TblEvolucionHCBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblEvolucionHCBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblEvolucionHCBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblEvolucionHCBindingNavigatorSaveItem.Name = "TblEvolucionHCBindingNavigatorSaveItem"
        Me.TblEvolucionHCBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblEvolucionHCBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'StrdescripcionTextBox
        '
        Me.StrdescripcionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblEvolucionHCBindingSource, "Strdescripcion", True))
        Me.StrdescripcionTextBox.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StrdescripcionTextBox.Location = New System.Drawing.Point(9, 61)
        Me.StrdescripcionTextBox.Multiline = True
        Me.StrdescripcionTextBox.Name = "StrdescripcionTextBox"
        Me.StrdescripcionTextBox.Size = New System.Drawing.Size(697, 378)
        Me.StrdescripcionTextBox.TabIndex = 6
        '
        'IntNivelEvolucionComboBox
        '
        Me.IntNivelEvolucionComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblEvolucionHCBindingSource, "intNivelEvolucion", True))
        Me.IntNivelEvolucionComboBox.FormattingEnabled = True
        Me.IntNivelEvolucionComboBox.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"})
        Me.IntNivelEvolucionComboBox.Location = New System.Drawing.Point(650, 34)
        Me.IntNivelEvolucionComboBox.Name = "IntNivelEvolucionComboBox"
        Me.IntNivelEvolucionComboBox.Size = New System.Drawing.Size(56, 21)
        Me.IntNivelEvolucionComboBox.TabIndex = 7
        '
        'ToolStripButtonImprimir
        '
        Me.ToolStripButtonImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButtonImprimir.Image = CType(resources.GetObject("ToolStripButtonImprimir.Image"), System.Drawing.Image)
        Me.ToolStripButtonImprimir.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButtonImprimir.Name = "ToolStripButtonImprimir"
        Me.ToolStripButtonImprimir.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButtonImprimir.Text = "Imprimir"
        '
        'uscEvolucionVisita
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(IntNivelEvolucionLabel)
        Me.Controls.Add(Me.IntNivelEvolucionComboBox)
        Me.Controls.Add(Me.StrdescripcionTextBox)
        Me.Controls.Add(StrdescripcionLabel)
        Me.Controls.Add(Me.TblEvolucionHCBindingNavigator)
        Me.Name = "uscEvolucionVisita"
        Me.Size = New System.Drawing.Size(726, 459)
        CType(Me.TblEvolucionHCBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblEvolucionHCBindingNavigator.ResumeLayout(False)
        Me.TblEvolucionHCBindingNavigator.PerformLayout()
        CType(Me.TblEvolucionHCBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblEvolucionHCBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblEvolucionHCBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblEvolucionHCBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents StrdescripcionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents IntNivelEvolucionComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ToolStripButtonImprimir As System.Windows.Forms.ToolStripButton

End Class
