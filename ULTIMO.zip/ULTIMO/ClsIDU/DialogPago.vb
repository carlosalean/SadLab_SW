﻿Imports System.Windows.Forms

Public Class DialogPago
    Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext
    Dim mstrStringConection As String
    Dim mstrIntIdUsuario As String
    Public mValorPagado As Integer
    Public mValorEfectivo As Integer
    Public mValorDevuelto As Integer
    Public mPrestadorServicio As Integer
    Dim intidPrestador As Integer

    Sub New(ByVal strStringConection As String, ByVal strIntIdUsuario As String, ByVal intIdEmpleado As Integer)
        Try
            InitializeComponent()
            mstrIntIdUsuario = strIntIdUsuario
            mstrStringConection = strStringConection
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
            TblDatosPrestadoresBindingSource.DataSource = dc.tblDatosPrestadores
            intidPrestador = (From P In dc.tblEmpeados Where P.intIdCodigoEmpleado = intIdEmpleado Select P.intIdCodigoPrestador).Single
            ClsComboBoxPrestador.SelectedValue = intidPrestador

            Dim TipoDoc = (From p In dc.tblTipos _
                            Where p.strTipo = "MEDIO_PAGO")
            TblTipoBindingSource.DataSource = TipoDoc

        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
        ' Llamada necesaria para el Diseñador de Windows Forms.

    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Try
            If ClsTextBoxValorPagado.Text = Nothing Then
                MsgBox("Debe ingresar un valor a pagar")
                Exit Sub
            End If

            If ClsTextBoxEfectivo.Text = Nothing Then
                MsgBox("Debe ingresar el valor del efectivo")
                Exit Sub
            End If

            Dim mValidaHuella As New DialogValidarHuella(mstrStringConection, mstrIntIdUsuario, False)
            If mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK Then
                mValorPagado = ClsTextBoxValorPagado.Text
                mValorEfectivo = ClsTextBoxEfectivo.Text
                mValorDevuelto = ClsTextBoxDevuelta.Text
                mPrestadorServicio = ClsComboBoxPrestador.SelectedItem().intIdPrestadores
                Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Else
                MsgBox("No se pudo guardar el pago")
            End If
            Me.Close()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
        
    End Sub
    Private Sub Devuelta()

        If ClsTextBoxEfectivo.Text.Length > 0 Then
            If ClsTextBoxValorPagado.Text.Length > 0 Then
                ClsTextBoxDevuelta.Text = Convert.ToInt32(ClsTextBoxEfectivo.Text) - Convert.ToInt32(ClsTextBoxValorPagado.Text)
                ''Se le agrega un mensaje preventivo al lado del ClsTextBoxDevuelta para que 
                ''muestre cuando el valor sea negativo. 
                ''Oscar Tabares 2015-07-02
                If Convert.ToInt32(ClsTextBoxDevuelta.Text) < 0 Then
                    MsjNegativo.Visible = True
                Else
                    MsjNegativo.Visible = False
                End If
            End If
        End If


    End Sub
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub DialogPago_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub ClsTextBoxValorPagado_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClsTextBoxValorPagado.TextChanged
        Devuelta()
    End Sub

    Private Sub ClsTextBoxEfectivo_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClsTextBoxEfectivo.TextChanged
        Devuelta()
    End Sub
End Class
