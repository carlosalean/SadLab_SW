﻿Public Class FrmLaboratoriosFarmaceuticos
    Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext

    Sub New(ByVal strStringConection As String)
        Try
            ' Llamada necesaria para el Diseñador de Windows Forms.
            InitializeComponent()
            dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub FrmLaboratoriosFarmaceuticos_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            TblLaboratoriosfarmaceuticosBindingSource.DataSource = dc.tblLaboratoriosfarmaceuticos
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub TblLaboratoriosfarmaceuticosBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TblLaboratoriosfarmaceuticosBindingNavigatorSaveItem.Click
        Try
            TblLaboratoriosfarmaceuticosBindingSource.EndEdit()
            dc.SubmitChanges()
        Catch ex As Exception
            ClsError.ClsError.PrMostrarError(ex)
        End Try
    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click
        TabControl1.SelectTab(1)
    End Sub
End Class