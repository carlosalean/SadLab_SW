﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFacturacionFormato
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IntIdFacturaFormatoLabel As System.Windows.Forms.Label
        Dim DtmFechaFacturaLabel As System.Windows.Forms.Label
        Dim IntIdEPSLabel As System.Windows.Forms.Label
        Dim IntIdFacturaFormatoLabel1 As System.Windows.Forms.Label
        Dim IntIdPrestadorLabel As System.Windows.Forms.Label
        Dim StrNroFacturaLabel As System.Windows.Forms.Label
        Dim StrPrefijoLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmFacturacionFormato))
        Me.TblFacturaFormatoEncabezadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblFacturaFormatoEncabezadoBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.TblFacturaFormatoEncabezadoBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.IntIdFacturaFormatoClsTextBox = New ClsUtilidades.ClsTextBox
        Me.DtmFechaFacturaClsDateTimePicker = New ClsUtilidades.ClsDateTimePicker
        Me.IntIdEPSClsComboBox = New ClsUtilidades.ClsComboBox
        Me.IntIdFacturaFormatoClsTextBox1 = New ClsUtilidades.ClsTextBox
        Me.IntIdPrestadorClsComboBox = New ClsUtilidades.ClsComboBox
        Me.StrNroFacturaClsTextBox = New ClsUtilidades.ClsTextBox
        Me.StrPrefijoClsTextBox = New ClsUtilidades.ClsTextBox
        IntIdFacturaFormatoLabel = New System.Windows.Forms.Label
        DtmFechaFacturaLabel = New System.Windows.Forms.Label
        IntIdEPSLabel = New System.Windows.Forms.Label
        IntIdFacturaFormatoLabel1 = New System.Windows.Forms.Label
        IntIdPrestadorLabel = New System.Windows.Forms.Label
        StrNroFacturaLabel = New System.Windows.Forms.Label
        StrPrefijoLabel = New System.Windows.Forms.Label
        CType(Me.TblFacturaFormatoEncabezadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblFacturaFormatoEncabezadoBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblFacturaFormatoEncabezadoBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntIdFacturaFormatoLabel
        '
        IntIdFacturaFormatoLabel.AutoSize = True
        IntIdFacturaFormatoLabel.Location = New System.Drawing.Point(31, 54)
        IntIdFacturaFormatoLabel.Name = "IntIdFacturaFormatoLabel"
        IntIdFacturaFormatoLabel.Size = New System.Drawing.Size(19, 13)
        IntIdFacturaFormatoLabel.TabIndex = 1
        IntIdFacturaFormatoLabel.Text = "Id:"
        '
        'DtmFechaFacturaLabel
        '
        DtmFechaFacturaLabel.AutoSize = True
        DtmFechaFacturaLabel.Location = New System.Drawing.Point(576, 51)
        DtmFechaFacturaLabel.Name = "DtmFechaFacturaLabel"
        DtmFechaFacturaLabel.Size = New System.Drawing.Size(40, 13)
        DtmFechaFacturaLabel.TabIndex = 3
        DtmFechaFacturaLabel.Text = "Fecha:"
        '
        'IntIdEPSLabel
        '
        IntIdEPSLabel.AutoSize = True
        IntIdEPSLabel.Location = New System.Drawing.Point(31, 107)
        IntIdEPSLabel.Name = "IntIdEPSLabel"
        IntIdEPSLabel.Size = New System.Drawing.Size(31, 13)
        IntIdEPSLabel.TabIndex = 5
        IntIdEPSLabel.Text = "EPS:"
        '
        'IntIdFacturaFormatoLabel1
        '
        IntIdFacturaFormatoLabel1.AutoSize = True
        IntIdFacturaFormatoLabel1.Location = New System.Drawing.Point(576, 76)
        IntIdFacturaFormatoLabel1.Name = "IntIdFacturaFormatoLabel1"
        IntIdFacturaFormatoLabel1.Size = New System.Drawing.Size(66, 13)
        IntIdFacturaFormatoLabel1.TabIndex = 7
        IntIdFacturaFormatoLabel1.Text = "Nro Factura:"
        '
        'IntIdPrestadorLabel
        '
        IntIdPrestadorLabel.AutoSize = True
        IntIdPrestadorLabel.Location = New System.Drawing.Point(31, 80)
        IntIdPrestadorLabel.Name = "IntIdPrestadorLabel"
        IntIdPrestadorLabel.Size = New System.Drawing.Size(55, 13)
        IntIdPrestadorLabel.TabIndex = 9
        IntIdPrestadorLabel.Text = "Prestador:"
        '
        'StrNroFacturaLabel
        '
        StrNroFacturaLabel.AutoSize = True
        StrNroFacturaLabel.Location = New System.Drawing.Point(409, 177)
        StrNroFacturaLabel.Name = "StrNroFacturaLabel"
        StrNroFacturaLabel.Size = New System.Drawing.Size(80, 13)
        StrNroFacturaLabel.TabIndex = 11
        StrNroFacturaLabel.Text = "str Nro Factura:"
        '
        'StrPrefijoLabel
        '
        StrPrefijoLabel.AutoSize = True
        StrPrefijoLabel.Location = New System.Drawing.Point(462, 218)
        StrPrefijoLabel.Name = "StrPrefijoLabel"
        StrPrefijoLabel.Size = New System.Drawing.Size(53, 13)
        StrPrefijoLabel.TabIndex = 13
        StrPrefijoLabel.Text = "str Prefijo:"
        '
        'TblFacturaFormatoEncabezadoBindingSource
        '
        Me.TblFacturaFormatoEncabezadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblFacturaFormatoEncabezado)
        '
        'TblFacturaFormatoEncabezadoBindingNavigator
        '
        Me.TblFacturaFormatoEncabezadoBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblFacturaFormatoEncabezadoBindingNavigator.BindingSource = Me.TblFacturaFormatoEncabezadoBindingSource
        Me.TblFacturaFormatoEncabezadoBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblFacturaFormatoEncabezadoBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblFacturaFormatoEncabezadoBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblFacturaFormatoEncabezadoBindingNavigatorSaveItem})
        Me.TblFacturaFormatoEncabezadoBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblFacturaFormatoEncabezadoBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblFacturaFormatoEncabezadoBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblFacturaFormatoEncabezadoBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblFacturaFormatoEncabezadoBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblFacturaFormatoEncabezadoBindingNavigator.Name = "TblFacturaFormatoEncabezadoBindingNavigator"
        Me.TblFacturaFormatoEncabezadoBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblFacturaFormatoEncabezadoBindingNavigator.Size = New System.Drawing.Size(941, 25)
        Me.TblFacturaFormatoEncabezadoBindingNavigator.TabIndex = 0
        Me.TblFacturaFormatoEncabezadoBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(36, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblFacturaFormatoEncabezadoBindingNavigatorSaveItem
        '
        Me.TblFacturaFormatoEncabezadoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblFacturaFormatoEncabezadoBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblFacturaFormatoEncabezadoBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblFacturaFormatoEncabezadoBindingNavigatorSaveItem.Name = "TblFacturaFormatoEncabezadoBindingNavigatorSaveItem"
        Me.TblFacturaFormatoEncabezadoBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblFacturaFormatoEncabezadoBindingNavigatorSaveItem.Text = "Save Data"
        '
        'IntIdFacturaFormatoClsTextBox
        '
        Me.IntIdFacturaFormatoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblFacturaFormatoEncabezadoBindingSource, "intIdFacturaFormato", True))
        Me.IntIdFacturaFormatoClsTextBox.DataSource = Nothing
        Me.IntIdFacturaFormatoClsTextBox.Location = New System.Drawing.Point(150, 51)
        Me.IntIdFacturaFormatoClsTextBox.Name = "IntIdFacturaFormatoClsTextBox"
        Me.IntIdFacturaFormatoClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdFacturaFormatoClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdFacturaFormatoClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.IntIdFacturaFormatoClsTextBox.TabIndex = 2
        Me.IntIdFacturaFormatoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'DtmFechaFacturaClsDateTimePicker
        '
        Me.DtmFechaFacturaClsDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblFacturaFormatoEncabezadoBindingSource, "dtmFechaFactura", True))
        Me.DtmFechaFacturaClsDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtmFechaFacturaClsDateTimePicker.Location = New System.Drawing.Point(681, 47)
        Me.DtmFechaFacturaClsDateTimePicker.Name = "DtmFechaFacturaClsDateTimePicker"
        Me.DtmFechaFacturaClsDateTimePicker.Size = New System.Drawing.Size(90, 20)
        Me.DtmFechaFacturaClsDateTimePicker.TabIndex = 4
        '
        'IntIdEPSClsComboBox
        '
        Me.IntIdEPSClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblFacturaFormatoEncabezadoBindingSource, "intIdEPS", True))
        Me.IntIdEPSClsComboBox.FormattingEnabled = True
        Me.IntIdEPSClsComboBox.Location = New System.Drawing.Point(150, 104)
        Me.IntIdEPSClsComboBox.Name = "IntIdEPSClsComboBox"
        Me.IntIdEPSClsComboBox.Size = New System.Drawing.Size(283, 21)
        Me.IntIdEPSClsComboBox.TabIndex = 6
        '
        'IntIdFacturaFormatoClsTextBox1
        '
        Me.IntIdFacturaFormatoClsTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblFacturaFormatoEncabezadoBindingSource, "intIdFacturaFormato", True))
        Me.IntIdFacturaFormatoClsTextBox1.DataSource = Nothing
        Me.IntIdFacturaFormatoClsTextBox1.Location = New System.Drawing.Point(681, 73)
        Me.IntIdFacturaFormatoClsTextBox1.Name = "IntIdFacturaFormatoClsTextBox1"
        Me.IntIdFacturaFormatoClsTextBox1.NombreCodigoF2 = Nothing
        Me.IntIdFacturaFormatoClsTextBox1.NombreDescripcionF2 = Nothing
        Me.IntIdFacturaFormatoClsTextBox1.Size = New System.Drawing.Size(100, 20)
        Me.IntIdFacturaFormatoClsTextBox1.TabIndex = 8
        Me.IntIdFacturaFormatoClsTextBox1.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdPrestadorClsComboBox
        '
        Me.IntIdPrestadorClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblFacturaFormatoEncabezadoBindingSource, "intIdPrestador", True))
        Me.IntIdPrestadorClsComboBox.FormattingEnabled = True
        Me.IntIdPrestadorClsComboBox.Location = New System.Drawing.Point(150, 77)
        Me.IntIdPrestadorClsComboBox.Name = "IntIdPrestadorClsComboBox"
        Me.IntIdPrestadorClsComboBox.Size = New System.Drawing.Size(283, 21)
        Me.IntIdPrestadorClsComboBox.TabIndex = 10
        '
        'StrNroFacturaClsTextBox
        '
        Me.StrNroFacturaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblFacturaFormatoEncabezadoBindingSource, "strNroFactura", True))
        Me.StrNroFacturaClsTextBox.DataSource = Nothing
        Me.StrNroFacturaClsTextBox.Location = New System.Drawing.Point(495, 174)
        Me.StrNroFacturaClsTextBox.Name = "StrNroFacturaClsTextBox"
        Me.StrNroFacturaClsTextBox.NombreCodigoF2 = Nothing
        Me.StrNroFacturaClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrNroFacturaClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrNroFacturaClsTextBox.TabIndex = 12
        Me.StrNroFacturaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrPrefijoClsTextBox
        '
        Me.StrPrefijoClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblFacturaFormatoEncabezadoBindingSource, "strPrefijo", True))
        Me.StrPrefijoClsTextBox.DataSource = Nothing
        Me.StrPrefijoClsTextBox.Location = New System.Drawing.Point(521, 215)
        Me.StrPrefijoClsTextBox.Name = "StrPrefijoClsTextBox"
        Me.StrPrefijoClsTextBox.NombreCodigoF2 = Nothing
        Me.StrPrefijoClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrPrefijoClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.StrPrefijoClsTextBox.TabIndex = 14
        Me.StrPrefijoClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'FrmFacturacionFormato
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(941, 484)
        Me.Controls.Add(StrPrefijoLabel)
        Me.Controls.Add(Me.StrPrefijoClsTextBox)
        Me.Controls.Add(StrNroFacturaLabel)
        Me.Controls.Add(Me.StrNroFacturaClsTextBox)
        Me.Controls.Add(IntIdPrestadorLabel)
        Me.Controls.Add(Me.IntIdPrestadorClsComboBox)
        Me.Controls.Add(IntIdFacturaFormatoLabel1)
        Me.Controls.Add(Me.IntIdFacturaFormatoClsTextBox1)
        Me.Controls.Add(IntIdEPSLabel)
        Me.Controls.Add(Me.IntIdEPSClsComboBox)
        Me.Controls.Add(DtmFechaFacturaLabel)
        Me.Controls.Add(Me.DtmFechaFacturaClsDateTimePicker)
        Me.Controls.Add(IntIdFacturaFormatoLabel)
        Me.Controls.Add(Me.IntIdFacturaFormatoClsTextBox)
        Me.Controls.Add(Me.TblFacturaFormatoEncabezadoBindingNavigator)
        Me.Name = "FrmFacturacionFormato"
        Me.Text = "Facturación"
        CType(Me.TblFacturaFormatoEncabezadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblFacturaFormatoEncabezadoBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblFacturaFormatoEncabezadoBindingNavigator.ResumeLayout(False)
        Me.TblFacturaFormatoEncabezadoBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TblFacturaFormatoEncabezadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblFacturaFormatoEncabezadoBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblFacturaFormatoEncabezadoBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IntIdFacturaFormatoClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DtmFechaFacturaClsDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents IntIdEPSClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents IntIdFacturaFormatoClsTextBox1 As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdPrestadorClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents StrNroFacturaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrPrefijoClsTextBox As ClsUtilidades.ClsTextBox
End Class
