﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmProcedimientos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim IntIdProcedimientosLabel As System.Windows.Forms.Label
        Dim StrCodigoProcedimientoLabel As System.Windows.Forms.Label
        Dim StrDescripcionLabel As System.Windows.Forms.Label
        Dim StrIndicacionesPreparacionLabel As System.Windows.Forms.Label
        Dim StrNombreLabel As System.Windows.Forms.Label
        Dim IntIdDivisionVasculabLabel As System.Windows.Forms.Label
        Dim NumValorLabel As System.Windows.Forms.Label
        Dim IntTiempoHorasLabel As System.Windows.Forms.Label
        Dim IntIdTipoProcedimientoLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmProcedimientos))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TblProcedimientoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.TblDivisionVasculabBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblProcedimientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.IntIdTipoProcedimientoClsComboBox = New ClsUtilidades.ClsComboBox()
        Me.TblTipoBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TblTarifasDataGridView = New System.Windows.Forms.DataGridView()
        Me.TblEPBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblTipoTarifaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblTipoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.IntTiempoMinutosNumericUpDown = New System.Windows.Forms.NumericUpDown()
        Me.IntTiempoHorasNumericUpDown = New System.Windows.Forms.NumericUpDown()
        Me.NumValorTextBox = New ClsUtilidades.ClsTextBox()
        Me.IntIdDivisionVasculabComboBox = New ClsUtilidades.ClsComboBox()
        Me.BitTienePreparacionCheckBox = New ClsUtilidades.ClsCheckBox()
        Me.IntIdProcedimientosTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrCodigoProcedimientoTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrDescripcionTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrIndicacionesPreparacionTextBox = New ClsUtilidades.ClsTextBox()
        Me.StrNombreTextBox = New ClsUtilidades.ClsTextBox()
        Me.TblProcedimientoBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TblProcedimientoBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TblTarifaBaseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.intIdEPS = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.strCodigoProcedimiento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.intIDTipoTarifa = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.intIdTarifaBase = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.intTipo = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.numValor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdTarifaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdEPSDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntIdProcedimientoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IntTipoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumValorDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StrCodigoProcedimientoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblProcedimientoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        IntIdProcedimientosLabel = New System.Windows.Forms.Label()
        StrCodigoProcedimientoLabel = New System.Windows.Forms.Label()
        StrDescripcionLabel = New System.Windows.Forms.Label()
        StrIndicacionesPreparacionLabel = New System.Windows.Forms.Label()
        StrNombreLabel = New System.Windows.Forms.Label()
        IntIdDivisionVasculabLabel = New System.Windows.Forms.Label()
        NumValorLabel = New System.Windows.Forms.Label()
        IntTiempoHorasLabel = New System.Windows.Forms.Label()
        IntIdTipoProcedimientoLabel = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblProcedimientoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblDivisionVasculabBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblTipoBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.TblTarifasDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblEPBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoTarifaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IntTiempoMinutosNumericUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.IntTiempoHorasNumericUpDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProcedimientoBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblProcedimientoBindingNavigator.SuspendLayout()
        CType(Me.TblTarifaBaseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IntIdProcedimientosLabel
        '
        IntIdProcedimientosLabel.AutoSize = True
        IntIdProcedimientosLabel.Location = New System.Drawing.Point(46, 30)
        IntIdProcedimientosLabel.Name = "IntIdProcedimientosLabel"
        IntIdProcedimientosLabel.Size = New System.Drawing.Size(19, 13)
        IntIdProcedimientosLabel.TabIndex = 4
        IntIdProcedimientosLabel.Text = "Id:"
        '
        'StrCodigoProcedimientoLabel
        '
        StrCodigoProcedimientoLabel.AutoSize = True
        StrCodigoProcedimientoLabel.Location = New System.Drawing.Point(46, 108)
        StrCodigoProcedimientoLabel.Name = "StrCodigoProcedimientoLabel"
        StrCodigoProcedimientoLabel.Size = New System.Drawing.Size(43, 13)
        StrCodigoProcedimientoLabel.TabIndex = 6
        StrCodigoProcedimientoLabel.Text = "Código:"
        '
        'StrDescripcionLabel
        '
        StrDescripcionLabel.AutoSize = True
        StrDescripcionLabel.Location = New System.Drawing.Point(46, 82)
        StrDescripcionLabel.Name = "StrDescripcionLabel"
        StrDescripcionLabel.Size = New System.Drawing.Size(66, 13)
        StrDescripcionLabel.TabIndex = 8
        StrDescripcionLabel.Text = "Descripción:"
        '
        'StrIndicacionesPreparacionLabel
        '
        StrIndicacionesPreparacionLabel.AutoSize = True
        StrIndicacionesPreparacionLabel.Location = New System.Drawing.Point(46, 258)
        StrIndicacionesPreparacionLabel.Name = "StrIndicacionesPreparacionLabel"
        StrIndicacionesPreparacionLabel.Size = New System.Drawing.Size(130, 13)
        StrIndicacionesPreparacionLabel.TabIndex = 10
        StrIndicacionesPreparacionLabel.Text = "Indicaciones Preparacion:"
        '
        'StrNombreLabel
        '
        StrNombreLabel.AutoSize = True
        StrNombreLabel.Location = New System.Drawing.Point(46, 56)
        StrNombreLabel.Name = "StrNombreLabel"
        StrNombreLabel.Size = New System.Drawing.Size(47, 13)
        StrNombreLabel.TabIndex = 12
        StrNombreLabel.Text = "Nombre:"
        '
        'IntIdDivisionVasculabLabel
        '
        IntIdDivisionVasculabLabel.AutoSize = True
        IntIdDivisionVasculabLabel.Location = New System.Drawing.Point(46, 134)
        IntIdDivisionVasculabLabel.Name = "IntIdDivisionVasculabLabel"
        IntIdDivisionVasculabLabel.Size = New System.Drawing.Size(94, 13)
        IntIdDivisionVasculabLabel.TabIndex = 13
        IntIdDivisionVasculabLabel.Text = "Division Vasculab:"
        '
        'NumValorLabel
        '
        NumValorLabel.AutoSize = True
        NumValorLabel.Location = New System.Drawing.Point(46, 161)
        NumValorLabel.Name = "NumValorLabel"
        NumValorLabel.Size = New System.Drawing.Size(34, 13)
        NumValorLabel.TabIndex = 13
        NumValorLabel.Text = "Valor:"
        '
        'IntTiempoHorasLabel
        '
        IntTiempoHorasLabel.AutoSize = True
        IntTiempoHorasLabel.Location = New System.Drawing.Point(321, 161)
        IntTiempoHorasLabel.Name = "IntTiempoHorasLabel"
        IntTiempoHorasLabel.Size = New System.Drawing.Size(97, 13)
        IntTiempoHorasLabel.TabIndex = 15
        IntTiempoHorasLabel.Text = "Duración (HH:mm):"
        '
        'IntIdTipoProcedimientoLabel
        '
        IntIdTipoProcedimientoLabel.AutoSize = True
        IntIdTipoProcedimientoLabel.Location = New System.Drawing.Point(46, 223)
        IntIdTipoProcedimientoLabel.Name = "IntIdTipoProcedimientoLabel"
        IntIdTipoProcedimientoLabel.Size = New System.Drawing.Size(101, 13)
        IntIdTipoProcedimientoLabel.TabIndex = 19
        IntIdTipoProcedimientoLabel.Text = "Tipo Procedimiento:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1021, 553)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TblProcedimientoDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(946, 527)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblProcedimientoDataGridView
        '
        Me.TblProcedimientoDataGridView.AllowUserToAddRows = False
        Me.TblProcedimientoDataGridView.AllowUserToDeleteRows = False
        Me.TblProcedimientoDataGridView.AllowUserToOrderColumns = True
        Me.TblProcedimientoDataGridView.AutoGenerateColumns = False
        Me.TblProcedimientoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblProcedimientoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.TblProcedimientoDataGridView.DataSource = Me.TblProcedimientoBindingSource
        Me.TblProcedimientoDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblProcedimientoDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblProcedimientoDataGridView.Name = "TblProcedimientoDataGridView"
        Me.TblProcedimientoDataGridView.ReadOnly = True
        Me.TblProcedimientoDataGridView.Size = New System.Drawing.Size(940, 521)
        Me.TblProcedimientoDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdProcedimientos"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strNombre"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 350
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "strDescripcion"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Descripción"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "strCodigoProcedimiento"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Código"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "intIdDivisionVasculab"
        Me.DataGridViewTextBoxColumn5.DataSource = Me.TblDivisionVasculabBindingSource
        Me.DataGridViewTextBoxColumn5.DisplayMember = "strNombreDivision"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Division Vasculab"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn5.ValueMember = "intIdDivisionVasculab"
        Me.DataGridViewTextBoxColumn5.Width = 250
        '
        'TblDivisionVasculabBindingSource
        '
        Me.TblDivisionVasculabBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblDivisionVasculab)
        Me.TblDivisionVasculabBindingSource.Sort = "strNombreDivision"
        '
        'TblProcedimientoBindingSource
        '
        Me.TblProcedimientoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblProcedimiento)
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.Controls.Add(IntIdTipoProcedimientoLabel)
        Me.TabPage2.Controls.Add(Me.IntIdTipoProcedimientoClsComboBox)
        Me.TabPage2.Controls.Add(Me.GroupBox1)
        Me.TabPage2.Controls.Add(Me.IntTiempoMinutosNumericUpDown)
        Me.TabPage2.Controls.Add(IntTiempoHorasLabel)
        Me.TabPage2.Controls.Add(Me.IntTiempoHorasNumericUpDown)
        Me.TabPage2.Controls.Add(NumValorLabel)
        Me.TabPage2.Controls.Add(Me.NumValorTextBox)
        Me.TabPage2.Controls.Add(IntIdDivisionVasculabLabel)
        Me.TabPage2.Controls.Add(Me.IntIdDivisionVasculabComboBox)
        Me.TabPage2.Controls.Add(Me.BitTienePreparacionCheckBox)
        Me.TabPage2.Controls.Add(IntIdProcedimientosLabel)
        Me.TabPage2.Controls.Add(Me.IntIdProcedimientosTextBox)
        Me.TabPage2.Controls.Add(StrCodigoProcedimientoLabel)
        Me.TabPage2.Controls.Add(Me.StrCodigoProcedimientoTextBox)
        Me.TabPage2.Controls.Add(StrDescripcionLabel)
        Me.TabPage2.Controls.Add(Me.StrDescripcionTextBox)
        Me.TabPage2.Controls.Add(StrIndicacionesPreparacionLabel)
        Me.TabPage2.Controls.Add(Me.StrIndicacionesPreparacionTextBox)
        Me.TabPage2.Controls.Add(StrNombreLabel)
        Me.TabPage2.Controls.Add(Me.StrNombreTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1013, 527)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'IntIdTipoProcedimientoClsComboBox
        '
        Me.IntIdTipoProcedimientoClsComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblProcedimientoBindingSource, "intIdTipoProcedimiento", True))
        Me.IntIdTipoProcedimientoClsComboBox.DataSource = Me.TblTipoBindingSource1
        Me.IntIdTipoProcedimientoClsComboBox.DisplayMember = "strValor"
        Me.IntIdTipoProcedimientoClsComboBox.FormattingEnabled = True
        Me.IntIdTipoProcedimientoClsComboBox.Location = New System.Drawing.Point(196, 220)
        Me.IntIdTipoProcedimientoClsComboBox.Name = "IntIdTipoProcedimientoClsComboBox"
        Me.IntIdTipoProcedimientoClsComboBox.Size = New System.Drawing.Size(169, 21)
        Me.IntIdTipoProcedimientoClsComboBox.TabIndex = 9
        Me.IntIdTipoProcedimientoClsComboBox.ValueMember = "intIdTipo"
        '
        'TblTipoBindingSource1
        '
        Me.TblTipoBindingSource1.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        Me.TblTipoBindingSource1.Sort = "strValor"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TblTarifasDataGridView)
        Me.GroupBox1.Location = New System.Drawing.Point(49, 317)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(948, 202)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Trarifas y Codigos Adicionales"
        '
        'TblTarifasDataGridView
        '
        Me.TblTarifasDataGridView.AutoGenerateColumns = False
        Me.TblTarifasDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblTarifasDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.intIdEPS, Me.strCodigoProcedimiento, Me.intIDTipoTarifa, Me.intIdTarifaBase, Me.intTipo, Me.numValor, Me.IntIdTarifaDataGridViewTextBoxColumn, Me.IntIdEPSDataGridViewTextBoxColumn, Me.IntIdProcedimientoDataGridViewTextBoxColumn, Me.IntTipoDataGridViewTextBoxColumn, Me.NumValorDataGridViewTextBoxColumn, Me.StrCodigoProcedimientoDataGridViewTextBoxColumn, Me.TblProcedimientoDataGridViewTextBoxColumn})
        Me.TblTarifasDataGridView.DataMember = "tblTarifas"
        Me.TblTarifasDataGridView.DataSource = Me.TblProcedimientoBindingSource
        Me.TblTarifasDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblTarifasDataGridView.Location = New System.Drawing.Point(3, 16)
        Me.TblTarifasDataGridView.Name = "TblTarifasDataGridView"
        Me.TblTarifasDataGridView.Size = New System.Drawing.Size(942, 183)
        Me.TblTarifasDataGridView.TabIndex = 0
        '
        'TblEPBindingSource
        '
        Me.TblEPBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEPs)
        '
        'TblTipoTarifaBindingSource
        '
        Me.TblTipoTarifaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipoTarifa)
        '
        'TblTipoBindingSource
        '
        Me.TblTipoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTipo)
        '
        'IntTiempoMinutosNumericUpDown
        '
        Me.IntTiempoMinutosNumericUpDown.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblProcedimientoBindingSource, "intTiempoMinutos", True))
        Me.IntTiempoMinutosNumericUpDown.Location = New System.Drawing.Point(464, 158)
        Me.IntTiempoMinutosNumericUpDown.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.IntTiempoMinutosNumericUpDown.Name = "IntTiempoMinutosNumericUpDown"
        Me.IntTiempoMinutosNumericUpDown.Size = New System.Drawing.Size(36, 20)
        Me.IntTiempoMinutosNumericUpDown.TabIndex = 7
        '
        'IntTiempoHorasNumericUpDown
        '
        Me.IntTiempoHorasNumericUpDown.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblProcedimientoBindingSource, "intTiempoHoras", True))
        Me.IntTiempoHorasNumericUpDown.Location = New System.Drawing.Point(424, 158)
        Me.IntTiempoHorasNumericUpDown.Maximum = New Decimal(New Integer() {12, 0, 0, 0})
        Me.IntTiempoHorasNumericUpDown.Name = "IntTiempoHorasNumericUpDown"
        Me.IntTiempoHorasNumericUpDown.Size = New System.Drawing.Size(34, 20)
        Me.IntTiempoHorasNumericUpDown.TabIndex = 6
        '
        'NumValorTextBox
        '
        Me.NumValorTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblProcedimientoBindingSource, "numValor", True))
        Me.NumValorTextBox.DataSource = Nothing
        Me.NumValorTextBox.EnterEntreCampos = True
        Me.NumValorTextBox.Location = New System.Drawing.Point(196, 158)
        Me.NumValorTextBox.Name = "NumValorTextBox"
        Me.NumValorTextBox.NombreCodigoF2 = Nothing
        Me.NumValorTextBox.NombreDescripcionF2 = Nothing
        Me.NumValorTextBox.Size = New System.Drawing.Size(100, 20)
        Me.NumValorTextBox.TabIndex = 5
        Me.NumValorTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdDivisionVasculabComboBox
        '
        Me.IntIdDivisionVasculabComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.TblProcedimientoBindingSource, "intIdDivisionVasculab", True))
        Me.IntIdDivisionVasculabComboBox.DataSource = Me.TblDivisionVasculabBindingSource
        Me.IntIdDivisionVasculabComboBox.DisplayMember = "strNombreDivision"
        Me.IntIdDivisionVasculabComboBox.FormattingEnabled = True
        Me.IntIdDivisionVasculabComboBox.Location = New System.Drawing.Point(196, 131)
        Me.IntIdDivisionVasculabComboBox.Name = "IntIdDivisionVasculabComboBox"
        Me.IntIdDivisionVasculabComboBox.Size = New System.Drawing.Size(341, 21)
        Me.IntIdDivisionVasculabComboBox.TabIndex = 4
        Me.IntIdDivisionVasculabComboBox.ValueMember = "intIdDivisionVasculab"
        '
        'BitTienePreparacionCheckBox
        '
        Me.BitTienePreparacionCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BitTienePreparacionCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblProcedimientoBindingSource, "bitTienePreparacion", True))
        Me.BitTienePreparacionCheckBox.Location = New System.Drawing.Point(49, 190)
        Me.BitTienePreparacionCheckBox.Name = "BitTienePreparacionCheckBox"
        Me.BitTienePreparacionCheckBox.Size = New System.Drawing.Size(162, 24)
        Me.BitTienePreparacionCheckBox.TabIndex = 8
        Me.BitTienePreparacionCheckBox.Text = "Tiene Preparación"
        Me.BitTienePreparacionCheckBox.ThreeState = True
        Me.BitTienePreparacionCheckBox.UseVisualStyleBackColor = True
        '
        'IntIdProcedimientosTextBox
        '
        Me.IntIdProcedimientosTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblProcedimientoBindingSource, "intIdProcedimientos", True))
        Me.IntIdProcedimientosTextBox.DataSource = Nothing
        Me.IntIdProcedimientosTextBox.Enabled = False
        Me.IntIdProcedimientosTextBox.EnterEntreCampos = True
        Me.IntIdProcedimientosTextBox.Location = New System.Drawing.Point(196, 27)
        Me.IntIdProcedimientosTextBox.Name = "IntIdProcedimientosTextBox"
        Me.IntIdProcedimientosTextBox.NombreCodigoF2 = Nothing
        Me.IntIdProcedimientosTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdProcedimientosTextBox.Size = New System.Drawing.Size(45, 20)
        Me.IntIdProcedimientosTextBox.TabIndex = 0
        Me.IntIdProcedimientosTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrCodigoProcedimientoTextBox
        '
        Me.StrCodigoProcedimientoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblProcedimientoBindingSource, "strCodigoProcedimiento", True))
        Me.StrCodigoProcedimientoTextBox.DataSource = Nothing
        Me.StrCodigoProcedimientoTextBox.EnterEntreCampos = True
        Me.StrCodigoProcedimientoTextBox.Location = New System.Drawing.Point(196, 105)
        Me.StrCodigoProcedimientoTextBox.Name = "StrCodigoProcedimientoTextBox"
        Me.StrCodigoProcedimientoTextBox.NombreCodigoF2 = Nothing
        Me.StrCodigoProcedimientoTextBox.NombreDescripcionF2 = Nothing
        Me.StrCodigoProcedimientoTextBox.Size = New System.Drawing.Size(104, 20)
        Me.StrCodigoProcedimientoTextBox.TabIndex = 3
        Me.StrCodigoProcedimientoTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrDescripcionTextBox
        '
        Me.StrDescripcionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblProcedimientoBindingSource, "strDescripcion", True))
        Me.StrDescripcionTextBox.DataSource = Nothing
        Me.StrDescripcionTextBox.EnterEntreCampos = True
        Me.StrDescripcionTextBox.Location = New System.Drawing.Point(196, 79)
        Me.StrDescripcionTextBox.Name = "StrDescripcionTextBox"
        Me.StrDescripcionTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcionTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcionTextBox.Size = New System.Drawing.Size(533, 20)
        Me.StrDescripcionTextBox.TabIndex = 2
        Me.StrDescripcionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrIndicacionesPreparacionTextBox
        '
        Me.StrIndicacionesPreparacionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblProcedimientoBindingSource, "strIndicacionesPreparacion", True))
        Me.StrIndicacionesPreparacionTextBox.DataSource = Nothing
        Me.StrIndicacionesPreparacionTextBox.EnterEntreCampos = True
        Me.StrIndicacionesPreparacionTextBox.Location = New System.Drawing.Point(196, 255)
        Me.StrIndicacionesPreparacionTextBox.Multiline = True
        Me.StrIndicacionesPreparacionTextBox.Name = "StrIndicacionesPreparacionTextBox"
        Me.StrIndicacionesPreparacionTextBox.NombreCodigoF2 = Nothing
        Me.StrIndicacionesPreparacionTextBox.NombreDescripcionF2 = Nothing
        Me.StrIndicacionesPreparacionTextBox.Size = New System.Drawing.Size(533, 49)
        Me.StrIndicacionesPreparacionTextBox.TabIndex = 10
        Me.StrIndicacionesPreparacionTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrNombreTextBox
        '
        Me.StrNombreTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblProcedimientoBindingSource, "strNombre", True))
        Me.StrNombreTextBox.DataSource = Nothing
        Me.StrNombreTextBox.EnterEntreCampos = True
        Me.StrNombreTextBox.Location = New System.Drawing.Point(196, 53)
        Me.StrNombreTextBox.Name = "StrNombreTextBox"
        Me.StrNombreTextBox.NombreCodigoF2 = Nothing
        Me.StrNombreTextBox.NombreDescripcionF2 = Nothing
        Me.StrNombreTextBox.Size = New System.Drawing.Size(374, 20)
        Me.StrNombreTextBox.TabIndex = 1
        Me.StrNombreTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblProcedimientoBindingNavigator
        '
        Me.TblProcedimientoBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblProcedimientoBindingNavigator.BindingSource = Me.TblProcedimientoBindingSource
        Me.TblProcedimientoBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblProcedimientoBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblProcedimientoBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblProcedimientoBindingNavigatorSaveItem})
        Me.TblProcedimientoBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblProcedimientoBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblProcedimientoBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblProcedimientoBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblProcedimientoBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblProcedimientoBindingNavigator.Name = "TblProcedimientoBindingNavigator"
        Me.TblProcedimientoBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblProcedimientoBindingNavigator.Size = New System.Drawing.Size(1021, 25)
        Me.TblProcedimientoBindingNavigator.TabIndex = 2
        Me.TblProcedimientoBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(37, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblProcedimientoBindingNavigatorSaveItem
        '
        Me.TblProcedimientoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblProcedimientoBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblProcedimientoBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblProcedimientoBindingNavigatorSaveItem.Name = "TblProcedimientoBindingNavigatorSaveItem"
        Me.TblProcedimientoBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblProcedimientoBindingNavigatorSaveItem.Text = "Save Data"
        '
        'TblTarifaBaseBindingSource
        '
        Me.TblTarifaBaseBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTarifaBase)
        '
        'intIdEPS
        '
        Me.intIdEPS.DataPropertyName = "intIdEPS"
        Me.intIdEPS.DataSource = Me.TblEPBindingSource
        Me.intIdEPS.DisplayMember = "strNombre"
        Me.intIdEPS.HeaderText = "EPS"
        Me.intIdEPS.Name = "intIdEPS"
        Me.intIdEPS.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.intIdEPS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.intIdEPS.ValueMember = "intIdEPS"
        Me.intIdEPS.Width = 250
        '
        'strCodigoProcedimiento
        '
        Me.strCodigoProcedimiento.DataPropertyName = "strCodigoProcedimiento"
        Me.strCodigoProcedimiento.HeaderText = "Codigo Procedimiento"
        Me.strCodigoProcedimiento.Name = "strCodigoProcedimiento"
        Me.strCodigoProcedimiento.Width = 140
        '
        'intIDTipoTarifa
        '
        Me.intIDTipoTarifa.DataPropertyName = "intIDTipoTarifa"
        Me.intIDTipoTarifa.DataSource = Me.TblTipoTarifaBindingSource
        Me.intIDTipoTarifa.DisplayMember = "strNombreTipoTarifa"
        Me.intIDTipoTarifa.HeaderText = "Tipo Tarifa"
        Me.intIDTipoTarifa.Name = "intIDTipoTarifa"
        Me.intIDTipoTarifa.ValueMember = "intIdTipoTarifa"
        Me.intIDTipoTarifa.Width = 150
        '
        'intIdTarifaBase
        '
        Me.intIdTarifaBase.DataPropertyName = "intIdTarifaBase"
        Me.intIdTarifaBase.DataSource = Me.TblTarifaBaseBindingSource
        Me.intIdTarifaBase.DisplayMember = "NombreTarifa"
        Me.intIdTarifaBase.HeaderText = "Tarifa Base"
        Me.intIdTarifaBase.Name = "intIdTarifaBase"
        Me.intIdTarifaBase.ValueMember = "intIdTarifaBase"
        Me.intIdTarifaBase.Width = 150
        '
        'intTipo
        '
        Me.intTipo.DataPropertyName = "intTipo"
        Me.intTipo.DataSource = Me.TblTipoBindingSource
        Me.intTipo.DisplayMember = "strValor"
        Me.intTipo.HeaderText = "Tipo"
        Me.intTipo.Name = "intTipo"
        Me.intTipo.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.intTipo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.intTipo.ValueMember = "intIdTipo"
        Me.intTipo.Width = 80
        '
        'numValor
        '
        Me.numValor.DataPropertyName = "numValor"
        Me.numValor.HeaderText = "Valor"
        Me.numValor.Name = "numValor"
        '
        'IntIdTarifaDataGridViewTextBoxColumn
        '
        Me.IntIdTarifaDataGridViewTextBoxColumn.DataPropertyName = "intIdTarifa"
        Me.IntIdTarifaDataGridViewTextBoxColumn.HeaderText = "intIdTarifa"
        Me.IntIdTarifaDataGridViewTextBoxColumn.Name = "IntIdTarifaDataGridViewTextBoxColumn"
        Me.IntIdTarifaDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdEPSDataGridViewTextBoxColumn
        '
        Me.IntIdEPSDataGridViewTextBoxColumn.DataPropertyName = "intIdEPS"
        Me.IntIdEPSDataGridViewTextBoxColumn.HeaderText = "intIdEPS"
        Me.IntIdEPSDataGridViewTextBoxColumn.Name = "IntIdEPSDataGridViewTextBoxColumn"
        Me.IntIdEPSDataGridViewTextBoxColumn.Visible = False
        '
        'IntIdProcedimientoDataGridViewTextBoxColumn
        '
        Me.IntIdProcedimientoDataGridViewTextBoxColumn.DataPropertyName = "intIdProcedimiento"
        Me.IntIdProcedimientoDataGridViewTextBoxColumn.HeaderText = "intIdProcedimiento"
        Me.IntIdProcedimientoDataGridViewTextBoxColumn.Name = "IntIdProcedimientoDataGridViewTextBoxColumn"
        Me.IntIdProcedimientoDataGridViewTextBoxColumn.Visible = False
        '
        'IntTipoDataGridViewTextBoxColumn
        '
        Me.IntTipoDataGridViewTextBoxColumn.DataPropertyName = "intTipo"
        Me.IntTipoDataGridViewTextBoxColumn.HeaderText = "intTipo"
        Me.IntTipoDataGridViewTextBoxColumn.Name = "IntTipoDataGridViewTextBoxColumn"
        Me.IntTipoDataGridViewTextBoxColumn.Visible = False
        '
        'NumValorDataGridViewTextBoxColumn
        '
        Me.NumValorDataGridViewTextBoxColumn.DataPropertyName = "numValor"
        Me.NumValorDataGridViewTextBoxColumn.HeaderText = "numValor"
        Me.NumValorDataGridViewTextBoxColumn.Name = "NumValorDataGridViewTextBoxColumn"
        Me.NumValorDataGridViewTextBoxColumn.Visible = False
        '
        'StrCodigoProcedimientoDataGridViewTextBoxColumn
        '
        Me.StrCodigoProcedimientoDataGridViewTextBoxColumn.DataPropertyName = "strCodigoProcedimiento"
        Me.StrCodigoProcedimientoDataGridViewTextBoxColumn.HeaderText = "strCodigoProcedimiento"
        Me.StrCodigoProcedimientoDataGridViewTextBoxColumn.Name = "StrCodigoProcedimientoDataGridViewTextBoxColumn"
        Me.StrCodigoProcedimientoDataGridViewTextBoxColumn.Visible = False
        '
        'TblProcedimientoDataGridViewTextBoxColumn
        '
        Me.TblProcedimientoDataGridViewTextBoxColumn.DataPropertyName = "tblProcedimiento"
        Me.TblProcedimientoDataGridViewTextBoxColumn.HeaderText = "tblProcedimiento"
        Me.TblProcedimientoDataGridViewTextBoxColumn.Name = "TblProcedimientoDataGridViewTextBoxColumn"
        Me.TblProcedimientoDataGridViewTextBoxColumn.Visible = False
        '
        'FrmProcedimientos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1021, 578)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblProcedimientoBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmProcedimientos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Procedimientos"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblProcedimientoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblDivisionVasculabBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProcedimientoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblTipoBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.TblTarifasDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblEPBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoTarifaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTipoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IntTiempoMinutosNumericUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.IntTiempoHorasNumericUpDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProcedimientoBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblProcedimientoBindingNavigator.ResumeLayout(False)
        Me.TblProcedimientoBindingNavigator.PerformLayout()
        CType(Me.TblTarifaBaseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents TabControl1 As System.Windows.Forms.TabControl
    Public WithEvents TabPage1 As System.Windows.Forms.TabPage
    Public WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblProcedimientoDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblProcedimientoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblProcedimientoBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblProcedimientoBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BitTienePreparacionCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents IntIdProcedimientosTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrCodigoProcedimientoTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrDescripcionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrIndicacionesPreparacionTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNombreTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdDivisionVasculabComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents TblDivisionVasculabBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents NumValorTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntTiempoMinutosNumericUpDown As System.Windows.Forms.NumericUpDown
    Friend WithEvents IntTiempoHorasNumericUpDown As System.Windows.Forms.NumericUpDown
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TblTarifasDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblEPBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblEPDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdTipoProcedimientoClsComboBox As ClsUtilidades.ClsComboBox
    Friend WithEvents TblTipoBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents TblTipoTarifaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents intIdEPS As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents strCodigoProcedimiento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIDTipoTarifa As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents intIdTarifaBase As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents TblTarifaBaseBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents intTipo As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents numValor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdTarifaDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdEPSDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntIdProcedimientoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IntTipoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NumValorDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StrCodigoProcedimientoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TblProcedimientoDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
