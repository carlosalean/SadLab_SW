﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCancelacionCita
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCancelacionCita))
        Me.CancelarContextMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CancelarCitaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ConfirmaCitaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TblEmpeadoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblCitaDataGridView = New System.Windows.Forms.DataGridView()
        Me.Seleccion = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dtmFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.strNroIdPaciente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Telefono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.intIdProcedimiento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EPS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.strObservacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.strProfesional = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.intIdUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.intIdUsuarioCancela = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblCitaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.FechaCheckBox = New System.Windows.Forms.CheckBox()
        Me.ButtonBuscar = New System.Windows.Forms.Button()
        Me.CheckBoxPaciente = New System.Windows.Forms.CheckBox()
        Me.CheckBoxProfesional = New System.Windows.Forms.CheckBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TextBoxPaciente = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBoxProfesional = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DateTimePickerFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.TblCitaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.EstadoToolStripComboBox = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripComboBoxSede = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButtonCancelarCita = New System.Windows.Forms.ToolStripButton()
        Me.CancelarContextMenuStrip.SuspendLayout()
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCitaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCitaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.TblCitaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCitaBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'CancelarContextMenuStrip
        '
        Me.CancelarContextMenuStrip.Enabled = False
        Me.CancelarContextMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CancelarCitaToolStripMenuItem, Me.ConfirmaCitaToolStripMenuItem})
        Me.CancelarContextMenuStrip.Name = "CancelarContextMenuStrip"
        Me.CancelarContextMenuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.CancelarContextMenuStrip.Size = New System.Drawing.Size(149, 48)
        Me.CancelarContextMenuStrip.Text = "Cancelar"
        '
        'CancelarCitaToolStripMenuItem
        '
        Me.CancelarCitaToolStripMenuItem.Enabled = False
        Me.CancelarCitaToolStripMenuItem.Name = "CancelarCitaToolStripMenuItem"
        Me.CancelarCitaToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.CancelarCitaToolStripMenuItem.Text = "Cancelar Cita"
        '
        'ConfirmaCitaToolStripMenuItem
        '
        Me.ConfirmaCitaToolStripMenuItem.Enabled = False
        Me.ConfirmaCitaToolStripMenuItem.Name = "ConfirmaCitaToolStripMenuItem"
        Me.ConfirmaCitaToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.ConfirmaCitaToolStripMenuItem.Text = "Confirma Cita"
        Me.ConfirmaCitaToolStripMenuItem.Visible = False
        '
        'TblEmpeadoBindingSource
        '
        Me.TblEmpeadoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblEmpeados)
        '
        'TblCitaDataGridView
        '
        Me.TblCitaDataGridView.AllowUserToAddRows = False
        Me.TblCitaDataGridView.AllowUserToDeleteRows = False
        Me.TblCitaDataGridView.AllowUserToOrderColumns = True
        Me.TblCitaDataGridView.AutoGenerateColumns = False
        Me.TblCitaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblCitaDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Seleccion, Me.DataGridViewTextBoxColumn6, Me.dtmFecha, Me.DataGridViewTextBoxColumn10, Me.strNroIdPaciente, Me.DataGridViewTextBoxColumn1, Me.Telefono, Me.intIdProcedimiento, Me.EPS, Me.strObservacion, Me.strProfesional, Me.intIdUsuario, Me.intIdUsuarioCancela})
        Me.TblCitaDataGridView.ContextMenuStrip = Me.CancelarContextMenuStrip
        Me.TblCitaDataGridView.DataSource = Me.TblCitaBindingSource
        Me.TblCitaDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblCitaDataGridView.Location = New System.Drawing.Point(0, 75)
        Me.TblCitaDataGridView.Name = "TblCitaDataGridView"
        Me.TblCitaDataGridView.RowHeadersVisible = False
        Me.TblCitaDataGridView.Size = New System.Drawing.Size(884, 328)
        Me.TblCitaDataGridView.TabIndex = 4
        '
        'Seleccion
        '
        Me.Seleccion.FalseValue = "false"
        Me.Seleccion.HeaderText = ""
        Me.Seleccion.IndeterminateValue = "null"
        Me.Seleccion.Name = "Seleccion"
        Me.Seleccion.TrueValue = "true"
        Me.Seleccion.Width = 30
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "dtmHora"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Hora"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Width = 70
        '
        'dtmFecha
        '
        Me.dtmFecha.DataPropertyName = "dtmFecha"
        DataGridViewCellStyle1.Format = "d"
        DataGridViewCellStyle1.NullValue = Nothing
        Me.dtmFecha.DefaultCellStyle = DataGridViewCellStyle1
        Me.dtmFecha.HeaderText = "Fecha"
        Me.dtmFecha.Name = "dtmFecha"
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "intIdEstadoCita"
        Me.DataGridViewTextBoxColumn10.HeaderText = "Estado"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn10.Width = 80
        '
        'strNroIdPaciente
        '
        Me.strNroIdPaciente.DataPropertyName = "strNroIdPaciente"
        Me.strNroIdPaciente.HeaderText = "Nro Identificación"
        Me.strNroIdPaciente.Name = "strNroIdPaciente"
        Me.strNroIdPaciente.ReadOnly = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "strNombrePaciente"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Paciente"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 200
        '
        'Telefono
        '
        Me.Telefono.DataPropertyName = "strTelefonos"
        Me.Telefono.HeaderText = "Telefono"
        Me.Telefono.Name = "Telefono"
        Me.Telefono.ReadOnly = True
        '
        'intIdProcedimiento
        '
        Me.intIdProcedimiento.DataPropertyName = "strProcedimiento"
        Me.intIdProcedimiento.HeaderText = "Procedimiento"
        Me.intIdProcedimiento.Name = "intIdProcedimiento"
        Me.intIdProcedimiento.ReadOnly = True
        Me.intIdProcedimiento.Width = 250
        '
        'EPS
        '
        Me.EPS.DataPropertyName = "strEPS"
        Me.EPS.HeaderText = "EPS"
        Me.EPS.Name = "EPS"
        Me.EPS.ReadOnly = True
        Me.EPS.Width = 150
        '
        'strObservacion
        '
        Me.strObservacion.DataPropertyName = "strObservacion"
        Me.strObservacion.HeaderText = "Observación"
        Me.strObservacion.Name = "strObservacion"
        Me.strObservacion.ReadOnly = True
        Me.strObservacion.Width = 250
        '
        'strProfesional
        '
        Me.strProfesional.DataPropertyName = "strProfesional"
        Me.strProfesional.HeaderText = "Profesional"
        Me.strProfesional.Name = "strProfesional"
        Me.strProfesional.ReadOnly = True
        Me.strProfesional.Width = 250
        '
        'intIdUsuario
        '
        Me.intIdUsuario.DataPropertyName = "strUsuario"
        Me.intIdUsuario.HeaderText = "Usuario"
        Me.intIdUsuario.Name = "intIdUsuario"
        Me.intIdUsuario.ReadOnly = True
        Me.intIdUsuario.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'intIdUsuarioCancela
        '
        Me.intIdUsuarioCancela.DataPropertyName = "strUsuarioCancela"
        Me.intIdUsuarioCancela.HeaderText = "Usuario Cancela"
        Me.intIdUsuarioCancela.Name = "intIdUsuarioCancela"
        Me.intIdUsuarioCancela.ReadOnly = True
        Me.intIdUsuarioCancela.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.intIdUsuarioCancela.Width = 120
        '
        'TblCitaBindingSource
        '
        Me.TblCitaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCita)
        '
        'FechaCheckBox
        '
        Me.FechaCheckBox.AutoSize = True
        Me.FechaCheckBox.Checked = True
        Me.FechaCheckBox.CheckState = System.Windows.Forms.CheckState.Checked
        Me.FechaCheckBox.Location = New System.Drawing.Point(157, 15)
        Me.FechaCheckBox.Name = "FechaCheckBox"
        Me.FechaCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.FechaCheckBox.TabIndex = 9
        Me.FechaCheckBox.UseVisualStyleBackColor = True
        '
        'ButtonBuscar
        '
        Me.ButtonBuscar.Location = New System.Drawing.Point(793, 9)
        Me.ButtonBuscar.Name = "ButtonBuscar"
        Me.ButtonBuscar.Size = New System.Drawing.Size(75, 23)
        Me.ButtonBuscar.TabIndex = 8
        Me.ButtonBuscar.Text = "Buscar..."
        Me.ButtonBuscar.UseVisualStyleBackColor = True
        '
        'CheckBoxPaciente
        '
        Me.CheckBoxPaciente.AutoSize = True
        Me.CheckBoxPaciente.Location = New System.Drawing.Point(754, 15)
        Me.CheckBoxPaciente.Name = "CheckBoxPaciente"
        Me.CheckBoxPaciente.Size = New System.Drawing.Size(15, 14)
        Me.CheckBoxPaciente.TabIndex = 7
        Me.CheckBoxPaciente.UseVisualStyleBackColor = True
        '
        'CheckBoxProfesional
        '
        Me.CheckBoxProfesional.AutoSize = True
        Me.CheckBoxProfesional.Checked = True
        Me.CheckBoxProfesional.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBoxProfesional.Location = New System.Drawing.Point(542, 15)
        Me.CheckBoxProfesional.Name = "CheckBoxProfesional"
        Me.CheckBoxProfesional.Size = New System.Drawing.Size(15, 14)
        Me.CheckBoxProfesional.TabIndex = 6
        Me.CheckBoxProfesional.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.FechaCheckBox)
        Me.Panel1.Controls.Add(Me.ButtonBuscar)
        Me.Panel1.Controls.Add(Me.CheckBoxPaciente)
        Me.Panel1.Controls.Add(Me.CheckBoxProfesional)
        Me.Panel1.Controls.Add(Me.TextBoxPaciente)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.ComboBoxProfesional)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.DateTimePickerFecha)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 25)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(884, 50)
        Me.Panel1.TabIndex = 5
        '
        'TextBoxPaciente
        '
        Me.TextBoxPaciente.Enabled = False
        Me.TextBoxPaciente.Location = New System.Drawing.Point(631, 12)
        Me.TextBoxPaciente.Name = "TextBoxPaciente"
        Me.TextBoxPaciente.Size = New System.Drawing.Size(119, 20)
        Me.TextBoxPaciente.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(573, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Paciente:"
        '
        'ComboBoxProfesional
        '
        Me.ComboBoxProfesional.DataSource = Me.TblEmpeadoBindingSource
        Me.ComboBoxProfesional.DisplayMember = "strNombreEmpleado"
        Me.ComboBoxProfesional.FormattingEnabled = True
        Me.ComboBoxProfesional.Location = New System.Drawing.Point(252, 11)
        Me.ComboBoxProfesional.Name = "ComboBoxProfesional"
        Me.ComboBoxProfesional.Size = New System.Drawing.Size(283, 21)
        Me.ComboBoxProfesional.TabIndex = 3
        Me.ComboBoxProfesional.ValueMember = "intIdCodigoEmpleado"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(187, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Profesional"
        '
        'DateTimePickerFecha
        '
        Me.DateTimePickerFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePickerFecha.Location = New System.Drawing.Point(59, 11)
        Me.DateTimePickerFecha.Name = "DateTimePickerFecha"
        Me.DateTimePickerFecha.Size = New System.Drawing.Size(92, 20)
        Me.DateTimePickerFecha.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Fecha:"
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'TblCitaBindingNavigator
        '
        Me.TblCitaBindingNavigator.AddNewItem = Nothing
        Me.TblCitaBindingNavigator.BindingSource = Me.TblCitaBindingSource
        Me.TblCitaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblCitaBindingNavigator.DeleteItem = Nothing
        Me.TblCitaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.ToolStripLabel1, Me.EstadoToolStripComboBox, Me.ToolStripSeparator2, Me.ToolStripLabel2, Me.ToolStripComboBoxSede, Me.ToolStripSeparator1, Me.ToolStripButtonCancelarCita})
        Me.TblCitaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCitaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblCitaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblCitaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblCitaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblCitaBindingNavigator.Name = "TblCitaBindingNavigator"
        Me.TblCitaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblCitaBindingNavigator.Size = New System.Drawing.Size(884, 25)
        Me.TblCitaBindingNavigator.TabIndex = 3
        Me.TblCitaBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(75, 22)
        Me.ToolStripLabel1.Text = "Estado Cita:  "
        '
        'EstadoToolStripComboBox
        '
        Me.EstadoToolStripComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.EstadoToolStripComboBox.Items.AddRange(New Object() {"Pendientes", "Cumplidas", "Canceladas"})
        Me.EstadoToolStripComboBox.Name = "EstadoToolStripComboBox"
        Me.EstadoToolStripComboBox.Size = New System.Drawing.Size(121, 25)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(41, 22)
        Me.ToolStripLabel2.Text = "Sede:  "
        '
        'ToolStripComboBoxSede
        '
        Me.ToolStripComboBoxSede.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ToolStripComboBoxSede.Name = "ToolStripComboBoxSede"
        Me.ToolStripComboBoxSede.Size = New System.Drawing.Size(121, 25)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButtonCancelarCita
        '
        Me.ToolStripButtonCancelarCita.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButtonCancelarCita.Image = CType(resources.GetObject("ToolStripButtonCancelarCita.Image"), System.Drawing.Image)
        Me.ToolStripButtonCancelarCita.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButtonCancelarCita.Name = "ToolStripButtonCancelarCita"
        Me.ToolStripButtonCancelarCita.Size = New System.Drawing.Size(86, 22)
        Me.ToolStripButtonCancelarCita.Text = "Cancelar Citas"
        '
        'FrmCancelacionCita
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 403)
        Me.Controls.Add(Me.TblCitaDataGridView)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TblCitaBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmCancelacionCita"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cancelacion Cita"
        Me.CancelarContextMenuStrip.ResumeLayout(False)
        CType(Me.TblEmpeadoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCitaDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCitaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.TblCitaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCitaBindingNavigator.ResumeLayout(False)
        Me.TblCitaBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CancelarContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CancelarCitaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ConfirmaCitaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TblEmpeadoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCitaDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblCitaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents FechaCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents ButtonBuscar As System.Windows.Forms.Button
    Friend WithEvents CheckBoxPaciente As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBoxProfesional As System.Windows.Forms.CheckBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TextBoxPaciente As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboBoxProfesional As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents DateTimePickerFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TblCitaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents EstadoToolStripComboBox As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripComboBoxSede As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButtonCancelarCita As System.Windows.Forms.ToolStripButton
    Friend WithEvents Seleccion As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dtmFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents strNroIdPaciente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Telefono As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIdProcedimiento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents EPS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents strObservacion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents strProfesional As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIdUsuario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents intIdUsuarioCancela As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
