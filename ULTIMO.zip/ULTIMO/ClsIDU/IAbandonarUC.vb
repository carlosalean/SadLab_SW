﻿Public Interface IAbandonarUC
    Sub prGuardar()
End Interface
