﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmTurnos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim BitDomingoLabel As System.Windows.Forms.Label
        Dim BitJuevesLabel As System.Windows.Forms.Label
        Dim BitLunesLabel As System.Windows.Forms.Label
        Dim BitMartesLabel As System.Windows.Forms.Label
        Dim BitMiercolesLabel As System.Windows.Forms.Label
        Dim BitSabadoLabel As System.Windows.Forms.Label
        Dim BitViernesLabel As System.Windows.Forms.Label
        Dim IntIdTurnoLabel As System.Windows.Forms.Label
        Dim StrNombreLabel As System.Windows.Forms.Label
        Dim TmHoraFinLabel As System.Windows.Forms.Label
        Dim TmHoraInicioLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmTurnos))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TblTurnoDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TblTurnoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.TmHoraInicioDateTimePicker = New ClsUtilidades.ClsDateTimePicker
        Me.TmHoraFinDateTimePicker = New ClsUtilidades.ClsDateTimePicker
        Me.BitDomingoCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitJuevesCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitLunesCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitMartesCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitMiercolesCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitSabadoCheckBox = New ClsUtilidades.ClsCheckBox
        Me.BitViernesCheckBox = New ClsUtilidades.ClsCheckBox
        Me.IntIdTurnoTextBox = New ClsUtilidades.ClsTextBox
        Me.StrNombreTextBox = New ClsUtilidades.ClsTextBox
        Me.TblTurnoBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.TblTurnoBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        BitDomingoLabel = New System.Windows.Forms.Label
        BitJuevesLabel = New System.Windows.Forms.Label
        BitLunesLabel = New System.Windows.Forms.Label
        BitMartesLabel = New System.Windows.Forms.Label
        BitMiercolesLabel = New System.Windows.Forms.Label
        BitSabadoLabel = New System.Windows.Forms.Label
        BitViernesLabel = New System.Windows.Forms.Label
        IntIdTurnoLabel = New System.Windows.Forms.Label
        StrNombreLabel = New System.Windows.Forms.Label
        TmHoraFinLabel = New System.Windows.Forms.Label
        TmHoraInicioLabel = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblTurnoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTurnoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblTurnoBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblTurnoBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'BitDomingoLabel
        '
        BitDomingoLabel.AutoSize = True
        BitDomingoLabel.Location = New System.Drawing.Point(242, 201)
        BitDomingoLabel.Name = "BitDomingoLabel"
        BitDomingoLabel.Size = New System.Drawing.Size(52, 13)
        BitDomingoLabel.TabIndex = 0
        BitDomingoLabel.Text = "Domingo:"
        '
        'BitJuevesLabel
        '
        BitJuevesLabel.AutoSize = True
        BitJuevesLabel.Location = New System.Drawing.Point(42, 231)
        BitJuevesLabel.Name = "BitJuevesLabel"
        BitJuevesLabel.Size = New System.Drawing.Size(44, 13)
        BitJuevesLabel.TabIndex = 2
        BitJuevesLabel.Text = "Jueves:"
        '
        'BitLunesLabel
        '
        BitLunesLabel.AutoSize = True
        BitLunesLabel.Location = New System.Drawing.Point(42, 141)
        BitLunesLabel.Name = "BitLunesLabel"
        BitLunesLabel.Size = New System.Drawing.Size(39, 13)
        BitLunesLabel.TabIndex = 4
        BitLunesLabel.Text = "Lunes:"
        '
        'BitMartesLabel
        '
        BitMartesLabel.AutoSize = True
        BitMartesLabel.Location = New System.Drawing.Point(42, 171)
        BitMartesLabel.Name = "BitMartesLabel"
        BitMartesLabel.Size = New System.Drawing.Size(42, 13)
        BitMartesLabel.TabIndex = 6
        BitMartesLabel.Text = "Martes:"
        '
        'BitMiercolesLabel
        '
        BitMiercolesLabel.AutoSize = True
        BitMiercolesLabel.Location = New System.Drawing.Point(42, 201)
        BitMiercolesLabel.Name = "BitMiercolesLabel"
        BitMiercolesLabel.Size = New System.Drawing.Size(55, 13)
        BitMiercolesLabel.TabIndex = 8
        BitMiercolesLabel.Text = "Miercoles:"
        '
        'BitSabadoLabel
        '
        BitSabadoLabel.AutoSize = True
        BitSabadoLabel.Location = New System.Drawing.Point(242, 171)
        BitSabadoLabel.Name = "BitSabadoLabel"
        BitSabadoLabel.Size = New System.Drawing.Size(47, 13)
        BitSabadoLabel.TabIndex = 10
        BitSabadoLabel.Text = "Sabado:"
        '
        'BitViernesLabel
        '
        BitViernesLabel.AutoSize = True
        BitViernesLabel.Location = New System.Drawing.Point(242, 141)
        BitViernesLabel.Name = "BitViernesLabel"
        BitViernesLabel.Size = New System.Drawing.Size(45, 13)
        BitViernesLabel.TabIndex = 12
        BitViernesLabel.Text = "Viernes:"
        '
        'IntIdTurnoLabel
        '
        IntIdTurnoLabel.AutoSize = True
        IntIdTurnoLabel.Location = New System.Drawing.Point(41, 26)
        IntIdTurnoLabel.Name = "IntIdTurnoLabel"
        IntIdTurnoLabel.Size = New System.Drawing.Size(19, 13)
        IntIdTurnoLabel.TabIndex = 14
        IntIdTurnoLabel.Text = "Id:"
        '
        'StrNombreLabel
        '
        StrNombreLabel.AutoSize = True
        StrNombreLabel.Location = New System.Drawing.Point(41, 52)
        StrNombreLabel.Name = "StrNombreLabel"
        StrNombreLabel.Size = New System.Drawing.Size(47, 13)
        StrNombreLabel.TabIndex = 16
        StrNombreLabel.Text = "Nombre:"
        '
        'TmHoraFinLabel
        '
        TmHoraFinLabel.AutoSize = True
        TmHoraFinLabel.Location = New System.Drawing.Point(41, 104)
        TmHoraFinLabel.Name = "TmHoraFinLabel"
        TmHoraFinLabel.Size = New System.Drawing.Size(50, 13)
        TmHoraFinLabel.TabIndex = 18
        TmHoraFinLabel.Text = "Hora Fin:"
        '
        'TmHoraInicioLabel
        '
        TmHoraInicioLabel.AutoSize = True
        TmHoraInicioLabel.Location = New System.Drawing.Point(41, 78)
        TmHoraInicioLabel.Name = "TmHoraInicioLabel"
        TmHoraInicioLabel.Size = New System.Drawing.Size(61, 13)
        TmHoraInicioLabel.TabIndex = 20
        TmHoraInicioLabel.Text = "Hora Inicio:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(668, 296)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TblTurnoDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(660, 270)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblTurnoDataGridView
        '
        Me.TblTurnoDataGridView.AllowUserToAddRows = False
        Me.TblTurnoDataGridView.AllowUserToDeleteRows = False
        Me.TblTurnoDataGridView.AllowUserToOrderColumns = True
        Me.TblTurnoDataGridView.AutoGenerateColumns = False
        Me.TblTurnoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblTurnoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.TblTurnoDataGridView.DataSource = Me.TblTurnoBindingSource
        Me.TblTurnoDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblTurnoDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblTurnoDataGridView.Name = "TblTurnoDataGridView"
        Me.TblTurnoDataGridView.ReadOnly = True
        Me.TblTurnoDataGridView.Size = New System.Drawing.Size(654, 264)
        Me.TblTurnoDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdTurno"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strNombre"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 450
        '
        'TblTurnoBindingSource
        '
        Me.TblTurnoBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblTurno)
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.Controls.Add(Me.TmHoraInicioDateTimePicker)
        Me.TabPage2.Controls.Add(Me.TmHoraFinDateTimePicker)
        Me.TabPage2.Controls.Add(BitDomingoLabel)
        Me.TabPage2.Controls.Add(Me.BitDomingoCheckBox)
        Me.TabPage2.Controls.Add(BitJuevesLabel)
        Me.TabPage2.Controls.Add(Me.BitJuevesCheckBox)
        Me.TabPage2.Controls.Add(BitLunesLabel)
        Me.TabPage2.Controls.Add(Me.BitLunesCheckBox)
        Me.TabPage2.Controls.Add(BitMartesLabel)
        Me.TabPage2.Controls.Add(Me.BitMartesCheckBox)
        Me.TabPage2.Controls.Add(BitMiercolesLabel)
        Me.TabPage2.Controls.Add(Me.BitMiercolesCheckBox)
        Me.TabPage2.Controls.Add(BitSabadoLabel)
        Me.TabPage2.Controls.Add(Me.BitSabadoCheckBox)
        Me.TabPage2.Controls.Add(BitViernesLabel)
        Me.TabPage2.Controls.Add(Me.BitViernesCheckBox)
        Me.TabPage2.Controls.Add(IntIdTurnoLabel)
        Me.TabPage2.Controls.Add(Me.IntIdTurnoTextBox)
        Me.TabPage2.Controls.Add(StrNombreLabel)
        Me.TabPage2.Controls.Add(Me.StrNombreTextBox)
        Me.TabPage2.Controls.Add(TmHoraFinLabel)
        Me.TabPage2.Controls.Add(TmHoraInicioLabel)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(660, 270)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TmHoraInicioDateTimePicker
        '
        Me.TmHoraInicioDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblTurnoBindingSource, "tmHoraInicio", True))
        Me.TmHoraInicioDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.TmHoraInicioDateTimePicker.Location = New System.Drawing.Point(123, 75)
        Me.TmHoraInicioDateTimePicker.Name = "TmHoraInicioDateTimePicker"
        Me.TmHoraInicioDateTimePicker.Size = New System.Drawing.Size(75, 20)
        Me.TmHoraInicioDateTimePicker.TabIndex = 2
        '
        'TmHoraFinDateTimePicker
        '
        Me.TmHoraFinDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.TblTurnoBindingSource, "tmHoraFin", True))
        Me.TmHoraFinDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.TmHoraFinDateTimePicker.Location = New System.Drawing.Point(122, 104)
        Me.TmHoraFinDateTimePicker.Name = "TmHoraFinDateTimePicker"
        Me.TmHoraFinDateTimePicker.Size = New System.Drawing.Size(76, 20)
        Me.TmHoraFinDateTimePicker.TabIndex = 3
        '
        'BitDomingoCheckBox
        '
        Me.BitDomingoCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblTurnoBindingSource, "bitDomingo", True))
        Me.BitDomingoCheckBox.Location = New System.Drawing.Point(323, 196)
        Me.BitDomingoCheckBox.Name = "BitDomingoCheckBox"
        Me.BitDomingoCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.BitDomingoCheckBox.TabIndex = 10
        Me.BitDomingoCheckBox.UseVisualStyleBackColor = True
        '
        'BitJuevesCheckBox
        '
        Me.BitJuevesCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblTurnoBindingSource, "bitJueves", True))
        Me.BitJuevesCheckBox.Location = New System.Drawing.Point(123, 226)
        Me.BitJuevesCheckBox.Name = "BitJuevesCheckBox"
        Me.BitJuevesCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.BitJuevesCheckBox.TabIndex = 7
        Me.BitJuevesCheckBox.UseVisualStyleBackColor = True
        '
        'BitLunesCheckBox
        '
        Me.BitLunesCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblTurnoBindingSource, "bitLunes", True))
        Me.BitLunesCheckBox.Location = New System.Drawing.Point(123, 136)
        Me.BitLunesCheckBox.Name = "BitLunesCheckBox"
        Me.BitLunesCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.BitLunesCheckBox.TabIndex = 4
        Me.BitLunesCheckBox.UseVisualStyleBackColor = True
        '
        'BitMartesCheckBox
        '
        Me.BitMartesCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblTurnoBindingSource, "bitMartes", True))
        Me.BitMartesCheckBox.Location = New System.Drawing.Point(123, 166)
        Me.BitMartesCheckBox.Name = "BitMartesCheckBox"
        Me.BitMartesCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.BitMartesCheckBox.TabIndex = 5
        Me.BitMartesCheckBox.UseVisualStyleBackColor = True
        '
        'BitMiercolesCheckBox
        '
        Me.BitMiercolesCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblTurnoBindingSource, "bitMiercoles", True))
        Me.BitMiercolesCheckBox.Location = New System.Drawing.Point(123, 196)
        Me.BitMiercolesCheckBox.Name = "BitMiercolesCheckBox"
        Me.BitMiercolesCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.BitMiercolesCheckBox.TabIndex = 6
        Me.BitMiercolesCheckBox.UseVisualStyleBackColor = True
        '
        'BitSabadoCheckBox
        '
        Me.BitSabadoCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblTurnoBindingSource, "bitSabado", True))
        Me.BitSabadoCheckBox.Location = New System.Drawing.Point(323, 166)
        Me.BitSabadoCheckBox.Name = "BitSabadoCheckBox"
        Me.BitSabadoCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.BitSabadoCheckBox.TabIndex = 9
        Me.BitSabadoCheckBox.UseVisualStyleBackColor = True
        '
        'BitViernesCheckBox
        '
        Me.BitViernesCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblTurnoBindingSource, "bitViernes", True))
        Me.BitViernesCheckBox.Location = New System.Drawing.Point(323, 136)
        Me.BitViernesCheckBox.Name = "BitViernesCheckBox"
        Me.BitViernesCheckBox.Size = New System.Drawing.Size(104, 24)
        Me.BitViernesCheckBox.TabIndex = 8
        Me.BitViernesCheckBox.UseVisualStyleBackColor = True
        '
        'IntIdTurnoTextBox
        '
        Me.IntIdTurnoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblTurnoBindingSource, "intIdTurno", True))
        Me.IntIdTurnoTextBox.DataSource = Nothing
        Me.IntIdTurnoTextBox.Enabled = False
        Me.IntIdTurnoTextBox.Location = New System.Drawing.Point(122, 23)
        Me.IntIdTurnoTextBox.Name = "IntIdTurnoTextBox"
        Me.IntIdTurnoTextBox.NombreCodigoF2 = Nothing
        Me.IntIdTurnoTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdTurnoTextBox.Size = New System.Drawing.Size(44, 20)
        Me.IntIdTurnoTextBox.TabIndex = 0
        Me.IntIdTurnoTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrNombreTextBox
        '
        Me.StrNombreTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblTurnoBindingSource, "strNombre", True))
        Me.StrNombreTextBox.DataSource = Nothing
        Me.StrNombreTextBox.Location = New System.Drawing.Point(122, 49)
        Me.StrNombreTextBox.Name = "StrNombreTextBox"
        Me.StrNombreTextBox.NombreCodigoF2 = Nothing
        Me.StrNombreTextBox.NombreDescripcionF2 = Nothing
        Me.StrNombreTextBox.Size = New System.Drawing.Size(482, 20)
        Me.StrNombreTextBox.TabIndex = 1
        Me.StrNombreTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblTurnoBindingNavigator
        '
        Me.TblTurnoBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblTurnoBindingNavigator.BindingSource = Me.TblTurnoBindingSource
        Me.TblTurnoBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblTurnoBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblTurnoBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblTurnoBindingNavigatorSaveItem})
        Me.TblTurnoBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblTurnoBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblTurnoBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblTurnoBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblTurnoBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblTurnoBindingNavigator.Name = "TblTurnoBindingNavigator"
        Me.TblTurnoBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblTurnoBindingNavigator.Size = New System.Drawing.Size(668, 25)
        Me.TblTurnoBindingNavigator.TabIndex = 2
        Me.TblTurnoBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(38, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblTurnoBindingNavigatorSaveItem
        '
        Me.TblTurnoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblTurnoBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblTurnoBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblTurnoBindingNavigatorSaveItem.Name = "TblTurnoBindingNavigatorSaveItem"
        Me.TblTurnoBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblTurnoBindingNavigatorSaveItem.Text = "Save Data"
        '
        'FrmTurnos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(668, 321)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblTurnoBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmTurnos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Turnos"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblTurnoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTurnoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblTurnoBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblTurnoBindingNavigator.ResumeLayout(False)
        Me.TblTurnoBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents TabControl1 As System.Windows.Forms.TabControl
    Public WithEvents TabPage1 As System.Windows.Forms.TabPage
    Public WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblTurnoDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblTurnoBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblTurnoBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblTurnoBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BitDomingoCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitJuevesCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitLunesCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitMartesCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitMiercolesCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitSabadoCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents BitViernesCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents IntIdTurnoTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNombreTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents TmHoraInicioDateTimePicker As ClsUtilidades.ClsDateTimePicker
    Friend WithEvents TmHoraFinDateTimePicker As ClsUtilidades.ClsDateTimePicker
End Class
