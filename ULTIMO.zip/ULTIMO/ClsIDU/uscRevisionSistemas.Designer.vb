﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uscRevisionSistemas
    Inherits System.Windows.Forms.UserControl

    'UserControl reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uscRevisionSistemas))
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.bitValorBoolNoRadioButton = New System.Windows.Forms.RadioButton
        Me.bitValorBoolSiRadioButton = New System.Windows.Forms.RadioButton
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.btnGuardar = New System.Windows.Forms.Button
        Me.btnContraer = New System.Windows.Forms.Button
        Me.btnExpandir = New System.Windows.Forms.Button
        Me.btnRevisar = New System.Windows.Forms.Button
        Me.txtTitulo = New System.Windows.Forms.TextBox
        Me.TreeViewSistemas = New System.Windows.Forms.TreeView
        Me.ImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.btnBorrar = New System.Windows.Forms.Button
        Me.ObservacionesClsTextBox = New System.Windows.Forms.TextBox
        Me.ValorNumClsTextBox = New ClsUtilidades.ClsTextBox
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(359, 150)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 13)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "Observaciones: "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(554, 111)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 13)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Valor: "
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.bitValorBoolNoRadioButton)
        Me.Panel2.Controls.Add(Me.bitValorBoolSiRadioButton)
        Me.Panel2.Location = New System.Drawing.Point(439, 100)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(109, 39)
        Me.Panel2.TabIndex = 25
        '
        'bitValorBoolNoRadioButton
        '
        Me.bitValorBoolNoRadioButton.AutoSize = True
        Me.bitValorBoolNoRadioButton.Location = New System.Drawing.Point(65, 11)
        Me.bitValorBoolNoRadioButton.Name = "bitValorBoolNoRadioButton"
        Me.bitValorBoolNoRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.bitValorBoolNoRadioButton.TabIndex = 1
        Me.bitValorBoolNoRadioButton.TabStop = True
        Me.bitValorBoolNoRadioButton.Text = "No"
        Me.bitValorBoolNoRadioButton.UseVisualStyleBackColor = True
        '
        'bitValorBoolSiRadioButton
        '
        Me.bitValorBoolSiRadioButton.AutoSize = True
        Me.bitValorBoolSiRadioButton.Location = New System.Drawing.Point(3, 11)
        Me.bitValorBoolSiRadioButton.Name = "bitValorBoolSiRadioButton"
        Me.bitValorBoolSiRadioButton.Size = New System.Drawing.Size(34, 17)
        Me.bitValorBoolSiRadioButton.TabIndex = 0
        Me.bitValorBoolSiRadioButton.TabStop = True
        Me.bitValorBoolSiRadioButton.Text = "Si"
        Me.bitValorBoolSiRadioButton.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.btnGuardar)
        Me.Panel1.Controls.Add(Me.btnContraer)
        Me.Panel1.Controls.Add(Me.btnExpandir)
        Me.Panel1.Controls.Add(Me.btnRevisar)
        Me.Panel1.Location = New System.Drawing.Point(362, 335)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(370, 120)
        Me.Panel1.TabIndex = 24
        '
        'btnGuardar
        '
        Me.btnGuardar.Image = Global.ClsIDU.My.Resources.Resources._16__Save_
        Me.btnGuardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnGuardar.Location = New System.Drawing.Point(182, 42)
        Me.btnGuardar.Name = "btnGuardar"
        Me.btnGuardar.Size = New System.Drawing.Size(138, 25)
        Me.btnGuardar.TabIndex = 17
        Me.btnGuardar.Text = "Guardar"
        Me.btnGuardar.UseVisualStyleBackColor = True
        '
        'btnContraer
        '
        Me.btnContraer.Location = New System.Drawing.Point(182, 10)
        Me.btnContraer.Name = "btnContraer"
        Me.btnContraer.Size = New System.Drawing.Size(138, 25)
        Me.btnContraer.TabIndex = 16
        Me.btnContraer.Text = "Contraer Lista"
        Me.btnContraer.UseVisualStyleBackColor = True
        '
        'btnExpandir
        '
        Me.btnExpandir.Location = New System.Drawing.Point(43, 10)
        Me.btnExpandir.Name = "btnExpandir"
        Me.btnExpandir.Size = New System.Drawing.Size(138, 25)
        Me.btnExpandir.TabIndex = 14
        Me.btnExpandir.Text = "Expandir Lista"
        Me.btnExpandir.UseVisualStyleBackColor = True
        '
        'btnRevisar
        '
        Me.btnRevisar.Image = Global.ClsIDU.My.Resources.Resources._16__Edit_3_
        Me.btnRevisar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnRevisar.Location = New System.Drawing.Point(43, 42)
        Me.btnRevisar.Name = "btnRevisar"
        Me.btnRevisar.Size = New System.Drawing.Size(138, 25)
        Me.btnRevisar.TabIndex = 15
        Me.btnRevisar.Text = "Revisar Información"
        Me.btnRevisar.UseVisualStyleBackColor = True
        '
        'txtTitulo
        '
        Me.txtTitulo.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.txtTitulo.Location = New System.Drawing.Point(362, 11)
        Me.txtTitulo.Name = "txtTitulo"
        Me.txtTitulo.ReadOnly = True
        Me.txtTitulo.Size = New System.Drawing.Size(370, 20)
        Me.txtTitulo.TabIndex = 23
        Me.txtTitulo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TreeViewSistemas
        '
        Me.TreeViewSistemas.HideSelection = False
        Me.TreeViewSistemas.ImageIndex = 0
        Me.TreeViewSistemas.ImageList = Me.ImageList
        Me.TreeViewSistemas.Location = New System.Drawing.Point(15, 10)
        Me.TreeViewSistemas.Name = "TreeViewSistemas"
        Me.TreeViewSistemas.SelectedImageIndex = 0
        Me.TreeViewSistemas.Size = New System.Drawing.Size(338, 446)
        Me.TreeViewSistemas.TabIndex = 21
        '
        'ImageList
        '
        Me.ImageList.ImageStream = CType(resources.GetObject("ImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList.Images.SetKeyName(0, "tree_folder.png")
        Me.ImageList.Images.SetKeyName(1, "books_016.gif")
        Me.ImageList.Images.SetKeyName(2, "2.ico")
        Me.ImageList.Images.SetKeyName(3, "wi0054-24.png")
        '
        'btnBorrar
        '
        Me.btnBorrar.Image = Global.ClsIDU.My.Resources.Resources._16__Delete_
        Me.btnBorrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnBorrar.Location = New System.Drawing.Point(406, 103)
        Me.btnBorrar.Name = "btnBorrar"
        Me.btnBorrar.Size = New System.Drawing.Size(27, 26)
        Me.btnBorrar.TabIndex = 26
        Me.btnBorrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnBorrar.UseVisualStyleBackColor = True
        '
        'ObservacionesClsTextBox
        '
        Me.ObservacionesClsTextBox.Location = New System.Drawing.Point(362, 166)
        Me.ObservacionesClsTextBox.Multiline = True
        Me.ObservacionesClsTextBox.Name = "ObservacionesClsTextBox"
        Me.ObservacionesClsTextBox.ReadOnly = True
        Me.ObservacionesClsTextBox.Size = New System.Drawing.Size(370, 164)
        Me.ObservacionesClsTextBox.TabIndex = 30
        '
        'ValorNumClsTextBox
        '
        Me.ValorNumClsTextBox.DataSource = Nothing
        Me.ValorNumClsTextBox.Location = New System.Drawing.Point(597, 107)
        Me.ValorNumClsTextBox.Name = "ValorNumClsTextBox"
        Me.ValorNumClsTextBox.NombreCodigoF2 = Nothing
        Me.ValorNumClsTextBox.NombreDescripcionF2 = Nothing
        Me.ValorNumClsTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ValorNumClsTextBox.TabIndex = 28
        Me.ValorNumClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'uscRevisionSistemas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.ObservacionesClsTextBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.txtTitulo)
        Me.Controls.Add(Me.TreeViewSistemas)
        Me.Controls.Add(Me.ValorNumClsTextBox)
        Me.Controls.Add(Me.btnBorrar)
        Me.Name = "uscRevisionSistemas"
        Me.Size = New System.Drawing.Size(748, 467)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents bitValorBoolNoRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents bitValorBoolSiRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents btnGuardar As System.Windows.Forms.Button
    Friend WithEvents btnContraer As System.Windows.Forms.Button
    Friend WithEvents btnExpandir As System.Windows.Forms.Button
    Friend WithEvents btnRevisar As System.Windows.Forms.Button
    Friend WithEvents txtTitulo As System.Windows.Forms.TextBox
    Friend WithEvents TreeViewSistemas As System.Windows.Forms.TreeView
    Friend WithEvents ValorNumClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents btnBorrar As System.Windows.Forms.Button
    Friend WithEvents ImageList As System.Windows.Forms.ImageList
    Friend WithEvents ObservacionesClsTextBox As System.Windows.Forms.TextBox

End Class
