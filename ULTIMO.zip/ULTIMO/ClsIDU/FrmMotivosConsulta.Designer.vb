﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMotivosConsulta
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IntIdMotivoConsultaLabel As System.Windows.Forms.Label
        Dim StrDescripcionLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMotivosConsulta))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.TblMotivosConsultaDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TblMotivosConsultaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.IntIdMotivoConsultaClsTextBox = New ClsUtilidades.ClsTextBox
        Me.StrDescripcionClsTextBox = New ClsUtilidades.ClsTextBox
        Me.TblMotivosConsultaBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.TblMotivosConsultaBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        IntIdMotivoConsultaLabel = New System.Windows.Forms.Label
        StrDescripcionLabel = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TblMotivosConsultaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.TblMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblMotivosConsultaBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'IntIdMotivoConsultaLabel
        '
        IntIdMotivoConsultaLabel.AutoSize = True
        IntIdMotivoConsultaLabel.Location = New System.Drawing.Point(20, 20)
        IntIdMotivoConsultaLabel.Name = "IntIdMotivoConsultaLabel"
        IntIdMotivoConsultaLabel.Size = New System.Drawing.Size(22, 13)
        IntIdMotivoConsultaLabel.TabIndex = 0
        IntIdMotivoConsultaLabel.Text = "Id :"
        '
        'StrDescripcionLabel
        '
        StrDescripcionLabel.AutoSize = True
        StrDescripcionLabel.Location = New System.Drawing.Point(20, 46)
        StrDescripcionLabel.Name = "StrDescripcionLabel"
        StrDescripcionLabel.Size = New System.Drawing.Size(69, 13)
        StrDescripcionLabel.TabIndex = 2
        StrDescripcionLabel.Text = "Descripción :"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(502, 178)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TblMotivosConsultaDataGridView)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(494, 152)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Tabla"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TblMotivosConsultaDataGridView
        '
        Me.TblMotivosConsultaDataGridView.AllowUserToAddRows = False
        Me.TblMotivosConsultaDataGridView.AllowUserToDeleteRows = False
        Me.TblMotivosConsultaDataGridView.AutoGenerateColumns = False
        Me.TblMotivosConsultaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblMotivosConsultaDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2})
        Me.TblMotivosConsultaDataGridView.DataSource = Me.TblMotivosConsultaBindingSource
        Me.TblMotivosConsultaDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblMotivosConsultaDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblMotivosConsultaDataGridView.Name = "TblMotivosConsultaDataGridView"
        Me.TblMotivosConsultaDataGridView.ReadOnly = True
        Me.TblMotivosConsultaDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TblMotivosConsultaDataGridView.Size = New System.Drawing.Size(488, 146)
        Me.TblMotivosConsultaDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdMotivoConsulta"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Id"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strDescripcion"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Descripcion"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 345
        '
        'TblMotivosConsultaBindingSource
        '
        Me.TblMotivosConsultaBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblMotivosConsulta)
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(IntIdMotivoConsultaLabel)
        Me.TabPage2.Controls.Add(Me.IntIdMotivoConsultaClsTextBox)
        Me.TabPage2.Controls.Add(StrDescripcionLabel)
        Me.TabPage2.Controls.Add(Me.StrDescripcionClsTextBox)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(494, 152)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Detalle"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'IntIdMotivoConsultaClsTextBox
        '
        Me.IntIdMotivoConsultaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMotivosConsultaBindingSource, "intIdMotivoConsulta", True))
        Me.IntIdMotivoConsultaClsTextBox.DataSource = Nothing
        Me.IntIdMotivoConsultaClsTextBox.Enabled = False
        Me.IntIdMotivoConsultaClsTextBox.Location = New System.Drawing.Point(96, 17)
        Me.IntIdMotivoConsultaClsTextBox.Name = "IntIdMotivoConsultaClsTextBox"
        Me.IntIdMotivoConsultaClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdMotivoConsultaClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdMotivoConsultaClsTextBox.Size = New System.Drawing.Size(66, 20)
        Me.IntIdMotivoConsultaClsTextBox.TabIndex = 1
        Me.IntIdMotivoConsultaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'StrDescripcionClsTextBox
        '
        Me.StrDescripcionClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblMotivosConsultaBindingSource, "strDescripcion", True))
        Me.StrDescripcionClsTextBox.DataSource = Nothing
        Me.StrDescripcionClsTextBox.Location = New System.Drawing.Point(96, 43)
        Me.StrDescripcionClsTextBox.Name = "StrDescripcionClsTextBox"
        Me.StrDescripcionClsTextBox.NombreCodigoF2 = Nothing
        Me.StrDescripcionClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrDescripcionClsTextBox.Size = New System.Drawing.Size(313, 20)
        Me.StrDescripcionClsTextBox.TabIndex = 3
        Me.StrDescripcionClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblMotivosConsultaBindingNavigator
        '
        Me.TblMotivosConsultaBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblMotivosConsultaBindingNavigator.BindingSource = Me.TblMotivosConsultaBindingSource
        Me.TblMotivosConsultaBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblMotivosConsultaBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblMotivosConsultaBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblMotivosConsultaBindingNavigatorSaveItem})
        Me.TblMotivosConsultaBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblMotivosConsultaBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblMotivosConsultaBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblMotivosConsultaBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblMotivosConsultaBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblMotivosConsultaBindingNavigator.Name = "TblMotivosConsultaBindingNavigator"
        Me.TblMotivosConsultaBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblMotivosConsultaBindingNavigator.Size = New System.Drawing.Size(502, 25)
        Me.TblMotivosConsultaBindingNavigator.TabIndex = 1
        Me.TblMotivosConsultaBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(36, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblMotivosConsultaBindingNavigatorSaveItem
        '
        Me.TblMotivosConsultaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblMotivosConsultaBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblMotivosConsultaBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblMotivosConsultaBindingNavigatorSaveItem.Name = "TblMotivosConsultaBindingNavigatorSaveItem"
        Me.TblMotivosConsultaBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblMotivosConsultaBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'FrmMotivosConsulta
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(502, 203)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblMotivosConsultaBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmMotivosConsulta"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Motivos Consulta"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.TblMotivosConsultaDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblMotivosConsultaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.TblMotivosConsultaBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblMotivosConsultaBindingNavigator.ResumeLayout(False)
        Me.TblMotivosConsultaBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TblMotivosConsultaDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblMotivosConsultaBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblMotivosConsultaBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblMotivosConsultaBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IntIdMotivoConsultaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrDescripcionClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
