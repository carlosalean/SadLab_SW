﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCajas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim BitAbiertaLabel As System.Windows.Forms.Label
        Dim IntIdCajasLabel As System.Windows.Forms.Label
        Dim IntIdCuadreLabel As System.Windows.Forms.Label
        Dim StrNombreCajaLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCajas))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.Tabla = New System.Windows.Forms.TabPage
        Me.TblCajasDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TblCajasBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Detalle = New System.Windows.Forms.TabPage
        Me.BitAbiertaClsCheckBox = New ClsUtilidades.ClsCheckBox
        Me.IntIdCajasClsTextBox = New ClsUtilidades.ClsTextBox
        Me.IntIdCuadreClsTextBox = New ClsUtilidades.ClsTextBox
        Me.StrNombreCajaClsTextBox = New ClsUtilidades.ClsTextBox
        Me.TblCajasBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.TblCajasBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        BitAbiertaLabel = New System.Windows.Forms.Label
        IntIdCajasLabel = New System.Windows.Forms.Label
        IntIdCuadreLabel = New System.Windows.Forms.Label
        StrNombreCajaLabel = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.Tabla.SuspendLayout()
        CType(Me.TblCajasDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblCajasBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Detalle.SuspendLayout()
        CType(Me.TblCajasBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TblCajasBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'BitAbiertaLabel
        '
        BitAbiertaLabel.AutoSize = True
        BitAbiertaLabel.Location = New System.Drawing.Point(35, 86)
        BitAbiertaLabel.Name = "BitAbiertaLabel"
        BitAbiertaLabel.Size = New System.Drawing.Size(43, 13)
        BitAbiertaLabel.TabIndex = 0
        BitAbiertaLabel.Text = "Abierta:"
        '
        'IntIdCajasLabel
        '
        IntIdCajasLabel.AutoSize = True
        IntIdCajasLabel.Location = New System.Drawing.Point(35, 32)
        IntIdCajasLabel.Name = "IntIdCajasLabel"
        IntIdCajasLabel.Size = New System.Drawing.Size(48, 13)
        IntIdCajasLabel.TabIndex = 2
        IntIdCajasLabel.Text = "Id Cajas:"
        '
        'IntIdCuadreLabel
        '
        IntIdCuadreLabel.AutoSize = True
        IntIdCuadreLabel.Location = New System.Drawing.Point(35, 117)
        IntIdCuadreLabel.Name = "IntIdCuadreLabel"
        IntIdCuadreLabel.Size = New System.Drawing.Size(56, 13)
        IntIdCuadreLabel.TabIndex = 4
        IntIdCuadreLabel.Text = "Id Cuadre:"
        IntIdCuadreLabel.Visible = False
        '
        'StrNombreCajaLabel
        '
        StrNombreCajaLabel.AutoSize = True
        StrNombreCajaLabel.Location = New System.Drawing.Point(35, 58)
        StrNombreCajaLabel.Name = "StrNombreCajaLabel"
        StrNombreCajaLabel.Size = New System.Drawing.Size(71, 13)
        StrNombreCajaLabel.TabIndex = 6
        StrNombreCajaLabel.Text = "Nombre Caja:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.Tabla)
        Me.TabControl1.Controls.Add(Me.Detalle)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 25)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(562, 345)
        Me.TabControl1.TabIndex = 0
        '
        'Tabla
        '
        Me.Tabla.Controls.Add(Me.TblCajasDataGridView)
        Me.Tabla.Location = New System.Drawing.Point(4, 22)
        Me.Tabla.Name = "Tabla"
        Me.Tabla.Padding = New System.Windows.Forms.Padding(3)
        Me.Tabla.Size = New System.Drawing.Size(554, 319)
        Me.Tabla.TabIndex = 0
        Me.Tabla.Text = "Tabla"
        Me.Tabla.UseVisualStyleBackColor = True
        '
        'TblCajasDataGridView
        '
        Me.TblCajasDataGridView.AllowUserToAddRows = False
        Me.TblCajasDataGridView.AllowUserToDeleteRows = False
        Me.TblCajasDataGridView.AutoGenerateColumns = False
        Me.TblCajasDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TblCajasDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewCheckBoxColumn1, Me.DataGridViewTextBoxColumn3})
        Me.TblCajasDataGridView.DataSource = Me.TblCajasBindingSource
        Me.TblCajasDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TblCajasDataGridView.Location = New System.Drawing.Point(3, 3)
        Me.TblCajasDataGridView.Name = "TblCajasDataGridView"
        Me.TblCajasDataGridView.ReadOnly = True
        Me.TblCajasDataGridView.Size = New System.Drawing.Size(548, 313)
        Me.TblCajasDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "intIdCajas"
        Me.DataGridViewTextBoxColumn1.HeaderText = "IdCajas"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "strNombreCaja"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nombre Caja"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 310
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.DataPropertyName = "bitAbierta"
        Me.DataGridViewCheckBoxColumn1.HeaderText = "Abierta"
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        Me.DataGridViewCheckBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "intIdCuadre"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Id Cuadre"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Visible = False
        '
        'TblCajasBindingSource
        '
        Me.TblCajasBindingSource.DataSource = GetType(ClsBaseDatos_SadLab.tblCajas)
        '
        'Detalle
        '
        Me.Detalle.Controls.Add(BitAbiertaLabel)
        Me.Detalle.Controls.Add(Me.BitAbiertaClsCheckBox)
        Me.Detalle.Controls.Add(IntIdCajasLabel)
        Me.Detalle.Controls.Add(Me.IntIdCajasClsTextBox)
        Me.Detalle.Controls.Add(IntIdCuadreLabel)
        Me.Detalle.Controls.Add(Me.IntIdCuadreClsTextBox)
        Me.Detalle.Controls.Add(StrNombreCajaLabel)
        Me.Detalle.Controls.Add(Me.StrNombreCajaClsTextBox)
        Me.Detalle.Location = New System.Drawing.Point(4, 22)
        Me.Detalle.Name = "Detalle"
        Me.Detalle.Padding = New System.Windows.Forms.Padding(3)
        Me.Detalle.Size = New System.Drawing.Size(554, 319)
        Me.Detalle.TabIndex = 1
        Me.Detalle.Text = "Detalle"
        Me.Detalle.UseVisualStyleBackColor = True
        '
        'BitAbiertaClsCheckBox
        '
        Me.BitAbiertaClsCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.TblCajasBindingSource, "bitAbierta", True))
        Me.BitAbiertaClsCheckBox.Enabled = False
        Me.BitAbiertaClsCheckBox.Location = New System.Drawing.Point(122, 81)
        Me.BitAbiertaClsCheckBox.Name = "BitAbiertaClsCheckBox"
        Me.BitAbiertaClsCheckBox.Size = New System.Drawing.Size(15, 24)
        Me.BitAbiertaClsCheckBox.TabIndex = 1
        Me.BitAbiertaClsCheckBox.UseVisualStyleBackColor = True
        '
        'IntIdCajasClsTextBox
        '
        Me.IntIdCajasClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCajasBindingSource, "intIdCajas", True))
        Me.IntIdCajasClsTextBox.DataSource = Nothing
        Me.IntIdCajasClsTextBox.Enabled = False
        Me.IntIdCajasClsTextBox.Location = New System.Drawing.Point(122, 29)
        Me.IntIdCajasClsTextBox.Name = "IntIdCajasClsTextBox"
        Me.IntIdCajasClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdCajasClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdCajasClsTextBox.Size = New System.Drawing.Size(50, 20)
        Me.IntIdCajasClsTextBox.TabIndex = 3
        Me.IntIdCajasClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'IntIdCuadreClsTextBox
        '
        Me.IntIdCuadreClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCajasBindingSource, "intIdCuadre", True))
        Me.IntIdCuadreClsTextBox.DataSource = Nothing
        Me.IntIdCuadreClsTextBox.Location = New System.Drawing.Point(122, 113)
        Me.IntIdCuadreClsTextBox.Name = "IntIdCuadreClsTextBox"
        Me.IntIdCuadreClsTextBox.NombreCodigoF2 = Nothing
        Me.IntIdCuadreClsTextBox.NombreDescripcionF2 = Nothing
        Me.IntIdCuadreClsTextBox.Size = New System.Drawing.Size(50, 20)
        Me.IntIdCuadreClsTextBox.TabIndex = 5
        Me.IntIdCuadreClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        Me.IntIdCuadreClsTextBox.Visible = False
        '
        'StrNombreCajaClsTextBox
        '
        Me.StrNombreCajaClsTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TblCajasBindingSource, "strNombreCaja", True))
        Me.StrNombreCajaClsTextBox.DataSource = Nothing
        Me.StrNombreCajaClsTextBox.Location = New System.Drawing.Point(122, 55)
        Me.StrNombreCajaClsTextBox.Name = "StrNombreCajaClsTextBox"
        Me.StrNombreCajaClsTextBox.NombreCodigoF2 = Nothing
        Me.StrNombreCajaClsTextBox.NombreDescripcionF2 = Nothing
        Me.StrNombreCajaClsTextBox.Size = New System.Drawing.Size(324, 20)
        Me.StrNombreCajaClsTextBox.TabIndex = 7
        Me.StrNombreCajaClsTextBox.TipoDato = ClsUtilidades.ClsTextBox.TipoDatos.Texto
        '
        'TblCajasBindingNavigator
        '
        Me.TblCajasBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TblCajasBindingNavigator.BindingSource = Me.TblCajasBindingSource
        Me.TblCajasBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TblCajasBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TblCajasBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TblCajasBindingNavigatorSaveItem})
        Me.TblCajasBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TblCajasBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TblCajasBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TblCajasBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TblCajasBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TblCajasBindingNavigator.Name = "TblCajasBindingNavigator"
        Me.TblCajasBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TblCajasBindingNavigator.Size = New System.Drawing.Size(562, 25)
        Me.TblCajasBindingNavigator.TabIndex = 1
        Me.TblCajasBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Agregar nuevo"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(38, 22)
        Me.BindingNavigatorCountItem.Text = "de {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Número total de elementos"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Eliminar"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Mover primero"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Mover anterior"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Posición"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Posición actual"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Mover siguiente"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Mover último"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TblCajasBindingNavigatorSaveItem
        '
        Me.TblCajasBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TblCajasBindingNavigatorSaveItem.Image = CType(resources.GetObject("TblCajasBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TblCajasBindingNavigatorSaveItem.Name = "TblCajasBindingNavigatorSaveItem"
        Me.TblCajasBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TblCajasBindingNavigatorSaveItem.Text = "Guardar datos"
        '
        'FrmCajas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(562, 370)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.TblCajasBindingNavigator)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "FrmCajas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cajas"
        Me.TabControl1.ResumeLayout(False)
        Me.Tabla.ResumeLayout(False)
        CType(Me.TblCajasDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblCajasBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Detalle.ResumeLayout(False)
        Me.Detalle.PerformLayout()
        CType(Me.TblCajasBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TblCajasBindingNavigator.ResumeLayout(False)
        Me.TblCajasBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents Tabla As System.Windows.Forms.TabPage
    Friend WithEvents Detalle As System.Windows.Forms.TabPage
    Friend WithEvents TblCajasDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents TblCajasBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TblCajasBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TblCajasBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BitAbiertaClsCheckBox As ClsUtilidades.ClsCheckBox
    Friend WithEvents IntIdCajasClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents IntIdCuadreClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents StrNombreCajaClsTextBox As ClsUtilidades.ClsTextBox
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
