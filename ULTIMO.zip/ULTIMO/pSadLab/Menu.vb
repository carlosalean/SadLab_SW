Imports System.Globalization
Imports ClsReportes

Public Class Menu


  Private Sub TiempoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CitasToolStripMenuItem.Click
    If Application.OpenForms("FrmCita") Is Nothing Then
      Dim mFrmCitas As New ClsIDU.FrmCita(strdbConnectionString, strIntIdUsuario, strIntIdSede)
      mFrmCitas.MdiParent = Me
      ShowNewForm(mFrmCitas)
    Else
      Application.OpenForms("FrmCita").BringToFront()
    End If
  End Sub

  Private Sub Menu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Try
      Dim Docxml As XDocument

      lblVersion.Text = My.Application.Info.Version.Major.ToString & "." & _
                        My.Application.Info.Version.MajorRevision.ToString & "." & _
                        My.Application.Info.Version.Minor.ToString & "." & _
                        My.Application.Info.Version.Revision.ToString & "." & _
                        My.Application.Info.Version.Build.ToString

      If Not My.Computer.FileSystem.FileExists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config") Then
        My.Computer.FileSystem.CopyFile(My.Application.Info.DirectoryPath & "\" & My.Application.Info.AssemblyName & ".exe.config", _
                                        My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")
      End If
      Docxml = XDocument.Load(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & My.Application.Info.CompanyName & "\" & My.Application.Info.AssemblyName & ".exe.config")
      strdbConnectionString = Docxml.Descendants("setting")(0).Value
      strIntIdSede = Docxml.Descendants("setting")(1).Value
      If Docxml.Descendants("setting").Count = 3 Then
        bitModificaCoopagoFactura = Docxml.Descendants("setting")(2).Value
      End If
      'MsgBox("Se conectar� a : " & strdbConnectionString)
      'strdbConnectionString = My.Settings.strStringConection

      PrIniciarCesion()
    Catch ex As Exception
            'ClsError.ClsError.PrMostrarError(ex)
        End Try
  End Sub

  Private Sub SalirToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SalirToolStripMenuItem.Click
    Close()
  End Sub



  Private Sub ProyectosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PacientesToolStripMenuItem.Click
    If Application.OpenForms("FrmPacientes") Is Nothing Then
      Dim mFrmPacientes = New ClsIDU.FrmPacientes(strdbConnectionString, strIntIdUsuario, strIntIdSede, "", mPermisosHC)

      mFrmPacientes.MdiParent = Me
      mFrmPacientes.mstrStringConection = strdbConnectionString
      ShowNewForm(mFrmPacientes)
    Else
      Application.OpenForms("FrmPacientes").BringToFront()
    End If
  End Sub

  Private Sub EmpleadosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EmpleadosToolStripMenuItem.Click
    If Application.OpenForms("FrmEmpleados") Is Nothing Then
      Dim mFrmEmpleados = New ClsIDU.FrmEmpleados(strdbConnectionString)
      mFrmEmpleados.MdiParent = Me
      ShowNewForm(mFrmEmpleados)
    Else
      Application.OpenForms("FrmEmpleados").BringToFront()
    End If

  End Sub


  Private Sub ClientesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DivisionToolStripMenuItem.Click
    If Application.OpenForms("FrmDivisionVasculab") Is Nothing Then
      Dim mFrmDivisionVasculab As New ClsIDU.FrmDivisionVasculab(strdbConnectionString)
      mFrmDivisionVasculab.MdiParent = Me
      ShowNewForm(mFrmDivisionVasculab)
    Else
      Application.OpenForms("FrmDivisionVasculab").BringToFront()
    End If

  End Sub


  Private Sub ShowNewForm(ByVal ChildForm As System.Windows.Forms.Form)
    ' Make it a child of this MDI form before showing it.
    ChildForm.MdiParent = Me
    ChildForm.Show()
  End Sub

  Private Sub NivelesDeAccesoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EpsToolStripMenuItem.Click
    If Application.OpenForms("FrmEPS") Is Nothing Then
      Dim mFrmEPS As New ClsIDU.FrmEPS(strdbConnectionString)
      mFrmEPS.MdiParent = Me
      ShowNewForm(mFrmEPS)
    Else
      Application.OpenForms("FrmEPS").BringToFront()
    End If

  End Sub


  Private Sub GenerarArchivosContabilidadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      'With DlgGeneraArchivoContabilidad
      '    If .ShowDialog = Windows.Forms.DialogResult.OK Then
      '        Dim _ClsExportacionNomina As New ClsExportacionNomina()
      '        _ClsExportacionNomina.PrGenerarArchivo(.FechaIDateTimePicker.Value, _
      '            .FechaFDateTimePicker.Value, .PeriodoDomainUpDown.Text, .HorasTextBox.Text, .NroLineasTextBox.Text)
      '    End If
      'End With
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TiempoToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      'Dim mMostrarForma As Boolean
      'Dim mFrmRptTiempoFaltante As New FrmRptTiempoFaltante(mMostrarForma)
      'If mMostrarForma Then
      '    ShowNewForm(mFrmRptTiempoFaltante)
      'End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ImportarCostosDirectosEjecutadosDeContabilidadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

  End Sub

  Private Sub PorEmpleadoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      'Dim mMostrarForma As Boolean
      'Dim mFrmRptTiempoProgramadoEmpleado As New FrmRptTiempoProgramadoEmpleado(mMostrarForma)
      'If mMostrarForma Then
      '    ShowNewForm(mFrmRptTiempoProgramadoEmpleado)
      'End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub EmpresaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    'If DlgrptIndicadorEmpresa.ShowDialog = Windows.Forms.DialogResult.OK Then
    '    mTipoProyecto = 1
    '    mAreaI = Nothing
    '    mAreaF = Nothing
    '    If DlgrptIndicadorEmpresa.TxtAno.Text <> String.Empty And IsNumeric(DlgrptIndicadorEmpresa.TxtAno.Text) Then
    '        mAno = Convert.ToInt32(DlgrptIndicadorEmpresa.TxtAno.Text)
    '    Else
    '        mAno = Now.Year
    '    End If
    '    If DlgrptIndicadorEmpresa.RadioButton1.Checked Then
    '        mTipoProyecto = "A"
    '    End If
    '    If DlgrptIndicadorEmpresa.RadioButton1.Checked Then
    '        mTipoProyecto = "O"
    '    End If
    '    If DlgrptIndicadorEmpresa.RadioButton1.Checked Then
    '        mTipoProyecto = "M"
    '    End If
    '    Dim _FrmIndiceEmpresa As New FrmIndiceEmpresa(mAreaI, mAreaF, mAno, mTipoProyecto)
    '    ShowNewForm(_FrmIndiceEmpresa)
    'End If
  End Sub

  Private Sub ToolStripButtonCambiarUsuario_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButtonCambiarUsuario.Click
    PrIniciarCesion()
  End Sub

  Private Sub PrIniciarCesion()
    Dim fLogin As New frmLogin(strdbConnectionString)
    'System.Windows.Forms.Application.EnableVisualStyles()
    Dim oldDecimalSeparator As String = Application.CurrentCulture.NumberFormat.NumberDecimalSeparator
    Try
      forceDotCulture = Application.CurrentCulture.Clone()
      forceDotCulture.NumberFormat.NumberDecimalSeparator = FDecimales
      forceDotCulture.NumberFormat.NumberGroupSeparator = FMiles
      forceDotCulture.NumberFormat.CurrencyDecimalSeparator = FDecimales
      forceDotCulture.NumberFormat.CurrencyGroupSeparator = FMiles
      Application.CurrentCulture = forceDotCulture

      'fLogin.ShowDialog()
      If Not fLogin.ShowDialog() = Windows.Forms.DialogResult.OK Then
        'Error al iniciar, la aplicaci�n termina
        End
      End If
      fLogin.Close()
      Dim _ClsAsignarAccesos As New ClsAsignarAccesos.ClsAsignacionAccesos()
      Dim _ClsNivelesAcceso As New ClsAsignarAccesos.ClsNivelesAcceso()
      Dim _ClsAccesosMenu As New ClsAsignarAccesos.ClsAccesosMenu()
      Dim mConection As New System.Data.SqlClient.SqlConnection(strdbConnectionString)
      mConection.Open()
      _ClsAsignarAccesos.PrAsignarAccesos(MenuStrip1, _ClsAccesosMenu.PrAccesosMenu(_ClsNivelesAcceso.FnNivelAcceso(strIntIdUsuario, mConection), mConection))
      TlSStUsuario.Text = "Usuario: " + strUsuario
      Dim mIntIdUsuario As Integer
      mIntIdUsuario = Integer.Parse(strIntIdUsuario)

      Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strdbConnectionString)
      Dim tblGrupos = (From g In dc.tblGrupo Join u In dc.tblUsuarios On g.intIdGrupo Equals u.intIdGrupo Where u.intIdUsuario = mIntIdUsuario Select g).Single
      mPermisosHC = New ClsUtilidades.ClsPermisos.ClsHistoriasClinicas()

      mPermisosHC.Ver = tblGrupos.bitVerHistoriaClinica
      mPermisosHC.Modificar = tblGrupos.bitModificarHistoriaClinica
      mPermisosHC.Crear = tblGrupos.bitCrearHistoriaClinica

      If ToolStripMenuItem6.Enabled And ToolStripMenuItem7.Enabled Then
        Dim McajasAbiertas = dc.usp_ConsultarCajasAbiertas(Convert.ToInt32(strIntIdUsuario))

        Dim listCajasAbiertas As New List(Of Object)
        For Each mR In McajasAbiertas
          listCajasAbiertas.Add(mR)
        Next

        If listCajasAbiertas.Count = 0 Then
          ToolStripStatusLabelCaja.Text = Nothing
          lblCaja.Text = Nothing
          intIdCaja = Nothing
          ToolStripMenuItem6.Enabled = True
          ToolStripMenuItem7.Enabled = False
        Else
          ToolStripStatusLabelCaja.Text = "Caja Abierta:"
          lblCaja.Text = listCajasAbiertas.Item(0).strNombreCaja
          intIdCaja = listCajasAbiertas.Item(0).intIdCajas
          ToolStripMenuItem6.Enabled = False
          ToolStripMenuItem7.Enabled = True
        End If
      Else
        ToolStripStatusLabelCaja.Text = Nothing
        lblCaja.Text = Nothing
        intIdCaja = Nothing
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub


  Private Sub PorProyectoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      'Dim mMostrarForma As Boolean
      'Dim mFrmRptTiempoProgramadoProyecto As New FrmRptTiempoProgramadoProyecto(mMostrarForma)
      'If mMostrarForma Then
      '    ShowNewForm(mFrmRptTiempoProgramadoProyecto)
      'End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem.Click
    'FrmBackUp.ShowDialog()
  End Sub

  Private Sub ProductosYServiciosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResultadosToolStripMenuItem.Click
    Try
      '           ShowNewForm(FrmServicio_Producto)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TiposToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TurnosToolStripMenuItem.Click
    Try
      If Application.OpenForms("FrmTurnos") Is Nothing Then
        Dim mFrmTurnos As New ClsIDU.FrmTurnos(strdbConnectionString)
        ShowNewForm(mFrmTurnos)
      Else
        Application.OpenForms("FrmTurnos").BringToFront()
      End If

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ToolStripMenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      '         ShowNewForm(FrmSolicitud)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub PaisesYDepartamentosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PaisesYDepartamentosToolStripMenuItem.Click
    Try
      If Application.OpenForms("FrmDepartamento") Is Nothing Then
        Dim mFrmDepartamentos As New ClsIDU.FrmDepartamento(strdbConnectionString)
        ShowNewForm(mFrmDepartamentos)
      Else
        Application.OpenForms("FrmDepartamento").BringToFront()
      End If

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub DepartamentosYCiudadesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DepartamentosYCiudadesToolStripMenuItem.Click
    Try
      If Application.OpenForms("FrmMunicipios") Is Nothing Then
        Dim mFrmMunicipios As New ClsIDU.FrmMunicipios(strdbConnectionString)
        ShowNewForm(mFrmMunicipios)
      Else
        Application.OpenForms("FrmMunicipios").BringToFront()
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ImportarDatosContabilidadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      '      ShowNewForm(FrmCargarDatosContabilidad)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub DatosContablesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CajasToolStripMenuItem.Click
    Try
      '     ShowNewForm(FrmDatosContables)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ImportarCostosDirectosEjecutadosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      'With DlgImportarCostos
      '    If .ShowDialog = Windows.Forms.DialogResult.OK Then
      '        Dim pClsImportacionCostos As New ClsImportacionCostos()
      '        pClsImportacionCostos.PrImportarCostos(.NombreArchivoTextBox.Text)
      '    End If
      'End With
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ImportarFacturacionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      'With DlgImportarCostos
      '    DlgImportarCostos.Text = "Importar Informaci�n de Facturaci�n"
      '    If .ShowDialog = Windows.Forms.DialogResult.OK Then
      '        Dim pClsImportarFacturacion As New ClsImportarFacturacion()
      '        pClsImportarFacturacion.PrImportarFacturacion(.NombreArchivoTextBox.Text)
      '    End If
      'End With
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub FacturacionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      '            ShowNewForm(FrmFacturacion)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub UnidadDeNegocioToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '       ShowNewForm(FrmUnidadNegocio)
  End Sub

  Private Sub IndicadoresToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    'ShowNewForm(FrmIndicadores)
  End Sub

  Private Sub UsuariosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UsuariosToolStripMenuItem.Click
    If Application.OpenForms("FrmUsuarios") Is Nothing Then
      Dim mFrmUsuario As New ClsIDU.FrmUsuarios(strdbConnectionString)
      ShowNewForm(mFrmUsuario)
    Else
      Application.OpenForms("FrmUsuarios").BringToFront()
    End If

  End Sub

  Private Sub GruposYAcesosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GruposYAcesosToolStripMenuItem.Click
    If Application.OpenForms("FrmGrupos") Is Nothing Then
      Dim mfrmGrupos As New ClsIDU.FrmGrupos(strdbConnectionString, MenuStrip1)
      ShowNewForm(mfrmGrupos)
    Else
      Application.OpenForms("FrmGrupos").BringToFront()
    End If

  End Sub

  Private Sub ExamenesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExamenesToolStripMenuItem.Click
    If Application.OpenForms("FrmProcedimientos") Is Nothing Then
      Dim mFrmExamenes As New ClsIDU.FrmProcedimientos(strdbConnectionString)
      ShowNewForm(mFrmExamenes)
    Else
      Application.OpenForms("FrmProcedimientos").BringToFront()
    End If

  End Sub

  Private Sub ToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem2.Click
    If Application.OpenForms("FrmNovedadesCitas") Is Nothing Then
      Dim mFrmNovedadesCitas As New ClsIDU.FrmNovedadesCitas(strdbConnectionString, strIntIdUsuario, strIntIdSede, mPermisosHC)
      ShowNewForm(mFrmNovedadesCitas)
    Else
      Application.OpenForms("FrmNovedadesCitas").BringToFront()
    End If

  End Sub

  Private Sub ToolStripMenuItem4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem4.Click
    If Application.OpenForms("FrmRegistrarLlegadaCita") Is Nothing Then
      Dim mFrmRegistrarLlegadaCita As New ClsIDU.FrmRegistrarLlegadaCita(strdbConnectionString, strIntIdUsuario, intIdCaja)
      ShowNewForm(mFrmRegistrarLlegadaCita)
    Else
      Application.OpenForms("FrmRegistrarLlegadaCita").BringToFront()
    End If
  End Sub

  Private Sub ResultadosExamToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResultadosExamToolStripMenuItem.Click
    'ShowNewForm(FrmPresupuesto)
  End Sub

  Private Sub RegistroSalidaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegistroSalidaToolStripMenuItem.Click
    If Application.OpenForms("FrmRegistroSalida") Is Nothing Then
      Dim mFrmRegistroSalida As New ClsIDU.FrmRegistroSalida(strdbConnectionString, strIntIdUsuario, intIdCaja)
      ShowNewForm(mFrmRegistroSalida)
    Else
      Application.OpenForms("FrmRegistroSalida").BringToFront()
    End If
  End Sub

  Private Sub DatosFacturacionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DatosFacturacionToolStripMenuItem.Click
    If Application.OpenForms("FrmRegistrarDatosFacturacion") Is Nothing Then
      Dim mFrmDatosFacturacion As New ClsIDU.FrmRegistrarDatosFacturacion(strdbConnectionString, bitModificaCoopagoFactura, strIntIdUsuario, strIntIdSede)
      ShowNewForm(mFrmDatosFacturacion)
    Else
      Application.OpenForms("FrmRegistrarDatosFacturacion").BringToFront()
    End If

  End Sub


  Private Sub TarifasToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TarifasToolStripMenuItem.Click
    ''TODO: CAMBIAR DESPUES DE PROBAR FrmTarifasHistorico
    If Application.OpenForms("FrmTarifas") Is Nothing Then
      Dim mFrmTarifas As New ClsIDU.FrmTarifas(strdbConnectionString)
      ShowNewForm(mFrmTarifas)
    Else
      Application.OpenForms("FrmTarifas").BringToFront()
    End If
  End Sub

  Private Sub IndicadorDeOportunidadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IndicadorDeOportunidadToolStripMenuItem.Click
    Try
      If Application.OpenForms("DialogIndicadorOportunidad") Is Nothing Then
        Dim mDialogIndicadorOportunidad As New ClsReportes.DialogIndicadorOportunidad()
        If mDialogIndicadorOportunidad.ShowDialog() = Windows.Forms.DialogResult.OK Then
          Dim mFrmIndicadorOportunidad As New ClsReportes.FrmIndicadorOportunidad(strdbConnectionString, mDialogIndicadorOportunidad.mFechaIncial, mDialogIndicadorOportunidad.mFechaFinal, strUsuario)
          mFrmIndicadorOportunidad.MdiParent = Me
          mFrmIndicadorOportunidad.Show()
        End If
      Else
        Application.OpenForms("DialogIndicadorOportunidad").BringToFront()
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub TiemposToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TiemposToolStripMenuItem1.Click
    Try
      If Application.OpenForms("DialogTiemposAtencion") Is Nothing Then
        Dim mDialogTiemposAtencion As New ClsReportes.DialogTiemposAtencion()
        If mDialogTiemposAtencion.ShowDialog() = Windows.Forms.DialogResult.OK Then
          Dim mFrmTiemposAtencion As New ClsReportes.FrmTiemposAtencion(strdbConnectionString, mDialogTiemposAtencion.mFechaIncial, mDialogTiemposAtencion.mFechaFinal, strUsuario)
          mFrmTiemposAtencion.MdiParent = Me
          mFrmTiemposAtencion.Show()
        End If
      Else
        Application.OpenForms("DialogTiemposAtencion").BringToFront()
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub CitasPacienteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CitasPacienteToolStripMenuItem.Click
    If Application.OpenForms("DialogCitasPaciente") Is Nothing Then
      Dim mDialogCitasPaciente As New ClsReportes.DialogCitasPaciente()
      If mDialogCitasPaciente.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Dim mFrmCitasPaciente As New ClsReportes.FrmCitasPaciente(strdbConnectionString, mDialogCitasPaciente.mFechaIncial, mDialogCitasPaciente.mFechaFinal, mDialogCitasPaciente.mCedula, mDialogCitasPaciente.mEstadoCita, strUsuario)
        mFrmCitasPaciente.MdiParent = Me
        mFrmCitasPaciente.Show()
      End If
    Else
      Application.OpenForms("DialogCitasPaciente").BringToFront()
    End If
  End Sub

  Private Sub DatosPrestadoresToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DatosPrestadoresToolStripMenuItem.Click
    If Application.OpenForms("FrmDatosPrestadores") Is Nothing Then
      Dim mFrmDatosPrestadores As New ClsIDU.FrmDatosPrestadores(strdbConnectionString)
      ShowNewForm(mFrmDatosPrestadores)
    Else
      Application.OpenForms("FrmDatosPrestadores").BringToFront()
    End If
  End Sub
  Private Sub ProcedimientosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProcedimientosToolStripMenuItem.Click

    If Application.OpenForms("DialogProcedimientosEPS") Is Nothing Then
      Dim mDialogProcedimientosEPS As New ClsReportes.DialogProcedimientosEPS()
      If mDialogProcedimientosEPS.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Dim mFrmProcedimientosEPS As New ClsReportes.FrmProcedimientosEPS(strdbConnectionString, mDialogProcedimientosEPS.mFechaIncial, mDialogProcedimientosEPS.mFechaFinal, mDialogProcedimientosEPS.mEstadoCita, strUsuario)
        mFrmProcedimientosEPS.MdiParent = Me
        mFrmProcedimientosEPS.Show()
      End If
    Else
      Application.OpenForms("DialogProcedimientosEPS").BringToFront()
    End If

  End Sub


  Private Sub ToolStripMenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem5.Click

    If Application.OpenForms("DialogCitasProfesionales") Is Nothing Then

      Dim mDialogCitasProfesionales As New ClsReportes.DialogCitasProfesionales(strdbConnectionString)

      If mDialogCitasProfesionales.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Dim mFrmCitasProfesionales As New ClsReportes.FrmCitasProfesionales(strdbConnectionString, mDialogCitasProfesionales.mFechaIncial, mDialogCitasProfesionales.mFechaFinal, mDialogCitasProfesionales.mIdProfesional, strUsuario, mDialogCitasProfesionales.mEstadoCita, mDialogCitasProfesionales.mSede)
        mFrmCitasProfesionales.MdiParent = Me
        mFrmCitasProfesionales.Show()
      End If

    Else
      Application.OpenForms("DialogCitasProfesionales").BringToFront()
    End If
  End Sub

  Private Sub SedesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SedesToolStripMenuItem.Click
    If Application.OpenForms("FrmSedes") Is Nothing Then
      Dim mFrmSedes As New ClsIDU.FrmSedes(strdbConnectionString)
      ShowNewForm(mFrmSedes)
    Else
      Application.OpenForms("FrmSedes").BringToFront()
    End If
  End Sub

  Private Sub ToolStripButtonAsignarCita_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    If Application.OpenForms("FrmCita") Is Nothing Then
      Dim mFrmCitas As New ClsIDU.FrmCita(strdbConnectionString, strIntIdUsuario, strIntIdSede)
      ShowNewForm(mFrmCitas)
    Else
      Application.OpenForms("FrmCita").BringToFront()
    End If
  End Sub


  Private Sub CANCELACI�ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CANCELACI�ToolStripMenuItem.Click
    If Application.OpenForms("FrmCancelacionCita") Is Nothing Then
      Dim mFrmCancelacionCita As New ClsIDU.FrmCancelacionCita(strdbConnectionString, strIntIdUsuario, strIntIdSede)
      ShowNewForm(mFrmCancelacionCita)
    Else
      Application.OpenForms("FrmCancelacionCita").BringToFront()
    End If
  End Sub

  Private Sub RutaConfigToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RutaConfigToolStripMenuItem.Click
    MsgBox(My.Application.Info.DirectoryPath)
  End Sub

  Private Sub CajasToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CajasToolStripMenuItem1.Click
    If Application.OpenForms("FrmCajas") Is Nothing Then
      Dim mFrmCajas As New ClsIDU.FrmCajas(strdbConnectionString)
      ShowNewForm(mFrmCajas)
    Else
      Application.OpenForms("FrmCajas").BringToFront()
    End If
  End Sub
  Private Sub ToolStripMenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem6.Click
    If Application.OpenForms("DialogAbrirCaja") Is Nothing Then
      Dim mDialogAbrirCaja As New ClsIDU.DialogAbrirCaja(strdbConnectionString, strIntIdUsuario)
      If mDialogAbrirCaja.ShowDialog() = Windows.Forms.DialogResult.OK Then
        ToolStripMenuItem6.Enabled = False
        ToolStripMenuItem7.Enabled = True
        ToolStripStatusLabelCaja.Text = "Caja Abierta: "
        lblCaja.Text = mDialogAbrirCaja.mCaja
        intIdCaja = mDialogAbrirCaja.mintIdCaja
      End If
    Else
      Application.OpenForms("DialogAbrirCaja").BringToFront()
    End If
  End Sub

  Private Sub ToolStripMenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem7.Click
    If Application.OpenForms("DialogCierreCaja") Is Nothing Then
      Dim mValidaHuella As New DialogValidarHuella(strdbConnectionString, strIntIdUsuario, True)
      If (mValidaHuella.ShowDialog() = Windows.Forms.DialogResult.OK) Then
        Dim mDialogCierreCaja As New ClsIDU.DialogCierreCaja(strdbConnectionString, mValidaHuella.mstrIntIdUsuario, intIdCaja)
        If mDialogCierreCaja.ShowDialog() = Windows.Forms.DialogResult.OK Then
          If mDialogCierreCaja.CajaCerrada = True Then
            ToolStripMenuItem6.Enabled = True
            ToolStripMenuItem7.Enabled = False
            lblCaja.Text = ""
            ToolStripStatusLabelCaja.Text = ""

            If Application.OpenForms("FrmCuadre") Is Nothing Then
              Dim mFrmCuadre As New ClsReportes.FrmCuadre(strdbConnectionString, intIdCaja, strIntIdUsuario, mDialogCierreCaja.mEfectivo, mDialogCierreCaja.mDiferencia)
              mFrmCuadre.MdiParent = Me
              mFrmCuadre.Show()
            Else
              Application.OpenForms("FrmCuadre").BringToFront()
            End If

          End If
        End If
      End If
    Else
      Application.OpenForms("DialogCierreCaja").BringToFront()
    End If

    'If Application.OpenForms("FrmCierreCaja") Is Nothing Then
    '    Dim mFrmCierreCaja As New ClsIDU.FrmCierreCaja(strdbConnectionString, strIntIdUsuario)
    '    ShowNewForm(mFrmCierreCaja)
    '    If mFrmCierreCaja.Then Then
    '        ToolStripMenuItem6.Enabled = True
    '        ToolStripMenuItem7.Enabled = False
    '    End If
    'Else
    '    Application.OpenForms("FrmCierreCaja").BringToFront()
    'End If

  End Sub

  Private Sub Liquidaci�nToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Liquidaci�nToolStripMenuItem.Click
    If Application.OpenForms("DialogPrestacionServicios") Is Nothing Then

      Dim mDialogPrestacionServicios As New ClsReportes.DialogPrestacionServicios(strdbConnectionString, intIdCaja)

      If mDialogPrestacionServicios.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Dim mFrmLiquidacionServicios As New ClsReportes.FrmLiquidacionServicios(strdbConnectionString, mDialogPrestacionServicios.mFechaIncial, mDialogPrestacionServicios.mFechaFinal, strUsuario, mDialogPrestacionServicios.mintIdPrestador, mDialogPrestacionServicios.mintIdCaja)
        mFrmLiquidacionServicios.MdiParent = Me
        mFrmLiquidacionServicios.Show()
      End If

    Else
      Application.OpenForms("DialogCitasProfesionales").BringToFront()
    End If

  End Sub

  Private Sub TiposToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TiposToolStripMenuItem.Click
    If Application.OpenForms("FrmTipos") Is Nothing Then
      Dim mFrmTipos As New ClsIDU.FrmTipos(strdbConnectionString)
      ShowNewForm(mFrmTipos)
    Else
      Application.OpenForms("FrmTipos").BringToFront()
    End If
  End Sub

  Private Sub MotivosConsultaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MotivosConsultaToolStripMenuItem.Click
    If Application.OpenForms("FrmMotivosConsulta") Is Nothing Then
      Dim mFrmMotivosConsulta As New ClsIDU.FrmMotivosConsulta(strdbConnectionString)
      ShowNewForm(mFrmMotivosConsulta)
    Else
      Application.OpenForms("FrmMotivosConsulta").BringToFront()
    End If
  End Sub

  Private Sub FrecuenciaMedicamentosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FrecuenciaMedicamentosToolStripMenuItem.Click
    If Application.OpenForms("FrmFrecuenciaMedicamentos") Is Nothing Then
      Dim mFrmFrecuenciaMedicamentos As New ClsIDU.FrmFrecuenciaMedicamentos(strdbConnectionString)
      ShowNewForm(mFrmFrecuenciaMedicamentos)
    Else
      Application.OpenForms("FrmFrecuenciaMedicamentos").BringToFront()
    End If

  End Sub

  Private Sub ProtocolosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProtocolosToolStripMenuItem.Click
    If Application.OpenForms("FrmProtocolos") Is Nothing Then
      Dim mFrmProtocolos As New ClsIDU.FrmProtocolos(strdbConnectionString)
      ShowNewForm(mFrmProtocolos)
    Else
      Application.OpenForms("FrmProtocolos").BringToFront()
    End If
  End Sub

  Private Sub LaboratoriosFarmac�uticosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LaboratoriosFarmac�uticosToolStripMenuItem.Click

    If Application.OpenForms("FrmLaboratoriosFarmaceuticos") Is Nothing Then
      Dim mFrmLaboratoriosFarmaceuticos As New ClsIDU.FrmLaboratoriosFarmaceuticos(strdbConnectionString)
      ShowNewForm(mFrmLaboratoriosFarmaceuticos)
    Else
      Application.OpenForms("FrmLaboratoriosFarmaceuticos").BringToFront()
    End If

  End Sub

  Private Sub SintomasSignosLaboratoriosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SintomasSignosLaboratoriosToolStripMenuItem.Click
    If Application.OpenForms("FrmSintomasSignosLaboratorios") Is Nothing Then
      Dim mFrmSintomasSignosLaboratorios As New ClsIDU.FrmSintomasSignosLaboratorios(strdbConnectionString)
      ShowNewForm(mFrmSintomasSignosLaboratorios)
    Else
      Application.OpenForms("FrmSintomasSignosLaboratorios").BringToFront()
    End If

  End Sub

  Private Sub OcupacionesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OcupacionesToolStripMenuItem.Click
    If Application.OpenForms("FrmOcupaciones") Is Nothing Then
      Dim mFrmOcupaciones As New ClsIDU.FrmOcupaciones(strdbConnectionString)
      ShowNewForm(mFrmOcupaciones)
    Else
      Application.OpenForms("FrmOcupaciones").BringToFront()
    End If
  End Sub

  Private Sub MedicamentosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MedicamentosToolStripMenuItem.Click
    If Application.OpenForms("FrmClaseMedicamentos") Is Nothing Then
      Dim mFrmMedicamentos As New ClsIDU.FrmClaseMedicamentos(strdbConnectionString)
      ShowNewForm(mFrmMedicamentos)
    Else
      Application.OpenForms("FrmClaseMedicamentos").BringToFront()
    End If
  End Sub

  Private Sub PrincipiosActivosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrincipiosActivosToolStripMenuItem.Click
    If Application.OpenForms("FrmPrincipiosActivos") Is Nothing Then
      Dim mFrmPrincipiosActivos As New ClsIDU.FrmPrincipiosActivos(strdbConnectionString)
      ShowNewForm(mFrmPrincipiosActivos)
    Else
      Application.OpenForms("FrmPrincipiosActivos").BringToFront()
    End If
  End Sub

  Private Sub ItemRevisi�nToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ItemRevisi�nToolStripMenuItem.Click
    If Application.OpenForms("FrmItemRevision") Is Nothing Then
      Dim mFrmItemRevision As New ClsIDU.FrmItemRevision(strdbConnectionString)
      ShowNewForm(mFrmItemRevision)
    Else
      Application.OpenForms("FrmItemRevision").BringToFront()
    End If
  End Sub

  Private Sub DescuentosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DescuentosToolStripMenuItem.Click
    Try
      If Application.OpenForms("FrmDescuentos") Is Nothing Then
        Dim mFrmDescuentos As New ClsIDU.FrmDescuentos(strdbConnectionString, strIntIdUsuario)
        ShowNewForm(mFrmDescuentos)
      Else
        Application.OpenForms("FrmDescuentos").BringToFront()
      End If

    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub AgendaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AgendaToolStripMenuItem.Click
    'Try
    '    If Application.OpenForms("FrmAgenda") Is Nothing Then
    '        Dim mFrmAgenda As New ClsIDU.FrmAgenda(strdbConnectionString)
    '        ShowNewForm(mFrmAgenda)
    '    Else
    '        Application.OpenForms("FrmDescuentos").BringToFront()
    '    End If

    'Catch ex As Exception
    '    ClsError.ClsError.PrMostrarError(ex)
    'End Try
  End Sub

  Private Sub ServiciosPrestadosToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ServiciosPrestadosToolStripMenuItem.Click
    If Application.OpenForms("DialogServiciosPrestados") Is Nothing Then

      Dim mDialogServiciosPrestados As New ClsReportes.DialogServiciosPrestacion(strdbConnectionString, intIdCaja, strIntIdUsuario)

      If mDialogServiciosPrestados.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Dim mFrmServiciosPrestados As New ClsReportes.FrmServiciosPrestados(strdbConnectionString, mDialogServiciosPrestados.mFechaIncial, mDialogServiciosPrestados.mFechaFinal, strUsuario, mDialogServiciosPrestados.mintIdPrestador, mDialogServiciosPrestados.mDatosDescuento)
        mFrmServiciosPrestados.MdiParent = Me
        mFrmServiciosPrestados.Show()
      End If

    Else
      Application.OpenForms("DialogServiciosPrestados").BringToFront()
    End If
  End Sub

  Private Sub InformesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InformesToolStripMenuItem.Click

  End Sub

  Private Sub NormaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NormaToolStripMenuItem.Click
    If Application.OpenForms("DialogFacturacion") Is Nothing Then
      Dim mDialogFacturacion As New ClsReportes.DialogFacturacion(strdbConnectionString, strIntIdUsuario)
      If mDialogFacturacion.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Try
          Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strdbConnectionString)
          Dim mFacturas = (From p In dc.tblFacturacions Where p.strNroFactura = mDialogFacturacion.mNroFactura And p.intIdPrestador = mDialogFacturacion.intIdPrestadores Select p)
          Dim mCuenta As Integer = 1
          For Each mFactura In mFacturas
            If mCuenta > 1 Then Exit For
            If Not mFactura Is Nothing Then
              If mFactura.bitAnulada = True Then
                MsgBox("La Factura se encuentra anulada..")
                Exit Sub
              End If
            End If
            mCuenta = mCuenta + 1
          Next
        Catch ex As Exception
          'MsgBox("La Factura no existe..")
        End Try
        Dim mFrmFacturacion As New ClsReportes.FrmFacturaCarta(strdbConnectionString, mDialogFacturacion.mNroFactura, mDialogFacturacion.MPaciente, mDialogFacturacion.intIdPrestadores, mDialogFacturacion.mCerrarFactura, mDialogFacturacion.FUsuarioCierra)
        mFrmFacturacion.MdiParent = Me
        mFrmFacturacion.Show()

        Dim mFrmAnexoRips As New ClsReportes.FrmAnexoRips(strdbConnectionString, mDialogFacturacion.mNroFactura, mDialogFacturacion.intIdPrestadores)
        mFrmAnexoRips.MdiParent = Me
        mFrmAnexoRips.Show()
      End If
    Else
      Application.OpenForms("DialogFacturacion").BringToFront()
    End If
  End Sub

  Private Sub ParaPacientesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ParaPacientesToolStripMenuItem.Click
    Try
      Dim mClsAnulacion As New ClsIDU.clsAnulacionesFacturacion
      mClsAnulacion.PrAnularFacturaPaciente(strdbConnectionString, strIntIdUsuario)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub NormalToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NormalToolStripMenuItem1.Click
    Try
      Dim mNroFactura As String
      Dim mintIdPrestador As String

      Dim mDialogFacturacion As New ClsIDU.DialogFacturacion(strdbConnectionString)
      mDialogFacturacion.Text = "Imprimir Factura"
      If mDialogFacturacion.ShowDialog() = Windows.Forms.DialogResult.OK Then
        mNroFactura = mDialogFacturacion.mNroFactura
        mintIdPrestador = mDialogFacturacion.intIdPrestadores

        If mNroFactura.Length > 0 And IsNumeric(mNroFactura) Then
          Dim mIntNroFactura As Integer = CInt(mNroFactura)
          Try

            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strdbConnectionString)
            Dim mFactura = (From p In dc.tblPagos Where p.intNroFactura = mIntNroFactura And p.intIdPrestadores = mintIdPrestador Select p).Single
            If mFactura Is Nothing Then
              MsgBox("Factura no existe")
            Else
              If Application.OpenForms("FrmFacturaMediaCarta") Is Nothing Then
                Dim mFrmFacturaMediaCarta As New ClsReportes.FrmFacturaMediaCarta(strdbConnectionString, mFactura.intIdCita)
                mFrmFacturaMediaCarta.Show()
              Else
                Application.OpenForms("FrmFacturaMediaCarta").BringToFront()
              End If
            End If
          Catch ex As Exception
            MsgBox("Factura no existe")
          End Try
        Else
          MsgBox("Factura no existe")
        End If
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub AnuladaToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AnuladaToolStripMenuItem1.Click
    Try
      Dim mNroFactura As String
      Dim mintIdPrestador As String

      Dim mDialogFacturacion As New ClsIDU.DialogFacturacion(strdbConnectionString)
      mDialogFacturacion.Text = "Imprimir Factura"
      If mDialogFacturacion.ShowDialog() = Windows.Forms.DialogResult.OK Then
        mNroFactura = mDialogFacturacion.mNroFactura
        mintIdPrestador = mDialogFacturacion.intIdPrestadores

        If mNroFactura.Length > 0 And IsNumeric(mNroFactura) Then
          Dim mIntNroFactura As Integer = CInt(mNroFactura)
          Dim intIdPrestador As Integer = CInt(mintIdPrestador)
          Try
            Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strdbConnectionString)
            Dim mFactura = (From p In dc.tblPagos Where p.intNroFacturaAnulada = mIntNroFactura And p.intIdPrestadores = intIdPrestador Select p).Single
            If mFactura Is Nothing Then
              MsgBox("Factura no existe")
            Else
              If Application.OpenForms("FrmFacturaMediaCarta") Is Nothing Then
                Dim mFrmFacturaMediaCarta As New ClsReportes.FrmFacturaMediaCarta(strdbConnectionString, mFactura.intIdCita, True)
                mFrmFacturaMediaCarta.Show()
              Else
                Application.OpenForms("FrmFacturaMediaCarta").BringToFront()
              End If
            End If
          Catch ex As Exception
            MsgBox("Factura no existe")
          End Try
        Else
          MsgBox("Factura no existe")
        End If
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ParaEPSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ParaEPSToolStripMenuItem.Click
    Try
      Dim mClsAnulacion As New ClsIDU.clsAnulacionesFacturacion
      mClsAnulacion.PrAnularFacturaEPS(strdbConnectionString, strIntIdUsuario)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub AnuladaToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AnuladaToolStripMenuItem.Click
    If Application.OpenForms("DialogFacturacion") Is Nothing Then
      Dim mDialogFacturacion As New ClsIDU.DialogFacturacion(strdbConnectionString)
      If mDialogFacturacion.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Try

          Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strdbConnectionString)
          Dim mFacturas = (From p In dc.tblFacturacions Where p.strNroFactura = mDialogFacturacion.mNroFactura And p.intIdPrestador = mDialogFacturacion.intIdPrestadores Select p)
          Dim mCuenta As Integer = 1
          For Each mFactura In mFacturas
            If mCuenta > 1 Then Exit For
            If mFactura Is Nothing Then
              MsgBox("Factura no existe")
            Else
              If mFactura.bitAnulada = True Then
                Dim mFrmFacturacion As New ClsReportes.FrmFacturaCarta(strdbConnectionString, mDialogFacturacion.mNroFactura, mDialogFacturacion.MPaciente, mDialogFacturacion.intIdPrestadores, False, 0)
                mFrmFacturacion.MdiParent = Me
                mFrmFacturacion.Show()
              Else
                MsgBox("La Factura no se encuentra anulada..")
              End If
            End If
            mCuenta = mCuenta + 1
          Next mFactura
        Catch ex As Exception
          MsgBox("La Factura no existe..")
        End Try
      End If
    Else
      Application.OpenForms("DialogFacturacion").BringToFront()
    End If
  End Sub

  Private Sub Generaraci�nDeFacturasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Generaraci�nDeFacturasToolStripMenuItem.Click

    If Application.OpenForms("DialogGenerarFacturacion") Is Nothing Then
      Dim mDialogGenerarFacturacion As New ClsReportes.DialogGenerarFacturacion(strdbConnectionString)

      If mDialogGenerarFacturacion.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Try
          Dim dc As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strdbConnectionString)
          dc.usp_GenerarFactura(mDialogGenerarFacturacion.mIdPrestador, mDialogGenerarFacturacion.mIdEPS, mDialogGenerarFacturacion.mFechaIncial, mDialogGenerarFacturacion.mFechaFinal, strIntIdUsuario)

          MsgBox("Las Facturas Fueron generadas con Exito..", MsgBoxStyle.Information)

          Dim mFacturas = (From p In dc.tblFacturasGeneradas Where p.intUsuario = strIntIdUsuario And p.intPrestador = mDialogGenerarFacturacion.mIdPrestador Select p)
          For Each mFactura In mFacturas
            dc.CommandTimeout = 12000
            dc.usp_Facturacion(mFactura.strNumeroFactura, Now, mFactura.intPrestador)

            Dim mFrmFacturacion As New ClsReportes.FrmFacturaCarta(strdbConnectionString, mFactura.strNumeroFactura, False, mFactura.intPrestador, False, strIntIdUsuario)
            mFrmFacturacion.MdiParent = Me
            mFrmFacturacion.Show()

            Dim mFrmAnexoRips As New ClsReportes.FrmAnexoRips(strdbConnectionString, mFactura.strNumeroFactura, mFactura.intPrestador)
            mFrmAnexoRips.MdiParent = Me
            mFrmAnexoRips.Show()

          Next

        Catch ex As Exception
          MsgBox("Ocurri� un error en la generaci�n de las facturas..", MsgBoxStyle.Critical)
        End Try

        ' Dim mFrmImportacionFacturas As New ClsReportes.FrmImportacionFacturas(strdbConnectionString, mDialogImportacionFacturas.mFechaIncial, mDialogImportacionFacturas.mFechaFinal, mDialogImportacionFacturas.mIdPrestador, strUsuario, mDialogImportacionFacturas.mAnulado)
        ' mFrmImportacionFacturas.MdiParent = Me
        ' mFrmImportacionFacturas.Show()
      End If

    Else
      Application.OpenForms("DialogImportacionFacturas").BringToFront()
    End If

  End Sub

  Private Sub FacturasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FacturasToolStripMenuItem.Click
    If Application.OpenForms("DialogImportacionFacturas") Is Nothing Then
      Dim mDialogImportacionFacturas As New ClsReportes.DialogImportacionFacturas(strdbConnectionString)

      If mDialogImportacionFacturas.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Dim mFrmImportacionFacturas As New ClsReportes.FrmImportacionFacturas(strdbConnectionString, mDialogImportacionFacturas.mFechaIncial, mDialogImportacionFacturas.mFechaFinal, mDialogImportacionFacturas.mIdPrestador, strUsuario, mDialogImportacionFacturas.mAnulado)
        mFrmImportacionFacturas.MdiParent = Me
        mFrmImportacionFacturas.Show()
      End If

    Else
      Application.OpenForms("DialogImportacionFacturas").BringToFront()
    End If


  End Sub

  Private Sub CopagosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopagosToolStripMenuItem.Click
    If Application.OpenForms("DialogImportacionCopagoFacturas") Is Nothing Then
      Dim mDialogImportacionCopagoFacturas As New ClsReportes.DialogImportacionCopagosFacturas(strdbConnectionString)

      If mDialogImportacionCopagoFacturas.ShowDialog() = Windows.Forms.DialogResult.OK Then
        Dim mFrmImportacionCopagoFacturas As New ClsReportes.FrmImportacionCopagosFacturas(strdbConnectionString, mDialogImportacionCopagoFacturas.mFechaIncial, mDialogImportacionCopagoFacturas.mFechaFinal, mDialogImportacionCopagoFacturas.mIdPrestador, strUsuario, mDialogImportacionCopagoFacturas.mAnulado)
        mFrmImportacionCopagoFacturas.MdiParent = Me
        mFrmImportacionCopagoFacturas.Show()
      End If

    Else
      Application.OpenForms("DialogImportacionCopagoFacturas").BringToFront()
    End If


  End Sub

  Private Sub ToolStripMenuItemTarifaBase_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItemTarifaBase.Click
    If Application.OpenForms("FrmTarifasBase") Is Nothing Then
      Dim mFrmTarifasBase As New ClsIDU.FrmTarifasBase(strdbConnectionString)
      ShowNewForm(mFrmTarifasBase)
    Else
      Application.OpenForms("FrmTarifasBase").BringToFront()
    End If
  End Sub

  Private Sub IPSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IPSToolStripMenuItem.Click
    If Application.OpenForms("FrmIPS") Is Nothing Then
      Dim mFrmIPS As New ClsIDU.FrmIPS(strdbConnectionString)
      mFrmIPS.MdiParent = Me
      ShowNewForm(mFrmIPS)
    Else
      Application.OpenForms("FrmIPS").BringToFront()
    End If
  End Sub

  Private Sub miRIPS_Click(sender As Object, e As EventArgs) Handles miRIPS.Click
    If Application.OpenForms("frmGenerarRIPS") Is Nothing Then
      Dim clsRIPS As New ClsReportes.frmGenerarRIPS(strdbConnectionString)

      If clsRIPS.ShowDialog() = Windows.Forms.DialogResult.OK Then
        If Not String.IsNullOrWhiteSpace(clsRIPS.sMensaje) Then
          MsgBox(clsRIPS.sMensaje, MsgBoxStyle.Information, "Generaci�n de archivos rips")
        Else
          MsgBox("Hay un error al generar los archivos RIPS, por favor intente m�s tarde.", MsgBoxStyle.Information, "Generaci�n de archivos rips")
        End If
      End If

    Else
      Application.OpenForms("frmGenerarRIPS").BringToFront()
    End If
  End Sub
End Class