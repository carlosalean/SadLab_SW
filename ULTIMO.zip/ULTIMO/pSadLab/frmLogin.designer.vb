<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmLogin
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public cmdBaseDatosOpen As System.Windows.Forms.OpenFileDialog
    Public WithEvents cboUsuario As System.Windows.Forms.ComboBox
    Public WithEvents cmdCancel As System.Windows.Forms.Button
    Public WithEvents cmdOK As System.Windows.Forms.Button
    Public WithEvents txtPassword As System.Windows.Forms.TextBox
    Public WithEvents _lblLabels_1 As System.Windows.Forms.Label
    Public WithEvents _lblLabels_0 As System.Windows.Forms.Label
    'Public WithEvents lblLabels As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLogin))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdBaseDatosOpen = New System.Windows.Forms.OpenFileDialog()
        Me.cboUsuario = New System.Windows.Forms.ComboBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me._lblLabels_1 = New System.Windows.Forms.Label()
        Me._lblLabels_0 = New System.Windows.Forms.Label()
        Me.BtnDetalles = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.BtnConectar = New System.Windows.Forms.Button()
        Me.CboDataBase = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cboServidor = New System.Windows.Forms.ComboBox()
        Me.TxtClave = New System.Windows.Forms.TextBox()
        Me.TxtUsuario = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ChkAutenticacionWindows = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.VerificationControl = New DPFP.Gui.Verification.VerificationControl()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdBaseDatosOpen
        '
        Me.cmdBaseDatosOpen.FileName = "*.mdb"
        '
        'cboUsuario
        '
        Me.cboUsuario.BackColor = System.Drawing.SystemColors.Window
        Me.cboUsuario.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboUsuario.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboUsuario.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboUsuario.Location = New System.Drawing.Point(147, 12)
        Me.cboUsuario.Name = "cboUsuario"
        Me.cboUsuario.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboUsuario.Size = New System.Drawing.Size(186, 21)
        Me.cboUsuario.TabIndex = 1
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Image = CType(resources.GetObject("cmdCancel.Image"), System.Drawing.Image)
        Me.cmdCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdCancel.Location = New System.Drawing.Point(189, 75)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(97, 32)
        Me.cmdCancel.TabIndex = 3
        Me.cmdCancel.Tag = "Cancelar"
        Me.cmdCancel.Text = "Cancelar"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdOK
        '
        Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
        Me.cmdOK.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdOK.Image = CType(resources.GetObject("cmdOK.Image"), System.Drawing.Image)
        Me.cmdOK.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.cmdOK.Location = New System.Drawing.Point(86, 75)
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdOK.Size = New System.Drawing.Size(97, 32)
        Me.cmdOK.TabIndex = 2
        Me.cmdOK.Tag = "Aceptar"
        Me.cmdOK.Text = "   Aceptar"
        Me.cmdOK.UseVisualStyleBackColor = False
        '
        'txtPassword
        '
        Me.txtPassword.AcceptsReturn = True
        Me.txtPassword.BackColor = System.Drawing.SystemColors.Window
        Me.txtPassword.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPassword.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPassword.ImeMode = System.Windows.Forms.ImeMode.Disable
        Me.txtPassword.Location = New System.Drawing.Point(147, 42)
        Me.txtPassword.MaxLength = 0
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtPassword.Size = New System.Drawing.Size(186, 20)
        Me.txtPassword.TabIndex = 0
        '
        '_lblLabels_1
        '
        Me._lblLabels_1.BackColor = System.Drawing.SystemColors.Control
        Me._lblLabels_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._lblLabels_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lblLabels_1.Location = New System.Drawing.Point(78, 44)
        Me._lblLabels_1.Name = "_lblLabels_1"
        Me._lblLabels_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lblLabels_1.Size = New System.Drawing.Size(72, 17)
        Me._lblLabels_1.TabIndex = 0
        Me._lblLabels_1.Tag = "&Contrase�a:"
        Me._lblLabels_1.Text = "&Contrase�a:"
        '
        '_lblLabels_0
        '
        Me._lblLabels_0.BackColor = System.Drawing.SystemColors.Control
        Me._lblLabels_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._lblLabels_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._lblLabels_0.Location = New System.Drawing.Point(78, 17)
        Me._lblLabels_0.Name = "_lblLabels_0"
        Me._lblLabels_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lblLabels_0.Size = New System.Drawing.Size(56, 17)
        Me._lblLabels_0.TabIndex = 2
        Me._lblLabels_0.Tag = "&Usuario:"
        Me._lblLabels_0.Text = "Usuario:"
        '
        'BtnDetalles
        '
        Me.BtnDetalles.BackColor = System.Drawing.SystemColors.Control
        Me.BtnDetalles.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnDetalles.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnDetalles.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BtnDetalles.Location = New System.Drawing.Point(292, 75)
        Me.BtnDetalles.Name = "BtnDetalles"
        Me.BtnDetalles.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnDetalles.Size = New System.Drawing.Size(97, 32)
        Me.BtnDetalles.TabIndex = 4
        Me.BtnDetalles.Tag = "Cancelar"
        Me.BtnDetalles.Text = "Detalles >>"
        Me.BtnDetalles.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.BtnConectar)
        Me.GroupBox1.Controls.Add(Me.CboDataBase)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.cboServidor)
        Me.GroupBox1.Controls.Add(Me.TxtClave)
        Me.GroupBox1.Controls.Add(Me.TxtUsuario)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.ChkAutenticacionWindows)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(6, 119)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(388, 156)
        Me.GroupBox1.TabIndex = 11
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Detalles de Conecci�n"
        '
        'BtnConectar
        '
        Me.BtnConectar.Location = New System.Drawing.Point(285, 115)
        Me.BtnConectar.Name = "BtnConectar"
        Me.BtnConectar.Size = New System.Drawing.Size(97, 32)
        Me.BtnConectar.TabIndex = 4
        Me.BtnConectar.Text = "Conectar..."
        Me.BtnConectar.UseVisualStyleBackColor = True
        '
        'CboDataBase
        '
        Me.CboDataBase.FormattingEnabled = True
        Me.CboDataBase.Location = New System.Drawing.Point(108, 122)
        Me.CboDataBase.Name = "CboDataBase"
        Me.CboDataBase.Size = New System.Drawing.Size(121, 21)
        Me.CboDataBase.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(16, 125)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(77, 13)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = "Base de Datos"
        '
        'cboServidor
        '
        Me.cboServidor.FormattingEnabled = True
        Me.cboServidor.Location = New System.Drawing.Point(108, 19)
        Me.cboServidor.Name = "cboServidor"
        Me.cboServidor.Size = New System.Drawing.Size(206, 21)
        Me.cboServidor.TabIndex = 0
        '
        'TxtClave
        '
        Me.TxtClave.Location = New System.Drawing.Point(108, 95)
        Me.TxtClave.MaxLength = 20
        Me.TxtClave.Name = "TxtClave"
        Me.TxtClave.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TxtClave.Size = New System.Drawing.Size(87, 20)
        Me.TxtClave.TabIndex = 2
        '
        'TxtUsuario
        '
        Me.TxtUsuario.AcceptsReturn = True
        Me.TxtUsuario.Location = New System.Drawing.Point(108, 69)
        Me.TxtUsuario.Name = "TxtUsuario"
        Me.TxtUsuario.Size = New System.Drawing.Size(87, 20)
        Me.TxtUsuario.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 95)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Clave"
        '
        'ChkAutenticacionWindows
        '
        Me.ChkAutenticacionWindows.AutoSize = True
        Me.ChkAutenticacionWindows.Checked = True
        Me.ChkAutenticacionWindows.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ChkAutenticacionWindows.Location = New System.Drawing.Point(19, 46)
        Me.ChkAutenticacionWindows.Name = "ChkAutenticacionWindows"
        Me.ChkAutenticacionWindows.Size = New System.Drawing.Size(138, 17)
        Me.ChkAutenticacionWindows.TabIndex = 20
        Me.ChkAutenticacionWindows.Text = "Autenticaci�n Windows"
        Me.ChkAutenticacionWindows.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 13)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Usuario"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Servidor"
        '
        'VerificationControl
        '
        Me.VerificationControl.Active = True
        Me.VerificationControl.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.VerificationControl.Location = New System.Drawing.Point(6, 12)
        Me.VerificationControl.Name = "VerificationControl"
        Me.VerificationControl.ReaderSerialNumber = "00000000-0000-0000-0000-000000000000"
        Me.VerificationControl.Size = New System.Drawing.Size(66, 71)
        Me.VerificationControl.TabIndex = 12
        '
        'frmLogin
        '
        Me.AcceptButton = Me.cmdOK
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton = Me.cmdCancel
        Me.ClientSize = New System.Drawing.Size(404, 281)
        Me.Controls.Add(Me.VerificationControl)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.BtnDetalles)
        Me.Controls.Add(Me.cboUsuario)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdOK)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me._lblLabels_1)
        Me.Controls.Add(Me._lblLabels_0)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Location = New System.Drawing.Point(3, 22)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLogin"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Tag = "Inicio de sesi�n"
        Me.Text = "Inicio de sesi�n"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents BtnDetalles As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtClave As System.Windows.Forms.TextBox
    Friend WithEvents TxtUsuario As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ChkAutenticacionWindows As System.Windows.Forms.CheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cboServidor As System.Windows.Forms.ComboBox
    Friend WithEvents BtnConectar As System.Windows.Forms.Button
    Friend WithEvents CboDataBase As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents VerificationControl As DPFP.Gui.Verification.VerificationControl
#End Region
End Class