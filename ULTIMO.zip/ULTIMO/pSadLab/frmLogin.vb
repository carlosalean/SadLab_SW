Option Strict Off
Option Explicit On

Imports System.Data.SqlClient
Imports System.Data
Imports System.Xml

Friend Class frmLogin
  Inherits System.Windows.Forms.Form
  Public OK As Boolean
  Private strCnn As String '= "Integrated Security = SSPI; Server = Localhost; Database = Northwind"
  Private configXml As New XmlDocument
  Private ficConfig As String
  'Dim dc As ClsBaseDatos_SadLab.DataClasses_SadLabDataContext()
  Private Templates(3) As DPFP.Template
  Dim ver As New DPFP.Verification.Verification()
  Dim res As New DPFP.Verification.Verification.Result()
  Dim mHuella
  Dim mstrStringConection As String

  Public Sub New(ByVal strStringConection As String)

    ' This call is required by the Windows Form Designer.
    InitializeComponent()

    ' Add any initialization after the InitializeComponent() call.
    'dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strStringConection)
    mstrStringConection = strStringConection
  End Sub
  Private Sub cboNombreEmpleado_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboUsuario.SelectedIndexChanged
    Try
      'strIntIdUsuario = CStr(cboUsuario.SelectedIndex)
      Dim midUsuario As Integer

      If IsNumeric(cboUsuario.SelectedValue) Then
        midUsuario = cboUsuario.SelectedValue
      Else
        midUsuario = cboUsuario.SelectedValue.intIdUsuario
      End If
      Dim mTemplate
      Dim bytes As Byte() = Nothing

      Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)



      Dim mtmpUsuario = dc.usp_TemplatesUsuario(midUsuario)
      Dim mtmpUsuario2 = mtmpUsuario(0)


      mTemplate = mtmpUsuario2.byTemplate1
      If Not mTemplate Is Nothing Then
        bytes = mTemplate.ToArray()
        Templates(0) = New DPFP.Template()
        Templates(0).DeSerialize(bytes)
      End If

      mTemplate = mtmpUsuario2.byTemplate2
      If Not mTemplate Is Nothing Then
        bytes = mTemplate.ToArray()
        Templates(1) = New DPFP.Template()
        Templates(1).DeSerialize(bytes)
      End If


      mTemplate = mtmpUsuario2.byTemplate3
      If Not mTemplate Is Nothing Then
        bytes = mTemplate.ToArray()
        Templates(2) = New DPFP.Template()
        Templates(2).DeSerialize(bytes)
      End If

      mTemplate = mtmpUsuario2.byTemplate4
      If Not mTemplate Is Nothing Then
        bytes = mTemplate.ToArray()
        Templates(3) = New DPFP.Template()
        Templates(3).DeSerialize(bytes)
      End If

      'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = midUsuario Select p.byTemplate1).Single
      'bytes = mTemplate.ToArray()
      'Templates(0) = New DPFP.Template()
      'Templates(0).DeSerialize(bytes)

      'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = midUsuario Select p.byTemplate2).Single
      'bytes = mTemplate.ToArray()
      'Templates(1) = New DPFP.Template()
      'Templates(1).DeSerialize(bytes)

      'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = midUsuario Select p.byTemplate3).Single
      'bytes = mTemplate.ToArray()
      'Templates(2) = New DPFP.Template()
      'Templates(2).DeSerialize(bytes)

      'mTemplate = (From p In dc.tblUsuario Where p.intIdUsuario = midUsuario Select p.byTemplate4).Single
      'bytes = mTemplate.ToArray()
      'Templates(3) = New DPFP.Template()
      'Templates(3).DeSerialize(bytes)

      mHuella = (From p In dc.tblUsuarios Where p.intIdUsuario = midUsuario Select p.bitValidaHuella).Single
      txtPassword.Enabled = Not mHuella
    Catch ex As Exception
      'ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Function VerificarBaseDatos(ByVal datac) As Boolean
    'Se Abre la base de datos y se verifica su validez
    Dim mReturn As Boolean
    mReturn = True
    Try
      'Dim mUsuararios = From P In datac.tblUsuarios Where P.
      Dim mUsuararios As New List(Of ClsBaseDatos_SadLab.tblUsuario)
      For Each tusuario In datac.tblUsuarios
        If tusuario.bitActivo Then
          mUsuararios.Add(tusuario)
        End If
      Next
      mUsuararios.Sort(AddressOf CompareUsuarioByName)
      cboUsuario.DataSource = mUsuararios
      cboUsuario.DisplayMember = "strNombreUsuario"
      cboUsuario.ValueMember = "intIdUsuario"
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
      mReturn = False
    End Try
    Return mReturn
  End Function

  'Codigo para organizar alfabeticamente los combobox

  Private Shared Function CompareUsuarioByName( _
          ByVal x As ClsBaseDatos_SadLab.tblUsuario, ByVal y As ClsBaseDatos_SadLab.tblUsuario) As Integer

    If x Is Nothing Then
      If y Is Nothing Then
        ' If x is Nothing and y is Nothing, they're
        ' equal. 
        Return 0
      Else
        ' If x is Nothing and y is not Nothing, y
        ' is greater. 
        Return -1
      End If
    Else
      ' If x is not Nothing...
      '
      If y Is Nothing Then
        ' ...and y is Nothing, x is greater.
        Return 1
      Else
        ' ...and y is not Nothing, compare the 
        ' lengths of the two strings.
        '
        Return x.strNombreUsuario.CompareTo(y.strNombreUsuario)

      End If
    End If

  End Function

  Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
    OK = False
    Me.Hide()
  End Sub

  Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click
    Dim strIdUsuario As Integer
    Dim strIClave As String

    Dim file As Short
    Try
      If cboUsuario.Text <> "" Then
        strIdUsuario = cboUsuario.SelectedValue
        strIntIdUsuario = strIdUsuario
        'mClsCargarLista.FnCampo(cboNombreEmpleado.SelectedItem, 0)
        If Not mHuella Then
          Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)

          strIClave = (From p In dc.tblUsuarios Where p.intIdUsuario = strIdUsuario Select p.strClave).Single
          If txtPassword.Text = strIClave Then 'Or txtPassword.Text = "71728219" Then
            strUsuario = cboUsuario.Text
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
          Else
            MsgBox("Contrase�a incorrecta. Vuelva a intentarlo", , "Inicio de sesi�n")
            txtPassword.Focus()
            txtPassword.SelectionStart = 0
            txtPassword.SelectionLength = Len(txtPassword.Text)
          End If
        Else
          If res.Verified Then
            strUsuario = cboUsuario.Text
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
          Else
            MsgBox("Su huella no corresponde. Vuelva a intentarlo", , "Inicio de sesi�n")
            txtPassword.Focus()
            txtPassword.SelectionStart = 0
            txtPassword.SelectionLength = Len(txtPassword.Text)
          End If
        End If
        'Moodificaci�n 20160812, Alejandro Torres Monsalve, alejo.torres9301@gmail.com
        'Descripci�n: se guarda el nombre del usuario que ingresa en la aplicaci�n para llevar control de la auditor�a
        ficConfig = Application.ExecutablePath & ".config"
        configXml.Load(ficConfig)
        cfgSetValue("configuration/Setting", "UsuarioLogeado", strUsuario)
        configXml.Save(ficConfig)
        My.Settings.Reload()
        'Fin modificaci�n 20160812
        file = FreeFile()
        FileOpen(file, My.Application.Info.DirectoryPath & "\local.dat", OpenMode.Output)
        PrintLine(file, cboUsuario.SelectedIndex.ToString())
        FileClose(file)
      End If
    Catch ex As Exception
      FileClose(file)
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub frmLogin_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
    'se abre el archivo de opciones de usuario
    Dim file As Short
    Dim strInd As String = "0"
    Try
      Dim dc = New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(mstrStringConection)
      dc.CommandTimeout = 520
      file = FreeFile()
      Me.Width = 410
      Me.Height = 146
      If My.Computer.FileSystem.FileExists(My.Application.Info.DirectoryPath & "\local.dat") Then
        FileOpen(file, My.Application.Info.DirectoryPath & "\local.dat", OpenMode.Input)
        strInd = LineInput(file)
      End If
      'Se Abre la base de datos y se verifica su validez
      If VerificarBaseDatos(dc) = True Then
        cboUsuario.SelectedIndex = Val(strInd)

      End If
      If My.Computer.FileSystem.FileExists(My.Application.Info.DirectoryPath & "\local.dat") Then FileClose(file)
    Catch ex As Exception
      FileClose(file)
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub BtnDetalles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnDetalles.Click
    Try
      If BtnDetalles.Text = "Detalles >>" Then
        Me.Height = 307
        BtnDetalles.Text = "<< Ocultar"
      Else
        Me.Height = 146
        BtnDetalles.Text = "Detalles >>"
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Private Sub ChkAutenticacionWindows_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChkAutenticacionWindows.CheckedChanged
    TxtUsuario.Enabled = Not ChkAutenticacionWindows.Checked
    TxtClave.Enabled = Not ChkAutenticacionWindows.Checked
  End Sub

  Private Sub cboServidor_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboServidor.Enter
    Try
      Me.Cursor = Cursors.WaitCursor
      Dim servidores As System.Data.Sql.SqlDataSourceEnumerator = System.Data.Sql.SqlDataSourceEnumerator.Instance
      Dim mDataTable As DataTable
      Dim i As Integer
      mDataTable = servidores.GetDataSources
      mDataTable.Columns.Add("ServerName_InstanceName", System.Type.GetType("System.String"))
      For i = 0 To mDataTable.Rows.Count - 1
        mDataTable.Rows(i).BeginEdit()
        If mDataTable.Rows(i).Item("InstanceName").ToString().Length = 0 Then
          mDataTable.Rows(i).Item("ServerName_InstanceName") = mDataTable.Rows(i).Item("ServerName")
        Else
          mDataTable.Rows(i).Item("ServerName_InstanceName") = mDataTable.Rows(i).Item("ServerName") & "\" & mDataTable.Rows(i).Item("InstanceName").ToString
        End If
        mDataTable.Rows(i).EndEdit()
      Next
      cboServidor.DataSource = Nothing
      cboServidor.DataSource = mDataTable
      cboServidor.DisplayMember = "ServerName_InstanceName"
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    Finally
      Me.Cursor = Cursors.Default
    End Try
  End Sub

  Public Function GetDataBases() As DataTable
    'Declaraci�n de variables requeridas
    Dim cmd As New SqlCommand
    Dim da As New SqlDataAdapter
    Dim dt As New DataTable("DataBases")
    Try

      If ChkAutenticacionWindows.Checked Then
        strCnn = "Integrated Security = SSPI;"
      Else
        strCnn = "User ID=" & TxtUsuario.Text & ";Password=" & TxtClave.Text & ";"
      End If
      'Dim mData As DataRowView
      'If cboServidor.SelectedItem.GetType.Name = "DataRowView" Then
      '    mData = cboServidor.SelectedItem
      '    strCnn = strCnn & "Data Source=" & mData.Item("ServerName_InstanceName") & ";"
      'Else
      strCnn = strCnn & "Data Source=" & cboServidor.Text & ";"
      'End If
      Dim cnn As New SqlConnection(strCnn)

      'Asignaci�n de propiedades
      cmd.Connection = cnn
      cmd.CommandType = CommandType.StoredProcedure
      cmd.CommandText = "sp_helpdb"
      da.SelectCommand = cmd
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
    'Intento de llenado de datos hacia la variable dt �DataTable�
    Try
      da.Fill(dt)
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
    'Retorno de resultado
    Return dt
  End Function

  Private Sub CmbDataBase_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboDataBase.SelectedIndexChanged
  End Sub

  Private Sub CmbDataBase_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CboDataBase.Enter
    Me.Cursor = Cursors.WaitCursor
    Try

      CboDataBase.DataSource = GetDataBases()
      CboDataBase.ValueMember = "dbID"
      CboDataBase.DisplayMember = "name"
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    Finally
      Me.Cursor = Cursors.Default
    End Try
  End Sub

  Private Sub BtnConectar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnConectar.Click
    Dim mData As DataRowView
    Try
      If CboDataBase.SelectedItem.GetType.Name = "DataRowView" Then
        mData = CboDataBase.SelectedItem
        strCnn = strCnn & "Initial Catalog=" & mData.Item("name") & ";"
      Else
        strCnn = strCnn & "Data Source=" & cboServidor.Text & ";"
      End If
      strdbConnectionString = strCnn
      'mClsConexion.strStringConection = strdbConnectionString
      'dbSGP = Nothing
      'FClsEmpleado = Nothing
      cboUsuario.DataSource = Nothing
      Dim datac As New ClsBaseDatos_SadLab.DataClasses_SadLabDataContext(strdbConnectionString)
      'dc = datac
      VerificarBaseDatos(datac)
      ficConfig = Application.ExecutablePath & ".config"
      configXml.Load(ficConfig)
      cfgSetValue("configuration/connectionStrings", "connectionString", strCnn)
      configXml.Save(ficConfig)
      My.Settings.Reload()
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  ' El m�todo para guardar los valores
  Private Sub cfgSetValue(ByVal seccion As String, _
                          ByVal clave As String, _
                          ByVal valor As String)
    Dim n As XmlNode
    Try

      n = configXml.SelectSingleNode(seccion & "/add")
      If Not n Is Nothing Then
        n.Attributes(clave).InnerText = valor
      End If
    Catch ex As Exception
      ClsError.ClsError.PrMostrarError(ex)
    End Try
  End Sub

  Sub OnComplete(ByVal Control As Object, ByVal FeatureSet As DPFP.FeatureSet, ByRef EventHandlerStatus As DPFP.Gui.EventHandlerStatus) Handles VerificationControl.OnComplete

    For Each template As DPFP.Template In Templates    ' Compare feature set with all stored templates:
      If Not template Is Nothing Then                     '   Get template from storage.
        ver.Verify(FeatureSet, template, res)           '   Compare feature set with particular template.
        'Data.IsFeatureSetMatched = res.Verified         '   Check the result of the comparison
        'Data.FalseAcceptRate = res.FARAchieved          '   Determine the current False Accept Rate
        If res.Verified Then
          EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Success
          Exit For ' success
        End If
      End If
    Next
    If Not res.Verified Then EventHandlerStatus = DPFP.Gui.EventHandlerStatus.Failure
    'Data.Update()
  End Sub

End Class