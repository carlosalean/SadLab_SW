Option Strict Off
Option Explicit On

Imports System.Globalization

Module Principal
    Public strdbConnectionString As String = My.Settings.strStringConection
    Public strUsuario As String
    Public strIntIdUsuario As String
  Public strIntIdSede As Integer = My.Settings.intIdSede
    Public intIdCaja As Integer
    Public mPermisosHC As ClsUtilidades.ClsPermisos.ClsHistoriasClinicas
    Public bitModificaCoopagoFactura As Boolean = False

    Public FDecimales As String = "."
    Public FMiles As String = ","
    Public forceDotCulture As CultureInfo
    Public numberFormatInfo As NumberFormatInfo = System.Globalization.CultureInfo.CurrentCulture.NumberFormat
    Public decimalSeparator As String = numberFormatInfo.NumberDecimalSeparator
    Public groupSeparator As String = numberFormatInfo.NumberGroupSeparator
    Public negativeSign As String = numberFormatInfo.NegativeSign



    Public Sub Main()
        Try
        Catch ex As Exception

        End Try

        'SE TRASLADO PARA EL LOAD DEL MENU
    End Sub
End Module