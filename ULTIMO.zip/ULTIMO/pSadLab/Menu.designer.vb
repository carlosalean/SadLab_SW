<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Menu))
    Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
    Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
    Me.CitasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
    Me.RegistroSalidaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
    Me.AgendaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.DatosFacturacionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ResultadosExamToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
    Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ArchivoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PacientesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.EmpleadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.DivisionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.EpsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ExamenesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.TarifasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItemTarifaBase = New System.Windows.Forms.ToolStripMenuItem()
    Me.DescuentosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ResultadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.TurnosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PaisesYDepartamentosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.DepartamentosYCiudadesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.CajasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.DatosPrestadoresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.SedesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.CajasToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
    Me.TiposToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
    Me.MotivosConsultaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.FrecuenciaMedicamentosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ProtocolosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.LaboratoriosFarmac�uticosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.SintomasSignosLaboratoriosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.OcupacionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.MedicamentosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PrincipiosActivosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ItemRevisi�nToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.IPSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
    Me.CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.UsuariosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.GruposYAcesosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.CANCELACI�ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.Anulaci�nDeFacturasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ParaEPSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ParaPacientesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.PorcesosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.Generaraci�nDeFacturasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.InformesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.CuentasCobrarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.TiemposToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
    Me.PagosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.rptFacturacionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.NormalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.NormaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.AnuladaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.AnuladasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.NormalToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
    Me.AnuladaToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
    Me.IndicadorDeOportunidadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
    Me.CitasPacienteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ProcedimientosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.Liquidaci�nToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.FinancierosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ServiciosPrestadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.Importai�nFacturasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.FacturasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.CopagosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.miRIPS = New System.Windows.Forms.ToolStripMenuItem()
    Me.AyudaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.AcercaDeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.IndiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.RutaConfigToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
    Me.ToolStripButtonCambiarUsuario = New System.Windows.Forms.ToolStripButton()
    Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
    Me.TlSStUsuario = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripProgressBar1 = New System.Windows.Forms.ToolStripProgressBar()
    Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.lblVersion = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripStatusLabelCaja = New System.Windows.Forms.ToolStripStatusLabel()
    Me.lblCaja = New System.Windows.Forms.ToolStripStatusLabel()
    Me.MenuStrip1.SuspendLayout()
    Me.ToolStrip1.SuspendLayout()
    Me.StatusStrip1.SuspendLayout()
    Me.SuspendLayout()
    '
    'MenuStrip1
    '
    Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.ArchivoToolStripMenuItem, Me.ToolStripMenuItem3, Me.PorcesosToolStripMenuItem, Me.InformesToolStripMenuItem, Me.AyudaToolStripMenuItem})
    Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
    Me.MenuStrip1.Name = "MenuStrip1"
    Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
    Me.MenuStrip1.TabIndex = 0
    Me.MenuStrip1.Text = "MenuStrip1"
    '
    'ToolStripMenuItem1
    '
    Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CitasToolStripMenuItem, Me.ToolStripMenuItem4, Me.RegistroSalidaToolStripMenuItem, Me.ToolStripMenuItem2, Me.AgendaToolStripMenuItem, Me.DatosFacturacionToolStripMenuItem, Me.ResultadosExamToolStripMenuItem, Me.ToolStripMenuItem6, Me.ToolStripMenuItem7, Me.SalirToolStripMenuItem})
    Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
    Me.ToolStripMenuItem1.Size = New System.Drawing.Size(65, 20)
    Me.ToolStripMenuItem1.Tag = "100"
    Me.ToolStripMenuItem1.Text = "Capturar"
    '
    'CitasToolStripMenuItem
    '
    Me.CitasToolStripMenuItem.Image = CType(resources.GetObject("CitasToolStripMenuItem.Image"), System.Drawing.Image)
    Me.CitasToolStripMenuItem.Name = "CitasToolStripMenuItem"
    Me.CitasToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
    Me.CitasToolStripMenuItem.Tag = "101"
    Me.CitasToolStripMenuItem.Text = "Asignar Citas"
    '
    'ToolStripMenuItem4
    '
    Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
    Me.ToolStripMenuItem4.Size = New System.Drawing.Size(218, 22)
    Me.ToolStripMenuItem4.Tag = "105"
    Me.ToolStripMenuItem4.Text = "Registro de Llegada"
    '
    'RegistroSalidaToolStripMenuItem
    '
    Me.RegistroSalidaToolStripMenuItem.Name = "RegistroSalidaToolStripMenuItem"
    Me.RegistroSalidaToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
    Me.RegistroSalidaToolStripMenuItem.Tag = "109"
    Me.RegistroSalidaToolStripMenuItem.Text = "Registro de Salida"
    '
    'ToolStripMenuItem2
    '
    Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
    Me.ToolStripMenuItem2.Size = New System.Drawing.Size(218, 22)
    Me.ToolStripMenuItem2.Tag = "110"
    Me.ToolStripMenuItem2.Text = "Novedades Citas"
    '
    'AgendaToolStripMenuItem
    '
    Me.AgendaToolStripMenuItem.Image = CType(resources.GetObject("AgendaToolStripMenuItem.Image"), System.Drawing.Image)
    Me.AgendaToolStripMenuItem.Name = "AgendaToolStripMenuItem"
    Me.AgendaToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
    Me.AgendaToolStripMenuItem.Tag = "2"
    Me.AgendaToolStripMenuItem.Text = "Agenda"
    Me.AgendaToolStripMenuItem.Visible = False
    '
    'DatosFacturacionToolStripMenuItem
    '
    Me.DatosFacturacionToolStripMenuItem.Name = "DatosFacturacionToolStripMenuItem"
    Me.DatosFacturacionToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
    Me.DatosFacturacionToolStripMenuItem.Tag = "130"
    Me.DatosFacturacionToolStripMenuItem.Text = "Registrar Datos Facturaci�n"
    '
    'ResultadosExamToolStripMenuItem
    '
    Me.ResultadosExamToolStripMenuItem.Name = "ResultadosExamToolStripMenuItem"
    Me.ResultadosExamToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
    Me.ResultadosExamToolStripMenuItem.Tag = "140"
    Me.ResultadosExamToolStripMenuItem.Text = "Resultados Examenes"
    Me.ResultadosExamToolStripMenuItem.Visible = False
    '
    'ToolStripMenuItem6
    '
    Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
    Me.ToolStripMenuItem6.Size = New System.Drawing.Size(218, 22)
    Me.ToolStripMenuItem6.Tag = "150"
    Me.ToolStripMenuItem6.Text = "Abrir Caja"
    '
    'ToolStripMenuItem7
    '
    Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
    Me.ToolStripMenuItem7.Size = New System.Drawing.Size(218, 22)
    Me.ToolStripMenuItem7.Tag = "160"
    Me.ToolStripMenuItem7.Text = "Cerrar Caja"
    '
    'SalirToolStripMenuItem
    '
    Me.SalirToolStripMenuItem.Image = CType(resources.GetObject("SalirToolStripMenuItem.Image"), System.Drawing.Image)
    Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
    Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(218, 22)
    Me.SalirToolStripMenuItem.Tag = "4"
    Me.SalirToolStripMenuItem.Text = "Salir"
    '
    'ArchivoToolStripMenuItem
    '
    Me.ArchivoToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PacientesToolStripMenuItem, Me.EmpleadosToolStripMenuItem, Me.DivisionToolStripMenuItem, Me.EpsToolStripMenuItem, Me.ExamenesToolStripMenuItem, Me.TarifasToolStripMenuItem, Me.ToolStripMenuItemTarifaBase, Me.DescuentosToolStripMenuItem, Me.ResultadosToolStripMenuItem, Me.TurnosToolStripMenuItem, Me.PaisesYDepartamentosToolStripMenuItem, Me.DepartamentosYCiudadesToolStripMenuItem, Me.CajasToolStripMenuItem, Me.DatosPrestadoresToolStripMenuItem, Me.SedesToolStripMenuItem, Me.CajasToolStripMenuItem1, Me.TiposToolStripMenuItem, Me.ToolStripMenuItem8, Me.IPSToolStripMenuItem})
    Me.ArchivoToolStripMenuItem.Name = "ArchivoToolStripMenuItem"
    Me.ArchivoToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
    Me.ArchivoToolStripMenuItem.Tag = "200"
    Me.ArchivoToolStripMenuItem.Text = "Archivo"
    '
    'PacientesToolStripMenuItem
    '
    Me.PacientesToolStripMenuItem.Name = "PacientesToolStripMenuItem"
    Me.PacientesToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.PacientesToolStripMenuItem.Tag = "201"
    Me.PacientesToolStripMenuItem.Text = "Pacientes"
    '
    'EmpleadosToolStripMenuItem
    '
    Me.EmpleadosToolStripMenuItem.Name = "EmpleadosToolStripMenuItem"
    Me.EmpleadosToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.EmpleadosToolStripMenuItem.Tag = "202"
    Me.EmpleadosToolStripMenuItem.Text = "Empleados y Profesionales"
    '
    'DivisionToolStripMenuItem
    '
    Me.DivisionToolStripMenuItem.Name = "DivisionToolStripMenuItem"
    Me.DivisionToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.DivisionToolStripMenuItem.Tag = "203"
    Me.DivisionToolStripMenuItem.Text = "Division Vasculab"
    '
    'EpsToolStripMenuItem
    '
    Me.EpsToolStripMenuItem.Name = "EpsToolStripMenuItem"
    Me.EpsToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.EpsToolStripMenuItem.Tag = "204"
    Me.EpsToolStripMenuItem.Text = "EPS"
    '
    'ExamenesToolStripMenuItem
    '
    Me.ExamenesToolStripMenuItem.Name = "ExamenesToolStripMenuItem"
    Me.ExamenesToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.ExamenesToolStripMenuItem.Tag = "210"
    Me.ExamenesToolStripMenuItem.Text = "Ex�menes y Procedimientos"
    '
    'TarifasToolStripMenuItem
    '
    Me.TarifasToolStripMenuItem.Name = "TarifasToolStripMenuItem"
    Me.TarifasToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.TarifasToolStripMenuItem.Tag = "220"
    Me.TarifasToolStripMenuItem.Text = "Tarifas"
    '
    'ToolStripMenuItemTarifaBase
    '
    Me.ToolStripMenuItemTarifaBase.Name = "ToolStripMenuItemTarifaBase"
    Me.ToolStripMenuItemTarifaBase.Size = New System.Drawing.Size(221, 22)
    Me.ToolStripMenuItemTarifaBase.Tag = "225"
    Me.ToolStripMenuItemTarifaBase.Text = "Tarifas Base"
    '
    'DescuentosToolStripMenuItem
    '
    Me.DescuentosToolStripMenuItem.Name = "DescuentosToolStripMenuItem"
    Me.DescuentosToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.DescuentosToolStripMenuItem.Tag = "230"
    Me.DescuentosToolStripMenuItem.Text = "Descuentos"
    '
    'ResultadosToolStripMenuItem
    '
    Me.ResultadosToolStripMenuItem.Name = "ResultadosToolStripMenuItem"
    Me.ResultadosToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.ResultadosToolStripMenuItem.Tag = "240"
    Me.ResultadosToolStripMenuItem.Text = "Resultados"
    Me.ResultadosToolStripMenuItem.Visible = False
    '
    'TurnosToolStripMenuItem
    '
    Me.TurnosToolStripMenuItem.Name = "TurnosToolStripMenuItem"
    Me.TurnosToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.TurnosToolStripMenuItem.Tag = "250"
    Me.TurnosToolStripMenuItem.Text = "Turnos"
    '
    'PaisesYDepartamentosToolStripMenuItem
    '
    Me.PaisesYDepartamentosToolStripMenuItem.Name = "PaisesYDepartamentosToolStripMenuItem"
    Me.PaisesYDepartamentosToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.PaisesYDepartamentosToolStripMenuItem.Tag = "260"
    Me.PaisesYDepartamentosToolStripMenuItem.Text = "Departamentos"
    '
    'DepartamentosYCiudadesToolStripMenuItem
    '
    Me.DepartamentosYCiudadesToolStripMenuItem.Name = "DepartamentosYCiudadesToolStripMenuItem"
    Me.DepartamentosYCiudadesToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.DepartamentosYCiudadesToolStripMenuItem.Tag = "280"
    Me.DepartamentosYCiudadesToolStripMenuItem.Text = "Municipios"
    '
    'CajasToolStripMenuItem
    '
    Me.CajasToolStripMenuItem.Name = "CajasToolStripMenuItem"
    Me.CajasToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.CajasToolStripMenuItem.Tag = "290"
    Me.CajasToolStripMenuItem.Text = "Cajas"
    Me.CajasToolStripMenuItem.Visible = False
    '
    'DatosPrestadoresToolStripMenuItem
    '
    Me.DatosPrestadoresToolStripMenuItem.Name = "DatosPrestadoresToolStripMenuItem"
    Me.DatosPrestadoresToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.DatosPrestadoresToolStripMenuItem.Tag = "2090"
    Me.DatosPrestadoresToolStripMenuItem.Text = "Datos Prestadores"
    '
    'SedesToolStripMenuItem
    '
    Me.SedesToolStripMenuItem.Name = "SedesToolStripMenuItem"
    Me.SedesToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.SedesToolStripMenuItem.Tag = "2010"
    Me.SedesToolStripMenuItem.Text = "Sedes"
    '
    'CajasToolStripMenuItem1
    '
    Me.CajasToolStripMenuItem1.Name = "CajasToolStripMenuItem1"
    Me.CajasToolStripMenuItem1.Size = New System.Drawing.Size(221, 22)
    Me.CajasToolStripMenuItem1.Tag = "2020"
    Me.CajasToolStripMenuItem1.Text = "Cajas"
    '
    'TiposToolStripMenuItem
    '
    Me.TiposToolStripMenuItem.Name = "TiposToolStripMenuItem"
    Me.TiposToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.TiposToolStripMenuItem.Tag = "2030"
    Me.TiposToolStripMenuItem.Text = "Tipos"
    '
    'ToolStripMenuItem8
    '
    Me.ToolStripMenuItem8.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MotivosConsultaToolStripMenuItem, Me.FrecuenciaMedicamentosToolStripMenuItem, Me.ProtocolosToolStripMenuItem, Me.LaboratoriosFarmac�uticosToolStripMenuItem, Me.SintomasSignosLaboratoriosToolStripMenuItem, Me.OcupacionesToolStripMenuItem, Me.MedicamentosToolStripMenuItem, Me.PrincipiosActivosToolStripMenuItem, Me.ItemRevisi�nToolStripMenuItem})
    Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
    Me.ToolStripMenuItem8.Size = New System.Drawing.Size(221, 22)
    Me.ToolStripMenuItem8.Tag = "2040"
    Me.ToolStripMenuItem8.Text = "Historias Cl�nicas"
    '
    'MotivosConsultaToolStripMenuItem
    '
    Me.MotivosConsultaToolStripMenuItem.Name = "MotivosConsultaToolStripMenuItem"
    Me.MotivosConsultaToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
    Me.MotivosConsultaToolStripMenuItem.Tag = "204001"
    Me.MotivosConsultaToolStripMenuItem.Text = "Motivos Consulta"
    '
    'FrecuenciaMedicamentosToolStripMenuItem
    '
    Me.FrecuenciaMedicamentosToolStripMenuItem.Name = "FrecuenciaMedicamentosToolStripMenuItem"
    Me.FrecuenciaMedicamentosToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
    Me.FrecuenciaMedicamentosToolStripMenuItem.Tag = "204005"
    Me.FrecuenciaMedicamentosToolStripMenuItem.Text = "Frecuencia medicamentos"
    '
    'ProtocolosToolStripMenuItem
    '
    Me.ProtocolosToolStripMenuItem.Name = "ProtocolosToolStripMenuItem"
    Me.ProtocolosToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
    Me.ProtocolosToolStripMenuItem.Tag = "204008"
    Me.ProtocolosToolStripMenuItem.Text = "Protocolos"
    '
    'LaboratoriosFarmac�uticosToolStripMenuItem
    '
    Me.LaboratoriosFarmac�uticosToolStripMenuItem.Name = "LaboratoriosFarmac�uticosToolStripMenuItem"
    Me.LaboratoriosFarmac�uticosToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
    Me.LaboratoriosFarmac�uticosToolStripMenuItem.Tag = "204011"
    Me.LaboratoriosFarmac�uticosToolStripMenuItem.Text = "Laboratorios farmac�uticos"
    '
    'SintomasSignosLaboratoriosToolStripMenuItem
    '
    Me.SintomasSignosLaboratoriosToolStripMenuItem.Name = "SintomasSignosLaboratoriosToolStripMenuItem"
    Me.SintomasSignosLaboratoriosToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
    Me.SintomasSignosLaboratoriosToolStripMenuItem.Tag = "204015"
    Me.SintomasSignosLaboratoriosToolStripMenuItem.Text = "Sintomas Signos y Laboratorios"
    '
    'OcupacionesToolStripMenuItem
    '
    Me.OcupacionesToolStripMenuItem.Name = "OcupacionesToolStripMenuItem"
    Me.OcupacionesToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
    Me.OcupacionesToolStripMenuItem.Tag = "204020"
    Me.OcupacionesToolStripMenuItem.Text = "Ocupaciones"
    '
    'MedicamentosToolStripMenuItem
    '
    Me.MedicamentosToolStripMenuItem.Name = "MedicamentosToolStripMenuItem"
    Me.MedicamentosToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
    Me.MedicamentosToolStripMenuItem.Tag = "204025"
    Me.MedicamentosToolStripMenuItem.Text = "Medicamentos"
    '
    'PrincipiosActivosToolStripMenuItem
    '
    Me.PrincipiosActivosToolStripMenuItem.Name = "PrincipiosActivosToolStripMenuItem"
    Me.PrincipiosActivosToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
    Me.PrincipiosActivosToolStripMenuItem.Tag = "204030"
    Me.PrincipiosActivosToolStripMenuItem.Text = "Principios Activos"
    '
    'ItemRevisi�nToolStripMenuItem
    '
    Me.ItemRevisi�nToolStripMenuItem.Name = "ItemRevisi�nToolStripMenuItem"
    Me.ItemRevisi�nToolStripMenuItem.Size = New System.Drawing.Size(239, 22)
    Me.ItemRevisi�nToolStripMenuItem.Tag = "204035"
    Me.ItemRevisi�nToolStripMenuItem.Text = "Item Revisi�n"
    '
    'IPSToolStripMenuItem
    '
    Me.IPSToolStripMenuItem.Name = "IPSToolStripMenuItem"
    Me.IPSToolStripMenuItem.Size = New System.Drawing.Size(221, 22)
    Me.IPSToolStripMenuItem.Tag = "819"
    Me.IPSToolStripMenuItem.Text = "IPS"
    '
    'ToolStripMenuItem3
    '
    Me.ToolStripMenuItem3.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem, Me.UsuariosToolStripMenuItem, Me.GruposYAcesosToolStripMenuItem, Me.CANCELACI�ToolStripMenuItem, Me.Anulaci�nDeFacturasToolStripMenuItem})
    Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
    Me.ToolStripMenuItem3.Size = New System.Drawing.Size(69, 20)
    Me.ToolStripMenuItem3.Tag = "300"
    Me.ToolStripMenuItem3.Text = "Opciones"
    '
    'CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem
    '
    Me.CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem.Name = "CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem"
    Me.CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem.Size = New System.Drawing.Size(315, 22)
    Me.CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem.Tag = "330"
    Me.CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem.Text = "Crear Copia de Seguridad de La Base de Datos"
    Me.CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem.Visible = False
    '
    'UsuariosToolStripMenuItem
    '
    Me.UsuariosToolStripMenuItem.Name = "UsuariosToolStripMenuItem"
    Me.UsuariosToolStripMenuItem.Size = New System.Drawing.Size(315, 22)
    Me.UsuariosToolStripMenuItem.Tag = "320"
    Me.UsuariosToolStripMenuItem.Text = "Usuarios"
    '
    'GruposYAcesosToolStripMenuItem
    '
    Me.GruposYAcesosToolStripMenuItem.Name = "GruposYAcesosToolStripMenuItem"
    Me.GruposYAcesosToolStripMenuItem.Size = New System.Drawing.Size(315, 22)
    Me.GruposYAcesosToolStripMenuItem.Tag = "350"
    Me.GruposYAcesosToolStripMenuItem.Text = "Grupos y Acesos"
    '
    'CANCELACI�ToolStripMenuItem
    '
    Me.CANCELACI�ToolStripMenuItem.Name = "CANCELACI�ToolStripMenuItem"
    Me.CANCELACI�ToolStripMenuItem.Size = New System.Drawing.Size(315, 22)
    Me.CANCELACI�ToolStripMenuItem.Tag = "360"
    Me.CANCELACI�ToolStripMenuItem.Text = "Cancelaci�n masiva de citas"
    '
    'Anulaci�nDeFacturasToolStripMenuItem
    '
    Me.Anulaci�nDeFacturasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ParaEPSToolStripMenuItem, Me.ParaPacientesToolStripMenuItem})
    Me.Anulaci�nDeFacturasToolStripMenuItem.Name = "Anulaci�nDeFacturasToolStripMenuItem"
    Me.Anulaci�nDeFacturasToolStripMenuItem.Size = New System.Drawing.Size(315, 22)
    Me.Anulaci�nDeFacturasToolStripMenuItem.Tag = "370"
    Me.Anulaci�nDeFacturasToolStripMenuItem.Text = "Anulaci�n de Facturas"
    '
    'ParaEPSToolStripMenuItem
    '
    Me.ParaEPSToolStripMenuItem.Name = "ParaEPSToolStripMenuItem"
    Me.ParaEPSToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
    Me.ParaEPSToolStripMenuItem.Tag = "37020"
    Me.ParaEPSToolStripMenuItem.Text = "Para EPS"
    '
    'ParaPacientesToolStripMenuItem
    '
    Me.ParaPacientesToolStripMenuItem.Name = "ParaPacientesToolStripMenuItem"
    Me.ParaPacientesToolStripMenuItem.Size = New System.Drawing.Size(150, 22)
    Me.ParaPacientesToolStripMenuItem.Tag = "37010"
    Me.ParaPacientesToolStripMenuItem.Text = "Para pacientes"
    '
    'PorcesosToolStripMenuItem
    '
    Me.PorcesosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Generaraci�nDeFacturasToolStripMenuItem})
    Me.PorcesosToolStripMenuItem.Name = "PorcesosToolStripMenuItem"
    Me.PorcesosToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
    Me.PorcesosToolStripMenuItem.Tag = "600"
    Me.PorcesosToolStripMenuItem.Text = "Porcesos"
    '
    'Generaraci�nDeFacturasToolStripMenuItem
    '
    Me.Generaraci�nDeFacturasToolStripMenuItem.Name = "Generaraci�nDeFacturasToolStripMenuItem"
    Me.Generaraci�nDeFacturasToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
    Me.Generaraci�nDeFacturasToolStripMenuItem.Tag = "610"
    Me.Generaraci�nDeFacturasToolStripMenuItem.Text = "Generaraci�n de Facturas"
    '
    'InformesToolStripMenuItem
    '
    Me.InformesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CuentasCobrarToolStripMenuItem, Me.TiemposToolStripMenuItem1, Me.PagosToolStripMenuItem, Me.rptFacturacionToolStripMenuItem, Me.IndicadorDeOportunidadToolStripMenuItem, Me.ToolStripMenuItem5, Me.CitasPacienteToolStripMenuItem, Me.ProcedimientosToolStripMenuItem, Me.Liquidaci�nToolStripMenuItem, Me.FinancierosToolStripMenuItem, Me.Importai�nFacturasToolStripMenuItem, Me.miRIPS})
    Me.InformesToolStripMenuItem.Name = "InformesToolStripMenuItem"
    Me.InformesToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
    Me.InformesToolStripMenuItem.Tag = "400"
    Me.InformesToolStripMenuItem.Text = "Informes"
    '
    'CuentasCobrarToolStripMenuItem
    '
    Me.CuentasCobrarToolStripMenuItem.Name = "CuentasCobrarToolStripMenuItem"
    Me.CuentasCobrarToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
    Me.CuentasCobrarToolStripMenuItem.Tag = "410"
    Me.CuentasCobrarToolStripMenuItem.Text = "Cuentas por Cobrar"
    Me.CuentasCobrarToolStripMenuItem.Visible = False
    '
    'TiemposToolStripMenuItem1
    '
    Me.TiemposToolStripMenuItem1.Name = "TiemposToolStripMenuItem1"
    Me.TiemposToolStripMenuItem1.Size = New System.Drawing.Size(264, 22)
    Me.TiemposToolStripMenuItem1.Tag = "420"
    Me.TiemposToolStripMenuItem1.Text = "Tiempos de Atenci�n"
    '
    'PagosToolStripMenuItem
    '
    Me.PagosToolStripMenuItem.Name = "PagosToolStripMenuItem"
    Me.PagosToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
    Me.PagosToolStripMenuItem.Tag = "440"
    Me.PagosToolStripMenuItem.Text = "Pagos Recibidos"
    Me.PagosToolStripMenuItem.Visible = False
    '
    'rptFacturacionToolStripMenuItem
    '
    Me.rptFacturacionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NormalToolStripMenuItem, Me.AnuladasToolStripMenuItem})
    Me.rptFacturacionToolStripMenuItem.Name = "rptFacturacionToolStripMenuItem"
    Me.rptFacturacionToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
    Me.rptFacturacionToolStripMenuItem.Tag = "480"
    Me.rptFacturacionToolStripMenuItem.Text = "Facturaci�n"
    '
    'NormalToolStripMenuItem
    '
    Me.NormalToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NormaToolStripMenuItem, Me.AnuladaToolStripMenuItem})
    Me.NormalToolStripMenuItem.Name = "NormalToolStripMenuItem"
    Me.NormalToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
    Me.NormalToolStripMenuItem.Tag = "48010"
    Me.NormalToolStripMenuItem.Text = "EPS"
    '
    'NormaToolStripMenuItem
    '
    Me.NormaToolStripMenuItem.Name = "NormaToolStripMenuItem"
    Me.NormaToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
    Me.NormaToolStripMenuItem.Tag = "4801010"
    Me.NormaToolStripMenuItem.Text = "Normal"
    '
    'AnuladaToolStripMenuItem
    '
    Me.AnuladaToolStripMenuItem.Name = "AnuladaToolStripMenuItem"
    Me.AnuladaToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
    Me.AnuladaToolStripMenuItem.Tag = "4801020"
    Me.AnuladaToolStripMenuItem.Text = "Anulada"
    '
    'AnuladasToolStripMenuItem
    '
    Me.AnuladasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NormalToolStripMenuItem1, Me.AnuladaToolStripMenuItem1})
    Me.AnuladasToolStripMenuItem.Name = "AnuladasToolStripMenuItem"
    Me.AnuladasToolStripMenuItem.Size = New System.Drawing.Size(119, 22)
    Me.AnuladasToolStripMenuItem.Tag = "48020"
    Me.AnuladasToolStripMenuItem.Text = "Paciente"
    '
    'NormalToolStripMenuItem1
    '
    Me.NormalToolStripMenuItem1.Name = "NormalToolStripMenuItem1"
    Me.NormalToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
    Me.NormalToolStripMenuItem1.Tag = "4802010"
    Me.NormalToolStripMenuItem1.Text = "Normal"
    '
    'AnuladaToolStripMenuItem1
    '
    Me.AnuladaToolStripMenuItem1.Name = "AnuladaToolStripMenuItem1"
    Me.AnuladaToolStripMenuItem1.Size = New System.Drawing.Size(118, 22)
    Me.AnuladaToolStripMenuItem1.Tag = "4802020"
    Me.AnuladaToolStripMenuItem1.Text = "Anulada"
    '
    'IndicadorDeOportunidadToolStripMenuItem
    '
    Me.IndicadorDeOportunidadToolStripMenuItem.Name = "IndicadorDeOportunidadToolStripMenuItem"
    Me.IndicadorDeOportunidadToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
    Me.IndicadorDeOportunidadToolStripMenuItem.Tag = "490"
    Me.IndicadorDeOportunidadToolStripMenuItem.Text = "Indicador de Oportunidad"
    '
    'ToolStripMenuItem5
    '
    Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
    Me.ToolStripMenuItem5.Size = New System.Drawing.Size(264, 22)
    Me.ToolStripMenuItem5.Tag = "460"
    Me.ToolStripMenuItem5.Text = "Citas Profesionales"
    '
    'CitasPacienteToolStripMenuItem
    '
    Me.CitasPacienteToolStripMenuItem.Name = "CitasPacienteToolStripMenuItem"
    Me.CitasPacienteToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
    Me.CitasPacienteToolStripMenuItem.Tag = "4010"
    Me.CitasPacienteToolStripMenuItem.Text = "Citas Paciente"
    '
    'ProcedimientosToolStripMenuItem
    '
    Me.ProcedimientosToolStripMenuItem.Name = "ProcedimientosToolStripMenuItem"
    Me.ProcedimientosToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
    Me.ProcedimientosToolStripMenuItem.Tag = "4060"
    Me.ProcedimientosToolStripMenuItem.Text = "Procedimientos EPS"
    '
    'Liquidaci�nToolStripMenuItem
    '
    Me.Liquidaci�nToolStripMenuItem.Name = "Liquidaci�nToolStripMenuItem"
    Me.Liquidaci�nToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
    Me.Liquidaci�nToolStripMenuItem.Tag = "4070"
    Me.Liquidaci�nToolStripMenuItem.Text = "Liquidaci�n prestadores de servicios"
    '
    'FinancierosToolStripMenuItem
    '
    Me.FinancierosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ServiciosPrestadosToolStripMenuItem})
    Me.FinancierosToolStripMenuItem.Name = "FinancierosToolStripMenuItem"
    Me.FinancierosToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
    Me.FinancierosToolStripMenuItem.Tag = "4080"
    Me.FinancierosToolStripMenuItem.Text = "Financieros"
    '
    'ServiciosPrestadosToolStripMenuItem
    '
    Me.ServiciosPrestadosToolStripMenuItem.Name = "ServiciosPrestadosToolStripMenuItem"
    Me.ServiciosPrestadosToolStripMenuItem.Size = New System.Drawing.Size(174, 22)
    Me.ServiciosPrestadosToolStripMenuItem.Tag = "408010"
    Me.ServiciosPrestadosToolStripMenuItem.Text = "Servicios Prestados"
    '
    'Importai�nFacturasToolStripMenuItem
    '
    Me.Importai�nFacturasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FacturasToolStripMenuItem, Me.CopagosToolStripMenuItem})
    Me.Importai�nFacturasToolStripMenuItem.Name = "Importai�nFacturasToolStripMenuItem"
    Me.Importai�nFacturasToolStripMenuItem.Size = New System.Drawing.Size(264, 22)
    Me.Importai�nFacturasToolStripMenuItem.Tag = "460"
    Me.Importai�nFacturasToolStripMenuItem.Text = "Exportaci�n a Contabilidad"
    '
    'FacturasToolStripMenuItem
    '
    Me.FacturasToolStripMenuItem.Name = "FacturasToolStripMenuItem"
    Me.FacturasToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
    Me.FacturasToolStripMenuItem.Tag = "46010"
    Me.FacturasToolStripMenuItem.Text = "Facturas"
    '
    'CopagosToolStripMenuItem
    '
    Me.CopagosToolStripMenuItem.Name = "CopagosToolStripMenuItem"
    Me.CopagosToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
    Me.CopagosToolStripMenuItem.Tag = "46015"
    Me.CopagosToolStripMenuItem.Text = "Copagos"
    '
    'miRIPS
    '
    Me.miRIPS.Name = "miRIPS"
    Me.miRIPS.Size = New System.Drawing.Size(264, 22)
    Me.miRIPS.Tag = "820"
    Me.miRIPS.Text = "RIPS"
    '
    'AyudaToolStripMenuItem
    '
    Me.AyudaToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AcercaDeToolStripMenuItem, Me.IndiceToolStripMenuItem, Me.RutaConfigToolStripMenuItem})
    Me.AyudaToolStripMenuItem.Name = "AyudaToolStripMenuItem"
    Me.AyudaToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
    Me.AyudaToolStripMenuItem.Tag = "500"
    Me.AyudaToolStripMenuItem.Text = "Ayuda"
    '
    'AcercaDeToolStripMenuItem
    '
    Me.AcercaDeToolStripMenuItem.Name = "AcercaDeToolStripMenuItem"
    Me.AcercaDeToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
    Me.AcercaDeToolStripMenuItem.Tag = "510"
    Me.AcercaDeToolStripMenuItem.Text = "Acerca De.."
    '
    'IndiceToolStripMenuItem
    '
    Me.IndiceToolStripMenuItem.Name = "IndiceToolStripMenuItem"
    Me.IndiceToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
    Me.IndiceToolStripMenuItem.Tag = "520"
    Me.IndiceToolStripMenuItem.Text = "Indice"
    '
    'RutaConfigToolStripMenuItem
    '
    Me.RutaConfigToolStripMenuItem.Name = "RutaConfigToolStripMenuItem"
    Me.RutaConfigToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
    Me.RutaConfigToolStripMenuItem.Tag = "540"
    Me.RutaConfigToolStripMenuItem.Text = "Ruta Config"
    '
    'ToolStrip1
    '
    Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButtonCambiarUsuario})
    Me.ToolStrip1.Location = New System.Drawing.Point(0, 24)
    Me.ToolStrip1.Name = "ToolStrip1"
    Me.ToolStrip1.Size = New System.Drawing.Size(800, 25)
    Me.ToolStrip1.TabIndex = 1
    Me.ToolStrip1.Text = "ToolStrip1"
    '
    'ToolStripButtonCambiarUsuario
    '
    Me.ToolStripButtonCambiarUsuario.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.ToolStripButtonCambiarUsuario.Image = CType(resources.GetObject("ToolStripButtonCambiarUsuario.Image"), System.Drawing.Image)
    Me.ToolStripButtonCambiarUsuario.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.ToolStripButtonCambiarUsuario.Name = "ToolStripButtonCambiarUsuario"
    Me.ToolStripButtonCambiarUsuario.Size = New System.Drawing.Size(23, 22)
    Me.ToolStripButtonCambiarUsuario.Text = "Cambiar de Usuario"
    '
    'StatusStrip1
    '
    Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TlSStUsuario, Me.ToolStripProgressBar1, Me.ToolStripStatusLabel1, Me.lblVersion, Me.ToolStripStatusLabelCaja, Me.lblCaja})
    Me.StatusStrip1.Location = New System.Drawing.Point(0, 556)
    Me.StatusStrip1.Name = "StatusStrip1"
    Me.StatusStrip1.Size = New System.Drawing.Size(800, 22)
    Me.StatusStrip1.TabIndex = 3
    Me.StatusStrip1.Text = "StatusStrip1"
    '
    'TlSStUsuario
    '
    Me.TlSStUsuario.BackColor = System.Drawing.SystemColors.ButtonFace
    Me.TlSStUsuario.Name = "TlSStUsuario"
    Me.TlSStUsuario.Size = New System.Drawing.Size(50, 17)
    Me.TlSStUsuario.Tag = ""
    Me.TlSStUsuario.Text = "Usuario:"
    '
    'ToolStripProgressBar1
    '
    Me.ToolStripProgressBar1.Name = "ToolStripProgressBar1"
    Me.ToolStripProgressBar1.Size = New System.Drawing.Size(200, 16)
    '
    'ToolStripStatusLabel1
    '
    Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
    Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(51, 17)
    Me.ToolStripStatusLabel1.Text = "Version: "
    '
    'lblVersion
    '
    Me.lblVersion.Name = "lblVersion"
    Me.lblVersion.Size = New System.Drawing.Size(120, 17)
    Me.lblVersion.Text = "ToolStripStatusLabel2"
    '
    'ToolStripStatusLabelCaja
    '
    Me.ToolStripStatusLabelCaja.Name = "ToolStripStatusLabelCaja"
    Me.ToolStripStatusLabelCaja.Size = New System.Drawing.Size(0, 17)
    '
    'lblCaja
    '
    Me.lblCaja.Name = "lblCaja"
    Me.lblCaja.Size = New System.Drawing.Size(0, 17)
    '
    'Menu
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
    Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
    Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
    Me.ClientSize = New System.Drawing.Size(800, 578)
    Me.Controls.Add(Me.StatusStrip1)
    Me.Controls.Add(Me.ToolStrip1)
    Me.Controls.Add(Me.MenuStrip1)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.IsMdiContainer = True
    Me.MainMenuStrip = Me.MenuStrip1
    Me.Name = "Menu"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Men� Principal"
    Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
    Me.MenuStrip1.ResumeLayout(False)
    Me.MenuStrip1.PerformLayout()
    Me.ToolStrip1.ResumeLayout(False)
    Me.ToolStrip1.PerformLayout()
    Me.StatusStrip1.ResumeLayout(False)
    Me.StatusStrip1.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents CitasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents TlSStUsuario As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripProgressBar1 As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents AgendaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ArchivoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PacientesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmpleadosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InformesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CuentasCobrarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TiemposToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DivisionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AyudaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AcercaDeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResultadosExamToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PagosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EpsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExamenesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TarifasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripButtonCambiarUsuario As System.Windows.Forms.ToolStripButton
    Friend WithEvents DescuentosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IndiceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblVersion As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents CrearCopiaDeSeguridadDeLaBaseDeDatosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResultadosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TurnosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaisesYDepartamentosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DepartamentosYCiudadesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CajasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UsuariosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GruposYAcesosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegistroSalidaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DatosFacturacionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents rptFacturacionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IndicadorDeOportunidadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CitasPacienteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DatosPrestadoresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProcedimientosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SedesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CANCELACI�ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RutaConfigToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CajasToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabelCaja As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblCaja As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Liquidaci�nToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TiposToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MotivosConsultaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FrecuenciaMedicamentosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProtocolosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LaboratoriosFarmac�uticosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SintomasSignosLaboratoriosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OcupacionesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MedicamentosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrincipiosActivosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ItemRevisi�nToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FinancierosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ServiciosPrestadosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Anulaci�nDeFacturasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ParaPacientesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ParaEPSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NormalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnuladasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NormaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnuladaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NormalToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AnuladaToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Importai�nFacturasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PorcesosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Generaraci�nDeFacturasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FacturasToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopagosToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItemTarifaBase As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents IPSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents miRIPS As System.Windows.Forms.ToolStripMenuItem
End Class
